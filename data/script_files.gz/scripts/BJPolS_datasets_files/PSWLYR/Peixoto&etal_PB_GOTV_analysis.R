rm(list = ls())
options(scipen=99)

#--------------------------------------------------#
# Replication Script for the paper:
# 'A Get Out The Vote (GOTV) Experiment on the World’s 
# Largest Participatory Budgeting Vote in Brazil' (2017)
# Tiago Peixoto, World Bank
# Fredrik M Sjoberg, World Bank
# Jonathan Mellon, World Bank & Oxford University
#--------------------------------------------------#

#Packages
library(ggplot2)
library(dplyr)
library(pander)
library(matrixStats)
#devtools::install_github("jon-mellon/mellonMisc")
library(mellonMisc)

#Load data
setwd("/Users/fsjoberg/Dropbox/WDR_2014_Papers/PB GOTV1/r/replication/")
load("Peixoto&etal_2017.RData")

#--------------------------------------------------#
#Table 1. Treatment Effects on Turnout – Main Model and Comparisons Across Different Treatment Subsets.
#--------------------------------------------------#

turnout.total <- rbind(
  summary(lm(voted ~ pooled.treat, data = vpr.turnout))$coefficients[2, ],
  summary(lm(voted ~ wb_treatment_vpr, data = vpr.turnout))$coefficients[2:4, ],
  summary(lm(voted ~ wb_treatment_vpr, data = vpr.turnout[vpr.turnout$wb_treatment_vpr %in% c(1,2), ]))$coefficients[2, ],
  summary(lm(voted ~ wb_treatment_vpr,data = vpr.turnout[vpr.turnout$wb_treatment_vpr %in% c(2, 3), ]))$coefficients[2, ],
  summary(lm(voted ~ wb_treatment_vpr,data = vpr.turnout[which(vpr.turnout$wb_treatment_vpr %in% c(1, 3)), ]))$coefficients[2, ])
turnout.total <- data.frame(turnout.total)
fit.n <- rbind(
  nobs(lm(voted ~ pooled.treat, data = vpr.turnout)),
  as.data.frame(rep(nobs(lm(voted ~ wb_treatment_vpr, data = vpr.turnout)),3)),
  nobs(lm(voted ~ wb_treatment_vpr, data = vpr.turnout[vpr.turnout$wb_treatment_vpr %in% c(1,2),])),
  nobs(lm(voted ~ wb_treatment_vpr,data = vpr.turnout[vpr.turnout$wb_treatment_vpr %in% c(2, 3),])),
  nobs(lm(voted ~ wb_treatment_vpr,data = vpr.turnout[which(vpr.turnout$wb_treatment_vpr %in% c(1,3)),])))
turnout.total <- cbind(fit.n,turnout.total)
turnout.total$comparison <- c("Pooled","Info", "Public", "Private", 
                              "Info v Public", "Public v Private",
                              "Info v Private")
options(scipen=99)
turnout.total$adjusted.p <- p.adjust(turnout.total$Pr...t.., method="fdr")
turnout.total.rounded <- turnout.total
for (i in c(2:5,7)) {
	turnout.total.rounded[,i] <- round(turnout.total.rounded[,i],3)
}
names(turnout.total.rounded) <- c("N","Estimate","Std.Error","T-value",
                                  "Unadjusted p-value","Comparison","FDR adjusted p-value")
pander(turnout.total.rounded)


#--------------------------------------------------#
#Figure 2. Online turnout in control, pooled treatment group, and the three treatments separately: informational, public benefit, and private benefit. 95% Confidence Intervals are displayed.
#--------------------------------------------------#

total <- aggregate(vpr.turnout$voted, list(vpr.turnout$wb_treatment_vpr), 
									 function(x) mean_se(x, 1.96) * 100)
total <- total[, 2]
total <- apply(total, 2, unlist)
total <- as.data.frame(total)
total$Group <- factor(c("Control", "Informational", "Public Benefit", "Private Benefit"), 
											c("Control", "Informational", "Public Benefit", "Private Benefit"))
total.pool <- aggregate(vpr.turnout$voted, list(vpr.turnout$pooled.treat), 
												function(x) mean_se(x, 1.96) * 100)
total.pool <- total.pool[, 2]
total.pool <- apply(total.pool, 2, unlist)
total.pool <- as.data.frame(total.pool)
total.pool$Group <- factor(c("Control", "Pooled\n Treatment"), 
													 c("Control", "Pooled\n Treatment"))
total <- rbind(total, 
							 total.pool[2, ])
total$Group <- factor(total$Group, 
											c("Control", "Pooled\n Treatment", 
												"Informational", "Public Benefit", "Private Benefit"))
email.exp <- 
	ggplot(total, aes(x = Group, y = y)) + 
	geom_hline(aes(yintercept = 5), colour = "gray") +
	geom_hline(aes(yintercept = 10), colour = "gray") +
	geom_hline(aes(yintercept = 15), colour = "gray") + 
	geom_hline(aes(yintercept = 20), colour = "gray") + 
	geom_hline(aes(yintercept = 25), colour = "gray") + 
	geom_hline(aes(yintercept = 30), colour = "gray") + 
	geom_bar(stat = "identity", aes(), fill = c("gray","#6699FF", "#ADD8E6",
																							"#ADD8E6","#ADD8E6"), colour = "black") +
	geom_errorbar(aes(ymin=ymin, ymax = ymax), size=1, width = 0.15)  + 
	theme(panel.background = element_blank()) + 
	theme(panel.grid.major = element_blank()) + 
	theme(panel.grid.minor = element_blank()) + 
	theme(panel.background = element_rect(colour = "black")) + 
	ylab("Percentage who voted") + 
	geom_hline(aes(yintercept = 0), size=1) + 
	theme(axis.text.x = element_text(colour = "black"))+  
	theme(text = element_text(colour = "black", size = 16)) + 
	geom_text(aes(label = round(y, 1)), 
						size = 5, hjust = 0.5, 
						vjust = 3, 
						position = "stack")
email.exp


#--------------------------------------------------#
#Table 2. Treatment Effects on Cost 
#--------------------------------------------------#

cost.comparisons <- rbind(
  summary(lm(formula = costs.norm ~ pooled.treat + factor(corede_id), 
             data = vpr[ vpr$corede_id != 6, ]))$coefficients[2, ],
  summary(lm(formula = costs.norm ~ factor(wb_treatment_vpr) + factor(corede_id), 
             data = vpr[ vpr$corede_id != 6, ]))$coefficients[2:4, ],
  summary(lm(formula = costs.norm ~ factor(wb_treatment_vpr) + factor(corede_id), 
             data = vpr[ vpr$corede_id != 6 & vpr$wb_treatment_vpr %in% 1:2, ]))$coefficients[2, ],
  summary(lm(formula = costs.norm ~ factor(wb_treatment_vpr) + factor(corede_id), 
             data = vpr[ vpr$corede_id != 6 & vpr$wb_treatment_vpr %in% 2:3, ]))$coefficients[2, ],
  summary(lm(formula = costs.norm ~ factor(wb_treatment_vpr) + factor(corede_id), 
             data = vpr[ vpr$corede_id != 6 & vpr$wb_treatment_vpr %in% 1:3, ]))$coefficients[2, ])
cost.comparisons <- data.frame(cost.comparisons)
cost.comparisons$comparison <- c("pooled.treat", "info", "public", "private",
                                 "info v public", "public v private", 
                                 "info v private")
cost.comparisons$adjusted.p <- p.adjust(cost.comparisons$Pr...t.., method="fdr")
cost.comparisons.rounded <- cost.comparisons
for (i in c(1:3,4,6)) {
  cost.comparisons.rounded[,i] <- round(cost.comparisons.rounded[,i],3)
}
names(cost.comparisons.rounded) <- c("Estimate","Std.Error","T-value",
                                     "Unadjusted p-value","Comparison","FDR adjusted p-value")
pander(cost.comparisons.rounded)


#--------------------------------------------------#
#Table 3. Treatment Effects on Vote Choice – Main Model and Comparisons Across Different Treatment Subsets. The average proportion of voters choosing the top three sectoral categories: health, infrastructure or security, and an ‘other’ category combining all other categories. 
#--------------------------------------------------#

#Pooled issue effects (second ballot section)
pooled.effects <- rbind(summary(lm(formula = voted.health ~ pooled.treat + factor(corede_id), 
                                   data = vpr))$coefficients[2, ], 
                        summary(lm(formula = voted.infrastructure ~ pooled.treat + factor(corede_id), 
                                   data = vpr))$coefficients[2, ],
                        summary(lm(formula = voted.sec ~ pooled.treat + factor(corede_id), 
                                   data = vpr))$coefficients[2, ],
                        summary(lm(formula = voted.oth ~ pooled.treat + factor(corede_id), 
                                   data = vpr))$coefficients[2, ])
pooled.effects <- data.frame(pooled.effects)
pooled.effects$issue <- c("Health", "Infrastructure", "Security", "Other")
pooled.effects$treatment <- "Pooled"
fit.n <- rbind(nobs(lm(formula = voted.health ~ pooled.treat + factor(corede_id), 
                       data = vpr)), 
               nobs(lm(formula = voted.infrastructure ~ pooled.treat + factor(corede_id), 
                       data = vpr)),
               nobs(lm(formula = voted.sec ~ pooled.treat + factor(corede_id), 
                       data = vpr)),
               nobs(lm(formula = voted.oth ~ pooled.treat + factor(corede_id), 
                       data = vpr)))
pooled.effects <- cbind(fit.n,pooled.effects)

#Separated issue effects (second ballot section)
single.effects <- rbind(summary(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                   data = vpr))$coefficients[2:4, ],
                        summary(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                   data = vpr))$coefficients[2:4, ],
                        summary(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                   data = vpr))$coefficients[2:4, ],
                        summary(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                   data = vpr))$coefficients[2:4, ])
single.effects <- data.frame(single.effects)
single.effects$issue <- inverse.rle(list(values = c("Health", "Infrastructure", 
                                                    "Security", "Other"),
                                         lengths = c(3,3,3,3)))
single.effects$treatment <- rep(c("Info", "Public", "Private"), 4)
fit.n <- rbind(nobs(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id),
                       data = vpr)),
               as.data.frame(rep(nobs(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                         data = vpr)),3)),
               as.data.frame(rep(nobs(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                         data = vpr)),3)),
               as.data.frame(rep(nobs(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                         data = vpr)),3)))
single.effects <- cbind(fit.n,single.effects)

# combining all the issue area treatments into a single data frame
treatment.comparisons <- rbind(summary(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:2, ]))$coefficients[2, ],
                               summary(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:2, ]))$coefficients[2, ],
                               summary(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:2, ]))$coefficients[2, ],
                               summary(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:2, ]))$coefficients[2, ],
                               
                               summary(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id),
                                          data = vpr[vpr$wb_treatment_vpr %in% 2:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 2:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 2:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 2:3, ]))$coefficients[2, ],
                               
                               summary(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id),
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:3, ]))$coefficients[2, ],
                               summary(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                                          data = vpr[vpr$wb_treatment_vpr %in% 1:3, ]))$coefficients[2, ])
treatment.comparisons <- data.frame(treatment.comparisons)
treatment.comparisons$treatment <- inverse.rle(list(values = c("Info vs. Public", "Public vs. Private", "Info vs. Private"),
                                                    lengths = c(4,4,4)))
fit.n <- rbind(nobs(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:2, ])),
               nobs(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:2, ])),
               nobs(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:2, ])),
               nobs(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:2, ])),
               
               nobs(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id),
                       data = vpr[vpr$wb_treatment_vpr %in% 2:3, ])),
               nobs(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 2:3, ])),
               nobs(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 2:3, ])),
               nobs(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 2:3, ])),
               
               nobs(lm(formula = voted.health ~ factor(wb_treatment_vpr) + factor(corede_id),
                       data = vpr[vpr$wb_treatment_vpr %in% 1:3, ])),
               nobs(lm(formula = voted.infrastructure ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:3, ])),
               nobs(lm(formula = voted.sec ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:3, ])),
               nobs(lm(formula = voted.oth ~ factor(wb_treatment_vpr) + factor(corede_id), 
                       data = vpr[vpr$wb_treatment_vpr %in% 1:3, ])))
treatment.comparisons <- cbind(fit.n,treatment.comparisons)
treatment.comparisons$issue <- rep(c("Health", "Infrastructure", "Security", "Other"), 3)
all.treatment.comparisons  <- rbind(pooled.effects, 
                                    single.effects, 
                                    treatment.comparisons)
all.treatment.comparisons$adjusted.p <- p.adjust(all.treatment.comparisons$Pr...t.., method="fdr")
all.treatment.comparisons.rounded <- all.treatment.comparisons
for (i in c(1:5,8)) {
  all.treatment.comparisons.rounded[,i] <- round(all.treatment.comparisons.rounded[,i],3)
}
names(all.treatment.comparisons.rounded) <- c("N","Estimate","Std.Error","T-value",
                                              "Unadjusted p-value","Issue Area","Treatment",
                                              "FDR adjusted p-value")
pander(all.treatment.comparisons.rounded)


#--------------------------------------------------#
#Table 4. Estimated differences in sectoral preference between regular and encouraged voters and difference in chosen cost. Confidence intervals estimated using bootstrapping.
#--------------------------------------------------#

#Creating the dummy variables for each of the three areas and other
vpr$voted.health <- sapply(themes, function(x) 4 %in% x)
vpr$voted.sec <- sapply(themes, function(x) 5 %in% x)
vpr$voted.infrastructure <- sapply(themes, function(x) 13 %in% x)
vpr$voted.oth <- sapply(themes, function(x) any(c(4,5,13) %in% x))

turnout.treat <- lm(voted ~ pooled.treat, data = vpr.turnout)
calcEncourage <- function(c1,c0,t1,t0) {
  encouraged <- ((c1 * t1) - (c0 * t0)) / (t1 - t0)
  encouraged - c0
}
pooled.cost <- tapply(vpr$costs.norm, vpr$pooled.treat, mean, na.rm = T)

pooled.infra <- prop.table(table(pooled = vpr$pooled.treat, 
                                 infra = vpr$voted.infrastructure), 1)
pooled.health <- prop.table(table(pooled = vpr$pooled.treat, 
                                  infra = vpr$voted.health), 1)
pooled.sec <- prop.table(table(pooled = vpr$pooled.treat, 
                               infra = vpr$voted.sec), 1)
pooled.oth <- prop.table(table(pooled = vpr$pooled.treat, 
                               infra = vpr$voted.oth), 1)

pooled.turnout <- prop.table(table(pooled = vpr.turnout$pooled.treat, 
                                   turnout = vpr.turnout$voted), 1)
colnames(pooled.turnout) <- c("DNV", "Voted")
rownames(pooled.turnout) <- c("control", "treatment")
colnames(pooled.infra) <- c("not_chosen", "chosen")
rownames(pooled.infra) <- c("control", "treatment")
colnames(pooled.health) <- c("not_chosen", "chosen")
rownames(pooled.health) <- c("control", "treatment")
colnames(pooled.sec) <- c("not_chosen", "chosen")
rownames(pooled.sec) <- c("control", "treatment")
colnames(pooled.oth) <- c("not_chosen", "chosen")
rownames(pooled.oth) <- c("control", "treatment")

t0 <- pooled.turnout["control", "Voted"]
t1 <- pooled.turnout["treatment", "Voted"]
c0 <- pooled.infra["control", "chosen"]
c1 <- pooled.infra["treatment", "chosen"]

point.estimates <- c(infra = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                           t1 = pooled.turnout["treatment", "Voted"],
                                           c0 = pooled.infra["control", "chosen"],
                                           c1 = pooled.infra["treatment", "chosen"]),
                     health = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                            t1 = pooled.turnout["treatment", "Voted"],
                                            c0 = pooled.health["control", "chosen"],
                                            c1 = pooled.health["treatment", "chosen"]),
                     sec = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                         t1 = pooled.turnout["treatment", "Voted"],
                                         c0 = pooled.sec["control", "chosen"],
                                         c1 = pooled.sec["treatment", "chosen"]),
                     oth = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                         t1 = pooled.turnout["treatment", "Voted"],
                                         c0 = pooled.oth["control", "chosen"],
                                         c1 = pooled.oth["treatment", "chosen"]),
                     cost = calcEncourage(c1 = pooled.cost["TRUE"], c0 = pooled.cost["FALSE"],
                                          t0 = pooled.turnout["control", "Voted"],
                                          t1 = pooled.turnout["treatment", "Voted"]))

set.seed(0987654)
oneBoot <- function(vpr, bootstrap = T) {
  # Using empirical bootstrap method described here:
  # https://ocw.mit.edu/courses/mathematics/18-05-introduction-to-probability-and-statistics-spring-2014/readings/MIT18_05S14_Reading24.pdf
  if(bootstrap) {
    vpr <- vpr[sample(1:nrow(vpr), nrow(vpr), replace = T), ]
  }
  
  pooled.infra <- prop.table(table(pooled = vpr$pooled.treat, 
                                   infra = vpr$voted.infrastructure), 1)
  pooled.health <- prop.table(table(pooled = vpr$pooled.treat, 
                                    infra = vpr$voted.health), 1)
  pooled.sec <- prop.table(table(pooled = vpr$pooled.treat, 
                                 infra = vpr$voted.sec), 1)
  pooled.oth <- prop.table(table(pooled = vpr$pooled.treat, 
                                 infra = vpr$voted.oth), 1)
  pooled.cost <- tapply(vpr$costs.norm, vpr$pooled.treat, mean, na.rm = T)
  
  pooled.turnout <- prop.table(table(pooled = vpr.turnout$pooled.treat, 
                                     turnout = vpr.turnout$voted), 1)
  colnames(pooled.turnout) <- c("DNV", "Voted")
  rownames(pooled.turnout) <- c("control", "treatment")
  colnames(pooled.infra) <- c("not_chosen", "chosen")
  rownames(pooled.infra) <- c("control", "treatment")
  colnames(pooled.health) <- c("not_chosen", "chosen")
  rownames(pooled.health) <- c("control", "treatment")
  colnames(pooled.sec) <- c("not_chosen", "chosen")
  rownames(pooled.sec) <- c("control", "treatment")
  colnames(pooled.oth) <- c("not_chosen", "chosen")
  rownames(pooled.oth) <- c("control", "treatment")
  
  t0 <- pooled.turnout["control", "Voted"]
  t1 <- pooled.turnout["treatment", "Voted"]
  c0 <- pooled.infra["control", "chosen"]
  c1 <- pooled.infra["treatment", "chosen"]
  
  output <- c(infra = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                    t1 = pooled.turnout["treatment", "Voted"],
                                    c0 = pooled.infra["control", "chosen"],
                                    c1 = pooled.infra["treatment", "chosen"]),
              health = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                     t1 = pooled.turnout["treatment", "Voted"],
                                     c0 = pooled.health["control", "chosen"],
                                     c1 = pooled.health["treatment", "chosen"]),
              sec = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                  t1 = pooled.turnout["treatment", "Voted"],
                                  c0 = pooled.sec["control", "chosen"],
                                  c1 = pooled.sec["treatment", "chosen"]),
              oth = calcEncourage(t0 = pooled.turnout["control", "Voted"],
                                  t1 = pooled.turnout["treatment", "Voted"],
                                  c0 = pooled.oth["control", "chosen"],
                                  c1 = pooled.oth["treatment", "chosen"]),
              cost = calcEncourage(c1 = pooled.cost["TRUE"], c0 = pooled.cost["FALSE"],
                                   t0 = pooled.turnout["control", "Voted"],
                                   t1 = pooled.turnout["treatment", "Voted"]))
  
  return(point.estimates- output)
}

boots <- as.list(rep(NA, 1000))
for(ii in 1:length(boots)) {
  print(ii)
  boots[[ii]] <- oneBoot(vpr)
}

boots <- do.call(rbind, boots)
boots <- dtf(boots)

#95% CIs
output <- rbind(point.estimates["infra"] + quantile(boots$infra, c(0.025, 0.975)),
                point.estimates["sec"] + quantile(boots$sec, c(0.025, 0.975)),
                point.estimates["oth"] + quantile(boots$oth, c(0.025, 0.975)),
                point.estimates["health"] + quantile(boots$health, c(0.025, 0.975)),
                point.estimates["cost.TRUE"] + quantile(boots$cost.TRUE, c(0.025, 0.975)))

output <- dtf(output)
colnames(output) <- c("Lower CI", "Upper CI")
output <- dtf(Issue = names(point.estimates), Estimate = point.estimates, output)
output$Issue[output$Issue=="infra"] <- "Infrastructure"
output$Issue[output$Issue=="health"] <- "Health"
output$Issue[output$Issue=="sec"] <- "Security"
output$Issue[output$Issue=="oth"] <- "Other"
output$Issue[output$Issue=="cost.TRUE"] <- "Cost"
rownames(output) <- NULL
pander(output)


#--------------------------------------------------#
#Fig. 4. (Appendix) Power Against A Null Of Zero Effect Given A Significance Level Of .05.
#--------------------------------------------------#

pooled.turnout <- table(pooled = vpr.turnout$pooled.treat, 
                        turnout = vpr.turnout$voted)
colnames(pooled.turnout) <- c("DNV", "Voted")
rownames(pooled.turnout) <- c("control", "treatment")
extra.voters <- pooled.turnout["treatment", "Voted"] - (pooled.turnout["control", "Voted"] * 3)

powerRun <- function(effect.size) {
  treatment <- c(rbinom(prob = 0.5, n = (pooled.turnout["control", "Voted"] * 3), size = 1), 
                 rbinom(prob = 0.5 + effect.size, n = extra.voters, size = 1))
  control <- rbinom(prob = 0.5, n = pooled.turnout["control", "Voted"], size = 1)
  
  df.sim <- dtf(issue = c(treatment, control), 
                group = c(rep("treat", length(treatment)),
                          rep("control", length(control))))
  
  mod.sim <- lm(data = df.sim, issue~group)
  mod.sim <- summary(mod.sim)
  return(mod.sim$coefficients["grouptreat", "Pr(>|t|)"])
}

calcPower <- function(effect.size, n = 1000, sig.level = 0.05) {
  power <- rep(NA, n)  
  for(ii in 1:length(power)) {
    if((ii / 10)==ii) {
      print(ii)
    }
    power[ii] <- powerRun(effect.size = effect.size)
  }
  
  return(prop.table(table(power<sig.level))["TRUE"])
}
powers <- seq(0.01, 0.3, 0.01)
power.levels <- sapply(powers, calcPower)

save(power.levels, file = "power_level.rda")

power.size <- dtf(power = power.levels, effect.size = powers)

ggplot(power.size, aes(x = effect.size * 100, y = power)) + 
  geom_point() + theme_bw() + geom_line() + 
  xlab("Effect size") + ylab("Power") + 
  scale_y_continuous(breaks = seq(0,1,0.1)) + 
  scale_x_continuous(breaks = seq(0,30,5))