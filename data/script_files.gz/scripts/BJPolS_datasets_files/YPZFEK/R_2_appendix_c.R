# R script for for replicating supplementary analysis in appendix C
# in 'When Parties Move to the Middle: The Role of Uncertainty'
# by J. Lindvall, D. Rueda, and H. Zhai
# this file written by: H Zhai (2022-11-03 [updated: -])
# on device: Mac Pro 13 Dual-Core Intel Core i5 2.3 GHz 

# PLEASE MAKE SURE ALL THE REPLICATION FILES (DATA AND SCRIPTS) ARE STORED AT THE SAME LEVEL IN THE SAME DIRECTORY
# OR MAKE SURE THE DIRECTORY-RELATED CODES ARE PROPERLY ADJUSTED 
# TO ENSURE THE CODES RUN WITHOUT DIRECTORY-RELATED PROBLEMS
# RESTART R SESSION BEFORE RUNNING

# This file replicates results from supplementary analysis reported in analysis section C
# In the order they appear in text

# BEGIN SCRIPT
rm(list = ls())

# pkgs --------------------------------------------------------------------

if (!require("tidyverse")) install.packages("tidyverse")
if (!require("magrittr")) install.packages("magrittr")
if (!require("broom")) install.packages("broom")
if (!require("knitr")) install.packages("knitr")

# load data ---------------------------------------------------------------

load("RData_manifesto_mlr.RData") 
load("RData_measure_scale.RData") 
load("RData_measure_voter.RData")

# clean data --------------------------------------------------------------

manifesto_mlr_leftright <- manifesto_mlr %>% 
  cbind.data.frame(leftright) # w/o log measures

measure_cparty <- manifesto_mlr_leftright %>% 
  group_by(country, countryname, eyear, edate) %>% 
  summarise(leftright_ml = unique(leftright[party_mlr=="main left"]),
            leftright_mr = unique(leftright[party_mlr=="main right"])) %>% 
  ungroup() %>% 
  left_join(manifesto_mlr_leftright %>% select(country, countryname, eyear, edate, leftright, pervote)) %>% 
  filter(leftright > leftright_ml & leftright < leftright_mr) %>% 
  select(-ends_with("ml"), -ends_with("mr")) %>% 
  group_by(country, countryname, eyear, edate) %>% 
  summarise(pervote_c = sum(pervote, na.rm = TRUE)) %>% 
  ungroup()

measure_cparty_mvoter <- measure_cparty %>% 
  left_join(measure_voter %>% select(country, countryname, eyear, edate, leftright_med, leftright_den_rlog)) %>% 
  mutate(eyear = as.integer(eyear))

# subset data -------------------------------------------------------------

IDs.ind <- c("Austria", "Belgium", "Canada", "Denmark", "Finland", 
             "France", "Germany", "Iceland", "Italy", "Luxembourg", 
             "Netherlands", "New Zealand", "Norway", "Portugal", "Spain", 
             "Sweden", "Switzerland", "United Kingdom", "United States", "Australia")

measure_cparty_mvoter1 <- measure_cparty_mvoter %>% 
  filter(countryname %in% IDs.ind & eyear>=1965)

measure_voter1 <- measure_voter %>% 
  filter(countryname %in% IDs.ind & eyear>=1965)

# tally cases -------------------------------------------------------------

n.cparty <- 
  list(measure_voter1, measure_cparty_mvoter1) %>% 
  map(~select(.x, any_of(c("countryname", "edate", "pervote_c")))) %$% 
  full_join(.[[1]], .[[2]]) %>% 
  group_by(countryname) %>% 
  summarise(n_c = sum(!is.na(pervote_c)), n = n()) %>% 
  ungroup() %>% 
  arrange(countryname)

# Figure 6 ----------------------------------------------------------------

ggplot(n.cparty) +
  geom_col(aes(x = countryname, y = n), fill = "grey60") +
  geom_col(aes(x = countryname, y = n_c), fill = "grey20") +
  theme_minimal(base_size = 12) +
  coord_flip() +
  scale_x_discrete(limits = rev) +
  labs(x = "", y = "#Elections", 
       title = "National elections with and without centrist parties", 
       subtitle = "Rich democracies, 1965-2018") +
  theme(plot.title = element_text(size = 14),
        plot.subtitle = element_text(size = 13)) 

# Table 3 -----------------------------------------------------------------

measure_cparty_mvoter1 %$% 
  cor.test(.$pervote_c, .$leftright_den_rlog) # cor=0.029, t=0.431, p=0.667
measure_cparty_mvoter1 %>% 
  select(countryname, pervote_c, leftright_den_rlog) %>% 
  nest(data = -countryname) %>% 
  mutate(corr = map(data, ~cor.test(.x$pervote_c, .x$leftright_den_rlog))) %>% 
  mutate(corr = map(corr, tidy)) %>% 
  unnest(cols = corr) %>% 
  ungroup() %>% 
  select(-data) %>% 
  arrange(countryname) %>% 
  mutate(across(where(is.numeric), ~round(.x, 3))) %>% 
  mutate(ci = paste0("[", conf.low, ", ", conf.high, "]")) %>% 
  select(Country = countryname, "Pearson's rho" = estimate, "p-value" = `p.value`, "95% CI" = ci) %>% 
  knitr::kable(format = "latex", caption = "Correlation between median voter certainty and centrist party by country", booktabs = TRUE)

# clear env. --------------------------------------------------------------

rm(list = ls())

# END SCRIPT