#############################
#Syntax to create Figure OA3
#############################

#####Packages
library(rio)
library(tidyverse)
library(meta)

#####Data

meta_df <- import("meta_explanations.xlsx")

meta_all <- meta_df %>%
  filter(subgroup == "All")

m.raw <- metacont(tr_n, 
                  tr_mean, 
                  tr_sd, 
                  c_n, 
                  c_mean, 
                  c_sd, 
                  data = meta_all, 
                  studlab = paste(study), 
                  comb.fixed=T, 
                  prediction = T, 
                  sm = "SMD" )

png(file= 'figure_oa3.png', width=720, height=480)
forest_all <- forest(m.raw, digits=2, digits.sd = 2, 
       layout = "JAMA")
dev.off()


