############################################
#   Code to create Figure OC4
#   MLOGIT Interactions: Therm Diff (Exp 2)
############################################
library(tidyverse)
library(rio)
library(ggstance)


######
worse <- import("inter_probs_1.dta") %>%
  rename(treat = `_deriv`, 
         cop = `_at2`, 
         estimate = `_margin`, 
         lower = `_ci_lb`, 
         upper = `_ci_ub`) %>%
  mutate(outcome = "Worse")

same <- import("inter_probs_2.dta") %>%
  rename(treat = `_deriv`, 
         cop = `_at2`, 
         estimate = `_margin`, 
         lower = `_ci_lb`, 
         upper = `_ci_ub`) %>%
  mutate(outcome = "Same")

better <- import("inter_probs_3.dta") %>%
  rename(treat = `_deriv`, 
         cop = `_at2`, 
         estimate = `_margin`, 
         lower = `_ci_lb`, 
         upper = `_ci_ub`) %>%
  mutate(outcome = "Better")

comb <- bind_rows(worse, same, better) %>%
  mutate(treat = factor(treat, 
                        levels=c(1,3,4), 
                        labels=c("No Justification", "High Credibility", 
                                 "Low Credibility")), 
         cop = factor(cop, 
                      levels=c(1,2), 
                      labels=c("Copartisan", 
                               "Opposing Partisan")))


comb %>%
  ggplot(aes(y=treat, x=estimate, shape=cop)) + 
  geom_pointrangeh(aes(xmin=lower, xmax=upper), position=position_dodge2v(height=0.2)) + 
  facet_wrap(outcome~.) + 
  geom_vline(xintercept=0, linetype="dashed", color="red") + 
  labs(shape = "Co-Partisan", 
       title = "Difference from Justification Condition in Response Probability", 
       y = NULL, 
       x = "Estimate") + 
  theme_light() + 
  theme(strip.text.x = element_text(face="bold", color="black"))

ggsave("figure_oc4.png", 
       height=8, width=14)
