############################################
#   Code to create Figure 3 & 4
############################################

##################
#Packages
##################
library(cowplot)
library(ggpubr)
library(car)
library(socviz)
library(scales)
library(broom)
library(margins)
library(rio)
library(tidyverse)
library(ggstance)

##################
#Experiment 1
##################


####Load & Clean Data
exp1 <- import("exp1_cleaned.dta") %>%
  mutate(cond_info = factor(cond_info, 
                            levels=c(3,1,2,4,5,6), 
                            labels=c("Justification", "Pure Baseline", 
                                     "No Justification", "Just. w/Teachers", 
                                     "Just. w/Non-Partisan", "Just. w/Partisan")), 
         cond_party1 = factor(cond_party1, 
                             levels=c(1,2,3), 
                             labels=c("Co-Partisan", "Opposing Partisan", "Independent")))

#Model
m1 <- lm(therm01 ~ cond_info*cond_party1, data=exp1)

#Margins
m1_margs <- summary(margins(m1, 
                            variables="cond_info", 
                            at = list(cond_party1=c("Co-Partisan", "Opposing Partisan")))) %>%
  filter(factor != "cond_infoPure Baseline") %>%
  mutate(factor = prefix_strip(factor, "cond_info"), 
         experiment = "Experiment 1", 
         testtype = "AME") %>%
  as.data.frame()

###Bringing in lincom results from Stata

##Within: Co-Partisans
exp1_co_teachers <- import("exp1_co_teachers.dta") %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Within Partisan Diff", 
         cond_party1 = "Co-Partisan", 
         factor = "Teachers-Partisan") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

exp1_co_np <- import("exp1_co_np.dta") %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Within Partisan Diff", 
         cond_party1 = "Co-Partisan", 
         factor = "Non-Partisan-Partisan") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

##Within: Opposing-Partisans
exp1_op_teachers <- import("exp1_op_teachers.dta") %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Within Partisan Diff", 
         cond_party1 = "Opposing Partisan", 
         factor = "Teachers-Partisan") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

exp1_op_np <- import("exp1_op_np.dta") %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Within Partisan Diff", 
         cond_party1 = "Opposing Partisan", 
         factor = "Non-Partisan-Partisan") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)


#Between Partisan
exp1_btwn_teach <- import("exp1_mat_teacher.dta") %>%
  rename(AME = exp1_mat_teacher1, 
         SE = exp1_mat_teacher2, 
         z = exp1_mat_teacher3, 
         p = exp1_mat_teacher4, 
         lower = exp1_mat_teacher5, 
         upper = exp1_mat_teacher6) %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Between Partisan Diff", 
         cond_party1 = "Diff in Diff", 
         factor = "Teachers-Partisan") %>%
  select(-param, -varlab)


exp1_btwn_np <- import("exp1_mat_np.dta") %>%
  rename(AME = exp1_mat_np1, 
         SE = exp1_mat_np2, 
         z = exp1_mat_np3, 
         p = exp1_mat_np4, 
         lower = exp1_mat_np5, 
         upper = exp1_mat_np6) %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Between Partisan Diff", 
         cond_party1 = "Diff in Diff", 
         factor = "Non-Partisan-Partisan") %>%
  select(-param, -varlab)
         
##Bind
exp1_comb <- bind_rows(m1_margs, 
                       exp1_co_teachers, exp1_co_np, 
                       exp1_op_np, exp1_op_teachers ,
                       exp1_btwn_teach, exp1_btwn_np)
       
export(exp1_comb, "figure3_exp1.csv")
export(exp1_comb, "figure3_exp1.Rda")

##################
#Experiment 2
##################

####Load and Clean Data
exp2 <- import("exp2_cleaned.dta") %>%
  mutate(treat_expl = factor(treat_expl, 
                             levels=c(2,1,3,4), 
                             labels=c("Justification", "No Justification", 
                                      "Just w/High Credibility", 
                                      "Just w/Low Credibility")),
         copartisan = factor(copartisan, 
                             levels=c(1,2,3), 
                             labels=c("Co-Partisan", "Opposing Partisan", 
                                      "Independent")))

#Model
m2 <- lm(therm_post01 ~ therm_pre01 + treat_expl*copartisan, data=exp2)
             
#Margins
m2_margs <- summary(margins(m2, 
                            variables="treat_expl", 
                            at = list(copartisan=c("Co-Partisan", "Opposing Partisan")))) %>%
  mutate(factor = prefix_strip(factor, "treat_expl"), 
         experiment = "Experiment 2", 
         testtype = "AME") %>%
  as.data.frame()

###########Lincom Results

#####Within: Co-Partisan
exp2_co_hc <- import("exp2_co_hc.dta") %>%
  mutate(experiment = "Experiment 2", 
         testtype = "Within Partisan Diff", 
         copartisan = "Co-Partisan", 
         factor = "HC - LC") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

#####Within: Opposing
exp2_op_hc <- import("exp2_op_hc.dta") %>%
  mutate(experiment = "Experiment 2", 
         testtype = "Within Partisan Diff", 
         copartisan = "Opposing Partisan", 
         factor = "HC - LC") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

#####Between
exp2_btwn <- import("exp2_mat_hc.dta") %>%
  rename(AME = exp2_mat_hc1, 
         SE = exp2_mat_hc2, 
         z = exp2_mat_hc3, 
         p = exp2_mat_hc4, 
         lower = exp2_mat_hc5, 
         upper = exp2_mat_hc6) %>%
  mutate(experiment = "Experiment 2", 
         testtype = "Between Partisan Diff", 
         copartisan = "Diff in Diff", 
         factor = "HC - LC") %>%
  select(-param, -varlab)
  
#####Bind
exp2_comb <- bind_rows(m2_margs, exp2_co_hc, exp2_op_hc, exp2_btwn)

export(exp2_comb, "figure3_exp2.csv")
export(exp2_comb, "figure3_exp2.Rda")

##################
#Experiment 3a
##################
exp3a <- import("exp3_cleaned.dta") %>%
  mutate(gil_exp = factor(gil_exp, 
                          levels=c(2,1,3,4), 
                          labels=c("Justification", "No Justification", 
                                   "Just w./LW", 
                                   "Just w./RW")), 
         treat_order = factor(treat_order, 
                              levels=c(0,1), 
                              labels=c("Corker First", "Gillibrand First")), 
         gil_pre = factor(gil_pre, 
                          levels=c(1,2,3), 
                          labels=c("Favorable Prior", "Unfavorable Prior", 
                                   "No Opinion toward Gillibrand")), 
         gil_prox = factor(gil_prox, 
                           levels=c(1,2,3), 
                           labels=c("Gain Proximity", 
                                    "Lose Proximity", "No Prior Issue Attitude")), 
         gil_partisan = factor(gil_partisan, 
                               levels=c(1,2,3), 
                               labels=c("Co-Partisan", "Opposing Partisan", 
                                        "Pure Independent")))

##Model
m3 <- lm(gil_post01 ~ gil_exp*gil_partisan + gil_pre + gil_prox + treat_order, 
              data = exp3a)

##Margins
m3_margs <- summary(margins(m3, 
                            variables="gil_exp", 
                            at=list(gil_partisan=c("Co-Partisan", "Opposing Partisan")))) %>%
  mutate(factor = prefix_strip(factor, "gil_exp"), 
         experiment = "Experiment 3a (Gillibrand)", 
         testtype = "AME") %>%
  as.data.frame()

###########Lincom
#####Within: Co-Partisan
exp3a_cop <- import("exp3_gil_co_hc.dta") %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         testtype = "Within Partisan Diff", 
         gil_partisan = "Co-Partisan", 
         factor = "LW - RW") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

#####Within: Opposing
exp3a_op <- import("exp3_gil_op_hc.dta") %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         testtype = "Within Partisan Diff", 
         gil_partisan = "Opposing Partisan", 
         factor = "LW - RW") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

#####Between
exp3a_btwn <- import("exp3_gil_mat_lwrw.dta") %>%
  rename(AME = exp3_gil_mat_lwrw1, 
         SE = exp3_gil_mat_lwrw2, 
         z = exp3_gil_mat_lwrw3, 
         p = exp3_gil_mat_lwrw4, 
         lower = exp3_gil_mat_lwrw5, 
         upper = exp3_gil_mat_lwrw6) %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         testtype = "Between Partisan Diff", 
         gil_partisan = "Diff in Diff", 
         factor = "LW - RW") %>%
  select(-param, -varlab)

####Bind
exp3a_comb <- bind_rows(m3_margs, exp3a_cop, exp3a_op, exp3a_btwn)

export(exp3a_comb, "fig4_exp3a_results.csv")
export(exp3a_comb, "fig4_exp3a_results.Rda")

##################
#Experiment 3b
##################

exp3b <- import("exp3_cleaned.dta") %>%
  mutate(corker_exp = factor(corker_exp, 
                             levels=c(2,1,3,4), 
                             labels=c("Justification", "No Justification", 
                                      "Just. w/LW", 
                                      "Just. w/RW")), 
         corker_pre = factor(corker_pre, 
                             levels=c(1,2,3), 
                             labels=c("Favorable Prior", "Unfavorable Prior", 
                                      "No Opinion toward Gillibrand")),
         corker_prox = factor(corker_prox, 
                              levels=c(1,2,3), 
                              labels=c("Gain Proximity", 
                                       "Lose Proximity", 
                                       "No Prior Issue Attitude")), 
         corker_partisan = factor(corker_partisan, 
                                  levels=c(1,2,3), 
                                  labels=c("Co-Partisan", "Opposing Partisan", 
                                           "Independent")))

###Model
m4 <- lm(corker_post01 ~ corker_exp*corker_partisan + corker_pre + corker_prox +
                treat_order, data = exp3b)

###Margins
m4_margs <- summary(margins(m4, 
                            variables="corker_exp", 
                            at=list(corker_partisan=c("Co-Partisan", "Opposing Partisan")))) %>%
  mutate(factor = prefix_strip(factor, "corker_exp"), 
         experiment = "Experiment 3b (Corker)", 
         testtype = "AME") %>%
  as.data.frame()

#########Lincom results
#####Within: Co-Partisan
exp3b_cop <- import("exp3_corker_co_hc.dta") %>%
  mutate(experiment = "Experiment 3b (Corker)", 
         testtype = "Within Partisan Diff", 
         corker_partisan = "Co-Partisan", 
         factor = "LW - RW") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)


#####Within: Opposing
exp3b_op <- import("exp3_corker_op_hc.dta") %>%
  mutate(experiment = "Experiment 3b (Corker)", 
         testtype = "Within Partisan Diff", 
         corker_partisan = "Opposing Partisan", 
         factor = "LW - RW") %>%
  rename(AME = estimate, 
         SE = stderr, 
         z = t, 
         lower = min95, 
         upper = max95) %>%
  select(-parm, -label, -dof)

###Between
exp3b_btwn <- import("exp3_corker_mat_lwrw.dta") %>%
  rename(AME = exp3_corker_mat_lwrw1, 
         SE = exp3_corker_mat_lwrw2, 
         z = exp3_corker_mat_lwrw3, 
         p = exp3_corker_mat_lwrw4, 
         lower = exp3_corker_mat_lwrw5, 
         upper = exp3_corker_mat_lwrw6) %>%
  mutate(experiment = "Experiment 3b (Corker)", 
         testtype = "Between Partisan Diff", 
         corker_partisan = "Diff in Diff", 
         factor = "LW - RW") %>%
  select(-param, -varlab)
  
####Bind
exp3b_comb <- bind_rows(m4_margs, exp3b_cop, exp3b_op, exp3b_btwn)

export(exp3b_comb, "fig4_exp3b_results.csv")
export(exp3b_comb, "fig4_exp3b_results.Rda")


##############################################
#     Figure (No Reference)
##############################################

################
#Exp1
################
f1 <- exp1_comb %>%
  mutate(factor = factor(factor, 
                         levels=c("Non-Partisan-Partisan", 
                                  "Teachers-Partisan", 
                                  "Just. w/Partisan", 
                                  "Just. w/Non-Partisan",
                                  "Just. w/Teachers", 
                                  "No Justification")) , 
         testtype = factor(testtype, 
                           levels=c("AME", 
                                    "Within Partisan Diff",
                                    "Between Partisan Diff"), 
                           labels=c("Difference from Justification Condition", 
                                    "Within Partisan Difference: Counter-Explanation Source", 
                                    "Between Partisan Difference: Counter-Explanation Source")), 
         copartisan = factor(cond_party1, 
                             levels=c("Co-Partisan", "Opposing Partisan", 
                                      "Diff in Diff"))) %>%
  ggplot(aes(x=AME, y=factor, shape=copartisan)) + 
  geom_pointrangeh(aes(xmin=lower, xmax=upper),
                   position = position_dodgev(height=0.3)) + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1) + 
  theme_light() + 
  labs(title = "Experiment 1", x = "Estimate", y = NULL, 
       shape = "Symbol") + 
  theme(strip.text.y = element_text(face="bold", color = "black")) + 
  geom_vline(xintercept=0, linetype="dashed") + 
  theme(strip.text.x=element_text(face="bold", color="black"))


################
#Exp2
################
f2 <- exp2_comb %>%
  mutate(factor = factor(factor, 
                         levels=c("HC - LC", 
                                  "Just w/Low Credibility", 
                                  "Just w/High Credibility", 
                                  "No Justification")) , 
         testtype = factor(testtype, 
                           levels=c("AME", 
                                    "Within Partisan Diff",
                                    "Between Partisan Diff"), 
                           labels=c("Difference from Justification Condition", 
                                    "Within Partisan Difference: Counter-Explanation Source", 
                                    "Between Partisan Difference: Counter-Explanation Source")), 
         copartisan = factor(copartisan, 
                             levels=c("Co-Partisan", "Opposing Partisan", 
                                      "Diff in Diff"))) %>%
  ggplot(aes(x=AME, y=factor, shape=copartisan)) + 
  geom_pointrangeh(aes(xmin=lower, xmax=upper),
                   position = position_dodgev(height=0.3)) + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1) + 
  theme_light() + 
  labs(title = "Experiment 2", x = "Estimate", y = NULL, 
       shape = "Symbol") + 
  theme(strip.text.y = element_text(face="bold", color = "black")) + 
  geom_vline(xintercept=0, linetype="dashed") + 
  theme(strip.text.x=element_text(face="bold", color="black"))

###Combine
ggarrange(f1, f2, 
          common.legend=T, 
          legend = "top")

ggsave("Figure 3.png", height=10, width=14)


################
#Exp3a
################
f3 <- exp3a_comb %>%
  mutate(factor = factor(factor, 
                         levels=c("LW - RW", 
                                  "Just W./RW", 
                                  "Just W./LW", 
                                  "No Justification")) , 
         testtype = factor(testtype, 
                           levels=c("AME", 
                                    "Within Partisan Diff",
                                    "Between Partisan Diff"), 
                           labels=c("Difference from Justification Condition", 
                                    "Within Partisan Difference: Counter-Explanation Source", 
                                    "Between Partisan Difference: Counter-Explanation Source")), 
         gil_partisan = factor(gil_partisan, 
                             levels=c("Co-Partisan", "Opposing Partisan", 
                                      "Diff in Diff"))) %>%
  ggplot(aes(x=AME, y=factor, shape=gil_partisan)) + 
  geom_pointrangeh(aes(xmin=lower, xmax=upper),
                   position = position_dodgev(height=0.4)) + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1) + 
  theme_light() + 
  labs(title = "Experiment 3a (Gillibrand)", x = "Estimate", y = NULL, 
       shape = "Symbol") + 
  theme(strip.text.y = element_text(face="bold", color = "black")) + 
  geom_vline(xintercept=0, linetype="dashed") + 
  theme(strip.text.x=element_text(face="bold", color="black"))

################
#Exp3b
################
f4 <- exp3b_comb %>%
  mutate(factor = factor(factor, 
                         levels=c("LW - RW", 
                                  "Just. w/RW", 
                                  "Just. w/LW", 
                                  "No Justification")) , 
         testtype = factor(testtype, 
                           levels=c("AME", 
                                    "Within Partisan Diff",
                                    "Between Partisan Diff"), 
                           labels=c("Difference from Justification Condition", 
                                    "Within Partisan Difference: Counter-Explanation Source", 
                                    "Between Partisan Difference: Counter-Explanation Source")),  
         corker_partisan = factor(corker_partisan, 
                               levels=c("Co-Partisan", "Opposing Partisan", 
                                        "Diff in Diff"))) %>%
  ggplot(aes(x=AME, y=factor, shape=corker_partisan)) + 
  geom_pointrangeh(aes(xmin=lower, xmax=upper),
                   position = position_dodgev(height=0.4)) + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1) + 
  theme_light() + 
  labs(title = "Experiment 3b (Corker)", x = "Estimate", y = NULL, 
       shape = "Symbol") + 
  theme(strip.text.y = element_text(face="bold", color = "black")) + 
  geom_vline(xintercept=0, linetype="dashed") + 
  theme(strip.text.x=element_text(face="bold", color="black"))


###Combine
ggarrange(f3, f4, 
          common.legend=T, 
          legend = "top")

ggsave("Figure 4.png", height=10, width=14)
