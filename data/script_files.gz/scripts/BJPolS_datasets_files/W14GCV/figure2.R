############################################
#   Code to create Figure 2
############################################

##################
#Packages
##################
library(cowplot)
library(ggpubr)
library(car)
library(socviz)
library(scales)
library(broom)
library(rio)
library(tidyverse)
library(ggstance)

##################
#Experiment 1
##################


####Load & Clean Data
exp1 <- import("exp1_cleaned.dta") %>%
  mutate(cond_info = factor(cond_info, 
                            levels=c(3,1,2,4,5,6), 
                            labels=c("Justification", "Pure Baseline", 
                                     "No Justification", "Just. w/Teachers", 
                                     "Just. w/Non-Partisan", "Just. w/Partisan")), 
                   cond_party = factor(cond_party, 
                             levels=c(0,1), 
                             labels=c("Republican Legislator", "Democratic Legislator")))

#Model
m1 <- tidy(lm(therm01 ~ cond_info + cond_party, data=exp1), 
           conf.int=T) %>%
  filter(term !="(Intercept)", 
         term !="cond_partyDemocratic Legislator", 
         term !="cond_infoPure Baseline") %>%
  mutate(term = socviz::prefix_strip(term, "cond_info"), 
         experiment = "Experiment 1", 
         testtype = "Difference from Justification Condition")

#Adding lincom results from Stata
m1_teach <- import("exp1_teachers.dta") %>%
  rename(std.error = stderr, 
         statistic = t, 
         p.value = p, 
         conf.low = min95, 
         conf.high = max95) %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Difference between Counter-Expl. Coefficients", 
         term = "Teacher - Partisan") %>%
  select(-dof, -label, -parm)
  
m1_non <- import("exp1_nonpartisan.dta") %>%
  rename(std.error = stderr, 
         statistic = t, 
         p.value = p, 
         conf.low = min95, 
         conf.high = max95) %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Difference between Counter-Expl. Coefficients", 
         term = "NP - Partisan") %>%
  select(-dof, -label, -parm)

m1_comb <- bind_rows(m1, m1_teach, m1_non)


##################
#Experiment 2
##################

####Load and Clean Data
exp2 <- import("exp2_cleaned.dta") %>%
  mutate(treat_expl = factor(treat_expl, 
                             levels=c(2,1,3,4), 
                             labels=c("Justification", "No Justification", 
                                      "Just w/High Credibility", 
                                      "Just w/Low Credibility")),
         treat_party = factor(treat_party, 
                              levels=c(0,1), 
                              labels=c("Democratic Legislator", 
                                       "Republican Legislator")))

#Model
m2 <- tidy(lm(therm_post01 ~ therm_pre01 + treat_expl + treat_party, data=exp2), 
           conf.int = T) %>%
  mutate(term = prefix_strip(term, c("treat_expl", "treat_party")), 
         experiment = "Experiment 2", 
         testtype = "Difference from Justification Condition") %>%
  filter(term != "(Intercept)", term!= "Republican Legislator", term != "Therm_pre01")

#Importing Lincom results
m2_high <- import("exp2_high.dta") %>%
  rename(std.error = stderr, 
         statistic = t, 
         p.value = p, 
         conf.low = min95, 
         conf.high = max95) %>%
  mutate(experiment = "Experiment 1", 
         testtype = "Difference between Counter-Expl. Coefficients", 
         term = "High Cred - Low Cred") %>%
  select(-dof, -label, -parm)

m2_comb <- bind_rows(m2, m2_high)


##################
#Experiment 3a
##################

exp3a <- import("exp3_cleaned.dta") %>%
  mutate(gil_exp = factor(gil_exp, 
                          levels=c(2,1,3,4), 
                          labels=c("Justification", "No Justification", 
                                   "Just w./LW", 
                                   "Just w./RW")), 
         treat_order = factor(treat_order, 
                              levels=c(0,1), 
                              labels=c("Corker First", "Gillibrand First")), 
         gil_pre = factor(gil_pre, 
                          levels=c(1,2,3), 
                          labels=c("Favorable Prior", "Unfavorable Prior", 
                                   "No Opinion toward Gillibrand")), 
         gil_prox = factor(gil_prox, 
                           levels=c(1,2,3), 
                           labels=c("Gain Proximity", 
                                    "Lose Proximity", "No Prior Issue Attitude")), 
         gil_partisan = factor(gil_partisan, 
                               levels=c(1,2,3), 
                               labels=c("Co-Partisan", "Opposing Partisan", 
                                        "Pure Independent")))

##Model
m3 <- tidy(lm(gil_post01 ~ gil_exp + gil_pre + gil_prox + gil_partisan + treat_order, 
              data = exp3a), conf.int=T) %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         testtype = "Difference from Justification Condition") %>%
  filter(grepl("gil_exp", term)) %>%
  mutate(term = prefix_strip(term, "gil_exp"))

##Lincom
exp3_lc_gil <- import("exp3_gil.dta") %>%
  rename(std.error = stderr, 
         statistic = t, 
         p.value = p, 
         conf.low = min95, 
         conf.high = max95) %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         testtype = "Difference between Counter-Expl. Coefficients", 
         term = "LW - RW") %>%
  select(-dof, -label, -parm)

##Bind
m3_comb <- bind_rows(m3, exp3_lc_gil)


##################
#Experiment 3b
##################
exp3b <- import("exp3_cleaned.dta") %>%
  mutate(corker_exp = factor(corker_exp, 
                             levels=c(2,1,3,4), 
                             labels=c("Justification", "No Justification", 
                                      "Just. w/LW", 
                                      "Just. w/RW")), 
         corker_pre = factor(corker_pre, 
                             levels=c(1,2,3), 
                             labels=c("Favorable Prior", "Unfavorable Prior", 
                                      "No Opinion toward Gillibrand")),
         corker_prox = factor(corker_prox, 
                              levels=c(1,2,3), 
                              labels=c("Gain Proximity", 
                                       "Lose Proximity", 
                                       "No Prior Issue Attitude")), 
         corker_partisan = factor(corker_partisan, 
                                  levels=c(1,2,3), 
                                  labels=c("Co-Partisan", "Opposing Partisan", 
                                           "Independent")))

###Model
m4 <- tidy(lm(corker_post01 ~ corker_exp + corker_pre + corker_prox + corker_partisan +
                treat_order, data = exp3b), conf.int=T) %>%
  mutate(experiment = "Experiment 3b (Corker)", 
       testtype = "Difference from Justification Condition") %>%
  filter(grepl("corker_exp", term)) %>%
  mutate(term = prefix_strip(term, "corker_exp"))

##Lincom
exp3_lc_corker <- import("exp3_corker.dta") %>%
  rename(std.error = stderr, 
         statistic = t, 
         p.value = p, 
         conf.low = min95, 
         conf.high = max95) %>%
  mutate(experiment = "Experiment 3b (Corker)", 
         testtype = "Difference between Counter-Expl. Coefficients", 
         term = "LW - RW") %>%
  select(-dof, -label, -parm)


##Bind
m4_comb <- bind_rows(m4, exp3_lc_corker)

#####################################
#   Bind and Export
#####################################
fig2_results <- bind_rows(m1_comb, m2_comb, m3_comb, m4_comb)

export(fig2_results, "fig2_results.csv")
export(fig2_results, "fig2_results.Rda")

#####################################
#   Figure
#####################################

######################
# With reference
# Need to create df with relevant info and then use that
# in geom_point()
######################
justdf <- data.frame(term = "Justification", estimate = 0, testtype = "Difference from Justification Condition")

###Exp1 
m1_comb1 <-  m1_comb %>%
  add_row(term = "Justification", estimate = NA, testtype = "Difference from Justification Condition") %>%
  mutate(term = factor(term, levels=c( "NP - Partisan", 
                                       "Teacher - Partisan", 
                                       "Just. w/Partisan", 
                                       "Just. w/Teachers", 
                                       "Just. w/Non-Partisan", 
                                       "No Justification", 
                                       "Justification")), 
         testtype = factor(testtype, 
                           levels=c("Difference from Justification Condition", 
                                    "Difference between Counter-Expl. Coefficients")))


f1a <- m1_comb1 %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1)  +
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 1")  + 
  geom_point(data = justdf, aes(x=estimate, y=term), inherit.aes=FALSE) + 
  theme(strip.text.x=element_text(face = "bold", color="black")) +
  geom_text(data=m1_comb1[m1_comb1$testtype=="Difference from Justification Condition",], 
            aes(label=round(estimate,2)), nudge_y=0.5) + 
  geom_text(data=m1_comb1[m1_comb1$testtype=="Difference between Counter-Expl. Coefficients",],
            aes(label=round(estimate,2)), nudge_y=0.2)




###Exp 2
m2_comb1 <- m2_comb %>%
  add_row(term = "Justification", estimate = NA, testtype = "Difference from Justification Condition") %>%
  mutate( testtype = factor(testtype, 
                            levels=c("Difference from Justification Condition", 
                                     "Difference between Counter-Expl. Coefficients")), 
          term = factor(term, 
                        levels=c("High Cred - Low Cred", 
                                 "Just w/Low Credibility", 
                                 "Just w/High Credibility", 
                                 "No Justification", "Justification"))) 

f2a <- m2_comb1 %>% 
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1) +
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 2")  + 
  geom_point(data = justdf, aes(x=estimate, y=term), inherit.aes=FALSE) + 
  theme(strip.text.x=element_text(face = "bold", color="black")) + 
  geom_text(data=m2_comb1[m2_comb1$testtype=="Difference from Justification Condition",], 
            aes(label=round(estimate,2)), nudge_y=0.4) + 
  geom_text(data=m2_comb1[m2_comb1$testtype=="Difference between Counter-Expl. Coefficients",],
            aes(label=round(estimate,2)), nudge_y=0.15)

###Exp 3a
m3_comb1 <- m3_comb %>%
  add_row(term = "Justification", estimate = NA, testtype = "Difference from Justification Condition") %>%
  mutate(testtype = factor(testtype, 
                           levels=c("Difference from Justification Condition", "Difference between Counter-Expl. Coefficients")), 
         term = factor(term, 
                       levels=c("LW - RW", 
                                "Just W./RW", 
                                "Just W./LW", 
                                "No Justification", "Justification"))) 

f3a <- m3_comb1 %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1)  +
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 3a (Gillibrand)")  + 
  geom_point(data = justdf, aes(x=estimate, y=term), inherit.aes=FALSE) + 
  theme(strip.text.x=element_text(face = "bold", color="black")) + 
  geom_text(data=m3_comb1[m3_comb1$testtype=="Difference from Justification Condition",], 
            aes(label=round(estimate,2)), nudge_y=0.4) + 
  geom_text(data=m3_comb1[m3_comb1$testtype=="Difference between Counter-Expl. Coefficients",],
            aes(label=round(estimate,2)), nudge_y=0.15)


###Exp 3b
m4_comb1 <- m4_comb %>%
  add_row(term = "Justification", estimate = NA, testtype = "Difference from Justification Condition") %>%
  mutate(testtype = factor(testtype, 
                           levels=c("Difference from Justification Condition", "Difference between Counter-Expl. Coefficients")), 
         term = factor(term, 
                       levels=c("LW - RW", 
                                "Just. w/RW", 
                                "Just. w/LW", 
                                "No Justification", 
                                "Justification"))) 

f4a <- m4_comb1 %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  facet_wrap(testtype ~ ., 
             scales="free_y", 
             labeller = label_wrap_gen(width = 30), 
             ncol=1)  +
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 3b (Corker)")  + 
  geom_point(data = justdf, aes(x=estimate, y=term), inherit.aes=FALSE) + 
  theme(strip.text.x=element_text(face = "bold", color="black")) + 
  geom_text(data=m4_comb1[m4_comb1$testtype=="Difference from Justification Condition",], 
            aes(label=round(estimate,2)), nudge_y=0.4) + 
  geom_text(data=m4_comb1[m4_comb1$testtype=="Difference between Counter-Expl. Coefficients",],
            aes(label=round(estimate,2)), nudge_y=0.15)


####Combine
plot_grid(f1a, f2a, f3a, f4a, 
          align = "v")

ggsave("figure2.png", 
       height=8, width=14)
