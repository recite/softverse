##############################
#Syntax to obtain MDE for Table OA7 per Online Appnendix A
###############################

library(WebPower)

#############################
# Experiment 1
##############################

#Figure 2
wp.anova(f = NULL, k = 2, n = 605, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 599, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 601, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 605, power = 0.8, alpha = 0.05)


#############################
# Experiment 2
##############################
wp.anova(f = NULL, k = 2, n = 806, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 807, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 810, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 805, power = 0.8, alpha = 0.05)

#############################
# Experiment 3
##############################

wp.anova(f = NULL, k = 2, n = 603, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 604, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 609, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 608, power = 0.8, alpha = 0.05)


wp.anova(f = NULL, k = 2, n = 611, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 609, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 614, power = 0.8, alpha = 0.05)
wp.anova(f = NULL, k = 2, n = 602, power = 0.8, alpha = 0.05)


