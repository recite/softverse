############################################
#   Code to create Figure 1
############################################

##################
#Packages
##################
library(cowplot)
library(ggpubr)
library(car)
library(socviz)
library(scales)
library(broom)
library(rio)
library(tidyverse)
library(ggstance)

##################
#Experiment 1
##################

####Load & Clean Data
exp1 <- import("exp1_cleaned.dta") %>%
  mutate(treat = car::recode(cond_info,'1=1;2=2;3=3;4=4;5=4;6=4'),
         treat = factor(treat, 
                        levels=c(3,1,2,4),
                        labels=c("Justification", "Pure Baseline", 
                                 "No Justification", "Just. w/Counter")), 
         cond_party = factor(cond_party, 
                             levels=c(0,1), 
                             labels=c("Republican Legislator", "Democratic Legislator")))

#Model
m1 <- tidy(lm(therm01 ~ treat + cond_party, data=exp1), 
           conf.int=T) %>%
  filter(term !="(Intercept)", 
         term !="cond_partyDemocratic Legislator", 
         term !="treatPure Baseline") %>%
  mutate(term = socviz::prefix_strip(term, "treat"), 
         experiment = "Experiment 1")


##################
#Experiment 2
##################

####Load and Clean Data
exp2 <- import("exp2_cleaned.dta") %>%
  mutate(treat = car::recode(treat_expl, '1=1;2=2;3=3;4=3'), 
         treat = factor(treat, 
                        levels=c(2,1,3), 
                        labels=c("Justification", 
                                 "No Justification", 
                                 "Just. w/Counter")), 
         treat_party = factor(treat_party, 
                              levels=c(0,1), 
                              labels=c("Democratic Legislator", 
                                       "Republican Legislator")))

#Model
m2 <- tidy(lm(therm_post01 ~ therm_pre01 + treat + treat_party, data=exp2), 
           conf.int = T) %>%
  mutate(term = prefix_strip(term, c("treat", "treat_party")), 
         experiment = "Experiment 2") %>%
  filter(term %in% c("No Justification", "Just. w/Counter"))

##################
#Experiment 3a: Gillibrand
##################

###Load Data
exp3a <- import("exp3_cleaned.dta") %>%
  mutate(treat1 = car::recode(gil_exp, '1=1;2=2;3=3;4=3'), 
         treat1 = factor(treat1, 
                         levels=c(2,1,3), 
                         labels=c("Justification", "No Justification", 
                                  "Just. w/Counter")), 
         treat_order = factor(treat_order, 
                              levels=c(0,1), 
                              labels=c("Corker First", "Gillibrand First")), 
         gil_pre = factor(gil_pre, 
                          levels=c(1,2,3), 
                          labels=c("Favorable Prior", "Unfavorable Prior", 
                                   "No Opinion toward Gillibrand")), 
         gil_prox = factor(gil_prox, 
                           levels=c(1,2,3), 
                           labels=c("Gain Proximity", 
                                    "Lose Proximity", "No Prior Issue Attitude")), 
         gil_partisan = factor(gil_partisan, 
                               levels=c(1,2,3), 
                               labels=c("Co-Partisan", "Opposing Partisan", 
                                        "Pure Independent")))
                          
##Model
m3 <- tidy(lm(gil_post01 ~ treat1 + gil_pre + gil_prox + gil_partisan + treat_order, 
              data = exp3a), conf.int=T) %>%
  mutate(experiment = "Experiment 3a (Gillibrand)", 
         term = prefix_strip(term, "treat1" )) %>%
  filter(term %in% c("No Justification", "Just. w/Counter"))

##################
#Experiment 3b: Corker
##################
####Load and Clean Data
exp3b <- import("exp3_cleaned.dta") %>%
  mutate(treat2 = car::recode(corker_exp, '1=1;2=2;3=3;4=3'), 
         treat2 = factor(treat2, 
                         levels=c(2,1,3), 
                         labels=c("Justification", 
                                  "No Justification", 
                                  "Just. w/Counter")), 
         corker_pre = factor(corker_pre, 
                             levels=c(1,2,3), 
                             labels=c("Favorable Prior", "Unfavorable Prior", 
                                      "No Opinion toward Gillibrand")),
         corker_prox = factor(corker_prox, 
                              levels=c(1,2,3), 
                              labels=c("Gain Proximity", 
                                       "Lose Proximity", 
                                       "No Prior Issue Attitude")), 
         corker_partisan = factor(corker_partisan, 
                                  levels=c(1,2,3), 
                                  labels=c("Co-Partisan", "Opposing Partisan", 
                                           "Independent")))

###Model: All Respondents
m4 <- tidy(lm(corker_post01 ~ treat2 + corker_pre + corker_prox + corker_partisan + treat_order, 
              data = exp3b), conf.int=T) %>%
  mutate(experiment = "Experiment 3b (Corker)", 
         term = prefix_strip(term, "treat2")) %>%
  filter(term %in% c("No Justification", "Just. w/Counter"))

##################
#Bind and Figure
##################

####Combined margins to export for later consultation
combdata <- bind_rows(m1, m2, m3, m4) 
export(combdata, "./Figure 1/figure1_results.csv")
export(combdata, "./Figure 1/figure1_results.rda")

######################
# Version of Figure 1 with 
# a Justification Baseline Added
######################
#Exp1
p1a <- m1 %>%
  add_row(term = "Justification", estimate = NA) %>%
  mutate(term = factor(term, levels=c( "Just. w/Counter",
                                       "No Justification",
                                       "Justification"))) %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  geom_point(aes(x=0, y=3)) + 
  geom_text(data=m1, aes(label=round(estimate, 2)), 
            nudge_y=0.20) + 
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 1") 

#Exp 2
p2a <- m2 %>%
  add_row(term = "Justification", estimate = NA) %>%
  mutate(term = factor(term, levels=c( "Just. w/Counter",
                                       "No Justification",
                                       "Justification"))) %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  geom_point(aes(x=0, y=3)) + 
  geom_text(data=m2, aes(label=round(estimate, 2)), 
            nudge_y=0.20) + 
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 2") 

###Experiment 3
p3a <- m3 %>%
  add_row(term = "Justification", estimate = NA) %>%
  mutate(term = factor(term, levels=c( "Just. w/Counter",
                                       "No Justification",
                                       "Justification"))) %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  geom_point(aes(x=0, y=3)) + 
  geom_text(data=m3, aes(label=round(estimate, 2)), 
            nudge_y=0.20) + 
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 3a (Gillibrand)") 

###Experiment 3a
p4a <- m4 %>%
  add_row(term = "Justification", estimate = NA) %>%
  mutate(term = factor(term, levels=c( "Just. w/Counter",
                                       "No Justification",
                                       "Justification"))) %>%
  ggplot(aes(y=term, x=estimate)) + 
  geom_pointrangeh(aes(xmin=conf.low, xmax=conf.high)) + 
  theme_light() + 
  geom_point(aes(x=0, y=3)) + 
  geom_text(data=m4, aes(label=round(estimate, 2)), 
            nudge_y=0.20) + 
  geom_vline(xintercept=0,  linetype="dashed") + 
  labs(y = NULL, x = "Estimate", title="Experiment 3b (Corker)") 


####Combine
ggarrange(p1a, p2a, p3a, p4a)

ggsave("./Figure 1/figure1.png", 
       height=7, width=14)
