###Table 4/5 and 6/7


library(dplyr)

setwd("C:/Users/kevin/Dropbox/Social_Media_Lab/Data_Survey/YouGov_Data/apsr_replication/")
load("merged_nr_soma.RData")


##subset to Twitter, non-Twitter



no_twitter<-filter(data, twitter_user==0 | twitter_freq_inc  <2)

yes_twitter<-filter(data, twitter_user==1 & twitter_freq_inc  >1)


##

table(no_twitter$soft_correct_EU_w1,no_twitter$soft_correct_EU_w4)/sum(table(no_twitter$soft_correct_EU_w1,no_twitter$soft_correct_EU_w4))

table(no_twitter$soft_correct_spend_w1,no_twitter$soft_correct_spend_w4)/sum(table(no_twitter$soft_correct_spend_w1,no_twitter$soft_correct_spend_w4))

table(no_twitter$soft_correct_immigration_w1,no_twitter$soft_correct_immigration_w4)/sum(table(no_twitter$soft_correct_immigration_w1,no_twitter$soft_correct_immigration_w4))

##

table(yes_twitter$soft_correct_EU_w1,yes_twitter$soft_correct_EU_w4)/sum(table(yes_twitter$soft_correct_EU_w1,yes_twitter$soft_correct_EU_w4))

table(yes_twitter$soft_correct_spend_w1,yes_twitter$soft_correct_spend_w4)/sum(table(yes_twitter$soft_correct_spend_w1,yes_twitter$soft_correct_spend_w4))

table(yes_twitter$soft_correct_immigration_w1,yes_twitter$soft_correct_immigration_w4)/sum(table(yes_twitter$soft_correct_immigration_w1,yes_twitter$soft_correct_immigration_w4))


## factual knowledge -- tables 6/7

table(no_twitter$fact_isis_w2_correct_dk0 ,no_twitter$fact_isis_w3_correct_dk0)/sum(table(no_twitter$fact_isis_w2_correct_dk0 ,no_twitter$fact_isis_w3_correct_dk0))


table(no_twitter$fact_unemployment_w2_correct_dk0 ,no_twitter$fact_unemployment_w3_correct_dk0)/sum(table(no_twitter$fact_unemployment_w2_correct_dk0 ,no_twitter$fact_unemployment_w3_correct_dk0))


table(no_twitter$fact_immigrants_w2_correct_dk0 ,no_twitter$fact_immigrants_w3_correct_dk0)/sum(table(no_twitter$fact_immigrants_w2_correct_dk0 ,no_twitter$fact_immigrants_w3_correct_dk0))

##Twitter users
table(yes_twitter$fact_isis_w2_correct_dk0 ,yes_twitter$fact_isis_w3_correct_dk0)/sum(table(yes_twitter$fact_isis_w2_correct_dk0 ,yes_twitter$fact_isis_w3_correct_dk0))


table(yes_twitter$fact_unemployment_w2_correct_dk0 ,yes_twitter$fact_unemployment_w3_correct_dk0)/sum(table(yes_twitter$fact_unemployment_w2_correct_dk0 ,yes_twitter$fact_unemployment_w3_correct_dk0))


table(yes_twitter$fact_immigrants_w2_correct_dk0 ,yes_twitter$fact_immigrants_w3_correct_dk0)/sum(table(yes_twitter$fact_immigrants_w2_correct_dk0 ,yes_twitter$fact_immigrants_w3_correct_dk0))

