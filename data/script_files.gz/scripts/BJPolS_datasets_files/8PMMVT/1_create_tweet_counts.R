###read in survey data matched with Twitter account info
###create useful tweet count variables


library(foreign)
library(readstata13)
library(dplyr)

setwd("C:/Users/kevin/Dropbox/Social_Media_Lab/Data_Survey/YouGov_Data/apsr_replication/")
data<-read.dta13("soma_tweets2.dta")



data$all_tweets<-log(data$tweets_all_topics)

summary(data$tweets_all_topics)
summary(data$all_tweets)

##turn media tweets into left and right 

data$p1_media_left_economy<-data$p1_1_economy_guar+data$p1_2_economy_guar+data$p1_1_economy_ind+data$p1_2_economy_ind

data$p1_media_cent_economy<-data$p1_1_economy_stv+data$p1_2_economy_stv+data$p1_1_economy_bbc+data$p1_2_economy_bbc+data$p1_1_economy_cnn+
  data$p1_2_economy_cnn + data$p1_1_economy_ftimes+data$p1_2_economy_ftimes + data$p1_1_economy_sunt+data$p1_2_economy_sunt

data$p1_media_right_economy<-data$p1_1_economy_ssun+data$p1_2_economy_ssun+data$p1_1_economy_times+data$p1_2_economy_times+
  data$p1_1_economy_sun+data$p1_2_economy_sun

data$p1_msm_economy<-data$p1_media_right_economy+data$p1_media_cent_economy+data$p1_media_left_economy



data$p1_media_left_isis<-data$p1_1_isis_guar+data$p1_2_isis_guar+data$p1_1_isis_ind+data$p1_2_isis_ind

data$p1_media_cent_isis<-data$p1_1_isis_stv+data$p1_2_isis_stv+data$p1_1_isis_bbc+data$p1_2_isis_bbc+ data$p1_1_isis_ftimes+data$p1_2_isis_ftimes+data$p1_1_isis_sunt+data$p1_2_isis_sunt

data$p1_media_right_isis<-data$p1_1_isis_times+data$p1_2_isis_times +
  data$p1_1_isis_sun+data$p1_2_isis_sun

data$p1_msm_isis<-data$p1_media_right_isis+data$p1_media_cent_isis+data$p1_media_left_isis


data$p1_media_left_eu<-data$p1_1_eu_guar+data$p1_2_eu_guar+data$p1_1_eu_ind+data$p1_2_eu_ind

data$p1_media_cent_eu<-data$p1_1_eu_stv+data$p1_2_eu_stv+data$p1_1_eu_bbc+data$p1_2_eu_bbc+ data$p1_1_eu_ftimes+data$p1_2_eu_ftimes

data$p1_media_right_eu<-data$p1_1_eu_times+data$p1_2_eu_times +data$p1_1_eu_ssun+data$p1_2_eu_ssun+
  data$p1_1_eu_sun+data$p1_2_eu_sun

data$p1_msm_eu<-data$p1_media_right_eu+data$p1_media_cent_eu+data$p1_media_left_eu


data$p1_media_left_immigr<-data$p1_1_immigr_guar+data$p1_2_immigr_guar+data$p1_1_immigr_ind+data$p1_2_immigr_ind

data$p1_media_cent_immigr<-data$p1_1_immigr_stv+data$p1_2_immigr_stv+data$p1_1_immigr_bbc+data$p1_2_immigr_bbc+data$p1_1_immigr_cnn+
  data$p1_2_immigr_cnn + data$p1_1_immigr_ftimes+data$p1_2_immigr_ftimes+data$p1_1_immigr_sunt+data$p1_2_immigr_sunt

data$p1_media_right_immigr<-data$p1_1_immigr_times+data$p1_2_immigr_times +data$p1_1_immigr_ssun+data$p1_2_immigr_ssun+
  data$p1_1_immigr_sun+data$p1_2_immigr_sun

data$p1_msm_immigr<-p1_media_right_immigr+p1_media_cent_immigr+p1_media_left_immigr

data$p1_media_left_immigr<-data$p1_1_immigr_guar+data$p1_2_immigr_guar+data$p1_1_immigr_ind+data$p1_2_immigr_ind

data$p1_media_cent_immigr<-data$p1_1_immigr_stv+data$p1_2_immigr_stv+data$p1_1_immigr_bbc+data$p1_2_immigr_bbc+data$p1_1_immigr_cnn+
  data$p1_2_immigr_cnn + data$p1_1_immigr_ftimes+data$p1_2_immigr_ftimes+data$p1_1_immigr_sunt+data$p1_2_immigr_sunt

data$p1_media_right_immigr<-data$p1_1_immigr_times+data$p1_2_immigr_times +data$p1_1_immigr_ssun+data$p1_2_immigr_ssun+
  data$p1_1_immigr_sun+data$p1_2_immigr_sun

data$p1_msm_immigr<-data$p1_media_right_immigr+data$p1_media_cent_immigr+data$p1_media_left_immigr

###period 2 

data$p2_media_left_economy<-data$p2_1_economy_guar+data$p2_2_economy_guar+data$p2_1_economy_ind+data$p2_2_economy_ind

data$p2_media_cent_economy<-data$p2_1_economy_stv+data$p2_2_economy_stv+data$p2_1_economy_bbc+data$p2_2_economy_bbc+data$p2_1_economy_cnn+
  data$p2_2_economy_cnn + data$p2_1_economy_ftimes+data$p2_2_economy_ftimes + data$p2_1_economy_sunt+data$p2_2_economy_sunt

data$p2_media_right_economy<-data$p2_1_economy_ssun+data$p2_2_economy_ssun+data$p2_1_economy_times+data$p2_2_economy_times+
  data$p2_1_economy_sun+data$p2_2_economy_sun

data$p2_msm_economy<-data$p2_media_right_economy+data$p2_media_cent_economy+data$p2_media_left_economy



data$p2_media_left_isis<-data$p2_1_isis_guar+data$p2_2_isis_guar+data$p2_1_isis_ind+data$p2_2_isis_ind

data$p2_media_cent_isis<-data$p2_1_isis_stv+data$p2_2_isis_stv+data$p2_1_isis_bbc+data$p2_2_isis_bbc+ data$p2_1_isis_ftimes+data$p2_2_isis_ftimes+data$p2_1_isis_sunt+data$p2_2_isis_sunt

data$p2_media_right_isis<-data$p2_1_isis_times+data$p2_2_isis_times +
  data$p2_1_isis_sun+data$p2_2_isis_sun

data$p2_msm_isis<-data$p2_media_right_isis+data$p2_media_cent_isis+data$p2_media_left_isis


data$p2_media_left_eu<-data$p2_1_eu_guar+data$p2_2_eu_guar+data$p2_1_eu_ind+data$p2_2_eu_ind

data$p2_media_cent_eu<-data$p2_1_eu_stv+data$p2_2_eu_stv+data$p2_1_eu_bbc+data$p2_2_eu_bbc+ data$p2_1_eu_ftimes+data$p2_2_eu_ftimes

data$p2_media_right_eu<-data$p2_1_eu_times+data$p2_2_eu_times +data$p2_1_eu_ssun+data$p2_2_eu_ssun+
  data$p2_1_eu_sun+data$p2_2_eu_sun

data$p2_msm_eu<-data$p2_media_right_eu+data$p2_media_cent_eu+data$p2_media_left_eu


data$p2_media_left_immigr<-data$p2_1_immigr_guar+data$p2_2_immigr_guar+data$p2_1_immigr_ind+data$p2_2_immigr_ind

data$p2_media_cent_immigr<-data$p2_1_immigr_stv+data$p2_2_immigr_stv+data$p2_1_immigr_bbc+data$p2_2_immigr_bbc+data$p2_1_immigr_cnn+
  data$p2_2_immigr_cnn + data$p2_1_immigr_ftimes+data$p2_2_immigr_ftimes+data$p2_1_immigr_sunt+data$p2_2_immigr_sunt

data$p2_media_right_immigr<-data$p2_1_immigr_times+data$p2_2_immigr_times +data$p2_1_immigr_ssun+data$p2_2_immigr_ssun+
  data$p2_1_immigr_sun+data$p2_2_immigr_sun

data$p2_msm_immigr<-p2_media_right_immigr+p2_media_cent_immigr+p2_media_left_immigr

data$p2_media_left_immigr<-data$p2_1_immigr_guar+data$p2_2_immigr_guar+data$p2_1_immigr_ind+data$p2_2_immigr_ind

data$p2_media_cent_immigr<-data$p2_1_immigr_stv+data$p2_2_immigr_stv+data$p2_1_immigr_bbc+data$p2_2_immigr_bbc+data$p2_1_immigr_cnn+
  data$p2_2_immigr_cnn + data$p2_1_immigr_ftimes+data$p2_2_immigr_ftimes+data$p2_1_immigr_sunt+data$p2_2_immigr_sunt

data$p2_media_right_immigr<-data$p2_1_immigr_times+data$p2_2_immigr_times +data$p2_1_immigr_ssun+data$p2_2_immigr_ssun+
  data$p2_1_immigr_sun+data$p2_2_immigr_sun

data$p2_msm_immigr<-data$p2_media_right_immigr+data$p2_media_cent_immigr+data$p2_media_left_immigr


###period 3

data$p3_media_left_economy<-data$p3_1_economy_guar+data$p3_2_economy_guar+data$p3_1_economy_ind+data$p3_2_economy_ind

data$p3_media_cent_economy<-data$p3_1_economy_stv+data$p3_2_economy_stv+data$p3_1_economy_bbc+data$p3_2_economy_bbc+data$p3_1_economy_cnn+
  data$p3_2_economy_cnn + data$p3_1_economy_ftimes+data$p3_2_economy_ftimes + data$p3_1_economy_sunt+data$p3_2_economy_sunt

data$p3_media_right_economy<-data$p3_1_economy_ssun+data$p3_2_economy_ssun+data$p3_1_economy_times+data$p3_2_economy_times+
  data$p3_1_economy_sun+data$p3_2_economy_sun

data$p3_msm_economy<-data$p3_media_right_economy+data$p3_media_cent_economy+data$p3_media_left_economy



data$p3_media_left_isis<-data$p3_1_isis_guar+data$p3_2_isis_guar+data$p3_1_isis_ind+data$p3_2_isis_ind

data$p3_media_cent_isis<-data$p3_1_isis_stv+data$p3_2_isis_stv+data$p3_1_isis_bbc+data$p3_2_isis_bbc+ data$p3_1_isis_ftimes+data$p3_2_isis_ftimes+data$p3_1_isis_sunt+data$p3_2_isis_sunt

data$p3_media_right_isis<-data$p3_1_isis_times+data$p3_2_isis_times +
  data$p3_1_isis_sun+data$p3_2_isis_sun

data$p3_msm_isis<-data$p3_media_right_isis+data$p3_media_cent_isis+data$p3_media_left_isis


data$p3_media_left_eu<-data$p3_1_eu_guar+data$p3_2_eu_guar+data$p3_1_eu_ind+data$p3_2_eu_ind

data$p3_media_cent_eu<-data$p3_1_eu_stv+data$p3_2_eu_stv+data$p3_1_eu_bbc+data$p3_2_eu_bbc+ data$p3_1_eu_ftimes+data$p3_2_eu_ftimes

data$p3_media_right_eu<-data$p3_1_eu_times+data$p3_2_eu_times +data$p3_1_eu_ssun+data$p3_2_eu_ssun+
  data$p3_1_eu_sun+data$p3_2_eu_sun

data$p3_msm_eu<-data$p3_media_right_eu+data$p3_media_cent_eu+data$p3_media_left_eu


data$p3_media_left_immigr<-data$p3_1_immigr_guar+data$p3_2_immigr_guar+data$p3_1_immigr_ind+data$p3_2_immigr_ind

data$p3_media_cent_immigr<-data$p3_1_immigr_stv+data$p3_2_immigr_stv+data$p3_1_immigr_bbc+data$p3_2_immigr_bbc+data$p3_1_immigr_cnn+
  data$p3_2_immigr_cnn + data$p3_1_immigr_ftimes+data$p3_2_immigr_ftimes+data$p3_1_immigr_sunt+data$p3_2_immigr_sunt

data$p3_media_right_immigr<-data$p3_1_immigr_times+data$p3_2_immigr_times +data$p3_1_immigr_ssun+data$p3_2_immigr_ssun+
  data$p3_1_immigr_sun+data$p3_2_immigr_sun

data$p3_msm_immigr<-p3_media_right_immigr+p3_media_cent_immigr+p3_media_left_immigr

data$p3_media_left_immigr<-data$p3_1_immigr_guar+data$p3_2_immigr_guar+data$p3_1_immigr_ind+data$p3_2_immigr_ind

data$p3_media_cent_immigr<-data$p3_1_immigr_stv+data$p3_2_immigr_stv+data$p3_1_immigr_bbc+data$p3_2_immigr_bbc+data$p3_1_immigr_cnn+
  data$p3_2_immigr_cnn + data$p3_1_immigr_ftimes+data$p3_2_immigr_ftimes+data$p3_1_immigr_sunt+data$p3_2_immigr_sunt

data$p3_media_right_immigr<-data$p3_1_immigr_times+data$p3_2_immigr_times +data$p3_1_immigr_ssun+data$p3_2_immigr_ssun+
  data$p3_1_immigr_sun+data$p3_2_immigr_sun

data$p3_msm_immigr<-data$p3_media_right_immigr+data$p3_media_cent_immigr+data$p3_media_left_immigr

###period 4 

data$p4_media_left_economy<-data$p4_1_economy_guar+data$p4_2_economy_guar+data$p4_1_economy_ind+data$p4_2_economy_ind

data$p4_media_cent_economy<-data$p4_1_economy_stv+data$p4_2_economy_stv+data$p4_1_economy_bbc+data$p4_2_economy_bbc+ data$p4_1_economy_ftimes+data$p4_2_economy_ftimes + data$p4_1_economy_sunt+data$p4_2_economy_sunt

data$p4_media_right_economy<-data$p4_1_economy_ssun+data$p4_2_economy_ssun+data$p4_1_economy_times+data$p4_2_economy_times+
  data$p4_1_economy_sun+data$p4_2_economy_sun

data$p4_msm_economy<-data$p4_media_right_economy+data$p4_media_cent_economy+data$p4_media_left_economy



data$p4_media_left_isis<-data$p4_1_isis_guar+data$p4_2_isis_guar+data$p4_1_isis_ind+data$p4_2_isis_ind

data$p4_media_cent_isis<-data$p4_1_isis_stv+data$p4_2_isis_stv+data$p4_1_isis_bbc+data$p4_2_isis_bbc+ data$p4_1_isis_ftimes+data$p4_2_isis_ftimes+data$p4_1_isis_sunt+data$p4_2_isis_sunt

data$p4_media_right_isis<-data$p4_1_isis_times+data$p4_2_isis_times +
  data$p4_1_isis_sun+data$p4_2_isis_sun

data$p4_msm_isis<-data$p4_media_right_isis+data$p4_media_cent_isis+data$p4_media_left_isis


data$p4_media_left_eu<-data$p4_1_eu_guar+data$p4_2_eu_guar+data$p4_1_eu_ind+data$p4_2_eu_ind

data$p4_media_cent_eu<-data$p4_1_eu_stv+data$p4_2_eu_stv+data$p4_1_eu_bbc+data$p4_2_eu_bbc+ data$p4_1_eu_ftimes+data$p4_2_eu_ftimes

data$p4_media_right_eu<-data$p4_1_eu_times+data$p4_2_eu_times +data$p4_1_eu_ssun+data$p4_2_eu_ssun+
  data$p4_1_eu_sun+data$p4_2_eu_sun

data$p4_msm_eu<-data$p4_media_right_eu+data$p4_media_cent_eu+data$p4_media_left_eu


data$p4_media_left_immigr<-data$p4_1_immigr_guar+data$p4_2_immigr_guar+data$p4_1_immigr_ind+data$p4_2_immigr_ind

data$p4_media_cent_immigr<-data$p4_1_immigr_stv+data$p4_2_immigr_stv+data$p4_1_immigr_bbc+data$p4_2_immigr_bbc+data$p4_1_immigr_cnn+
  data$p4_2_immigr_cnn + data$p4_1_immigr_ftimes+data$p4_2_immigr_ftimes+data$p4_1_immigr_sunt+data$p4_2_immigr_sunt

data$p4_media_right_immigr<-data$p4_1_immigr_times+data$p4_2_immigr_times +data$p4_1_immigr_ssun+data$p4_2_immigr_ssun+
  data$p4_1_immigr_sun+data$p4_2_immigr_sun

data$p4_msm_immigr<-p4_media_right_immigr+p4_media_cent_immigr+p4_media_left_immigr

data$p4_media_left_immigr<-data$p4_1_immigr_guar+data$p4_2_immigr_guar+data$p4_1_immigr_ind+data$p4_2_immigr_ind

data$p4_media_cent_immigr<-data$p4_1_immigr_stv+data$p4_2_immigr_stv+data$p4_1_immigr_bbc+data$p4_2_immigr_bbc+data$p4_1_immigr_cnn+
  data$p4_2_immigr_cnn + data$p4_1_immigr_ftimes+data$p4_2_immigr_ftimes+data$p4_1_immigr_sunt+data$p4_2_immigr_sunt

data$p4_media_right_immigr<-data$p4_1_immigr_times+data$p4_2_immigr_times +data$p4_1_immigr_ssun+data$p4_2_immigr_ssun+
  data$p4_1_immigr_sun+data$p4_2_immigr_sun

data$p4_msm_immigr<-data$p4_media_right_immigr+data$p4_media_cent_immigr+data$p4_media_left_immigr


###combine tweets 

data$media_right_immigr<- data$p2_media_right_immigr+data$p3_media_right_immigr+data$p4_media_right_immigr
data$media_right_eu<- data$p2_media_right_eu+data$p3_media_right_eu+data$p4_media_right_eu
data$media_right_economy<- data$p2_media_right_economy+data$p3_media_right_economy+data$p4_media_right_economy
data$media_right_isis<- data$p2_media_right_isis+data$p3_media_right_isis+data$p4_media_right_isis

data$media_cent_immigr<- data$p2_media_cent_immigr+data$p3_media_cent_immigr+data$p4_media_cent_immigr
data$media_cent_eu<- data$p2_media_cent_eu+data$p3_media_cent_eu+data$p4_media_cent_eu
data$media_cent_economy<- data$p2_media_cent_economy+data$p3_media_cent_economy+data$p4_media_cent_economy
data$media_cent_isis<- data$p2_media_cent_isis+data$p3_media_cent_isis+data$p4_media_cent_isis

data$media_left_immigr<- data$p2_media_left_immigr+data$p3_media_left_immigr+data$p4_media_left_immigr
data$media_left_eu<- data$p2_media_left_eu+data$p3_media_left_eu+data$p4_media_left_eu
data$media_left_economy<- data$p2_media_left_economy+data$p3_media_left_economy+data$p4_media_left_economy
data$media_left_isis<- data$p2_media_left_isis+data$p3_media_left_isis+data$p4_media_left_isis


save.image("combined_tweets.RData")
