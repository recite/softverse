
windows(height=5,width=8.5)
par(mar=c(3, 2.5, 2, 1),mfrow=c(1,2))
par(mgp = c(1.75, 0.5, 0))
prob1 <- c(7.3,11.3,17.1,24.7,34.2,45,56.2,66.8,76.1,83.5,89.1)
se1 <- c(2.8,3.3,3.6,3.5,3,2.9,3.6,4.6,5,4.8,4.2)
adv <- c(-20,-16,-12,-8,-4,0,4,8,12,16,20)
plot(adv,prob1/100,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Candidate A Spatial Advantage",ylab="Predicted Probability of Supporting Candidate A",main="Convergence Condition")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob1/100-1.96*se1/100,adv,prob1/100+1.96*se1/100,lwd=2)


prob2 <- c(23.6,26.9,30.4,34.1,37.9,42,46.1,50.3,54.4,58.5,62.5)
se2 <- c(3.1,3.1,3,3,3,3,3.1,3.2,3.4,3.6,3.8)
plot(adv,prob2/100,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Candidate A Spatial Advantage",ylab="Predicted Probability of Supporting Candidate A",main="Divergence Condition")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob2/100-1.96*se2/100,adv,prob2/100+1.96*se2/100,lwd=2)



