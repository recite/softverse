library(foreign)
library(arm)
library(lme4)


#######################
## Read in 2006 data ##
#######################

data2006 <- read.dta("CCES 2006.dta")

#######################
## Read in 2010 data ##
#######################
data2010 <- read.dta("CCES 2010.dta")


#########################
## Results for Table 1 ##
#########################

## Column 1 ##
display(lmer1.2006.1 <- lmer(repactualvote ~ rep_advantage_quad + female+ age_recode + pid+inc + factor(race) + educ + inc_party + (1|st_id)+(1+rep_advantage_quad|cluster),data=data2006,family=binomial))

## Column 2 ##
display(lmer1.2010.2 <- lmer(rhousevote ~ r_adv_quad + educ + female + black + hispanic + age + income +  pid7  + incumbent_party + (1|st) + (1 + r_adv_quad|cluster),family=binomial,data=data2010))

## Column 3 ##
display(lmer1.2006.3 <- lmer(repactualvote ~ rep_advantage_quad*polarization+ female+ age_recode + pid+inc + factor(race) + educ + inc_party + (1|st_id)+(1+rep_advantage_quad|cluster),data=data2006,family=binomial))

## Column 4 ##
display(lmer1.2010.4 <- lmer(rhousevote ~ r_adv_quad*divergence+ educ + female + black + hispanic + age + income + pid7  + incumbent_party + (1|st) + (1 + r_adv_quad|cluster),family=binomial,data=data2010))






