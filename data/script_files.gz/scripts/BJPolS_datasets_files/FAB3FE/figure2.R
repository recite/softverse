windows(height=8.5,width=8.5)
par(mar=c(3, 2.5, 2, 1),mfrow=c(2,2))
par(mgp = c(1.75, 0.5, 0))
prob1 <- c(.002,.007,.036,.171,.538,.865,.971,.994,.999)
se1 <- c(.001,.005,.014,.031,.053,.044,.018,.005,.002)
adv <- c(-4,-3,-2,-1,0,1,2,3,4)
plot(adv,prob1,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Republican candidate advantage",ylab="Predicted probability of Republican vote",main="Convergence (2006)")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob1-1.96*se1,adv,prob1+1.96*se1,lwd=1)


prob2 <- c(.067,.129,.238,.403,.588,.756,.864,.929,.961)
se2 <- c(.035,.046,.049,.045,.054,.062,.059,.04,.031)
plot(adv,prob2,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Republican candidate advantage",ylab="Predicted Probability of Republican vote",main="Divergence (2006)")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob2-1.96*se2,adv,prob2+1.96*se2,lwd=1)



prob1 <- c(.052,.118,.257,.471,.696,.856,.938,.975,.99)
se1 <- c(.007,.013,.019,.023,.02,.014,.008,.004,.002)
adv <- c(-4,-3,-2,-1,0,1,2,3,4)
plot(adv,prob1,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Republican candidate advantage",ylab="Predicted probability of Republican vote",main="Convergence (2010)")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob1-1.96*se1,adv,prob1+1.96*se1,lwd=1)


prob2 <- c(.252,.352,.467,.586,.693,.786,.855,.904,.939)
se2 <- c(.021,.023,.023,.023,.022,.018,.015,.012,.009)
plot(adv,prob2,ylim=c(0,1),yaxt="n",pch=20,cex=1.5,cex.lab=0.8,cex.axis=0.6,cex.main=.9,xlab="Republican candidate advantage",ylab="Predicted Probability of Republican vote",main="Divergence (2010)")
axis(2,at=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),las=2,lab=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0),cex.axis=0.6)
segments(adv,prob2-1.96*se2,adv,prob2+1.96*se2,lwd=1)
