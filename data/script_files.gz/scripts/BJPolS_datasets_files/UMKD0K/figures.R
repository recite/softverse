
#################### Figure 3
data <- read_dta("noncitizenvoting.dta")


x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=.9)
plot(bty="n",x,y,pch=20,xlim=c(-183,183),ylim=c(0,.4),col="gray",xlab="",ylab="p(Vote 2015)",main="",type="n",xaxt="n")
axis(1,at=c(-150,-100,-50,0,50, 100,150) )
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.96
max <- pred.c$fit +  pred.c$s*1.96
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)
x <- data$days[data$days>0]
y <- data$vote[data$days>0]
lo <- loess(y~x,span=.9)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.96
max <- pred.c$fit +  pred.c$s*1.96
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)
grid()



############### Figure 4

data <- read_dta("noncitizenvoting.dta")

par(mfrow=c(2,2),mar=c(3,3,3,3))
rdplot(data$vote[(data$days > -100 & data$days < 100) & data$eiu_dpc < 6.5],data$days[(data$days > -100 & data$days < 100) & data$eiu_dpc < 6.5],p=1,y.lim=c(.0,.4),numbinl=10,numbinr=10,x.label="",y.label="",col.dots="gray",title="Weak Democratic Culture",bty="n")
grid(ny=NULL,nx=0)

rdplot(data$vote[(data$days > -110 & data$days < 110) & data$eiu_dpc >= 6.5],data$days[(data$days > -110 & data$days < 110) & data$eiu_dpc >= 6.5],p=1,y.lim=c(.0,.65),numbinl=10,numbinr=10,x.label="",y.label="",col.dots="gray",title="Strong Democratic Culture",bty="n")
grid(ny=NULL,nx=0)


rdplot(data$vote[(data$days > -99 & data$days < 99) & data$dem_wholelife==0],data$days[(data$days > -100 & data$days < 99)  & data$dem_wholelife==0],p=1,y.lim=c(.0,.4),numbinl=25,numbinr=25,x.label="",y.label="",col.dots="gray",title="Not Raised in a Democracy",bty="n")
grid(ny=NULL,nx=0)

rdplot(data$vote[(data$days > -109 & data$days < 109)   & data$dem_wholelife==1],data$days[(data$days > -109 & data$days < 109)  & data$dem_wholelife==1],p=1,y.lim=c(.0,.65),numbinl=10,numbinr=10,x.label="",y.label="",col.dots="gray",title="Raised in a Democracy",bty="n")
grid(ny=NULL,nx=0)






############ Figure A-3

data <- read_dta("noncitizenvoting.dta")

par(mfrow=c(1,2))
rdplot(data$vote[data$days > -64 & data$days < 64],data$days[data$days > -64 & data$days < 64],p=1,y.lim=c(.1,.35),numbinl=0,numbinr=0,x.label="",y.label="",col.dots="gray",title="First Order",bty="n")
grid(ny=NULL,nx=0)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=.9)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='gray', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)
x <- data$days[data$days>0]
y <- data$vote[data$days>0]
lo <- loess(y~x,span=.9)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='gray', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)

rdplot(data$vote[data$days > -74 & data$days < 74],data$days[data$days > -74 & data$days < 74],p=2,y.lim=c(.1,.35),numbinl=0,numbinr=0,x.label="",y.label="",col.dots="gray",title="Second Order",bty="n",xaxt="n")
axis(1,at=c(-60,-40,-20,0,20,40,60) )
grid(ny=NULL,nx=0)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=.9)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='gray', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)
x <- data$days[data$days>0]
y <- data$vote[data$days>0]
lo <- loess(y~x,span=.9)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='gray', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
rug(x,col="lightgray",lwd=.01)




####### Figure A-4
# Bandwidths from stata
data <- read.dta("bandwidths.dta")
data <- subset(data,data$group == 1)
plot(y=data[,1],x=data[,3],type="n",main="",ylim=c(-.05,.15),xlab="Bandwidth: Days",ylab="Effect Size")
abline(h=0,lty=3)

for (i in 1:nrow(data)){
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.64*data[i,2],data[i,1] + 1.64*data[i,2]),lwd=2,col="darkgray")
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.96*data[i,2],data[i,1] + 1.96*data[i,2]),lwd=1,col="darkgray")
	points(y=data[i,1],x=data[i,3],pch=19,cex=.5)
}

####### Figure A-5


par(mfrow=c(1,2))
## EIU
data <- read.dta("noncitizenvoting.dta")
data <- subset(data,data$days > -183 & data$days <183)
data <- subset(data,data$eiu_dpc >= 6.5)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=1.5)
plot(bty="n",x,y,pch=20,xlim=c(-185,185),ylim=c(0,.6),col="gray",xlab="",ylab="p(Vote 2015)",type="n",xaxt="n",main="Democratic Culture")
axis(1,at=c(-150,-100,-50,0,50, 100,150) )
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1,lty=3)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("lightblue",alpha.f=0.4),border="white")
x <- data$days[data$days>=0]
y <- data$vote[data$days>=0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1,lty=3)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("lightblue",alpha.f=0.4),border="white")
data <- read.dta("noncitizenvoting_r_eiu.dta")
data <- subset(data,data$days > -183 & data$days <183)
data <- subset(data,data$eiu_dpc < 6.5)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
x <- data$days[data$days>=0]
y <- data$vote[data$days>=0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
grid()


## bmr
data <- read.dta("noncitizenvoting.dta")
data <- subset(data,data$days > -183 & data$days <183)
data <- subset(data,data$dem_wholelife==1)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=1.5)
plot(bty="n",x,y,pch=20,xlim=c(-180,180),ylim=c(0,.6),col="gray",xlab="",ylab="p(Vote 2015)",type="n",xaxt="n",main="Born in a Democracy")
axis(1,at=c(-150,-100,-50,0,50, 100,150) )
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1,lty=3)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("lightblue",alpha.f=0.4),border="white")
x <- data$days[data$days>=0]
y <- data$vote[data$days>=0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1,lty=3)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("lightblue",alpha.f=0.4),border="white")
data <- read.dta("noncitizenvoting_r_bmr.dta")
data <- subset(data,data$days > -183 & data$days <183)
data <- subset(data,data$dem_wholelife==0)
x <- data$days[data$days<0]
y <- data$vote[data$days<0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
x <- data$days[data$days>=0]
y <- data$vote[data$days>=0]
lo <- loess(y~x,span=1.5)
xl <- seq(min(x,na.rm=T),max(x,na.rm=T), (max(x,na.rm=T) - min(x,na.rm=T))/1000)
pred.c <- predict(lo,xl,se=T)
lines(xl, pred.c$fit, col='black', lwd=1)
min <- pred.c$fit -  pred.c$s*1.9
max <- pred.c$fit +  pred.c$s*1.9
polygon(c(xl,rev(xl)),c(max,rev(min)),col=adjustcolor("gray",alpha.f=0.4),border="white")
grid()



####### Figure A-6

par(mfrow=c(1,2))

data <- read.dta("bandwidths.dta")
data <- subset(data,data$group == 2)
plot(y=data[,1],x=data[,3],type="n",main="Weak Democratic Culture",ylim=c(-.05,.15),xlab="Bandwidth: Days",ylab="Effect Size")
abline(h=0,lty=3)

for (i in 1:nrow(data)){
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.64*data[i,2],data[i,1] + 1.64*data[i,2]),lwd=2,col="darkgray")
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.96*data[i,2],data[i,1] + 1.96*data[i,2]),lwd=1,col="darkgray")
	points(y=data[i,1],x=data[i,3],pch=19,cex=.5)
}

data <- read.dta("bandwidths.dta")
data <- subset(data,data$group == 3)
plot(y=data[,1],x=data[,3],type="n",main="Not Born in a Democracy",ylim=c(-.05,.15),xlab="Bandwidth: Days",ylab="Effect Size")
abline(h=0,lty=3)

for (i in 1:nrow(data)){
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.64*data[i,2],data[i,1] + 1.64*data[i,2]),lwd=2,col="darkgray")
	lines(x=c(data[i,3],data[i,3]),y=c(data[i,1] - 1.96*data[i,2],data[i,1] + 1.96*data[i,2]),lwd=1,col="darkgray")
	points(y=data[i,1],x=data[i,3],pch=19,cex=.5)
}

