

#EDUCATION


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c(0.037,0.053,0.076 ,0.064,0.063, 0.071)
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)


min.vec <- c(-0.035,-0.009 ,0.019 ,0.016,0.013,0.008 )
max.vec <- c( 0.128, 0.120,0.134,0.115,  0.115 ,  0.137)
var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)", "5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis




par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Education")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.



#Health


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c( -0.019, -0.006 ,-0.010,-0.001,	0.027,	0.002)
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)


min.vec <- c(-0.092,-0.063 , -0.062, -0.048, -0.018,-0.055 )
max.vec <- c( 0.054 ,0.050, 0.042, 0.046, 0.074,0.058)

var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Health")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.

#UNEMPLOYMENT


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c( -0.002 ,-0.012,-0.025, -0.020,-0.004, -0.014)
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)

min.vec <- c(-0.105, -0.085, -0.094 ,-0.079,-0.064 , -0.084  )

max.vec <- c(0.099, 0.060, 0.043, 0.038,0.056, 0.057)

var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Unemployment")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.



#Retirement


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c( -0.038, -0.049, -0.060, -0.051, -0.036 , -0.050 )

#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)
min.vec <- c(-0.113  ,-0.109,-0.115, -0.098, -0.083, -0.105  )
max.vec <- c( 0.039, 0.010, -0.006,-0.004, 0.014,0.006)


var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Retirement")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.


