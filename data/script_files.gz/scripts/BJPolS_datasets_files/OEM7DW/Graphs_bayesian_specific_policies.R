

#EDUCATION


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c(-0.007,	0.037,	0.029,0.020, 0.010 , 0.000)
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)
min.vec <- c( -0.046, 0.005 , -0.008 , -0.0212, -0.037 , -0.056)
max.vec <- c( 0.033, 0.071, 0.068,  0.061, 0.058, 0.054)
var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)", "5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis




par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Education")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.



#Health


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c(-0.045,-0.021 ,-0.029 ,	-0.038,0.001, -0.032)
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)
min.vec <- c(-0.106, -0.067 ,-0.077, -0.078, -0.038,-0.081)
max.vec <- c(0.019,0.026, 0.019,0.001,0.041, 0.017)

var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Health")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.

#UNEMPLOYMENT


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c(-0.050, -0.070, -0.084, -0.066, -0.070 ,-0.07 )
#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)

min.vec <- c(-0.111 , -0.134 ,-0.139,-0.113 ,-0.140 ,-0.13)
max.vec <- c(0.010,-0.009,-0.029,-0.018,0.002,0.00)

var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Unemployment")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.



#Retirement


#Create vectors for coefficients, standard errors and variable names 
#we place coefficient as last element in each vector rather than 1st
#since it is least important predictor, and thus we place it at the bottom of the graph
#note: we exclude the constant, since it is substantively meaningless
coef.vec <- c( 0.009, -0.003 ,-0.008,-0.004, 0.000, -0.002 )

#se.vec <- c (-0.02, 0.02,-0.05, 0, 0,0.05)
min.vec <- c( -0.063,-0.063,-0.066, -0.055,-0.044,-0.057)
max.vec <- c( 0.085 , 0.058 ,  0.049 ,  0.049, 0.046 ,0.056)


var.names <- c( "(t-1)", "(t-2)","(t-3)", "(t-4)", "(t-5)","5 years \n average")
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis


par(mar=c(2,6,2,0))#set margins for plot, leaving lots of room on left-margin (2nd number in margin command) for variable names
plot(coef.vec, y.axis, type = "p", axes = F, xlab = "", ylab = "", pch = 19, cex = 1,#plot coefficients as points, turning off axes and labels. 
     xlim = c(-0.15,0.15), xaxs = "r", main = "") #set limits of x-axis so that they include mins and maxs of 
#coefficients + .95% confidence intervals and plot is symmetric; use "internal axes", and leave plot title empty
#the 3 lines below create horiztonal lines for 95% confidence intervals, and vertical ticks for 90% intervals
segments(min.vec, y.axis, max.vec, y.axis, lwd =  1.5)#coef +/-1.96*se = 95% interval, lwd adjusts line thickness
#if you want to add tick marks for 90% confidence interval, use following 2 lines:
#segments(coef.vec-qnorm(.95)*se.vec, y.axis -.1, coef.vec-qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)#coef +/-1.64*se = 90% interval
#segments(coef.vec+qnorm(.95)*se.vec, y.axis -.1, coef.vec+qnorm(.95)*se.vec, y.axis +.1, lwd = 1.1)
axis(1, at = seq(-0.15,0.15,by=0.05), labels = NA, tick = T,#draw x-axis and labels with tick marks
     cex.axis = .2, mgp = c(1,.5,0))#reduce label size, moves labels closer to tick marks
axis(1, at = seq(-0.15,0.15,by=0.05), labels =  c(-0.15,-0.1,-0.05,0,0.05,0.1,0.15), tick = T,#draw x-axis and labels with tick marks
     cex.axis = 1, mgp = c(0.5,.7,0))#reduce label size, moves labels closer to tick marks    
#axis(3, at = seq(-2.5,2.5,by=.5), labels =  seq(-2.5,2.5,by=.5), tick = T, las  = 1,#same as x-axis, but on top axis so 
#    line =0, cex.axis = .8, mgp = c(2,.7,0))                                            #it's easier to lookup coefs at top of graph
axis(2, at = y.axis, label = var.names, las = 1, tick = T, mgp = c(1,1,0),
     cex.axis =1)
segments(0,0,0,17,lty=2)# draw dotted line through 0
#box(bty = "l") #place box around plot
title(main="Retirement")
#use following code to place model info into plot region
#x.height <- .57
#text(x.height, 10, expression(R^{2} == .15), adj = 0, cex = 1) #add text for R-squared
#text(x.height, 9, expression(paste("Adjusted ", R^{2} == ".12", "")), adj = 0, cex = 1)#add text for Adjusted-R-squared
#text(x.height, 8, "n = 500", adj = 0, cex = 1)#add text for sample size
#segments(1.1, 2.7, 1.1,5.3)#use 3 segment commands to draw box around text; connect to  right-side of box 
#segments(1.1, 2.7, 5,2.7)
#segments(1.1, 5.3, 5.2,5.3)

#dev.off() #turn off pdf device; graph is created in working directory.


