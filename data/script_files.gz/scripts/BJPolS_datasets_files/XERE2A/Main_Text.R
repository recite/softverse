# Replication code for "Wartime Violence and Post-War Women's Representation" (Main text)

# clear workspace
rm(list=ls())

# install relevant packages before loading them 
# install.packages("multiwayvcov")
# install.packages("lmtest")

# load packages
library(multiwayvcov)
library(lmtest)

# ensure that you have set the appropriate working directory
# setwd("...")

dataCandidates <- read.csv("Candidates_Data.csv")
dataCouncilors <- read.csv("Councilors_Data.csv")
dataCandidates <- dataCandidates[1:87,]

##### Descriptive statistics discussed in the main text #####

# range of Candidates
round(range(dataCandidates$Candidates),2)
# mean of Candidates
round(mean(dataCandidates$Candidates),2)

# average number of total candidates
round(mean(dataCandidates$Total_candidates),0)
# average number of female candidates
round(mean(dataCandidates$Female_candidates),0)

# range of Councilors for 1990
round(range(dataCandidates$Y1990_councilors),2)
# mean of Councilors for 1990
round(mean(dataCandidates$Y1990_councilors),2)

# range of Councilors for 2000
round(range(dataCandidates$Councilors_2000),2)
# mean of Councilors for 2000
round(mean(dataCandidates$Councilors_2000),2)

# range of Councilors across 1990 and 2000
round(range(c(dataCandidates$Councilors_2000, dataCandidates$Y1990_councilors)),2)
# mean of Councilors across 1990 and 2000
round(mean(c(dataCandidates$Councilors_2000, dataCandidates$Y1990_councilors)),2)

# average corresponds to three women in 1990
round((mean(dataCandidates$Y1990_councilors)/100)*(mean(dataCandidates$Magnitude_1990)),0)

# average corresponds to five women in 2000
round((mean(dataCandidates$Councilors_2000)/100)*(mean(dataCandidates$Magnitude_2000)),0)

# district magnitude in 1990
round(mean(dataCandidates$Magnitude_1990),0)

# district magnitude in 2000
round(mean(dataCandidates$Magnitude_2000),0)

# range of Casualty
round(range(dataCandidates$Casualty),2)
# mean of Casualty
round(mean(dataCandidates$Casualty),2)

# range of Confirmed dead
round(range(dataCandidates$Confirmed_dead),2)
# mean of Confirmed dead
round(mean(dataCandidates$Confirmed_dead),2)

# mean number of casualties
mean(dataCandidates$Casualties)

# percentage of population in smallest municipality
(mean(dataCandidates$Casualties)/min(dataCandidates$Population_size))*100

# percentage of population in largest municipality
(mean(dataCandidates$Casualties)/max(dataCandidates$Population_size))*100

### NOTE ABOUT RESULTS FROM TABLE 1: please note that models presented in Table 1 test a directional hypothesis (violence has a
### positive association with women's participation) and employ one-tailed t-tests. Therefore, in order to obtain the correct
### p-values, (a) divide the p-values presented in the output by 2 and (b) remember that only positive coefficient estimates
### can be marked as statistically significant.

# Table 1: Wartime Violence and Female Candidates
# Model 1: Candidates
summary(mod1 <- lm(Candidates ~ log_Casualty + Urban_share + Income_per_capita + Ethnic_polarization +
                     Share_of_women + Y1990_councilors, data=dataCandidates))
nobs(mod1)

# substantive interpretation of results from Model 1
min(dataCandidates$log_Casualty)
max(dataCandidates$log_Casualt)
(max(dataCandidates$log_Casualty) - min(dataCandidates$log_Casualty))*0.56020
mean(dataCandidates$Total_candidates)*((max(dataCandidates$log_Casualty) - min(dataCandidates$log_Casualty))*0.56020/100)

# Model 2: Candidates
summary(mod2 <- lm(Candidates ~ log_Confirmed_dead + Urban_share + Income_per_capita + Ethnic_polarization +
                     Share_of_women + Y1990_councilors, data=dataCandidates))
nobs(mod2)

# substantive interpretation of results from Model 2
min(dataCandidates$log_Confirmed_dead)
max(dataCandidates$log_Confirmed_dead)
(max(dataCandidates$log_Confirmed_dead) - min(dataCandidates$log_Confirmed_dead))*0.65060
mean(dataCandidates$Total_candidates)*((max(dataCandidates$log_Confirmed_dead) - min(dataCandidates$log_Confirmed_dead))*0.65060/100)

### NOTE ABOUT RESULTS FROM TABLE 2: please note that models presented in Table 2 test a directional hypothesis (violence has a
### negative association with women's electoral success) and employ one-tailed t-tests. Therefore, in order to obtain the correct
### p-values, (a) divide the p-values presented in the output by 2 and (b) remember that only negative coefficient estimates
### can be marked as statistically significant.

# Table 2: Wartime Violence and Female Candidates
# Model 1: Councilors
mod1 <- lm(Councilors ~ log_Casualty:PrePost + PrePost + Municipality - 1, data=dataCouncilors) 
vcovCL1 <- cluster.vcov(mod1, ~dataCouncilors$Municipality+dataCouncilors$PrePost)
coeftest(mod1, vcovCL1) 
nobs(mod1) 
summary(mod1)$r.squared 

# substantive interpretation of results from Model 1
(max(dataCandidates$log_Casualty) - min(dataCandidates$log_Casualty))*-1.94734
mean(dataCandidates$Magnitude_2000)*((max(dataCandidates$log_Casualty) - min(dataCandidates$log_Casualty))*1.94734/100)

# Model 2: Councilors
mod2 <- lm(Councilors ~ log_Confirmed_dead:PrePost + PrePost + Municipality - 1, data=dataCouncilors) 
vcovCL1 <- cluster.vcov(mod2, ~dataCouncilors$Municipality+dataCouncilors$PrePost)
coeftest(mod2, vcovCL1) 
nobs(mod2) 
summary(mod2)$r.squared 

# substantive interpretation of results from Model 2
(max(dataCandidates$log_Confirmed_dead) - min(dataCandidates$log_Confirmed_dead))*-2.21738
mean(dataCandidates$Magnitude_2000)*((max(dataCandidates$log_Confirmed_dead) - min(dataCandidates$log_Confirmed_dead))*2.21738/100)

