# Replication code for "Figure OA2.2: Variable Heat Maps"

# clear workspace
rm(list=ls())

# ensure that you have set the appropriate working directory
# setwd("...")

# install relevant packages before loading them 
# install.packages("sp")
# install.packages("lattice")
# install.packages("rgdal")
# install.packages("gpclib")
# install.packages("maptools")

# load packages
library(sp)
library(lattice)
library(rgdal)
library(gpclib)
library(maptools)

gpclibPermit()

# load shape file and auxiliary files needed to create heat maps
# bosnia <- readOGR(dsn="...appropriate working directory here...",
#                   layer="bosnia_replication")

# Heat map for "Candidates"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Candidates 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Candidates"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Councilors (in 1990)"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Y1990_councilors 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Councilors (in 1990)"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Councilors (in 2000)"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Councilors_2000 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Councilors (in 2000)"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Change in Councilors (2000 minus 1990)"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Change_In_Councilors 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Change in Councilors (2000 minus 1990)"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Casualty"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Casualty 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Casualty"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "log(Casualty)"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$log_Casualty 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("log(Casualty)"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Confirmed dead"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Confirmed_dead 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Confirmed dead"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "log(Confirmed dead)"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$log_Confirmed_dead 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("log(Confirmed dead)"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Urban share"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Urban_share 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Urban share"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Income per capita"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Income_per_capita 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Income per capita"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Ethnic polarization"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Ethnic_polarization 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Ethnic polarization"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")

# Heat map for "Share of women"
data <- read.csv("Shape_Data.csv") 
names(data) 
d <- bosnia$name
d <- as.character(d)
e <- data$Share_of_women 
name3 <- c("NAME_1", "Churn"); dt2 <- as.data.frame(cbind(d, e), stringsAsFactors=FALSE) 
dt2$e <- as.numeric(dt2$e); colnames(dt2) <- name3; churn <- dt2
bosnia_new <- unionSpatialPolygons(bosnia, bosnia$MUNID)
bosnia_new_new <- SpatialPolygonsDataFrame(bosnia_new, churn) 
pal2 <- colorRampPalette(c("lightgray", "black"))
trellis.par.set(axis.line=list(col=NA))
spplot(bosnia_new_new, "Churn", 
       main=expression("Share of women"), 
       lwd=1, col="gray", col.regions=pal2(109), colorkey=TRUE, bty="n")
