##############
# Replication data for "Behavioral Consequences of Election Outcomes"
#############

####
# Libraries
######


library(tidyverse)
library(ggplot2)
library(rdd)
library(xtable)
library(rdrobust)
library(reshape2)


########
# Preparing the data
#######

#load the final data

#conduct on RD for all race types and separate race types for different outcomes

setwd("~/Dropbox (MIT)/Donors Project")

load('finalStateLegRDData.RData')
merge2 <- subset(merge2, merge2$how_many_recipients == 1)

#states with 4-year Senate terms
sen4 <- c('AL', 'AK', 'CA', 'CO', 'IN', 'IA', 'KS', 'KY', 'LA', 'MD', 'MI', 'MS',
          'MO', 'MT', 'NE', 'NV', 'NM', 'ND', 'OH', 'OK', 'OR', 'PA', 'SC', 'TN',
          'UT', 'VA', 'WA', 'WV', 'WI', 'WY')

sen2 <- c('AZ', 'CT', 'GA', 'ID', 'ME', 'MA', 'NH', 'NY', 'NC', 'RI', 'SD', 'VT')

#lower house - 4 year terms

house4 <- c('AL', 'LA', 'MD', 'MS', 'ND')

merge2$future_other_office <- ifelse(rowSums(merge2[,c(30:32, 34, 36:38, 
                                                       40, 42:44, 46)]) > 0, 1, 0)

merge2$future_same_office_on <- ifelse(merge2$seat.y == 'state.lower',
                                       ifelse(merge2$State %in% house4, 
                                              merge2$future_donor_sl4,
                                              merge2$future_donor_sl2),
                                       ifelse(merge2$State %in% sen4,
                                              merge2$future_donor_sl4,
                                              ifelse(merge2$State %in% sen2,
                                                     merge2$future_donor_sl2, NA)))

merge2$future_same_office <- ifelse(merge2$future_donor_sl2 == 1 | merge2$future_donor_sl4 == 1 | 
                                      merge2$future_donor_sl6 == 1, 1, 0)

merge2$future_same_office_off <- ifelse(merge2$seat.y == 'state.lower',
                                        ifelse(merge2$State %in% house4, 
                                               merge2$future_donor_sl2,
                                               NA),
                                        ifelse(merge2$State %in% sen4,
                                               merge2$future_donor_sl2,
                                               NA))

load('finalUSSenRDData.RData')
mergeSenate <- subset(mergeSenate, mergeSenate$how_many_recipients == 1)

mergeSenate$future_same_office <- ifelse(mergeSenate$future_donor_ussen2 
                                         + mergeSenate$future_donor_ussen4 + 
                                           mergeSenate$future_donor_ussen6>= 1, 1, 0)

mergeSenate$future_same_office_on <- mergeSenate$future_donor_ussen6

mergeSenate$future_same_office_off <- ifelse(mergeSenate$future_donor_ussen2 == 1 |
                                               mergeSenate$future_donor_ussen4 == 1, 1, 0)

mergeSenate$future_other_office <- ifelse(rowSums(mergeSenate[,c(29:30, 32:33, 35:36, 38:39, 41:42,
                                                                 44:45)]) >= 1, 1, 0)

load('finalGovRDData.RData') 
finalGovData <- subset(finalGovData, finalGovData$how_many_recipients == 1)

finalGovData$future_same_office_on <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                             finalGovData$future_donor_gov2, 
                                             finalGovData$future_donor_gov4)

finalGovData$future_same_office_off <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                              NA, 
                                              finalGovData$future_donor_gov2)

finalGovData$future_other_office <- ifelse(rowSums(finalGovData[,c(30:33, 36:39, 42:45)]) >= 1, 1, 0)

finalGovData$future_same_office <- ifelse(finalGovData$future_donor_ussen2 
                                          + finalGovData$future_donor_ussen4 + 
                                            finalGovData$future_donor_ussen6>= 1, 1, 0)


mergeSenate$future_donor <- ifelse(mergeSenate$future_donor2 + mergeSenate$future_donor4 +
                                     mergeSenate$future_donor6 > 0, 1, 0)

merge2$future_donor <- ifelse(merge2$future_donor2 + merge2$future_donor4 +
                                merge2$future_donor6 > 0, 1, 0)

finalGovData$future_donor <- ifelse(finalGovData$future_donor2 + finalGovData$future_donor4 +
                                      finalGovData$future_donor6 > 0, 1, 0)


#export the final data
cols.to.keep <- c('donor_cycle', 'future_same_office_on',
                  'future_same_office_off', 'future_other_office',
                  'future_same_office', 'future_donor',
                  'past_donor', 'cycle', 'bonica_rid', 'amount',
                  'contributor_gender', 'seat.y', 'incumbent.y',
                  'top.two.voteshare', 'cluster')

rd.data <- rbind(merge2[,cols.to.keep], mergeSenate[,cols.to.keep], 
                 finalGovData[,cols.to.keep])


###########
# Table 1 #
###########


# create two subsets: within the bandwidth and left of cutoff, and within bandwidth
# to the right of the cutoff

rd.left <- subset(rd.data, rd.data$top.two.voteshare < .5 &
                    rd.data$top.two.voteshare >= .485)

rd.right <- subset(rd.data, rd.data$top.two.voteshare < .525 &
                    rd.data$top.two.voteshare >= .5)

rd.right.sl <- subset(rd.right, rd.right$seat.y %in% c('state:lower', 'state:upper'))
rd.left.sl <- subset(rd.left, rd.left$seat.y %in% c('state:lower', 'state:upper'))

rd.right.gov <- subset(rd.right, rd.right$seat.y == 'state:governor')
rd.left.gov <- subset(rd.left, rd.left$seat.y == 'state:governor')

rd.right.ussen <- subset(rd.right, rd.right$seat.y == 'federal:senate')
rd.left.ussen <- subset(rd.left, rd.left$seat.y == 'federal:senate')

all.sl <- subset(rd.data, rd.data$seat.y %in% c('state:lower', 'state:upper'))
all.gov <- subset(rd.data, rd.data$seat.y  == 'state:governor')
all.ussen <- subset(rd.data, rd.data$seat.y == 'federal:senate')

#results for Table 1
# note that there are some NAs in the second two columns because of states
#where there is no 
#column 1
mean(all.sl$future_other_office)
mean(rd.left.sl$future_other_office)
mean(rd.right.sl$future_other_office)

mean(all.gov$future_other_office)
mean(rd.left.gov$future_other_office)
mean(rd.right.gov$future_other_office)

mean(all.ussen$future_other_office)
mean(rd.left.ussen$future_other_office)
mean(rd.right.ussen$future_other_office)

#column 2
mean(all.sl$future_same_office_off, na.rm = T)
mean(rd.left.sl$future_same_office_off, na.rm = T)
mean(rd.right.sl$future_same_office_off, na.rm = T)

mean(all.gov$future_same_office_off, na.rm = T)
mean(rd.left.gov$future_same_office_off, na.rm = T)
mean(rd.right.gov$future_same_office_off, na.rm = T)

mean(all.ussen$future_same_office_off)
mean(rd.left.ussen$future_same_office_off)
mean(rd.right.ussen$future_same_office_off)

#column 3
mean(all.sl$future_same_office_on, na.rm = T)
mean(rd.left.sl$future_same_office_on, na.rm = T)
mean(rd.right.sl$future_same_office_on, na.rm = T)

mean(all.gov$future_same_office_on, na.rm = T)
mean(rd.left.gov$future_same_office_on, na.rm = T)
mean(rd.right.gov$future_same_office_on, na.rm = T)

mean(all.ussen$future_same_office_on, na.rm = T)
mean(rd.left.ussen$future_same_office_on, na.rm = T)
mean(rd.right.ussen$future_same_office_on, na.rm = T)


###########
# Table 2 #
###########

#column 2

nrow(all.ussen)
nrow(all.gov)
nrow(all.sl)

#column 3

length(unique(all.ussen$cluster))
length(unique(all.gov$cluster))
length(unique(all.sl$cluster))

#column 4
summary(RDestimate(future_other_office ~ top.two.voteshare, all.ussen,
                   cutpoint = .5, cluster = all.ussen$cluster, 
                   bw = .05))

summary(RDestimate(future_other_office ~ top.two.voteshare, all.gov,
                   cutpoint = .5, cluster = all.gov$cluster, 
                   bw = .05))

summary(RDestimate(future_other_office ~ top.two.voteshare, all.sl,
                   cutpoint = .5, cluster = all.sl$cluster, 
                   bw = .05))

#column 5
summary(RDestimate(future_same_office_on ~ top.two.voteshare, all.ussen,
                   cutpoint = .5, cluster = all.ussen$cluster, 
                   bw = .05))

summary(RDestimate(future_same_office_on ~ top.two.voteshare, all.gov,
                   cutpoint = .5, cluster = all.gov$cluster, 
                   bw = .05))

summary(RDestimate(future_same_office_on ~ top.two.voteshare, all.sl,
                   cutpoint = .5, cluster = all.sl$cluster, 
                   bw = .05))

#column 6
summary(RDestimate(future_same_office_off ~ top.two.voteshare, all.ussen,
                   cutpoint = .5, cluster = all.ussen$cluster, 
                   bw = .05))

summary(RDestimate(future_same_office_off ~ top.two.voteshare, all.gov,
                   cutpoint = .5, cluster = all.gov$cluster, 
                   bw = .05))

summary(RDestimate(future_same_office_off ~ top.two.voteshare, all.sl,
                   cutpoint = .5, cluster = all.sl$cluster, 
                   bw = .05))

#############
# Figure 1 #
############

pdf(file = 'robustness_bw.pdf')

par(mfrow = c(3,3),
    mar = c(0, 2, 1, 0) + .01,
    oma = c(5,2,2,01))

#state leg - future same on


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_on ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_on ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#US Senate
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_on ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#future same office -- off
#state leg
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_off ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_off ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#US Senate
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_same_office_off ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


#future other office


#state leg
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3))

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_other_office ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}



#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3))

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_other_office ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.1,.3))

abline(h = 0, lty = 2)

my.rd <- RDestimate(future_other_office ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


mtext(text = 'State Legislative Donors', side = 3, outer = T,
      at = .17)

mtext(text = 'Governor Donors', side = 3, outer = T,
      at = .5)

mtext(text = 'US Senate Donors', side = 3, outer = T,
      at = .85)

mtext('Same Office - Reelect. Cycle', side = 2, outer = T, at = 0.84)
mtext('Same Office - Other Cycle', side = 2, outer = T, at = 0.47)
mtext('Different Office', side = 2, outer = T, at = 0.15)

dev.off()

