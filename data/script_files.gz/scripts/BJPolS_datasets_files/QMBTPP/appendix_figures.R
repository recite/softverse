##############
# Replication data for "Behavioral Consequences of Election Outcomes"

# The Appendix Figures

#############

#####
# process the data
######


setwd("~/Dropbox (MIT)/Donors Project")

load('finalStateLegRDData.RData')
merge2 <- subset(merge2, merge2$how_many_recipients == 1)

#states with 4-year Senate terms
sen4 <- c('AL', 'AK', 'CA', 'CO', 'IN', 'IA', 'KS', 'KY', 'LA', 'MD', 'MI', 'MS',
          'MO', 'MT', 'NE', 'NV', 'NM', 'ND', 'OH', 'OK', 'OR', 'PA', 'SC', 'TN',
          'UT', 'VA', 'WA', 'WV', 'WI', 'WY')

sen2 <- c('AZ', 'CT', 'GA', 'ID', 'ME', 'MA', 'NH', 'NY', 'NC', 'RI', 'SD', 'VT')

#lower house - 4 year terms

house4 <- c('AL', 'LA', 'MD', 'MS', 'ND')

merge2$future_other_office <- ifelse(rowSums(merge2[,c(30:32, 34, 36:38, 
                                                       40, 42:44, 46)]) > 0, 1, 0)

merge2$future_same_office_on <- ifelse(merge2$seat.y == 'state.lower',
                                       ifelse(merge2$State %in% house4, 
                                              merge2$future_donor_sl4,
                                              merge2$future_donor_sl2),
                                       ifelse(merge2$State %in% sen4,
                                              merge2$future_donor_sl4,
                                              ifelse(merge2$State %in% sen2,
                                                     merge2$future_donor_sl2, NA)))

merge2$future_same_office <- ifelse(merge2$future_donor_sl2 == 1 | merge2$future_donor_sl4 == 1 | 
                                      merge2$future_donor_sl6 == 1, 1, 0)

merge2$future_same_office_off <- ifelse(merge2$seat.y == 'state.lower',
                                        ifelse(merge2$State %in% house4, 
                                               merge2$future_donor_sl2,
                                               NA),
                                        ifelse(merge2$State %in% sen4,
                                               merge2$future_donor_sl2,
                                               NA))

load('finalUSSenRDData.RData')
mergeSenate <- subset(mergeSenate, mergeSenate$how_many_recipients == 1)

mergeSenate$future_same_office <- ifelse(mergeSenate$future_donor_ussen2 
                                         + mergeSenate$future_donor_ussen4 + 
                                           mergeSenate$future_donor_ussen6>= 1, 1, 0)

mergeSenate$future_same_office_on <- mergeSenate$future_donor_ussen6

mergeSenate$future_same_office_off <- ifelse(mergeSenate$future_donor_ussen2 == 1 |
                                               mergeSenate$future_donor_ussen4 == 1, 1, 0)

mergeSenate$future_other_office <- ifelse(rowSums(mergeSenate[,c(29:30, 32:33, 35:36, 38:39, 41:42,
                                                                 44:45)]) >= 1, 1, 0)

load('finalGovRDData.RData') 
finalGovData <- subset(finalGovData, finalGovData$how_many_recipients == 1)

finalGovData$future_same_office_on <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                             finalGovData$future_donor_gov2, 
                                             finalGovData$future_donor_gov4)

finalGovData$future_same_office_off <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                              NA, 
                                              finalGovData$future_donor_gov2)

finalGovData$future_other_office <- ifelse(rowSums(finalGovData[,c(30:33, 36:39, 42:45)]) >= 1, 1, 0)

finalGovData$future_same_office <- ifelse(finalGovData$future_donor_ussen2 
                                          + finalGovData$future_donor_ussen4 + 
                                            finalGovData$future_donor_ussen6>= 1, 1, 0)


mergeSenate$future_donor <- ifelse(mergeSenate$future_donor2 + mergeSenate$future_donor4 +
                                     mergeSenate$future_donor6 > 0, 1, 0)

merge2$future_donor <- ifelse(merge2$future_donor2 + merge2$future_donor4 +
                                merge2$future_donor6 > 0, 1, 0)

finalGovData$future_donor <- ifelse(finalGovData$future_donor2 + finalGovData$future_donor4 +
                                      finalGovData$future_donor6 > 0, 1, 0)


#export the final data
cols.to.keep <- c('donor_cycle', 'future_same_office_on',
                  'future_same_office_off', 'future_other_office',
                  'future_same_office', 'future_donor',
                  'past_donor', 'cycle', 'bonica_rid', 'amount',
                  'contributor_gender', 'seat.y', 'incumbent.y',
                  'top.two.voteshare', 'cluster')

rd.data <- rbind(merge2[,cols.to.keep], mergeSenate[,cols.to.keep], 
                 finalGovData[,cols.to.keep])

all.sl <- subset(rd.data, rd.data$seat.y %in% c('state:lower', 'state:upper'))
all.gov <- subset(rd.data, rd.data$seat.y  == 'state:governor')
all.ussen <- subset(rd.data, rd.data$seat.y == 'federal:senate')

#######
# Figure 1: Mccrary Test for Sorting
#########

#extract the vote share for each candidate

sl.cands <- all.sl[match(unique(all.sl$cluster), all.sl$cluster), 
                   'top.two.voteshare']

pdf(file = 'density_sl.pdf')
DCdensity(sl.cands, cutpoint = .5)
dev.off()

gov.cands <- all.gov[match(unique(all.gov$cluster), all.gov$cluster), 
                   'top.two.voteshare']

pdf(file = 'density_gov.pdf')
DCdensity(gov.cands, cutpoint = .5)
dev.off()

ussen.cands <- all.ussen[match(unique(all.ussen$cluster), all.ussen$cluster), 
                   'top.two.voteshare']

pdf(file = 'density_ussen.pdf')
DCdensity(ussen.cands, cutpoint = .5)
dev.off()

########
#Figure 2: placebo tests -- estimating the effect on pre-treatment variables
########


pdf(file = 'rd_diagnostics.pdf')

par(mfrow = c(3,3),
    mar = c(0, 2, 1, 0) + .01,
    oma = c(5,2,2,01))

#state leg - future same on


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(past_donor ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(past_donor ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#US Senate
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(past_donor ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#future same office -- off
#state leg
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(ifelse(contributor_gender == 'F',1,0) ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(ifelse(contributor_gender == 'F',1,0) ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}

#US Senate
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4),
     xaxt = 'n')

abline(h = 0, lty = 2)

my.rd <- RDestimate(ifelse(contributor_gender == 'F',1,0) ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


#future other office


#state leg
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4))

abline(h = 0, lty = 2)

my.rd <- RDestimate(incumbent.y ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.sl, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.sl$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}



#state governor
plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4))

abline(h = 0, lty = 2)

my.rd <- RDestimate(incumbent.y ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.gov, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.gov$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(0, .16), ylim = c(-.4,.4))

abline(h = 0, lty = 2)

my.rd <- RDestimate(incumbent.y ~ top.two.voteshare, 
                    cutpoint = .5,
                    all.ussen, bw = seq(from = .01, to = .16, by = .005),
                    cluster = all.ussen$cluster)

for(i in 1:31){
  my.est <- my.rd$est[i]
  my.lower <- my.est - my.rd$se[i]*1.96
  my.upper <- my.est + my.rd$se[i]*1.96
  
  points(x = i/200, y = my.est, pch = 16)
  
  segments(x0 = i/200, x1 = i/200, y0 = my.lower, y1 = my.upper,
           lwd = 2)
}


mtext(text = 'State Legislative Donors', side = 3, outer = T,
      at = .17)

mtext(text = 'Governor Donors', side = 3, outer = T,
      at = .5)

mtext(text = 'US Senate Donors', side = 3, outer = T,
      at = .85)

mtext('Past donor', side = 2, outer = T, at = 0.84)
mtext('Female', side = 2, outer = T, at = 0.47)
mtext('Donated to incumbent', side = 2, outer = T, at = 0.15)

dev.off()


#########
# Figure 3: plotting the data
##########


all.sl$constant <- rep(1, nrow(all.sl))
all.gov$constant <- rep(1, nrow(all.gov))
all.ussen$constant <- rep(1, nrow(all.ussen))

pdf(file = 'rdplots_combined.pdf')

par(mfrow = c(3,3),
    mar = c(0, 2, 1, 0) + .01,
    oma = c(5,2,2,01))

#state leg
all.sl$cluster <- as.factor(as.character(all.sl$cluster))

pool.size <- tapply(all.sl$constant, 
                    INDEX = all.sl$cluster,
                    FUN = sum)

vote.shares <- tapply(all.sl$top.two.voteshare, 
                      INDEX = all.sl$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.sl$future_same_office_on, 
                                  INDEX = all.sl$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/100)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)

#state governor
all.gov$cluster <- as.factor(as.character(all.gov$cluster))

pool.size <- tapply(all.gov$constant, 
                    INDEX = all.gov$cluster,
                    FUN = sum)

vote.shares <- tapply(all.gov$top.two.voteshare, 
                      INDEX = all.gov$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.gov$future_same_office_on, 
                                  INDEX = all.gov$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n',
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/1000)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)




all.ussen$cluster <- as.factor(as.character(all.ussen$cluster))

pool.size <- tapply(all.ussen$constant, 
                    INDEX = all.ussen$cluster,
                    FUN = sum)

vote.shares <- tapply(all.ussen$top.two.voteshare, 
                      INDEX = all.ussen$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.ussen$future_same_office_on, 
                                  INDEX = all.ussen$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n',
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/500)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)


right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )

segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)

#future same office -- off
#state leg
all.sl$cluster <- as.factor(as.character(all.sl$cluster))

pool.size <- tapply(all.sl$constant, 
                    INDEX = all.sl$cluster,
                    FUN = sum)

vote.shares <- tapply(all.sl$top.two.voteshare, 
                      INDEX = all.sl$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.sl$future_same_office_off, 
                                  INDEX = all.sl$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/100)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)


#state governor
all.gov$cluster <- as.factor(as.character(all.gov$cluster))

pool.size <- tapply(all.gov$constant, 
                    INDEX = all.gov$cluster,
                    FUN = sum)

vote.shares <- tapply(all.gov$top.two.voteshare, 
                      INDEX = all.gov$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.gov$future_same_office_off, 
                                  INDEX = all.gov$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n',
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/1000)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)

#US Senate

all.ussen$cluster <- as.factor(as.character(all.ussen$cluster))

pool.size <- tapply(all.ussen$constant, 
                    INDEX = all.ussen$cluster,
                    FUN = sum)

vote.shares <- tapply(all.ussen$top.two.voteshare, 
                      INDEX = all.ussen$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.ussen$future_same_office_off, 
                                  INDEX = all.ussen$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     xaxt = 'n',
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/500)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )

segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)


#future other office


#state leg
all.sl$cluster <- as.factor(as.character(all.sl$cluster))

pool.size <- tapply(all.sl$constant, 
                    INDEX = all.sl$cluster,
                    FUN = sum)

vote.shares <- tapply(all.sl$top.two.voteshare, 
                      INDEX = all.sl$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.sl$future_other_office, 
                                  INDEX = all.sl$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = 'Top-two Vote Share',
     xlim = c(.475, .525), ylim = c(0,.6))

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/100)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)



#state governor
all.gov$cluster <- as.factor(as.character(all.gov$cluster))

pool.size <- tapply(all.gov$constant, 
                    INDEX = all.gov$cluster,
                    FUN = sum)

vote.shares <- tapply(all.gov$top.two.voteshare, 
                      INDEX = all.gov$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.gov$future_other_office, 
                                  INDEX = all.gov$cluster,
                                  FUN = mean)


plot(1000, main = '',
     ylab = '',
     xlab = 'Top-two Vote Share',
     xlim = c(.475, .525), ylim = c(0,.6),
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/1000)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)

right.lm <- lm(future.same.office[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )
segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)


all.ussen$cluster <- as.factor(as.character(all.ussen$cluster))

pool.size <- tapply(all.ussen$constant, 
                    INDEX = all.ussen$cluster,
                    FUN = sum)

vote.shares <- tapply(all.ussen$top.two.voteshare, 
                      INDEX = all.ussen$cluster,
                      FUN = mean)

future.same.office.reel <- tapply(all.ussen$future_other_office,
                                  INDEX = all.ussen$cluster,
                                  FUN = mean)

#plot

plot(1000, main = '',
     ylab = '',
     xlab = '',
     xlim = c(.475, .525), ylim = c(0,.6),
     yaxt = 'n')

abline(v = .5, lty = 2)

points(future.same.office.reel ~ vote.shares, 
       pch = 16, col = rgb(.33, .33, .33, alpha = .2),
       cex = pool.size/500)

#plot the linear regression

#left

#subset
left.lm <- lm(future.same.office.reel[vote.shares >= .475 &  vote.shares < .5] 
              ~ vote.shares[vote.shares >= .475 &  vote.shares < .5], 
              w = pool.size[vote.shares >= .475 &  vote.shares < .5] )

segments(y0 = left.lm$coefficients[1] + .46*left.lm$coefficients[2],
         y1 = left.lm$coefficients[1] + .5*left.lm$coefficients[2],
         x0 = .46, x1 = .5)


right.lm <- lm(future.same.office.reel[vote.shares >= .5 &  vote.shares < .525] 
               ~ vote.shares[vote.shares >= .5 &  vote.shares < .525], 
               w = pool.size[vote.shares >= .5 &  vote.shares < .525] )

segments(y0 = right.lm$coefficients[1] + .5*right.lm$coefficients[2],
         y1 = right.lm$coefficients[1] + .53*right.lm$coefficients[2],
         x0 = .5, x1 = .53)


mtext(text = 'State Legislative Donors', side = 3, outer = T,
      at = .17)

mtext(text = 'Governor Donors', side = 3, outer = T,
      at = .5)

mtext(text = 'US Senate Donors', side = 3, outer = T,
      at = .85)

mtext('Same Office - Reelect. Cycle', side = 2, outer = T, at = 0.84)
mtext('Same Office - Other Cycle', side = 2, outer = T, at = 0.47)
mtext('Different Office', side = 2, outer = T, at = 0.15)

dev.off()


load('finalStateLegRDData.RData')
sen4 <- c('AL', 'AK', 'CA', 'CO', 'IN', 'IA', 'KS', 'KY', 'LA', 'MD', 'MI', 'MS',
          'MO', 'MT', 'NE', 'NV', 'NM', 'ND', 'OH', 'OK', 'OR', 'PA', 'SC', 'TN',
          'UT', 'VA', 'WA', 'WV', 'WI', 'WY')

sen2 <- c('AZ', 'CT', 'GA', 'ID', 'ME', 'MA', 'NH', 'NY', 'NC', 'RI', 'SD', 'VT')

#lower house - 4 year terms

house4 <- c('AL', 'LA', 'MD', 'MS', 'ND')

#not staggered

not.staggered <- c('AL', 'KS', 'LA', 'MD', 'MI', 'MS', 'NM', 'SC', 'VA')

merge2$future_other_office <- ifelse(rowSums(merge2[,c(30:32, 34, 36:38, 
                                                       40, 42:44, 46)]) > 0, 1, 0)

merge2$future_same_office_on <- ifelse(merge2$seat.y == 'state.lower',
                                       ifelse(merge2$State %in% house4, 
                                              merge2$future_donor_sl4,
                                              merge2$future_donor_sl2),
                                       ifelse(merge2$State %in% sen4,
                                              merge2$future_donor_sl4,
                                              ifelse(merge2$State %in% sen2,
                                                     merge2$future_donor_sl2, NA)))

merge2$future_same_office <- ifelse(merge2$future_donor_sl2 == 1 | merge2$future_donor_sl4 == 1 | 
                                      merge2$future_donor_sl6 == 1, 1, 0)

merge2$future_same_office_off <- ifelse(merge2$seat.y == 'state.lower',
                                        ifelse(merge2$State %in% house4, 
                                               merge2$future_donor_sl2,
                                               NA),
                                        ifelse(merge2$State %in% sen4,
                                               merge2$future_donor_sl2,
                                               NA))
load('finalUSSenRDData.RData')


mergeSenate$future_same_office <- ifelse(mergeSenate$future_donor_ussen2 
                                         + mergeSenate$future_donor_ussen4 + 
                                           mergeSenate$future_donor_ussen6>= 1, 1, 0)

mergeSenate$future_same_office_on <- mergeSenate$future_donor_ussen6

mergeSenate$future_same_office_off <- ifelse(mergeSenate$future_donor_ussen2 == 1 |
                                               mergeSenate$future_donor_ussen4 == 1, 1, 0)

mergeSenate$future_other_office <- ifelse(rowSums(mergeSenate[,c(29:30, 32:33, 35:36, 38:39, 41:42,
                                                                 44:45)]) >= 1, 1, 0)

load('finalGovRDData.RData') 

finalGovData$future_same_office_on <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                             finalGovData$future_donor_gov2, 
                                             finalGovData$future_donor_gov4)

finalGovData$future_same_office_off <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                              NA, 
                                              finalGovData$future_donor_gov2)

finalGovData$future_other_office <- ifelse(rowSums(finalGovData[,c(30:33, 36:39, 42:45)]) >= 1, 1, 0)

finalGovData$future_same_office <- ifelse(finalGovData$future_donor_ussen2 
                                          + finalGovData$future_donor_ussen4 + 
                                            finalGovData$future_donor_ussen6>= 1, 1, 0)

#first, donating in the future in general

mergeSenate$future_donor <- ifelse(mergeSenate$future_donor2 + mergeSenate$future_donor4 +
                                     mergeSenate$future_donor6 > 0, 1, 0)

merge2$future_donor <- ifelse(merge2$future_donor2 + merge2$future_donor4 +
                                merge2$future_donor6 > 0, 1, 0)

finalGovData$future_donor <- ifelse(finalGovData$future_donor2 + finalGovData$future_donor4 +
                                      finalGovData$future_donor6 > 0, 1, 0)


#subset to include only candidates within a 5% bandwidth

ussen.close <- subset(mergeSenate, abs(mergeSenate$top.two.voteshare - .5 ) <= .05)
stateleg.close <- subset(merge2, abs(merge2$top.two.voteshare - .5 ) <= .05)
gov.close <- subset(finalGovData, abs(finalGovData$top.two.voteshare - .5 ) <= .05)

#code how many candidates total that donor gave to in that cycle

#create a donor-cycle variable

all.close <- bind_rows(ussen.close,
                       stateleg.close,
                       gov.close)

all.close$cand.won <- ifelse(all.close$top.two.voteshare >= .5, 1, 0)

obj <- c()
for(my.cycle in seq(from = 1990, to = 2004, by = 2)){
  
  my.sub <- subset(all.close, all.close$cycle == my.cycle)
  total.sums <- tapply(my.sub$constant, INDEX = my.sub$bonica_cid, FUN = sum)
  total.win.sums <- tapply(my.sub$cand.won, INDEX = my.sub$bonica_cid, FUN = sum)
  
  #merge outcomes too
  future.donor<- tapply(my.sub$future_donor, 
                        INDEX = my.sub$bonica_cid, FUN = mean)
  
  obj <- rbind(obj, cbind(total.sums, total.win.sums, 
                          future.donor,
                          names(total.sums),
                          rep(my.cycle, length(total.sums))))
  
}

obj <- as.data.frame(obj)

summary(obj)

# for each number of recipient candidates

obj$future.donor <- as.numeric(as.character(obj$future.donor))

obj$total.win.sums <- as.numeric(as.character(obj$total.win.sums))

one.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 1,])
two.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 2,])
three.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 3,])

summary(one.cand.lm)
summary(two.cand.lm)
summary(three.cand.lm)

stargazer(one.cand.lm, two.cand.lm, three.cand.lm)
