##############
# Replication data for "Behavioral Consequences of Election Outcomes"

# The Appendix Figures

#############

library(stargazer)


#load and process the data

load('finalStateLegRDData.RData')

sen4 <- c('AL', 'AK', 'CA', 'CO', 'IN', 'IA', 'KS', 'KY', 'LA', 'MD', 'MI', 'MS',
          'MO', 'MT', 'NE', 'NV', 'NM', 'ND', 'OH', 'OK', 'OR', 'PA', 'SC', 'TN',
          'UT', 'VA', 'WA', 'WV', 'WI', 'WY')

sen2 <- c('AZ', 'CT', 'GA', 'ID', 'ME', 'MA', 'NH', 'NY', 'NC', 'RI', 'SD', 'VT')

#lower house - 4 year terms

house4 <- c('AL', 'LA', 'MD', 'MS', 'ND')

merge2$future_other_office <- ifelse(rowSums(merge2[,c(30:32, 34, 36:38, 
                                                       40, 42:44, 46)]) > 0, 1, 0)

merge2$future_same_office_on <- ifelse(merge2$seat.y == 'state.lower',
                                       ifelse(merge2$State %in% house4, 
                                              merge2$future_donor_sl4,
                                              merge2$future_donor_sl2),
                                       ifelse(merge2$State %in% sen4,
                                              merge2$future_donor_sl4,
                                              ifelse(merge2$State %in% sen2,
                                                     merge2$future_donor_sl2, NA)))

merge2$future_same_office <- ifelse(merge2$future_donor_sl2 == 1 | merge2$future_donor_sl4 == 1 | 
                                      merge2$future_donor_sl6 == 1, 1, 0)

merge2$future_same_office_off <- ifelse(merge2$seat.y == 'state.lower',
                                        ifelse(merge2$State %in% house4, 
                                               merge2$future_donor_sl2,
                                               NA),
                                        ifelse(merge2$State %in% sen4,
                                               merge2$future_donor_sl2,
                                               NA))
load('finalUSSenRDData.RData')


mergeSenate$future_same_office <- ifelse(mergeSenate$future_donor_ussen2 
                                         + mergeSenate$future_donor_ussen4 + 
                                           mergeSenate$future_donor_ussen6>= 1, 1, 0)

mergeSenate$future_same_office_on <- mergeSenate$future_donor_ussen6

mergeSenate$future_same_office_off <- ifelse(mergeSenate$future_donor_ussen2 == 1 |
                                               mergeSenate$future_donor_ussen4 == 1, 1, 0)

mergeSenate$future_other_office <- ifelse(rowSums(mergeSenate[,c(29:30, 32:33, 35:36, 38:39, 41:42,
                                                                 44:45)]) >= 1, 1, 0)

load('finalGovRDData.RData') 

finalGovData$future_same_office_on <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                             finalGovData$future_donor_gov2, 
                                             finalGovData$future_donor_gov4)

finalGovData$future_same_office_off <- ifelse(finalGovData$State %in% c('NH', 'VT'),
                                              NA, 
                                              finalGovData$future_donor_gov2)

finalGovData$future_other_office <- ifelse(rowSums(finalGovData[,c(30:33, 36:39, 42:45)]) >= 1, 1, 0)

finalGovData$future_same_office <- ifelse(finalGovData$future_donor_ussen2 
                                          + finalGovData$future_donor_ussen4 + 
                                            finalGovData$future_donor_ussen6>= 1, 1, 0)

#first, donating in the future in general

mergeSenate$future_donor <- ifelse(mergeSenate$future_donor2 + mergeSenate$future_donor4 +
                                     mergeSenate$future_donor6 > 0, 1, 0)

merge2$future_donor <- ifelse(merge2$future_donor2 + merge2$future_donor4 +
                                merge2$future_donor6 > 0, 1, 0)

finalGovData$future_donor <- ifelse(finalGovData$future_donor2 + finalGovData$future_donor4 +
                                      finalGovData$future_donor6 > 0, 1, 0)


#subset to include only candidates within a 5% bandwidth

ussen.close <- subset(mergeSenate, abs(mergeSenate$top.two.voteshare - .5 ) <= .05)
stateleg.close <- subset(merge2, abs(merge2$top.two.voteshare - .5 ) <= .05)
gov.close <- subset(finalGovData, abs(finalGovData$top.two.voteshare - .5 ) <= .05)

#code how many candidates total that donor gave to in that cycle

#create a donor-cycle variable

all.close <- bind_rows(ussen.close,
                       stateleg.close,
                       gov.close)

all.close$cand.won <- ifelse(all.close$top.two.voteshare >= .5, 1, 0)

obj <- c()
for(my.cycle in seq(from = 1990, to = 2004, by = 2)){
  
  my.sub <- subset(all.close, all.close$cycle == my.cycle)
  total.sums <- tapply(my.sub$constant, INDEX = my.sub$bonica_cid, FUN = sum)
  total.win.sums <- tapply(my.sub$cand.won, INDEX = my.sub$bonica_cid, FUN = sum)
  
  #merge outcomes too
  future.donor<- tapply(my.sub$future_donor, 
                        INDEX = my.sub$bonica_cid, FUN = mean)
  
  obj <- rbind(obj, cbind(total.sums, total.win.sums, 
                          future.donor,
                          names(total.sums),
                          rep(my.cycle, length(total.sums))))
  
}

obj <- as.data.frame(obj)

summary(obj)

# for each number of recipient candidates

obj$future.donor <- as.numeric(as.character(obj$future.donor))

obj$total.win.sums <- as.numeric(as.character(obj$total.win.sums))


#######
# Run the model
########

one.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 1,])
two.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 2,])
three.cand.lm <- lm(future.donor ~ as.factor(total.win.sums) + as.factor(V5), obj[obj$total.sums == 3,])

summary(one.cand.lm)
summary(two.cand.lm)
summary(three.cand.lm)

stargazer(one.cand.lm, two.cand.lm, three.cand.lm)
