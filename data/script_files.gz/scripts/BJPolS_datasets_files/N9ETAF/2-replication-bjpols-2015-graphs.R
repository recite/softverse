rm(list = ls())

library(ggplot2)
library(plyr)
library(reshape2)


cab.out <- read.csv('graphs-tables/cabinet-lm.csv', fileEncoding='cp1252', as.is=TRUE)

cab <- cab.out[cab.out$region != 4, ]

dim(cab[!duplicated(cab$election_id), ])
dim(cab[!duplicated(cab$cabinet_id), ])

cab$mean_elec <- cab$mean_elec - 5
cab$mean_parl <- cab$mean_parl - 5
cab$mean_cab <- cab$mean_cab - 5

StatMeanCi<-function(x, level, type, z=1.96){
  x <- x[!is.na(x)]
  cal.df<-data.frame(
    level=level,
    type=type,
    position=mean(x),
    ymin=mean(x)-z*sd(x)/sqrt(length(x)),
    ymax=mean(x)+z*sd(x)/sqrt(length(x)))
  return(cal.df)
}


cab.pl <- cab[cab$country_name_short != 'JPN' , ]
pl <- StatMeanCi(cab.pl[cab.pl$proportional==0 & !duplicated(cab.pl$election_id), 'mean_elec'], 'election', 'Maj.')
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==0 & !duplicated(cab.pl$election_id), 'mean_parl'], 'parliament', 'Maj.'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==0, 'mean_cab'], 'cabinet', 'Maj.'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1 & !duplicated(cab.pl$election_id), 'mean_elec'], 'election', 'PR'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1 & !duplicated(cab.pl$election_id), 'mean_parl'], 'parliament', 'PR'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1, 'mean_cab'], 'cabinet', 'PR'))
pl$type  <- factor(pl$type)
pl <- rename(pl, c('position'='left.right'))

pl <- ggplot(pl, aes(x=level, y=left.right, shape=type)) + geom_point(size=3) + 
        geom_errorbar(aes(ymin=ymin, ymax=ymax), width=0.5, size=1) + ylim(-1, 2)
print(pl)
ggsave(file = 'graphs-tables/figure-2.pdf', plot = pl, version='1.6', width=6, height=4)

print(paste('Number observations', nrow(cab.pl), nrow(cab.pl[ !duplicated(cab.pl$election_id) , ])))


cab.pl <- cab[cab$country_name_short != 'JPN' , ]
pl <- StatMeanCi(cab.pl[cab.pl$proportional==0 & !duplicated(cab.pl$election_id), 'cmp_mean_elec'], 'election', 'Maj.')
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==0 & !duplicated(cab.pl$election_id), 'cmp_mean_parl'], 'parliament', 'Maj.'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==0, 'cmp_mean_cab'], 'cabinet', 'Maj.'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1 & !duplicated(cab.pl$election_id), 'cmp_mean_elec'], 'election', 'PR'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1 & !duplicated(cab.pl$election_id), 'cmp_mean_parl'], 'parliament', 'PR'))
pl <- rbind(pl, StatMeanCi(cab.pl[cab.pl$proportional==1, 'cmp_mean_cab'], 'cabinet', 'PR'))
pl$type  <- factor(pl$type)
pl <- rename(pl, c('position'="left.right ('rile')"))

pl <- ggplot(pl, aes(x=level, y=`left.right ('rile')`)) + geom_point(size=3) + 
  geom_errorbar(aes(ymin=ymin, ymax=ymax), width=0.5, size=1) + facet_grid( . ~ type)
print(pl)
ggsave(file = 'graphs-tables/figure-a2-cmp.pdf', plot = pl, version='1.6', width=6, height=4)



cab.pl <- cab
cab.pl$country <- cab.pl$country_name
cab.pl[cab.pl$country_name_short=='FRA-I', 'country'] <- 'France (PR)'
cab.pl[cab.pl$country_name_short=='NZL-II', 'country'] <- 'New Zealand (PR)'

cab.pl <- cab.pl[ ! is.na(cab.pl$mean_cab) , ]
cab.pl <- ddply(cab.pl, .(country, proportional), summarize, 
                position=mean(mean_cab),
                pos.min=mean(mean_cab)-1.96*sd(mean_cab)/sqrt(length(mean_cab)),
                pos.max=mean(mean_cab)+1.96*sd(mean_cab)/sqrt(length(mean_cab)),
                position.cmp=mean(cmp_mean_cab, na.rm=T),
                pos.min.cmp=mean(cmp_mean_cab, na.rm=T)-1.96*sd(cmp_mean_cab, na.rm=T)/sqrt(length(cmp_mean_cab)),
                pos.max.cmp=mean(cmp_mean_cab, na.rm=T)+1.96*sd(cmp_mean_cab, na.rm=T)/sqrt(length(cmp_mean_cab)) )

cab.pl$country <- factor(cab.pl$country, levels=cab.pl[with(cab.pl, order(proportional, position, country)), 'country'] )
cab.pl$type <- factor(cab.pl$proportional, levels=c(0, 1), labels=c('Maj.', 'PR'))
cab.pl <- rename(cab.pl, c('position'='left.right'))
cab.pl$tmp <- cab.pl$position.cmp
cab.pl <- rename(cab.pl, c('tmp'="left.right ('rile')"))

pl <- ggplot(cab.pl, aes(x=country, y=left.right, shape=type)) + geom_point(size=3) +
        geom_errorbar(aes(ymin=pos.min, ymax=pos.max), width=0.5, size=1) + 
        theme(axis.text.x = element_text(angle = 90, hjust = 1))
print(pl)
ggsave(file = 'graphs-tables/figure-1-countries.pdf', plot = pl, version='1.6', width=6, height=4)


