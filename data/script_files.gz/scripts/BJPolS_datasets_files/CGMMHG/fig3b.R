# SET DIRECTORY TO SOURCE FILE 


require(miceadds)
require(ggplot2)
library(plyr)

dat_t <- read.csv('../../data/cleaned/heuristics_cleaned_long.csv', stringsAsFactors = FALSE)

# What percent correct in control group?
mean(dat_t$correct[dat_t$direct == 1], na.rm = TRUE)
mean(dat_t$correct[dat_t$direct == 0], na.rm = TRUE)

# Regress whether the respondent guessed correctly on whether they were cued, with issue area fixed effects and respondent-level clustered SEs.
# Respondents in the treatment group are only randomly assigned to one rating among the ratings that it makes sense to show them for their MoC (because the MC has both the rating and the corresponding vote). Some MCs are missing different numbers than others, meaning that respondent's probability of assignment to each issue depends on how many other issues there. E.g., if you got issue A and your MC has 3 other issues, your prob of assignment is 1/4, but if your MC has 7 other issues, your prob of assignment is 1/8. So we need fixed effects for the number of issues to which you were assigned.
main.results <- summary(miceadds::lm.cluster(data = dat_t,
                             formula = correct ~ direct + 
                               factor(issue) + factor(heur_num_eligible_ratings),
                             cluster = 'id'))
main.results
main.result.coefs <- main.results[2,1:2]

# remove NARAL, Parks, NRA
dat_no_obvious <- dat_t[!dat_t$heur_randomrating_house_vote_id %in% c(55735, 58622, 60587),]
summary(miceadds::lm.cluster(data = dat_no_obvious,
                             formula = correct ~ direct + 
                               factor(issue) + factor(heur_num_eligible_ratings),
                             cluster = 'id'))

# results by issue
# Break up data by issue, then fit the specified model to each piece and
# return a list
models <- dlply(dat_t, "issue", function(df) 
  lm(correct ~ direct + factor(heur_num_eligible_ratings), data = df))

# Run by PK scale level - not in preregistered code
modelspk <- dlply(dat_t, "knowledgescale", function(df) 
  lm(correct ~ direct , data = df))
summary(modelspk$`4`)

# Apply coef to each model and return a data frame
get.coefs <- function(i) {
  issue.id <- names(models)[i]
  lm.obj <- models[[i]]
  coefs <- summary(lm.obj)$coefficients
  return(c(direct.est = coefs[2,1],
           direct.se = coefs[2,2],
           house_vote_id = issue.id))
}
estimates <- adply(1:length(models), 1, get.coefs)
for(i in 1:ncol(estimates)) estimates[,i] <- as.numeric(estimates[,i])
estimates <- merge(estimates, read.csv('../../data/Ancillary Data/vote_and_group_info_map.csv', stringsAsFactors = FALSE))
head(estimates)

# add the average estimates
overall.ests <- data.frame(direct.est = main.result.coefs[1],
                           direct.se = main.result.coefs[2],
                           sig_name = 'Average Across All')

# plot estimates
estimates <- estimates[order(estimates$direct.est),]
estimates <- plyr::rbind.fill(overall.ests, estimates)

estimates$sig_name <- factor(estimates$sig_name, ordered = TRUE, levels = estimates$sig_name)
g <- ggplot(estimates, aes(x = sig_name)) +
  geom_hline(yintercept=0, lty=2, lwd=1, colour="grey50") +
  geom_point(aes(y = direct.est)) +
  geom_errorbar(aes(ymin = direct.est - 1.96 * direct.se, ymax = direct.est + 1.96 * direct.se), 
                lwd = 1, width = 0) +
  theme_bw() + coord_flip() + ylim(-.25, .45) +
  ylab('Treatment Effect on Accurate Perception of\nMC Vote on Relevant Issue (0/1)') + xlab('Interest Group Name')
ggsave('../../figures/fig3b.pdf', g, scale = .8, width = 9, height = 5)
weighted.mean(estimates$direct.est, 1/(estimates$direct.se^2))



