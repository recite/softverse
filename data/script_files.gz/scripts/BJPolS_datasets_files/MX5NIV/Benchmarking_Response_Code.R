
# only run this the first time (this installs a compiled dll that will only work on 64-bit windows)
install.packages("https://sites.google.com/a/stonybrook.edu/mperess/research/mnlresp_0.1.0.tar.gz")

# load the package
library(mnlresp)

# other useful code
source("https://sites.google.com/a/stonybrook.edu/mperess/r0.r")
library0("fastmatch")

# labels
Xlabels <- c("Distance","Outside Option","Leader Party","Local Growth * Leader Party","Global Growth * Leader Party","Local Unem. * Leader Party","Global Unem. * Leader Party")

# wald test functions
wald45 <- function(x) { x[4] - x[5] }
wald67 <- function(x) { x[6] - x[7] }

# print out the results
print_res <- function(res) { list(model=cbind(c(Xlabels,rep("",length(res$Theta)-7)),as.coef(res$Theta,res$ThetaSe),as.se(res$ThetaSe)),sizes=cbind(c("I","N","C"),c(res$I,res$N,res$C)),grtest=wald_test(wald45,res$Theta,res$ThetaVar),untest=wald_test(wald67,res$Theta,res$ThetaVar)) }

# load data (change the location to the appropriate folder)
data1 <- read.csv("Benchmarking_Response_Data.csv")

elecstud1 <- data1$elecstud
dist1 <- as.numeric(data1$dist)
outside1 <- as.numeric(data1$party==0)
lead1 <- as.numeric(data1$lead)
gr_loc_md1  <- as.numeric(data1$gr_loc_md)
gr_glob_md1 <- as.numeric(data1$gr_glob_md)
un_loc_md1  <- as.numeric(data1$un_loc_md)
un_glob_md1 <- as.numeric(data1$un_glob_md)
gr_loc_pc1  <- as.numeric(data1$gr_loc_pc)
gr_glob_pc1 <- as.numeric(data1$gr_glob_pc)
un_loc_pc1  <- as.numeric(data1$un_loc_pc)
un_glob_pc1 <- as.numeric(data1$un_glob_pc)
gr_loc_tr1  <- as.numeric(data1$gr_loc_tr)
gr_glob_tr1 <- as.numeric(data1$gr_glob_tr)
un_loc_tr1  <- as.numeric(data1$un_loc_tr)
un_glob_tr1 <- as.numeric(data1$un_glob_tr)

gr_loc_md_lead1  <- lead1 * gr_loc_md1
gr_glob_md_lead1 <- lead1 * gr_glob_md1
un_loc_md_lead1  <- lead1 * un_loc_md1
un_glob_md_lead1 <- lead1 * un_glob_md1

gr_loc_pc_lead1  <- lead1 * gr_loc_pc1
gr_glob_pc_lead1 <- lead1 * gr_glob_pc1
un_loc_pc_lead1  <- lead1 * un_loc_pc1
un_glob_pc_lead1 <- lead1 * un_glob_pc1

gr_loc_tr_lead1  <- lead1 * gr_loc_tr1
gr_glob_tr_lead1 <- lead1 * gr_glob_tr1
un_loc_tr_lead1  <- lead1 * un_loc_tr1
un_glob_tr_lead1 <- lead1 * un_glob_tr1

Ind1 <- data1$id
Choice1 <- data1$party
Cluster1 <- elecstud1

Y1 <- data1$vote

X1a <- cbind(dist1,outside1,lead1,gr_loc_md_lead1,gr_glob_md_lead1,un_loc_md_lead1,un_glob_md_lead1)
X1b <- cbind(dist1,outside1,lead1,gr_loc_pc_lead1,gr_glob_pc_lead1,un_loc_pc_lead1,un_glob_pc_lead1)
X1c <- cbind(dist1,outside1,lead1,gr_loc_tr_lead1,gr_glob_tr_lead1,un_loc_tr_lead1,un_glob_tr_lead1)

# logit, md
res11 <- mnl(Y1,X1a,Ind1,Choice1,Cluster1,Opt="logit")
print_res(res11)

# logit, pc
res12 <- mnl(Y1,X1b,Ind1,Choice1,Cluster1,Opt="logit")
print_res(res12)

# logit, tr
res13 <- mnl(Y1,X1c,Ind1,Choice1,Cluster1,Opt="logit")
print_res(res13)

# warning -- the following code will take a long time execute

# relogit, md
res21 <- mnl(Y1,X1a,Ind1,Choice1,Cluster1,Opt="relogit",MaxIter=20000)
print_res(res21)

# relogit, pc
res22 <- mnl(Y1,X1b,Ind1,Choice1,Cluster1,Opt="relogit",MaxIter=20000)
print_res(res22)

# relogit, tr
res23 <- mnl(Y1,X1c,Ind1,Choice1,Cluster1,Opt="relogit",MaxIter=20000)
print_res(res23)
