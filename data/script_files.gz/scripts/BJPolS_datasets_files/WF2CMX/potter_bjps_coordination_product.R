#################################################
###### Coordination Product Concept Mapping #####
######          Joshua D. Potter            #####
#################################################


#### high wastage, but decent coordination among losers


plot(x=c(1,2,3,4,5,6,7,8,9,10),
	y=c(1,2,3,4,5,6,7,8,9,10),
	xlim=c(0,9.5),
	ylim=c(0,3.5),
	col="white",
	axes=FALSE, 
	xlab="",
	ylab="Vote Share",
	main="High Wastage, Low ENLP")


rect(xleft=0, xright=9.5, ybottom=0, ytop=3.5, density=NA, col="gray95")
polygon(x=c(0.5,0.5,1.5,1.5), y=c(0,3,3,0), col="gray20", lwd=2)
polygon(x=c(2,2,3,3), y=c(0,2.5,2.5,0), col="gray20", lwd=2)
polygon(x=c(3.5,3.5,4.5,4.5), y=c(0,2.3,2.3,0), col="gray80", lwd=2)
polygon(x=c(5,5,6,6), y=c(0,1,1,0), col="gray80", lwd=2)
polygon(x=c(6.5,6.5,7.5,7.5), y=c(0,0.7,0.7,0), col="gray80", lwd=2)
polygon(x=c(8,8,9,9), y=c(0,0.5,0.5,0), col="gray80", lwd=2)

axis(side=1, col="gray40", lwd=2, at=c(1, 2.5, 4, 5.5, 7, 8.5), labels=c( "Winner", "Winner", "Loser", "Loser", "Loser", "Loser"))	
axis(side=2, col="black", lwd=2, at=c(0, 1, 2, 3), labels=c("0.0", "0.1", "0.2","0.3"))	

text(x=5, y=3, lab="ENLP = 2.9", pos=4, cex=0.9)
text(x=5, y=2.75, lab="Share Wasted Votes = 0.45", pos=4, cex=0.9)
text(x=5, y=2.5, lab="Coordination Product = 1.3", pos=4, cex=0.9)


#### high wastage, but poor coordination among losers

plot(x=c(1,2,3,4,5,6,7,8,9,10),
	y=c(1,2,3,4,5,6,7,8,9,10),
	xlim=c(0,9.5),
	ylim=c(0,3.5),
	col="white",
	axes=FALSE, 
	xlab="",
	ylab="Vote Share",
	main="High Wastage, High ENLP")


rect(xleft=0, xright=10, ybottom=0, ytop=3.5, density=NA, col="gray95")
polygon(x=c(0.5,0.5,1.5,1.5), y=c(0,3,3,0), col="gray20", lwd=2)
polygon(x=c(2,2,3,3), y=c(0,2.5,2.5,0), col="gray20", lwd=2)
polygon(x=c(3.5,3.5,4.5,4.5), y=c(0,1.3,1.3,0), col="gray80", lwd=2)
polygon(x=c(5,5,6,6), y=c(0,1.2,1.2,0), col="gray80", lwd=2)
polygon(x=c(6.5,6.5,7.5,7.5), y=c(0,1.1,1.1,0), col="gray80", lwd=2)
polygon(x=c(8,8,9,9), y=c(0,0.9,0.9,0), col="gray80", lwd=2)

axis(side=1, col="gray40", lwd=2, at=c(1, 2.5, 4, 5.5, 7, 8.5), labels=c( "Winner", "Winner", "Loser", "Loser", "Loser", "Loser"))	
axis(side=2, col="black", lwd=2, at=c(0, 1, 2, 3), labels=c("0.0", "0.1", "0.2","0.3"))	

text(x=5, y=3, lab="ENLP = 3.9", pos=4, cex=0.9)
text(x=5, y=2.75, lab="Share Wasted Votes = 0.45", pos=4, cex=0.9)
text(x=5, y=2.5, lab="Coordination Product = 1.8", pos=4, cex=0.9)



#### low wastage, but decent coordination among losers

plot(x=c(1,2,3,4,5,6,7,8,9,10),
	y=c(1,2,3,4,5,6,7,8,9,10),
	xlim=c(0,9.5),
	ylim=c(0,3.5),
	col="white",
	axes=FALSE, 
	xlab="",
	ylab="Vote Share",
	main="Low Wastage, Low ENLP")


rect(xleft=0, xright=9.5, ybottom=0, ytop=3.5, density=NA, col="gray95")
polygon(x=c(0.5,0.5,1.5,1.5), y=c(0,3.5,3.5,0), col="gray20", lwd=2)
polygon(x=c(2,2,3,3), y=c(0,3.3,3.3,0), col="gray20", lwd=2)
polygon(x=c(3.5,3.5,4.5,4.5), y=c(0,1.3,1.3,0), col="gray80", lwd=2)
polygon(x=c(5,5,6,6), y=c(0,1.2,1.2,0), col="gray80", lwd=2)
polygon(x=c(6.5,6.5,7.5,7.5), y=c(0,0.6,0.6,0), col="gray80", lwd=2)
polygon(x=c(8,8,9,9), y=c(0,0.1,0.1,0), col="gray80", lwd=2)

axis(side=1, col="gray40", lwd=2, at=c(1, 2.5, 4, 5.5, 7, 8.5), labels=c( "Winner", "Winner", "Loser", "Loser", "Loser", "Loser"))	
axis(side=2, col="black", lwd=2, at=c(0, 1, 2, 3), labels=c("0.0", "0.1", "0.2","0.3"))	

text(x=5, y=3, lab="ENLP = 2.9", pos=4, cex=0.9)
text(x=5, y=2.75, lab="Share Wasted Votes = 0.32", pos=4, cex=0.9)
text(x=5, y=2.5, lab="Coordination Product = 0.9", pos=4, cex=0.9)


#### low wastage, but poor coordination among losers

plot(x=c(1,2,3,4,5,6,7,8,9,10),
	y=c(1,2,3,4,5,6,7,8,9,10),
	xlim=c(0,9.5),
	ylim=c(0,3.5),
	col="white",
	axes=FALSE, 
	xlab="",
	ylab="Vote Share",
	main="Low Wastage, High ENLP")


rect(xleft=0, xright=9.5, ybottom=0, ytop=3.5, density=NA, col="gray95")
polygon(x=c(0.5,0.5,1.5,1.5), y=c(0,3.5,3.5,0), col="gray20", lwd=2)
polygon(x=c(2,2,3,3), y=c(0,3.3,3.3,0), col="gray20", lwd=2)
polygon(x=c(3.5,3.5,4.5,4.5), y=c(0,1,1,0), col="gray80", lwd=2)
polygon(x=c(5,5,6,6), y=c(0,0.8,0.8,0), col="gray80", lwd=2)
polygon(x=c(6.5,6.5,7.5,7.5), y=c(0,0.7,0.7,0), col="gray80", lwd=2)
polygon(x=c(8,8,9,9), y=c(0,0.68,0.68,0), col="gray80", lwd=2)

axis(side=1, col="gray40", lwd=2, at=c(1, 2.5, 4, 5.5, 7, 8.5), labels=c( "Winner", "Winner", "Loser", "Loser", "Loser", "Loser"))	
axis(side=2, col="black", lwd=2, at=c(0, 1, 2, 3), labels=c("0.0", "0.1", "0.2","0.3"))	

text(x=5, y=3, lab="ENLP = 3.9", pos=4, cex=0.9)
text(x=5, y=2.75, lab="Share Wasted Votes = 0.32", pos=4, cex=0.9)
text(x=5, y=2.5, lab="Coordination Product = 1.3", pos=4, cex=0.9)