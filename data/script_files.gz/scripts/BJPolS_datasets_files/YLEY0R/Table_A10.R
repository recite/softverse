# Table_A10.R

# Part of the replication archive for 
#
#   Bullock, John G., and Kelly Rader. 2021. "Response Options and the 
#   Measurement of Political Knowledge." Forthcoming in the British Journal 
#   of Political Science.

library(Bullock)
library(dplyr)   # for dplyr::recode()
library(Hmisc)   # for llist()
library(lmtest)  # for lrtest()
library(nnet)    # for multinom()


ELIMINATE_BREAKOFFS <- TRUE
source(here::here("R/SSI_2017_coding.R"))

filenameStem <- here::here("float_output/Table_A10")



# **************************************************************************
# ESTIMATE REGRESSIONS ####
# **************************************************************************
# We have 12 questions to check. Six have two conditions ("three response 
# options" vs. "five response options"). For these questions, we use OLS and 
# then examine the F statistics. Six other questions have five conditions,  
# and for these questions, we use multinomial logistic regression and then 
# examine the logs likelihoods. See Gerber and Green (2010, 107).
Qs_fiveConditions <- mget(ls(pat = 'condition'))
Qs_numOnly <- llist(
  JusticesChosen_numROs,
  WatchLawyersArgue_numROs,
  ConflictOverMeaning_numROs,
  IfJusticesSplit_numROs,
  CourtPowerDescription_numROs,
  JusticeRemoval_numROs)

race <- dplyr::recode(race, "other"="missing", "whiteem"="white")

reg_fiveConditions <- lapply(
  Qs_fiveConditions,
  function (x) multinom(x ~ age + I(age^2) + educ + female + Pence + Yellen + SenateTerm + PID + raceSSI + state))

reg_numOnly <- lapply(
  Qs_numOnly, 
  function (x) summary(lm(x ~ age + I(age^2) + educ + female + Pence + Yellen + SenateTerm + PID + raceSSI + state)))



# **************************************************************************
# CREATE OUTPUT TABLE ####
# **************************************************************************
# One row per question, and thus 12 rows in all. Data columns are F, 
# chi-square, and p.  [2020 02 19]
questionText <- c(
  "Name of Chief Justice",
  "How many justices currently serve",
  "How many justices usually serve",
  "How many women currently serve",
  "Name of Senate Majority Leader",
  "Term length of justices",
  
  "How are justices chosen",
  "Can one watch lawyers argue at the Court",
  "Who decides constitutionality",
  "What happens when there is a tie vote",
  "When can the Court act",
  "Can justices ever be removed")

randCheckTable <- tibble(
  questionText,
  chiSq = c(sapply(reg_fiveConditions, function (x) lrtest(x)[2, "Chisq"]), rep(NA, 6)),
  F     = c(rep(NA, 6), sapply(reg_numOnly, function (x) x$fstatistic['value'])),
  p     = c(
    sapply(reg_fiveConditions, function (x) lrtest(x)[2, "Pr(>Chisq)"]),
    sapply(reg_numOnly, function (x) pf(
      x$fstatistic["value"],
      x$fstatistic["numdf"],
      x$fstatistic["dendf"],
      lower = FALSE)))
  )
rownames(randCheckTable) <- NULL  
  

# COMPARE RESULTS
if (!sourcing()) {
  reg_fiveConditions$HowManyWomen_condition %>% lrtest
  reg_numOnly$WatchLawyersArgue_numROs
}



# **************************************************************************
# EXPORT TABLE TO LATEX ####
# **************************************************************************
randCheckTable_caption <- paste(
  "\\textit{Randomization checks.}",
  "The table reports separate randomization checks for each of our 12 questions.",
  "For each question, treatment condition was regressed on age, race, gender, education, and state of residence.",
  "The first six questions had five treatment conditions, and for these questions, we used multinomial logistic regression.",
  "The six remaining questions had only two treatment conditions (``three response options'' and ``five response options''), and in these cases, we used OLS.",
  collapse = " "
)

randCheckTable_latex <- latexTable(
  as.matrix(randCheckTable[, 2:4]),
  SE_table = FALSE,
  rowNames = pull(randCheckTable, questionText),
  colNames = c("$\\chi^2$", "F", "p"),
  caption  = randCheckTable_caption,
  commandName = "TabRandCheck",
  callCommand = FALSE)

latexTablePDF(
  randCheckTable_latex,
  container = FALSE,
  writePDF  = FALSE,
  writeTex  = TRUE,
  outputFilenameStem = filenameStem,
  overwrite = TRUE)
