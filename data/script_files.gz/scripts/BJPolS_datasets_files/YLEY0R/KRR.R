# KRR.R

# Part of the replication archive for 
#
#   Bullock, John G., and Kelly Rader. 2021. "Response Options and the 
#   Measurement of Political Knowledge." Forthcoming in the British Journal 
#   of Political Science.


# Correct responses follow either from knowledge or from lucky guessing.  
# This code produces estimates of the percentages answering each question  
# who really knew the answers.  See the appendix of our paper for details.  
KRR <- function(C, I, J) {
  # KRR is "knowledgeable-response rate"
  # C is the correct-response rate
  # I is the incorrect-response rate
  # J is the number of response options (not counting "don't know")
  #
  # If some respondents answer "don't know," C+I will not equal 1.
  C - I*(1/(J-1))
}



