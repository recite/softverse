# Table_1.R

# Part of the replication archive for 
#
#   Bullock, John G., and Kelly Rader. 2021. "Response Options and the 
#   Measurement of Political Knowledge." Forthcoming in the British Journal 
#   of Political Science.

library(Bullock)  # devtools::install_github("jbullock35/Bullock", build_vignettes = TRUE)
library(dplyr)    # for arrange()
library(readr)    # for read_csv()
source(here::here("R/functions/KRR.R"))  # guessing-correction function

filenameStem <- here::here("float_output/Table_1")



# **************************************************************************
# PREPARE DATA FRAME ####
# **************************************************************************

# LOAD AND CLEAN DATA
questionHistory <- read_csv("data/ChiefJustice_questionHistory.csv") %>%  
  filter(
    Topic == "Chief Justice identity", 
    Subtopic == "Who",
    grepl("Closed.ended", `Question Format`)) %>%
  select(
    source                  = "Name of Study", 
    percentCorrect          = "% correct",
    percentIncorrect        = "% incorrect",
    percentDK               = "% DK",
    year                    = "Year Fielded",
    numberOfResponseOptions = "Number of Response Options",
    mode                    = "Interview Mode") %>%
  mutate_at(
    vars(percentCorrect, percentIncorrect, percentDK, numberOfResponseOptions),
    as.numeric) %>%
  mutate(
    source = c(
      '\\citet{Prior_News_2005}',  # 'Prior (2005) News and Entertainment Survey',
      'Pew Research Center',
      'ANES EGSS~3',
      'ANES EGSS~4',
      'Pew Research Center',       # 'Pew Political Knowledge Survey',
      '\\citet{Sen_How_2017}'),
    mode = recode(mode, "Online"="internet", "Telephone"="phone"),
    year = recode(year, "2002-2003"="2003"),
    percentCorrectAdj = KRR(
      C = .$percentCorrect,
      I = .$percentIncorrect,
      J = .$numberOfResponseOptions) %>% round(., 0),
    responseOptions = c(
      'Rehnquist, Thomas, Scalia, Kennedy',
      'Roberts, Stevens, Marshall, Reid',
      'Roberts, David Cole, Kennedy, Larry~Thompson',
      'Roberts, David Cole, Kennedy, Larry~Thompson',
      'Roberts, Breyer, Rehnquist, Reid',
      'Roberts, Rehnquist, Breyer, Scalia, Kennedy')) %>%

  
# ADD THE QUESTIONS REPORTED IN GIBSON AND CALDEIRA (2009, 435)
# Gibson and Caldeira (2009, 435) report correct-response rates of 71.1% for 
# the Rehnquist question and 46.3% for the Roberts question. 
add_row(
  source                  = 'Gibson and Caldeira (2009)', 
  percentCorrect          = 71, 
  percentIncorrect        = 9, 
  percentDK               = 21, 
  year                    = "2006", 
  numberOfResponseOptions = 3, 
  percentCorrectAdj       = 66, 
  responseOptions         = 'Rehnquist, Powell, White',
  mode                    = "phone") %>%
add_row(
  source = 'Gibson and Caldeira (2009)', 
  percentCorrect          = 46, 
  percentIncorrect        = 6, 
  percentDK               = 50, 
  year                    = "2006", 
  numberOfResponseOptions = 3, 
  percentCorrectAdj       = 41, 
  responseOptions         = 'Roberts; J.~Harvie Wilkinson,~III; Theodore Olson',
  mode                    = "phone") %>%

# ORDER COLUMNS AND ROWS
mutate(RehnquistRow = year < 2007 & grepl('Rehnquist', responseOptions)) %>%
arrange(desc(RehnquistRow), percentCorrect) %>%
select(source, percentCorrect, percentCorrectAdj, responseOptions, mode, year)



# **************************************************************************
# MAKE GUESSING-CORRECTED LATEX TABLE (TABLE A14) ####
# **************************************************************************
questionHistory_colNames <- list(
  c('\\%',     '\\%'),
  c('correct', 'correct'),
  c('(raw)',   '(adj.)',  'response options', 'mode', 'year'))

questionHistory_caption <- paste(
  '\\textit{Variation in responses to closed-ended ``Chief Justice\'\' questions.}',
  'This table is very similar to \\autoref{TabCJQuestionHistory}.',
  'The sole difference is that this table also reports guessing-corrected correct-response rates, per the formula on \\autopageref{EqKnowledgeableResponse}.',
  'These percentages appear in the ``adjusted\'\' column.',
  '``EGSS\'\' stands for ``Evaluations of Government and Society Study.\'\'',
  'The correct answer to the questions reported in the first two rows is ``William Rehnquist\'\'; for the questions reported in the other rows, it is ``John Roberts.\'\'')

questionHistoryLatexGC <- latexTable(
  mat                = subset(questionHistory, select=-source) %>% as.matrix,
  SE_table           = FALSE, 
  formatNumbers      = FALSE,
  decimalPlaces      = 0,
  rowNames           = questionHistory$source,
  colNames           = questionHistory_colNames,
  horizOffset        = '-.30in',
  headerFooter       = TRUE,
  footerRows         = NULL,
  spacerColumnsWidth = ".50em",
  caption            = questionHistory_caption, 
  commandName        = 'TabCJQuestionHistoryWithGC',
  callCommand        = FALSE)


# TWEAK THE TABLE
# Change column specifications
rowNums <- which(grepl('N\\{\\d\\}', questionHistoryLatexGC))
questionHistoryLatexGC[rowNums] <- gsub('([[:space:]]+)>\\{.*\\}', '\\1c', questionHistoryLatexGC[rowNums])
rowNum <- which(grepl('N\\{\\d\\d\\}', questionHistoryLatexGC))
questionHistoryLatexGC[rowNum] <- gsub('([[:space:]]+)>\\{.*\\}', '\\1>{\\\\noindent}p{2.5in}', questionHistoryLatexGC[rowNum])

# Add vertical space between the Rehnquist and Roberts tiers.
rowNum_RobertsStart <- which(grepl('Pew Research Center &+ 28', questionHistoryLatexGC))
questionHistoryLatexGC <- c(
  questionHistoryLatexGC[1:(rowNum_RobertsStart-1)], 
  '        \\addlinespace[.35in]', 
  questionHistoryLatexGC[rowNum_RobertsStart:length(questionHistoryLatexGC)])

# Adjust the line segments that appear immediately below the column names.
questionHistoryLatexGC <- gsub('cmidrule(lr)', 'cmidrule', questionHistoryLatexGC, fixed = TRUE)



# **************************************************************************
# MAKE NON-GUESSING-CORRECTED TABLE (TABLE 1) ####
# **************************************************************************
questionHistory_colNames <- c("\\% correct", "response options", "mode", "year")
questionHistory_caption <- paste(
  '\\textit{Variation in responses to closed-ended ``Chief Justice\'\' questions.}',
  '``EGSS\'\' stands for ``Evaluations of Government and Society Study.\'\'',
  'The table has two tiers: in the first tier (top two rows), the correct answer is ``William Rehnquist\'\'; in the second tier, it is ``John Roberts.\'\' Within each tier, studies are sorted by the percentage of respondents who answered correctly.')
questionHistoryLatex <- latexTable(
  mat                = questionHistory %>% 
    select(-source, -percentCorrectAdj) %>% 
    as.matrix,
  SE_table           = FALSE, 
  formatNumbers      = FALSE,
  decimalPlaces      = 0,
  rowNames           = questionHistory$source,
  colNames           = questionHistory_colNames,
  horizOffset        = '-.30in',
  headerFooter       = TRUE,
  footerRows         = NULL,
  caption            = questionHistory_caption, 
  commandName        = 'TabCJQuestionHistory',
  callCommand        = FALSE)


# TWEAK THE TABLE
# Change column specifications
rowNums <- which(grepl('N\\{\\d\\}', questionHistoryLatex))
questionHistoryLatex[rowNums] <- gsub('([[:space:]]+)>\\{.*\\}', '\\1c', questionHistoryLatex[rowNums])
rowNum <- which(grepl('N\\{\\d\\d\\}', questionHistoryLatex))
questionHistoryLatex[rowNum] <- gsub('([[:space:]]+)>\\{.*\\}', '\\1>{\\\\noindent}p{2.5in}', questionHistoryLatex[rowNum])

# Add vertical space between the Rehnquist and Roberts tiers.
rowNum_RobertsStart <- which(grepl('Pew Research Center &+ 28', questionHistoryLatex))
questionHistoryLatex <- c(
  questionHistoryLatex[1:(rowNum_RobertsStart-1)], 
  '        \\addlinespace[.35in]', 
  questionHistoryLatex[rowNum_RobertsStart:length(questionHistoryLatex)])

# Adjust the line segments that appear immediately below the column names.
questionHistoryLatex <- gsub('cmidrule(lr)', 'cmidrule', questionHistoryLatex, fixed = TRUE)



# **************************************************************************
# SAVE LATEX FILE ####
# **************************************************************************
# The file is a .tex file that contains code for both tables.
latexTablePDF(
  latexTable         = list(questionHistoryLatex, questionHistoryLatexGC), 
  container          = FALSE,  
  outputFilenameStem = filenameStem,       
  overwriteExisting  = TRUE,
  writePDF           = FALSE,
  writeTex           = TRUE,
  openPDFOnExit      = FALSE)
