# SSI_analysis.R 

# Part of the replication archive for 
#
#   Bullock, John G., and Kelly Rader. 2021. "Response Options and the 
#   Measurement of Political Knowledge." Forthcoming in the British Journal 
#   of Political Science.


library(Bullock)
library(dplyr)         # for %>%, select()
library(here)          # for here::here()
library(readxl)        # to import the XLSX file sent by SSI on 2017 March 28 
Recode <- car::Recode


source(here::here("R/SSI_2017_coding.R"))



# **************************************************************************
# PRELIMINARY PROCESSING 
# **************************************************************************
# Identify all variables that were created from the original dataset and that
# have n rows, where n is the number of subjects in the data.  Move all such 
# variables into an environment called "data".  This is the environment from 
# which we will pull variables for analysis.  
objectLengths       <- unlist(eapply(env=environment(), FUN=length))
objectsToMove_names <- objectLengths[objectLengths == modalValue(objectLengths)] %>%
  names() 
data                <- new.env()  
for (i in objectsToMove_names) {
  assign(i, get(i), envir = data)
  rm(list = i)
}

# Add variables from the original data frame.
data$psid   <- as.character(originalData$psid)
data$weight <- originalData$weight



# **************************************************************************
# CORRECT-RESPONSE VECTOR  ####
# **************************************************************************
# Create a single vector that indicates whether a respondent-question was
# answered correctly, regardless of condition.  [2021 02 07]
correctNames <- qw(
  "ChiefJustice_correct
   SenMajLeader_correct
   HowManyJusticesCurrently_correct
   ProcedureForChoosingJustices_correct
   WatchLawyersArgue_correct
   FinalSay_correct
   HowManyJusticesUsually_correct
   TieVoteProcedure_correct
   HowManyWomen_correct
   CourtPower_correct
   JusticeRemoval_correct
   TermLength_correct")

correct <- unlist(
  lapply(correctNames, get, envir = as.environment(data))
)



# **************************************************************************
# NUMBER OF RESPONSE OPTIONS ####
# **************************************************************************
# Create a vector, numROs, that indicates the number of response options 
# provided for each respondent-question. Open-ended respondent-questions are
# coded as NA.  [2021 02 07]
numROs_names <- qw(
  "ChiefJustice_numROs 
   SenMajLeader_numROs 
   HowManyJusticesCurrently_numROs 
   JusticesChosen_numROs
   WatchLawyersArgue_numROs 
   ConflictOverMeaning_numROs 
   HowManyJusticesUsually_numROs 
   IfJusticesSplit_numROs
   HowManyWomen_numROs
   CourtPowerDescription_numROs 
   JusticeRemoval_numROs
   TermLength_numROs")   

numROs <- unlist(
  lapply(numROs_names, get, envir = as.environment(data))
)
    

# **************************************************************************
# DIFFICULTY MANIPULATIONS ####
# **************************************************************************
correct_diff_names <- qw(
  "ChiefJustice_CE_correct
   SenMajLeader_CE_correct
   HowManyJusticesCurrently_correct
   HowManyJusticesUsually_correct
   HowManyWomen_correct
   TermLength_correct")

# Create a vector that concatenates the TRUE, FALSE, and NA responses to  
# each question.
correct_diff <- unlist(lapply(correct_diff_names, get, envir = as.environment(data)))

# Concatenate the difficulty level ("easy" or "hard") for each question into 
# a single variable.
diffTF_names <- qw(
  "ChiefJustice_diffTF 
   SenMajLeader_diffTF 
   HowManyJusticesCurrently_diffTF 
   HowManyJusticesUsually_diffTF 
   HowManyWomen_diffTF
   TermLength_diffTF") 
diffTF <- unlist(lapply(diffTF_names, get, envir = as.environment(data)))



# **************************************************************************
# TEST THE MAIN HYPOTHESIS ####
# **************************************************************************
varNames_correct <- qw(
  "ChiefJustice_correct
   HowManyJusticesCurrently_correct
   HowManyJusticesUsually_correct
   HowManyWomen_correct
   SenMajLeader_correct
   TermLength_correct")  
varNames_condition <- gsub('correct', 'condition', varNames_correct)



# **************************************************************************
# PLACEBO QUESTION ####
# **************************************************************************
# Appendix pages A15-A16: "One hundred and sixty-four of our subjects (8.4%) 
# answered correctly."
sumNA(data$placeboCorrect[!is.na(data$weight)])
sumNA(data$placeboCorrect[!is.na(data$weight)]) / length(data$placeboCorrect[!is.na(data$weight)])