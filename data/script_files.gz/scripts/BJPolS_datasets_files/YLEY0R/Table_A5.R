# Table_A5.R

# Part of the replication archive for 
#
#   Bullock, John G., and Kelly Rader. 2021. "Response Options and the 
#   Measurement of Political Knowledge." Forthcoming in the British Journal 
#   of Political Science.

library(Bullock)

source(here::here("R/SSI_2017_analysis.R"))

filenameStem <- here::here("float_output/Table_A5")

WEIGHTS_ONLY <- TRUE  



# **************************************************************************
# RESTRICT THE SAMPLE ####
# **************************************************************************
if (WEIGHTS_ONLY) {
  data <- sapply(data, function (x) x[!is.na(data$weight)])
}



# **************************************************************************
# CREATE THE TABLE IN R ####
# **************************************************************************
rowNames <- c(
  "Name of Chief Justice",
  "How many justices usually",
  "How many justices currently",
  "How many women",
  "Name of Senate Majority Leader",
  "Term length of justice",
  
  "How are justices chosen",
  "Possible to watch lawyers argue",
  "Final say over Constitution",
  "What happens if tie decision",
  "Best description of Court power",
  "Possible to remove justices")

colNames <- qw("3-superEasy 3-easy 3-hard 5-superEasy 5-easy 5-hard OE 3 5 total") 

questionConditions <- as.list(data)[
  c("ChiefJustice_condition",
    "HowManyJusticesUsually_condition",
    "HowManyJusticesCurrently_condition",
    "HowManyWomen_condition",
    "SenMajLeader_condition",
    "TermLength_condition",

    "JusticesChosen_numROs",
    "WatchLawyersArgue_numROs", 
    "ConflictOverMeaning_numROs", 
    "IfJusticesSplit_numROs",
    "CourtPowerDescription_numROs", 
    "JusticeRemoval_numROs")]

table_numSubjects <- matrix(NA, 12, 10, dimnames = list(rowNames, colNames))
table_numSubjects[ 1, 1:7] <- table(questionConditions[['ChiefJustice_condition']])
table_numSubjects[ 2, c(2,3,5:7)] <- table(questionConditions[['HowManyJusticesUsually_condition']])
table_numSubjects[ 3, c(2,3,5:7)] <- table(questionConditions[['HowManyJusticesCurrently_condition']])
table_numSubjects[ 4, c(2,3,5:7)] <- table(questionConditions[['HowManyWomen_condition']])
table_numSubjects[ 5, c(2,3,5:7)] <- table(questionConditions[['SenMajLeader_condition']])
table_numSubjects[ 6, c(2,3,5:7)] <- table(questionConditions[['TermLength_condition']])

table_numSubjects[ 7, qw('3 5')] <- table(questionConditions[['JusticesChosen_numROs']])
table_numSubjects[ 8, qw('3 5')] <- table(questionConditions[['WatchLawyersArgue_numROs']])
table_numSubjects[ 9, qw('3 5')] <- table(questionConditions[['ConflictOverMeaning_numROs']])
table_numSubjects[10, qw('3 5')] <- table(questionConditions[['IfJusticesSplit_numROs']])
table_numSubjects[11, qw('3 5')] <- table(questionConditions[['CourtPowerDescription_numROs']])
table_numSubjects[12, qw('3 5')] <- table(questionConditions[['JusticeRemoval_numROs']])

table_numSubjects[, 'total'] <- apply(table_numSubjects, 1, sumNA)



# **************************************************************************
# CREATE THE TABLE IN LATEX ####
# **************************************************************************
colNames_latex <- list(
  c("3",      "",   "",   "5"),
  qw("super- 3    3     super- 5    5     open-"),
  qw("easy   easy diff. easy   easy diff. ended 3 5 total"))

caption_latex <- '\\textit{Number of subjects in each condition.} For each question, subjects were assigned to a number-of-response-options condition. For each of the first six questions, subjects were also assigned to a difficulty condition.'

table_numSubjects_latex <- latexTable(
  mat                     = table_numSubjects,
  SE_table                = FALSE,
  colNames                = colNames_latex,
  headerFooter            = TRUE,
  spaceBetweenColNameRows = '-.065in',
  decimalPlaces           = 0,
  caption                 = caption_latex,
  landscape               = TRUE,
  floatPlacement          = 'p',
  commandName             = 'TabNumberOfSubjects',
  callCommand             = TRUE)


# Center the cells in the "super-easy" columns. By default, it looks as
# though they are left-aligned.  
table_numSubjects_latex <- gsub(
  '>{{\\hspace*{0em}}}N{2}{0}%', 
  'c%', 
  table_numSubjects_latex,
  fixed = TRUE)


# Write the LaTeX table to a file.
latexTablePDF(
  latexTable         = table_numSubjects_latex, 
  firstPageEmpty     = FALSE,  
  continuedFloat     = FALSE,  
  container          = FALSE,  # FALSE if inserting LaTeX tables into appendix of my paper
  outputFilenameStem = filenameStem,
  overwriteExisting  = TRUE,
  writePDF           = FALSE,
  writeTex           = TRUE,
  openPDFOnExit      = FALSE)
