
rm(list=ls())

library(tidyr)
library(tibble)
library(stargazer)
library(dplyr)
library(haven)
library(readstata13)
library(ggplot2)
library(cregg)
library(zoo)

#########################################################################
# REPLICATION FILES: MILITARIZATION AND PERCEPTIONS OF LAW ENFORCEMENT  #
# JOURNAL: BJPS                                                         #
# RESULTS IN SUPP. APP. FOR                                             #
# 1. DIFFERENCE IN AMCEs BY SUBGORUP                                    #
# 2. LEVELS OF FAVORABILITY                                             #          
#########################################################################


#### STEP 1: READ DATA                              ####

militconj <- read.dta13("MilitConjoint.dta")
baselines <- list()

#### STEP 2: RENAME VARIABLES                       ####

colnames(militconj)[colnames(militconj)=="uniform"] <- "uniform_numeric"
colnames(militconj)[colnames(militconj)=="weapon"] <- "weapon_numeric"
colnames(militconj)[colnames(militconj)=="gender"] <- "gender_numeric"
colnames(militconj)[colnames(militconj)=="race"] <- "race_numeric"
colnames(militconj)[colnames(militconj)=="trustarmy"] <- "Trust"
colnames(militconj)[colnames(militconj)=="upclass"] <- "Income"
colnames(militconj)[colnames(militconj)=="sexo"] <- "Sex"
colnames(militconj)[colnames(militconj)=="old"] <- "Age"
colnames(militconj)[colnames(militconj)=="mored"] <- "Education"
colnames(militconj)[colnames(militconj)=="vict"] <- "Victimization"
colnames(militconj)[colnames(militconj)=="self_ideology_two"] <- "Ideology_Two"
colnames(militconj)[colnames(militconj)=="partisanship2"] <- "PartyID_3"
colnames(militconj)[colnames(militconj)=="insecure"] <- "Insecure"
colnames(militconj)[colnames(militconj)=="grupo_thom_med"] <- "Homicide_Rate_Median"


#### STEP 3: CHANGE TO FACTORS                      ####


militconj$Uniform<-factor(militconj$uniform_numeric,labels=c("Police", "Military"))
militconj$Weapon<-factor(militconj$weapon_numeric,labels=c("None", "Assault Rifle"))
militconj$Gender<-factor(militconj$gender_numeric,labels=c("Female", "Male"))
militconj$SkinColor<-factor(militconj$race_numeric,labels=c("Dark", "Light"))

#### STEP 4: ADD LABELS AND CONVERT TO FACTORS   ####

militconj$Trust<-factor(militconj$Trust,labels=c("Not at all/Some", "Completely"))
militconj$Income<-factor(militconj$Income,labels=c("Less than $200 USD", "More than $200 USD"))
militconj$Sex<-factor(militconj$Sex,labels=c("Male", "Female"))
militconj$Age<-factor(militconj$Age,labels=c("Less than 40", "40 +"))
militconj$Education<-factor(militconj$Education,labels=c("Less than highschool", "Highschool+"))
militconj$Victimization<-factor(militconj$Victimization,labels=c("Non-victim", "Victim"))
militconj$Ideology_Two<-factor(militconj$Ideology_Two,labels=c("Left", "Right"))
militconj$PartyID_3<-factor(militconj$PartyID_3,labels=c("Morena", "PRI", "PAN"))
militconj$Insecure<-factor(militconj$Insecure,labels=c("Below 63.9%", "Above 63.9%"))
militconj$Homicide_Rate_Median<-factor(militconj$Homicide_Rate_Median,labels=c("Below 15.8", "Above 15.8"))


#### STEP 5: SUBGROUP TESTS: TRUST IN THE MILITARY ####

## EFFECTIVENESS

# 1. PLOT AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
eff_amce_bytrust <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
plot(eff_amce_bytrust, group = "Trust", vline = 0.0)

# 2. PLOT MMs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
eff_mm_bytrust <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
plot(eff_mm_bytrust, group = "Trust", vline = 0.59)

# 3. MM DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
eff_mmdiffs_bytrust <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(eff_mmdiffs_bytrust, group = "Trust", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
eff_amcediffs_bytrust <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(eff_amcediffs_bytrust, group = "Trust", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
civlib_amce_bytrust <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
plot(civlib_amce_bytrust, group = "Trust", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
civlib_mm_bytrust <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
plot(civlib_mm_bytrust, group = "Trust", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
civlib_mmdiffs_bytrust <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(civlib_mmdiffs_bytrust, group = "Trust", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
civlib_amcediffs_bytrust <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(civlib_amcediffs_bytrust, group = "Trust", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
corr_amce_bylang <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
plot(corr_amce_bylang, group = "Trust", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
corr_mm_bytrust<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
plot(corr_mm_bytrust, group = "Trust", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
corr_mmdiffs_bytrust <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(corr_mmdiffs_bytrust, group = "Trust", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
corr_amcediffs_bytrust <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(corr_amcediffs_bytrust, group = "Trust", vline = 0.0)

## NEIGHBORHOOD

# 1. MCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
neigh_amce_bytrust<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Trust)
plot(neigh_amce_bytrust, group = "Trust", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
neigh_mm_bytrust <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Trust)
plot(neigh_mm_bytrust, group = "Trust", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
neigh_mmdiffs_bytrust <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(neigh_mmdiffs_bytrust, group = "Trust", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
neigh_amcediffs_bytrust <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Trust, id = ~ idresp)
plot(neigh_amcediffs_bytrust, group = "Trust", vline = 0.0)

#### STEP 6: SUBGROUP TESTS: INCOME ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
eff_amce_byinc <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
plot(eff_amce_byinc, group = "Income", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
eff_mm_byinc <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
plot(eff_mm_byinc, group = "Income", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
eff_mmdiffs_byinc <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(eff_mmdiffs_byinc, group = "Income", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
eff_amcediffs_byinc <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(eff_amcediffs_byinc, group = "Income", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
civlib_amce_byinc <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
plot(civlib_amce_byinc, group = "Income", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
civlib_mm_byinc <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
plot(civlib_mm_byinc, group = "Income", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
civlib_mmdiffs_byinc <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(civlib_mmdiffs_byinc, group = "Income", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
civlib_amcediffs_byinc <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(civlib_amcediffs_byinc, group = "Income", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
corr_amce_byinc<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
plot(corr_amce_byinc, group = "Income", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
corr_mm_byinc <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
plot(corr_mm_byinc, group = "Income", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
corr_mmdiffs_byinc <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(corr_mmdiffs_byinc, group = "Income", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
corr_amcediffs_byinc <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(corr_amcediffs_byinc, group = "Income", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
neigh_amce_byinc<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Income)
plot(neigh_amce_byinc, group = "Income", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
neigh_mm_byinc <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Income)
plot(neigh_mm_byinc, group = "Income", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
neigh_mmdiffs_byinc <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(neigh_mmdiffs_byinc, group = "Income", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
neigh_amcediffs_byinc <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Income, id = ~ idresp)
plot(neigh_amcediffs_byinc, group = "Income", vline = 0.0)


#### STEP 7: SUBGROUP TESTS: GENDER ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
eff_amce_bygen <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
plot(eff_amce_bygen, group = "Sex", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
eff_mm_bygen <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
plot(eff_mm_bygen, group = "Sex", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
eff_mmdiffs_bygen <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(eff_mmdiffs_bygen, group = "Sex", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
eff_amcediffs_bygen <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(eff_amcediffs_bygen, group = "Sex", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
civlib_amce_bygen <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
plot(civlib_amce_bygen, group = "Sex", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
civlib_mm_bygen <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
plot(civlib_mm_bygen, group = "Sex", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
civlib_mmdiffs_bygen <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(civlib_mmdiffs_bygen, group = "Sex", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
civlib_amcediffs_bygen <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(civlib_amcediffs_bygen, group = "Sex", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
corr_amce_bygen<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
plot(corr_amce_bygen, group = "Sex", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
corr_mm_bygen <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
plot(corr_mm_bygen, group = "Sex", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
corr_mmdiffs_bygen <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(corr_mmdiffs_bygen, group = "Sex", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
corr_amcediffs_bygen <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(corr_amcediffs_bygen, group = "Sex", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
neigh_amce_bygen<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Sex)
plot(neigh_amce_bygen, group = "Sex", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
neigh_mm_bygen <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Sex)
plot(neigh_mm_bygen, group = "Sex", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
neigh_mmdiffs_bygen <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(neigh_mmdiffs_bygen, group = "Sex", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
neigh_amcediffs_bygen <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Sex, id = ~ idresp)
plot(neigh_amcediffs_bygen, group = "Sex", vline = 0.0)

#### STEP 8: SUBGROUP TESTS: AGE ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
eff_amce_byage <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
plot(eff_amce_byage, group = "Age", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
eff_mm_byage <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
plot(eff_mm_byage, group = "Age", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
eff_mmdiffs_byage <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(eff_mmdiffs_byage, group = "Age", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
eff_amcediffs_byage <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(eff_amcediffs_byage, group = "Age", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
civlib_amce_byage <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
plot(civlib_amce_byage, group = "Age", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
civlib_mm_byage <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
plot(civlib_mm_byage, group = "Age", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
civlib_mmdiffs_byage<-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(civlib_mmdiffs_byage, group = "Age", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
civlib_amcediffs_byage <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(civlib_amcediffs_byage, group = "Age", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
corr_amce_byage<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
plot(corr_amce_byage, group = "Age", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
corr_mm_byage <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
plot(corr_mm_byage, group = "Age", vline = 0.53)

# 3. MM DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
corr_mmdiffs_byage <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(corr_mmdiffs_byage, group = "Age", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
corr_amcediffs_byage <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(corr_amcediffs_byage, group = "Age", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
neigh_amce_byage<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Age)
plot(neigh_amce_byage, group = "Age", vline = 0.0)

# 2. MARGINAL MEANS
neigh_mm_byage <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Age)
plot(neigh_mm_byage, group = "Age", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
neigh_mmdiffs_byage <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(neigh_mmdiffs_byage, group = "Age", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
neigh_amcediffs_byage <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Age, id = ~ idresp)
plot(neigh_amcediffs_byage, group = "Age", vline = 0.0)

#### STEP 9: SUBGROUP TESTS: EDUCATION ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
eff_amce_byedu <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
plot(eff_amce_byedu, group = "Education", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
eff_mm_byedu <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
plot(eff_mm_byedu, group = "Education", vline = 0.59)

# 3. MM DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
eff_mmdiffs_byedu <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(eff_mmdiffs_byedu, group = "Education", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
eff_amcediffs_byedu <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(eff_amcediffs_byedu, group = "Education", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
civlib_amce_byedu <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
plot(civlib_amce_byedu, group = "Education", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
civlib_mm_byedu <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
plot(civlib_mm_byedu, group = "Education", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
civlib_mmdiffs_byedu <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(civlib_mmdiffs_byedu, group = "Education", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
civlib_amcediffs_byedu <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(civlib_amcediffs_byedu, group = "Education", vline = 0.0)

## CORRUPTION

# 1. AMCEs
corr_amce_byedu<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
plot(corr_amce_byedu, group = "Education", vline = 0.0)

# 2. MARGINAL MEANS
corr_mm_byedu <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
plot(corr_mm_byedu, group = "Education", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
corr_mmdiffs_byedu <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(corr_mmdiffs_byedu, group = "Education", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
corr_amcediffs_byedu <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(corr_amcediffs_byedu, group = "Education", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
neigh_amce_byedu<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Education)
plot(neigh_amce_byedu, group = "Education", vline = 0.0)

# 2. PLOT MMs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
neigh_mm_byedu <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Education)
plot(neigh_mm_byedu, group = "Education", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
neigh_mmdiffs_byedu <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(neigh_mmdiffs_byedu, group = "Education", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
neigh_amcediffs_byedu <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Education, id = ~ idresp)
plot(neigh_amcediffs_byedu, group = "Education", vline = 0.0)

#### STEP 10: SUBGROUP TESTS: VICTIMIZATION ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
eff_amce_byvic <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
plot(eff_amce_byvic, group = "Victimization", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
eff_mm_byvic <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
plot(eff_mm_byvic, group = "Victimization", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
eff_mmdiffs_byvic <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(eff_mmdiffs_byvic, group = "Victimization", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
eff_amcediffs_byvic <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(eff_amcediffs_byvic, group = "Victimization", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
civlib_amce_byvic <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
plot(civlib_amce_byvic, group = "Victimization", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
civlib_mm_byvic <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
plot(civlib_mm_byvic, group = "Victimization", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
civlib_mmdiffs_byvic <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(civlib_mmdiffs_byvic, group = "Victimization", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
civlib_amcediffs_byvic <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(civlib_amcediffs_byvic, group = "Victimization", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
corr_amce_byvic<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
plot(corr_amce_byvic, group = "Victimization", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
corr_mm_byvic <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
plot(corr_mm_byvic, group = "Victimization", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
corr_mmdiffs_byvic <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(corr_mmdiffs_byvic, group = "Victimization", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
corr_amcediffs_byvic <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(corr_amcediffs_byvic, group = "Victimization", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
neigh_amce_byvic<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Victimization)
plot(neigh_amce_byvic, group = "Victimization", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
neigh_mm_byvic <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Victimization)
plot(neigh_mm_byvic, group = "Victimization", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
neigh_mmdiffs_byvic <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(neigh_mmdiffs_byvic, group = "Victimization", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
neigh_amcediffs_byvic <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Victimization, id = ~ idresp)
plot(neigh_amcediffs_byvic, group = "Victimization", vline = 0.0)     

#### STEP 11: SUBGROUP TESTS: IDEOLOGY ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
eff_amce_byid <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
plot(eff_amce_byid, group = "Ideology_Two", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
eff_mm_byid <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
plot(eff_mm_byid, group = "Ideology_Two", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
eff_mmdiffs_byid <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(eff_mmdiffs_byid, group = "Ideology_Two", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
eff_amcediffs_byid <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(eff_amcediffs_byid, group = "Ideology_Two", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
civlib_amce_byid <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
plot(civlib_amce_byid, group = "Ideology_Two", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
civlib_mm_byid <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
plot(civlib_mm_byid, group = "Ideology_Two", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
civlib_mmdiffs_byid <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(civlib_mmdiffs_byid, group = "Ideology_Two", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
civlib_amcediffs_byid <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(civlib_amcediffs_byid, group = "Ideology_Two", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
corr_amce_byid<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
plot(corr_amce_byid, group = "Ideology_Two", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
corr_mm_byid <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
plot(corr_mm_byid, group = "Ideology_Two", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
corr_mmdiffs_byid <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(corr_mmdiffs_byid, group = "Ideology_Two", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
corr_amcediffs_byid <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(corr_amcediffs_byid, group = "Ideology_Two", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
neigh_amce_byid<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Ideology_Two)
plot(neigh_amce_byid, group = "Ideology_Two", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
neigh_mm_byid <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Ideology_Two)
plot(neigh_mm_byid, group = "Ideology_Two", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
neigh_mmdiffs_byid <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(neigh_mmdiffs_byid, group = "Ideology_Two", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
neigh_amcediffs_byid <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Ideology_Two, id = ~ idresp)
plot(neigh_amcediffs_byid, group = "Ideology_Two", vline = 0.0) 

#### STEP 12: SUBGROUP TESTS: PERCEIVED INSECURITY ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
eff_amce_byinsec <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
plot(eff_amce_byinsec, group = "Insecure", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
eff_mm_byinsec <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
plot(eff_mm_byinsec, group = "Insecure", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
eff_mmdiffs_byinsec <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(eff_mmdiffs_byinsec, group = "Insecure", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
eff_amcediffs_byinsec <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(eff_amcediffs_byinsec, group = "Insecure", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
civlib_amce_byinsec <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
plot(civlib_amce_byinsec, group = "Insecure", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
civlib_mm_byinsec<- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
plot(civlib_mm_byinsec, group = "Insecure", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
civlib_mmdiffs_byinsec <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(civlib_mmdiffs_byinsec, group = "Insecure", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
civlib_amcediffs_byinsec <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(civlib_amcediffs_byinsec, group = "Insecure", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
corr_amce_byinsec<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
plot(corr_amce_byinsec, group = "Insecure", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
corr_mm_byinsec <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
plot(corr_mm_byinsec, group = "Insecure", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
corr_mmdiffs_byinsec <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(corr_mmdiffs_byinsec, group = "Insecure", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
corr_amcediffs_byinsec<-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(corr_amcediffs_byinsec, group = "Insecure", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
neigh_amce_byinsec<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Insecure)
plot(neigh_amce_byinsec, group = "Insecure", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
neigh_mm_byinsec <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Insecure)
plot(neigh_mm_byinsec, group = "Insecure", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
neigh_mmdiffs_byinsec <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(neigh_mmdiffs_byinsec, group = "Insecure", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
neigh_amcediffs_byinsec <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Insecure, id = ~ idresp)
plot(neigh_amcediffs_byinsec, group = "Insecure", vline = 0.0) 

#### STEP 13: SUBGROUP TESTS: HOMICIDES ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
eff_amce_byhom <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
plot(eff_amce_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
eff_mm_byhom <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
plot(eff_mm_byhom, group = "Homicide_Rate_Median", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
eff_mmdiffs_byhom <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(eff_mmdiffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
eff_amcediffs_byhom <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(eff_amcediffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
civlib_amce_byhom <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
plot(civlib_amce_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
civlib_mm_byhom<- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
plot(civlib_mm_byhom, group = "Homicide_Rate_Median", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
civlib_mmdiffs_byhom <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(civlib_mmdiffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
civlib_amcediffs_byhom <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(civlib_amcediffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
corr_amce_byhom<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
plot(corr_amce_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
corr_mm_byhom <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
plot(corr_mm_byhom, group = "Homicide_Rate_Median", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
corr_mmdiffs_byhom <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(corr_mmdiffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
corr_amcediffs_byhom<-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(corr_amcediffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
neigh_amce_byhom<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~Homicide_Rate_Median)
plot(neigh_amce_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
neigh_mm_byhom <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~Homicide_Rate_Median)
plot(neigh_mm_byhom, group = "Homicide_Rate_Median", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
neigh_mmdiffs_byhom <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(neigh_mmdiffs_byhom, group = "Homicide_Rate_Median", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
neigh_amcediffs_byhom <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ Homicide_Rate_Median, id = ~ idresp)
plot(neigh_amcediffs_byhom, group = "Homicide_Rate_Median", vline = 0.0) 


#### STEP 14: SUBGROUP TESTS: PARTYID ####

## EFFECTIVENESS

# 1. AMCEs
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
eff_amce_bypid <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
plot(eff_amce_bypid, group = "PartyID_3", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
eff_mm_bypid <- cj(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
plot(eff_mm_bypid, group = "PartyID_3", vline = 0.59)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
eff_mmdiffs_bypid <-mm_diffs(militconj, effective ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(eff_mmdiffs_bypid, group = "PartyID_3", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
eff_amcediffs_bypid <-amce_diffs(militconj, whicheffective ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(eff_amcediffs_bypid, group = "PartyID_3", vline = 0.0)

## CIVIL LIBERTIES

# 1. AMCEs
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
civlib_amce_bypid <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
plot(civlib_amce_bypid, group = "PartyID_3", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
civlib_mm_bypid <- cj(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
plot(civlib_mm_bypid, group = "PartyID_3", vline = 0.55)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
civlib_mmdiffs_bypid <-mm_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(civlib_mmdiffs_bypid, group = "PartyID_3", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
civlib_amcediffs_bypid <-amce_diffs(militconj, lib ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(civlib_amcediffs_bypid, group = "PartyID_3", vline = 0.0)

## CORRUPTION

# 1. AMCEs
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
corr_amce_bypid<- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
plot(corr_amce_bypid, group = "PartyID_3", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
corr_mm_bypid <- cj(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
plot(corr_mm_bypid, group = "PartyID_3", vline = 0.53)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
corr_mmdiffs_bypid <-mm_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(corr_mmdiffs_bypid, group = "PartyID_3", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
corr_amcediffs_bypid <-amce_diffs(militconj, corrupt ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(corr_amcediffs_bypid, group = "PartyID_3", vline = 0.0)

## NEIGHBORHOOD

# 1. AMCEs
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
neigh_amce_bypid<- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "amce", by = ~PartyID_3)
plot(neigh_amce_bypid, group = "PartyID_3", vline = 0.0)

# 2. MARGINAL MEANS
cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
neigh_mm_bypid <- cj(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, id = ~idresp, estimate = "mm", by = ~PartyID_3)
plot(neigh_mm_bypid, group = "PartyID_3", vline = 0.62)

# 3. MARGINAL MEANS DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
neigh_mmdiffs_bypid <-mm_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(neigh_mmdiffs_bypid, group = "PartyID_3", vline = 0.0)

# 4. AMCE DIFFERENCES BY ATTRIBUTE TO SEE IF SIGNIFICANTLY DIFFERENT
amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
neigh_amcediffs_bypid <-amce_diffs(militconj, neighb ~ Weapon + Uniform + Gender + SkinColor, ~ PartyID_3, id = ~ idresp)
plot(neigh_amcediffs_bypid, group = "PartyID_3", vline = 0.0) 



