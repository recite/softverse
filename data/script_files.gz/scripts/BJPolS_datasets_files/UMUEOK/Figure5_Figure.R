
rm(list=ls())

library(tidyr)
library(tibble)
library(stargazer)
library(dplyr)
library(haven)
library(ggplot2)
library(gtools)

#########################################################################
# REPLICATION FILES: MILITARIZATION AND PERCEPTIONS OF LAW ENFORCEMENT  #
# JOURNAL: BJPS                                                         #
# FIGURE 5: FIGURE                                                      #
#########################################################################

#### STEP 1: UPLOAD RESULTS DATA                          ####

all_corr <- read.table("All_Corr.txt",sep="")
all_eff <- read.table("All_Eff.txt",sep="")
all_neigh <- read.table("All_Neigh.txt",sep="")
all_civ <- read.table("All_CivLib.txt",sep="")


#### STEP 1: SET THEME                                     ####

theme_bw1 <- function(base_size = 13, base_family = "") {
  theme_grey(base_size = base_size, base_family = base_family) %+replace%
    theme(
      axis.text.x =       element_text(size = 8, colour = "black",  hjust = .5 , vjust=1),
      axis.text.y =       element_text(size = 11 , colour = "black", hjust = 0 , vjust=.5 ), # changes position of X axis text
      axis.ticks =        element_line(colour = "grey50"),
      axis.title.y =      element_text(size = base_size,angle=90,vjust=.01,hjust=.1),
      axis.title.x =      element_text(size =12),
      legend.position = "none",
      panel.background = element_rect(fill = "#F5F5F5"),
      strip.background = element_rect(colour="black", fill="white")
    )
}

#### STEP 3: FUNCTION TO PREPARE DATA FOR FIGURES           ####

prepdata <- function(d){
  
  # prep estimates
  d$var <- rownames(d)
  colnames(d) <- c("pe","se","var")
  d$order <- 1:nrow(d)
  # compute Cis
  d$upper95 <-d$pe + 1.96*d$se
  d$lower95 <-d$pe - 1.96*d$se
  
  d$upper90 <-d$pe + 1.645*d$se
  d$lower90 <-d$pe - 1.645*d$se
  
  # define group
  d$group <- NA
  d$group[d$var %in% paste(c("1b",2),".FeatGender",sep="")]         <- "Gender"
  d$group[d$var %in% paste(c("1b",2),".FeatSkin",sep="")]           <- "Skin Color"
  d$group[d$var %in% paste(c("1b",2),".FeatUniform",sep="")]         <- "Uniform"
  d$group[d$var %in% paste(c("1b",2),".FeatWeapon",sep="")]       <- "Weapon"
  
  # order 
  d <- d[order(factor(d$group,levels=unique(d$group)[c(3,4,1,2)])),]
  d$order <- 1:nrow(d)
  
  # label attributes
  offset <- c("   ")
  
  d$var[d$group=="Gender"] <- paste(offset,c("Male","Female"))
  d$var[d$group=="Skin Color"] <- paste(offset,c("Light","Dark"))
  d$var[d$group=="Uniform"] <- paste(offset,c("Military","Police"))
  d$var[d$group=="Weapon"] <- paste(offset,c("Assault Rifle","None"))
  
  # sub in group labels
  dd <- data.frame(var= c("Uniform:",
                          " ",
                          "Weapon:",
                          "  ",
                          "Gender:",
                          "   ",
                          "Skin Color:"
  ),order=c(.5,2.1,2.5,4.1,4.5,6.1,6.5),
  pe=1,se=1,upper95=1,lower95=1, upper90=1, lower90=1,group=NA)
  d <- rbind(d,dd)
  d <-d[order(d$order),]
  d$var <- factor(d$var,levels=unique(d$var)[length(d$var):1])
  return(d)
}

#### STEP 4: PREPARE DATASETS                               ####

all_civ <- prepdata(all_civ)
all_civ$model<-"Civil Liberties"

all_corr <- prepdata(all_corr)
all_corr$model<-"Corruption"

all_eff <- prepdata(all_eff)
all_eff$model<-"Effectiveness"

all_neigh <- prepdata(all_neigh)
all_neigh$model<-"Neighborhood"

#### STEP 5: APPEND DATASETS                               ####

ratings_all<-smartbind(all_civ, all_corr, all_eff, all_neigh)

#### STEP 6: ORDER FACETS                                  ####

ratings_all$model <- factor(ratings_all$model, levels = c("Effectiveness", "Civil Liberties",
                                                          "Corruption", "Neighborhood"))

#### STEP 7: CREATE FIGURE 5                                 ####


yylab2  <- c("Standardized effect on Security Personnel Rating")


all_ratings = ggplot(ratings_all, aes(y=pe,x=var)) +
  coord_flip(ylim = c(-.2, 0.2)) +
  geom_hline(yintercept = 0,size=.5,colour="darkgrey",linetype="solid") + 
  geom_linerange(aes(ymin=lower95,ymax=upper95),position="dodge",size=1, color="black") +
  geom_linerange(aes(ymin=lower90,ymax=upper90),size=1, color="#969696", linetype=1, position = position_nudge(x = -0.09)) +
  geom_point(size=3) +
  scale_y_continuous(name=yylab2) +
  scale_x_discrete(name="") +
  facet_grid(.~ model)

plot(all_ratings)

#pdf(paste("FIGURE5.pdf",sep=""),width=10,height=6) 
#all_ratings = all_ratings  + theme_bw1()
#print(all_ratings)
#dev.off()

#ggsave("Figure5.png", plot=all_ratings, width=10,height=6, units = "in", dpi = 300)

