
rm(list=ls())

library(tidyr)
library(tibble)
library(stargazer)
library(dplyr)
library(haven)
library(readstata13)
library(ggplot2)
library(cregg)
library(zoo)

#########################################################################
# REPLICATION FILES: MILITARIZATION AND PERCEPTIONS OF LAW ENFORCEMENT  #
# JOURNAL: BJPS                                                         #
# FIGURE 5: REGRESSION RESULTS AMCE                                     #
#########################################################################

#### STEP 1: READ DATA                              ####

militconj <- read.dta13("MilitConjoint.dta")
baselines <- list()

#### STEP 2: RENAME VARIABLES                       ####

colnames(militconj)[colnames(militconj)=="uniform"] <- "uniform_numeric"
colnames(militconj)[colnames(militconj)=="weapon"] <- "weapon_numeric"
colnames(militconj)[colnames(militconj)=="gender"] <- "gender_numeric"
colnames(militconj)[colnames(militconj)=="race"] <- "race_numeric"

#### STEP 3: CHANGE TO FACTORS                      ####


militconj$Uniform<-factor(militconj$uniform_numeric,labels=c("Police", "Military"))
militconj$Weapon<-factor(militconj$weapon_numeric,labels=c("None", "Assault Rifle"))
militconj$Gender<-factor(militconj$gender_numeric,labels=c("Female", "Male"))
militconj$SkinColor<-factor(militconj$race_numeric,labels=c("Dark", "Light"))

##### STEP 4: AMCEs, (DVs IN STANDARD DEVIATIONS)   ####

cj(militconj, zeffective ~ Weapon + Uniform +  Gender + SkinColor, id = ~idresp, estimate = "amce")
cj(militconj, zlib ~ Weapon + Uniform +  Gender + SkinColor, id = ~idresp, estimate = "amce")
cj(militconj, zcorrupt ~ Weapon + Uniform +  Gender + SkinColor, id = ~idresp, estimate = "amce")
cj(militconj, zneighb ~ Weapon + Uniform +  Gender + SkinColor, id = ~idresp, estimate = "amce")

