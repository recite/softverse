
# Replication code for: 
# "Partisan Context and Procedural Values: Attitudes Towards Presidential Secrecy Before and After the 2016 United States Election."
# by Daniel Berliner


library(survey)
library(MASS)
library(texreg)
library(xtable)


setwd("YOUR FILE PATH HERE")

d<-readRDS("CCES16_ASU_OUTPUT_Jul2017.Rds") # from: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/YUONNU





## attitudes towards secrecy, oriented so 100 = harder

#president
d$pres_secrecy<-as.character(d$ASU329)
d$pres_secrecy[d$pres_secrecy=="0 - Much harder"]<-0
d$pres_secrecy[d$pres_secrecy=="100 - Much easier"]<-100
d$pres_secrecy[d$pres_secrecy=="Skipped"]<-NA
d$pres_secrecy<-100 - as.numeric(d$pres_secrecy)

d$pres_secrecy_post<-as.character(d$ASU402)
d$pres_secrecy_post[d$pres_secrecy_post=="0 - Much Harder"]<-0
d$pres_secrecy_post[d$pres_secrecy_post=="100 - Much easier"]<-100
d$pres_secrecy_post[d$pres_secrecy_post=="Skipped"]<-NA
d$pres_secrecy_post<- 100 - as.numeric(d$pres_secrecy_post)

d$pres_secrecy_change<-d$pres_secrecy_post - d$pres_secrecy

d$pres_secrecy_change_dummy_harder<-as.numeric(d$pres_secrecy_change>0)

d$pres_secrecy_change_dummy_harder10<-as.numeric(d$pres_secrecy_change>=10)


#governor
d$gov_secrecy<-as.character(d$ASU328)
d$gov_secrecy[d$gov_secrecy=="0 - Much harder"]<-0
d$gov_secrecy[d$gov_secrecy=="100 - Much easier"]<-100
d$gov_secrecy[d$gov_secrecy=="Skipped"]<-NA
d$gov_secrecy[d$gov_secrecy=="Not Asked"]<-NA
d$gov_secrecy<- 100 - as.numeric(d$gov_secrecy)

d$gov_secrecy_post<-as.character(d$ASU401)
d$gov_secrecy_post[d$gov_secrecy_post=="0 - Much Harder"]<-0
d$gov_secrecy_post[d$gov_secrecy_post=="100 - Much easier"]<-100
d$gov_secrecy_post[d$gov_secrecy_post=="Skipped"]<-NA
d$gov_secrecy_post[d$gov_secrecy_post=="Not Asked"]<-NA
d$gov_secrecy_post<- 100 - as.numeric(d$gov_secrecy_post)

d$gov_secrecy_change<-d$gov_secrecy_post - d$gov_secrecy

d$gov_secrecy_change_dummy_harder<-as.numeric(d$gov_secrecy_change>0)






## political knowledge variable

states<-read.csv("state_info.csv",header=T)

#convert numbers back to parties

#statesen
d$statesen_knowl<-ifelse(d$CC16_321c == 1, "Republicans",
			ifelse(d$CC16_321c == 2, "Democrats", 
			"Other"))

#statelower
d$statelower_knowl<-ifelse(d$CC16_321d == 1, "Republicans",
			ifelse(d$CC16_321d == 2, "Democrats", 
			"Other"))

#GOV
d$GOV_knowl<-ifelse(d$CC16_322a == 2, "Republican",
			ifelse(d$CC16_322a == 3, "Democrat", 
			ifelse(d$CC16_322a == 4, "Other Party / Independent", 
			"Other")))

#SEN1
d$SEN1_knowl<-ifelse(d$CC16_322b == 2, "Republican",
			ifelse(d$CC16_322b == 3, "Democrat", 
			"Other"))

#SEN2
d$SEN2_knowl<-ifelse(d$CC16_322c == 2, "Republican",
			ifelse(d$CC16_322c == 3, "Democrat", 
			ifelse(d$CC16_322c == 4, "Other Party / Independent", 
			"Other")))

#REP
d$REP_knowl<- ifelse(d$CC16_322d == 2, "Republican",
			ifelse(d$CC16_322d == 3, "Democratic", 
			"Other"))

#count how many correct

d$statesen_correct<-NA
d$statelower_correct<-NA
d$GOV_correct<-NA
d$SEN1_correct<-NA
d$SEN2_correct<-NA
d$REP_correct<-NA

for(i in 1:nrow(d)){
	tempstate<-as.character(d$inputstate[i])

	d$statesen_correct[i]<-as.numeric(as.character(d$statesen_knowl[i])==as.character(states$statesen[states$inputstate==tempstate]))
	d$statelower_correct[i]<-as.numeric(as.character(d$statelower_knowl[i])==as.character(states$statelower[states$inputstate==tempstate]))
	d$GOV_correct[i]<-as.numeric(as.character(d$GOV_knowl[i])==as.character(states$GOV[states$inputstate==tempstate]))
	d$SEN1_correct[i]<-as.numeric(as.character(d$SEN1_knowl[i])==as.character(states$SEN1[states$inputstate==tempstate]))
	d$SEN2_correct[i]<-as.numeric(as.character(d$SEN2_knowl[i])==as.character(states$SEN2[states$inputstate==tempstate]))
}

d$REP_correct<-as.numeric(as.character(d$REP_knowl)==d$CurrentHouseParty)


#fix District of Columbia
d$statesen_correct[d$inputstate==11]<-1
d$statelower_correct[d$inputstate==11]<-1
d$GOV_correct[d$inputstate==11]<-1
d$SEN1_correct[d$inputstate==11]<-1
d$SEN2_correct[d$inputstate==11]<-1


#fix nebraska
d$statesen_correct[d$inputstate==31]<-1
d$statelower_correct[d$inputstate==31]<-1

d$GOV_correct[is.na(d$GOV_correct)]<-0
d$SEN1_correct[is.na(d$SEN1_correct)]<-0
d$SEN2_correct[is.na(d$SEN2_correct)]<-0
d$REP_correct[is.na(d$REP_correct)]<-0


d$polknowl<- as.numeric(d$CC16_321a==1) + as.numeric(d$CC16_321b==1) + # house and senate
	d$statesen_correct+
	d$statelower_correct+
	d$GOV_correct+
	d$SEN1_correct+
	d$SEN2_correct+
	d$REP_correct





# index of attitudes towards transparency

d$t_right_to_info<-d$ASU322
d$t_better_decisions<-d$ASU323
d$t_fight_corruption<-d$ASU324
d$t_secrets_natsec<-d$ASU325
d$t_secrets_privacy<-d$ASU326
d$t_wasteoftime<-d$ASU327

d$t_right_to_info[is.na(d$t_right_to_info)]<-3
d$t_better_decisions[is.na(d$t_better_decisions)]<-3
d$t_fight_corruption[is.na(d$t_fight_corruption)]<-3
d$t_secrets_natsec[is.na(d$t_secrets_natsec)]<-3
d$t_secrets_privacy[is.na(d$t_secrets_privacy)]<-3
d$t_wasteoftime[is.na(d$t_wasteoftime)]<-3

#flip where the question was oriented reverse
d$t_secrets_natsec_flip<- 6-d$t_secrets_natsec
d$t_secrets_privacy_flip<- 6-d$t_secrets_privacy
d$t_wasteoftime_flip<- 6-d$t_wasteoftime

d$transparency_index<-  d$t_right_to_info + d$t_better_decisions + d$t_fight_corruption + d$t_secrets_natsec_flip + d$t_secrets_privacy_flip + d$t_wasteoftime_flip



##partisanship, vote, ideology

d$partyID7<-d$pid7
d$partyID7[d$partyID7==8]<-4 #"not sure" in the middle

d$partyID7_3<-NA
d$partyID7_3[d$partyID7 %in% c(1,2,3)]<-1
d$partyID7_3[d$partyID7==4]<-2
d$partyID7_3[d$partyID7 %in% c(5,6,7)]<-3

d$republican <- as.numeric(d$partyID7_3==3)
d$democrat <- as.numeric(d$partyID7_3==1)
d$independent <- as.numeric(d$partyID7_3==2)

d$ideology<-d$CC16_340a
d$ideology[d$ideology==8]<-4 #"not sure" in the middle


#vote post
d$trump_vote<-as.numeric(d$CC16_410a==1)
d$clinton_vote<-as.numeric(d$CC16_410a==2)

#vote intention pre (also include the few who had already voted early)
d$trump_intention<-as.numeric(d$CC16_364c==1)
d$trump_intention[d$CC16_364b==1 & !is.na(d$CC16_364b)]<-1
d$trump_intention[is.na(d$trump_intention)]<-0

d$clinton_intention<-as.numeric(d$CC16_364c==2)
d$clinton_intention[d$CC16_364b==2 & !is.na(d$CC16_364b)]<-1
d$clinton_intention[is.na(d$clinton_intention)]<-0


#age
d$age<- 2016 - d$birthyr

#gender
d$female<-as.numeric(d$gender==2)

#education
d$education<- d$educ - 1 #start at 0

#race
d$white<-as.numeric(d$race==1)

#income
d$income<-d$faminc
d$income[d$income %in% c(12,13,14,15,16,31)]<-12
d$income[d$income==97]<-0
d$income_noanswer<-as.numeric(d$faminc==97)

#military
#milstat_1, 2, 3, 4 -- self, family, self previuosly, family previously
d$military_fam<-as.numeric(((d$milstat_1==1)+(d$milstat_2==1)+(d$milstat_3==1)+(d$milstat_4==1))>0)

#newsinterest
d$newsinterest_dum<-as.numeric(d$newsint==1) # follow political news "most of the time"





## descriptive statistics noted in text

# The within-individual correlation between pre-election and post-election responses is only 0.29. 
cor(d$pres_secrecy, d$pres_secrecy_post, use="complete.obs")

# A full 64 percent of respondents shifted by ten or more points in either direction
mean(abs(d$pres_secrecy_change[!is.na(d$pres_secrecy_change)])>=10)

# 32.6 percent crossed the midpoint in one direction or the other – either from below 50 to above, or vice versa.
mean(d$pres_secrecy[!is.na(d$pres_secrecy_change)]<50 & d$pres_secrecy_post[!is.na(d$pres_secrecy_change)]>50) + mean(d$pres_secrecy[!is.na(d$pres_secrecy_change)]>50 & d$pres_secrecy_post[!is.na(d$pres_secrecy_change)]<50)



## survey weights

#vermont has only one obs; need to drop for clustering to work
dw <- svydesign(ids=~1, data=d[d$inputstate!=50,], strata=~inputstate , weights=d$weight[d$inputstate!=50])



## summary statistics (with weights)

temp_seq<-c(
"pres_secrecy",
"pres_secrecy_post",
"pres_secrecy_change",
"pres_secrecy_change_dummy_harder",
"pres_secrecy_change_dummy_harder10",
"republican",
"democrat",
"partyID7",
"ideology",
"trump_intention",
"polknowl",
"female",
"age",
"white",
"military_fam",
"education",
"income",
"income_noanswer",
"transparency_index",
"newsinterest_dum"
)

sumstats<-NULL

for(i in 1:length(temp_seq)){
tempvar<-temp_seq[i]
tempform<-paste("~",tempvar)

tempstats<-c( range(d[tempvar],na.rm=T), svymean(as.formula(tempform), dw, na.rm=T)[1], sqrt(svyvar(as.formula(tempform), dw, na.rm=T))[1] )
sumstats<-rbind(sumstats, tempstats)
}
rownames(sumstats)<-temp_seq
colnames(sumstats)<-c("Min.","Max.","Mean","SD")

xtable(round(sumstats,2))


## correlation matrix
cormatrix<-as.matrix(svyvar(~ 
pres_secrecy+
pres_secrecy_post+
pres_secrecy_change+
pres_secrecy_change_dummy_harder+
pres_secrecy_change_dummy_harder10+
republican+
democrat+
partyID7+
ideology+
trump_intention+
polknowl+
female+
age+
white+
military_fam+
education+
income+
income_noanswer+
transparency_index+
newsinterest_dum
, dw, na.rm=T))

attr(cormatrix, "var")<-NULL
attr(cormatrix, "statistic")<-NULL

cormatrix<-cov2cor(cormatrix)
xtable(round(cormatrix,3))









############################
############################
############################

## regression models

r2list<-function(x){as.numeric(lapply(x, function(x){1-x$deviance/x$null.deviance }))}

custom_coefs<-list(
'republican'="Republican", 
'democrat'="Democrat",
'trump_intention'="Trump Vote Intention",
'trump_vote'="Trump Vote (Reported Post-Election)",
'clinton_intention'="Clinton Vote Intention",
'republican:polknowl'="Rep. $\\times$ Pol. Knowl.",
'trump_intention:polknowl'="Trump $\\times$ Pol. Knowl.",
'trump_vote:polknowl'="Trump Vote $\\times$ Pol. Knowl.",
'democrat:polknowl'="Dem. $\\times$ Pol. Knowl.",
'clinton_intention:polknowl'="Clinton $\\times$ Pol. Knowl.",
'republican:newsinterest_dum'="Rep. $\\times$ High News Interest",
'trump_intention:newsinterest_dum'="Trump $\\times$ High News Interest",
'partyID7'='Party ID (7-point)',
'polknowl'= "Pol. Knowledge",
'newsinterest'="News Interest",
'pres_secrecy'="Pres. Secrecy: Pre",
'gov_secrecy_change'="Gov. Secrecy: Change",
'female'= "Female",
'age'= "Age",
'white'= "White",
'military_fam'="Military Family",
'education'= "Education",
'income'= "Income",
'income_noanswer'="Income: No Answer",
'transparency_index'="Transparency Index",
'(Intercept)'="Constant"
)



# main models, logit and continuous
m1<-svyglm(pres_secrecy_change_dummy_harder~republican,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m2<-svyglm(pres_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m3<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )


m4<-svyglm(pres_secrecy_change_dummy_harder10~republican,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m5<-svyglm(pres_secrecy_change_dummy_harder10~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m6<-svyglm(pres_secrecy_change_dummy_harder10~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )


m7<-svyglm(pres_secrecy_change~republican,design=subset(dw, as.numeric(partyID7_3!=2)))

m8<-svyglm(pres_secrecy_change~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)))

m9<-svyglm(pres_secrecy_change~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)))

texreg(list(m1, m2, m3, m4, m5, m6, m7, m8, m9), stars=c(0.001, 0.01, 0.05),
	caption="
	Models 1-3 employ logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on secrecy) in response from pre-election to post-election survey wave. 
	Models 4-6 employ logistic regressions of indicator for only those within-individual changes of 10 points or greater.
	Models 7-9 employ linear models of continuous within-individual changes in response.
	Independents omitted from all samples. Standard errors clustered by state.",
	custom.coef.map=custom_coefs )
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6, m7, m8, m9)[,2],2) , sep=" & "),"\\\\",sep="")
cat(cat("R-square", round(r2list(list(m1, m2, m3, m4, m5, m6, m7, m8, m9)),3) , sep=" & "),"\\\\",sep="")




# trump variables instead of republican

m1<-svyglm(pres_secrecy_change_dummy_harder~trump_intention,design=dw, family=quasibinomial() )

m2<-svyglm(pres_secrecy_change_dummy_harder~trump_intention+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m3<-svyglm(pres_secrecy_change_dummy_harder~trump_intention*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )


m4<-svyglm(pres_secrecy_change_dummy_harder~trump_vote,design=dw, family=quasibinomial() )

m5<-svyglm(pres_secrecy_change_dummy_harder~trump_vote+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m6<-svyglm(pres_secrecy_change_dummy_harder~trump_vote*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

texreg(list(m1, m2, m3, m4, m5, m6 ), stars=c(0.001, 0.01, 0.05) ,
	caption="Robustness checks replacing measure of partisan identification with Trump vote, either reported vote intention in pre-election survey, or reported vote choice in post-election survey.
	Logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on secrecy) in response from pre-election to post-election survey wave. Standard errors clustered by state.",
	custom.coef.map=custom_coefs )
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6)[,2],2) , sep=" & "),"\\\\",sep="")





# include independents, alternately comparing R-vs-others and D-vs-others
m1<-svyglm(pres_secrecy_change_dummy_harder~republican,design=dw, family=quasibinomial() )

m2<-svyglm(pres_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m3<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )


m4<-svyglm(pres_secrecy_change_dummy_harder~democrat,design=dw, family=quasibinomial() )

m5<-svyglm(pres_secrecy_change_dummy_harder~democrat+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m6<-svyglm(pres_secrecy_change_dummy_harder~democrat*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )


texreg(list(m1, m2, m3, m4, m5, m6), stars=c(0.001, 0.01, 0.05),
	caption="Robustness checks retaining Independents in the sample, comparing either Republicans to the set of Democrats and Independents, or Democrats to the set of Republicans and Independents. Logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on secrecy) in response from pre-election to post-election survey wave. Standard errors clustered by state.",
	custom.coef.map=custom_coefs)
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6)[,2],2) , sep=" & "),"\\\\",sep="")




# additional controls

# control for transparency index
m1<-svyglm(pres_secrecy_change_dummy_harder~republican + transparency_index,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m2<-svyglm(pres_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + transparency_index,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m3<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + transparency_index,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

# control for initial response
m4<-svyglm(pres_secrecy_change_dummy_harder~republican + pres_secrecy,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m5<-svyglm(pres_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + pres_secrecy,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m6<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + pres_secrecy,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

# control for change in gov secrecy attitude
m7<-svyglm(pres_secrecy_change_dummy_harder~republican + gov_secrecy_change,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m8<-svyglm(pres_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + gov_secrecy_change,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m9<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer + gov_secrecy_change,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

texreg(list(m1, m2, m3, m4, m5, m6, m7, m8, m9), stars=c(0.001, 0.01, 0.05),
	caption="Robustness checks controlling for index of principled support for transparency (Models 1-3),
	controlling for initial response in the pre-election wave (Models 4-6), 
	and controlling for change in attitude towards Governor's secrecy (Models 7-9). Logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on secrecy) in response from pre-election to post-election survey wave. Independents omitted from sample. Standard errors clustered by state.",
	custom.coef.map=custom_coefs)
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6, m7, m8, m9)[,2],2) , sep=" & "),"\\\\",sep="")




# other possible interaction terms
m1<-svyglm(pres_secrecy_change_dummy_harder~republican*newsinterest_dum+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m2<-svyglm(pres_secrecy_change_dummy_harder~republican*transparency_index+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m3<-svyglm(pres_secrecy_change_dummy_harder~republican*female+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m4<-svyglm(pres_secrecy_change_dummy_harder~republican*age+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m5<-svyglm(pres_secrecy_change_dummy_harder~republican*white+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m6<-svyglm(pres_secrecy_change_dummy_harder~republican*military_fam+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m7<-svyglm(pres_secrecy_change_dummy_harder~republican*education+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
m8<-svyglm(pres_secrecy_change_dummy_harder~republican*income + republican*income_noanswer+polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )
texreg(list(m1, m2, m3, m4, m5, m6, m7, m8), stars=c(0.001, 0.01, 0.05),
		caption="Alternative interaction terms with partisanship. Logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on secrecy) in response from pre-election to post-election survey wave. Independents omitted from sample. Standard errors clustered by state.",
	custom.coef.map=list(
'republican'="Republican", 
'newsinterest_dum'="High News Interest",
'republican:newsinterest_dum'="Rep. $\\times$ High News Interest",
'transparency_index'="Transparency Index",
'republican:transparency_index'="Republican $\\times$ Transparency Index",
'female'= "Female",
'republican:female'="Republican $\\times$ Female",
'age'= "Age",
'republican:age'="Republican $\\times$ Age",
'white'= "White",
'republican:white'="Republican $\\times$ White",
'military_fam'="Military Family",
'republican:military_fam'="Republican $\\times$ Military Family",
'education'= "Education",
'republican:education'="Republican $\\times$ Education",
'income'= "Income",
'income_noanswer'="Income: No Answer",
'republican:income'="Republican $\\times$ Income",
'republican:income_noanswer'="Republican $\\times$ Income: No Answer",
'polknowl'= "Pol. Knowledge",
'(Intercept)'="Constant"
))
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6, m7, m8)[,2],2) , sep=" & "),"\\\\",sep="")




# party ID 7 point, ideology, and partisan strength

m1<-svyglm(pres_secrecy_change_dummy_harder~partyID7,design=dw, family=quasibinomial() )

m2<-svyglm(pres_secrecy_change_dummy_harder~partyID7+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m3<-svyglm(pres_secrecy_change_dummy_harder~partyID7*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m4<-svyglm(pres_secrecy_change_dummy_harder~ideology,design=dw, family=quasibinomial() )

m5<-svyglm(pres_secrecy_change_dummy_harder~ideology+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m6<-svyglm(pres_secrecy_change_dummy_harder~ideology*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

m7<-svyglm(pres_secrecy_change_dummy_harder~as.numeric(partyID7==1)+
	as.numeric(partyID7==2)+
	as.numeric(partyID7==3)+
	as.numeric(partyID7==5)+
	as.numeric(partyID7==6)+
	as.numeric(partyID7==7),design=dw, family=quasibinomial() )

m8<-svyglm(pres_secrecy_change_dummy_harder~as.numeric(partyID7==1)+
	as.numeric(partyID7==2)+
	as.numeric(partyID7==3)+
	as.numeric(partyID7==5)+
	as.numeric(partyID7==6)+
	as.numeric(partyID7==7)+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=dw, family=quasibinomial() )

texreg(list(m1, m2, m3, m4, m5, m6, m7, m8), stars=c(0.001, 0.01, 0.05),
	caption="Robustness checks using seven-point partisan identification scale in place of dichotomous partisanship variable. Models 5 and 6 treat the seven-point scale as categorial, with Independent as the reference category.",
	custom.coef.map=list(
'partyID7'="Party ID (7-point)", 
'partyID7:polknowl'="Party ID $\\times$ Pol. Knowledge",
'ideology'="Ideology",
'ideology:polknowl'="Ideology $\\times$ Pol. Knowl.",
'polknowl'= "Pol. Knowledge",
'female'= "Female",
'age'= "Age",
'white'= "White",
'military_fam'="Military Family",
'education'= "Education",
'income'= "Income",
'income_noanswer'="Income: No Answer",
'as.numeric(partyID7 == 1)'="`Strong Democrat'",
'as.numeric(partyID7 == 2)'="`Not very strong Democrat'",
'as.numeric(partyID7 == 3)'="`Lean Democrat'",
'as.numeric(partyID7 == 5)'="`Lean Republican'",
'as.numeric(partyID7 == 6)'="`Not very strong Republican'",
'as.numeric(partyID7 == 7)'="`Strong Republican'",
'(Intercept)'="Constant"
))
cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6, m7, m8)[,2],2) , sep=" & "),"\\\\",sep="")



# change in gov secrecy attitude as outcome variable, as a placebo test

m1<-svyglm(gov_secrecy_change_dummy_harder~republican,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m2<-svyglm(gov_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

m3<-svyglm(gov_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

# excluding states with 2016 governor races

gov2016list<-c("Delaware","Indiana","Missouri","Montana","New Hampshire","North Carolina","North Dakota","Oregon","Utah","Vermont","Washington","West Virginia")

m4<-svyglm(gov_secrecy_change_dummy_harder~republican,design=subset(dw, as.numeric(partyID7_3!=2) & !inputstate %in% gov2016list), family=quasibinomial() )

m5<-svyglm(gov_secrecy_change_dummy_harder~republican+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2) & !inputstate %in% gov2016list), family=quasibinomial() )

m6<-svyglm(gov_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2) & !inputstate %in% gov2016list), family=quasibinomial() )

texreg(list(m1, m2, m3, m4, m5, m6), stars=c(0.001, 0.01, 0.05),
	caption="Placebo test employing dependent variable focused on change in attitudes towards gubernatorial secrecy. Logistic regressions of indicator for positive within-individual change (reflecting a shift towards supporting greater constraints on governor's secrecy) in response from pre-election to post-election survey wave. Independents omitted from sample. 
	Sample for Models 4-6 also excludes respondents from twelve states with gubernatorial elections in 2016. 
	Standard errors clustered by state.",
	custom.coef.map=custom_coefs)

cat(cat("AIC", round(AIC(m1, m2, m3, m4, m5, m6)[,2],2) , sep=" & "),"\\\\",sep="")










############################
############################
############################

## figures


pdf(file="final_figureA1.pdf", width=8,height=3)
par(mfrow=c(1,3))
svyhist(~pres_secrecy, subset(dw, !is.na(pres_secrecy_post)), col="gray80", xlab="Easier - Harder", ylim=c(0,0.04), breaks=20, main="Before Election")
abline(v=svymean(~pres_secrecy,subset(dw, !is.na(pres_secrecy_post)),na.rm=T), lty=2)
svyhist(~pres_secrecy_post, dw, col="gray80", xlab="Easier - Harder", ylim=c(0,0.04), breaks=20, main="After Election")
abline(v=svymean(~pres_secrecy_post,dw,na.rm=T), lty=2)
svyhist(~pres_secrecy_change, dw, col="gray80", xlab="Change", ylim=c(0,0.04), breaks=20, main="Change from Before to After")
abline(v=svymean(~pres_secrecy_change,dw,na.rm=T), lty=2)
dev.off()




# in color

col3<-c("#4292c6","#8c6bb1","#fb6a4a")

pdf(file="final_figureA2.pdf", height=5,width=8)
#par(mfrow=c(1,3), mar=c(4, 4, 4, 0)) #c(bottom, left, top, right))
par(mfrow=c(1,3),
    oma = c(2, 4, 0, 0), # two rows of text at the outer left and bottom margin
    mar = c(0, 1, 3, 0), # space for one row of text at ticks and to separate plots
    xpd = NA)            # allow content to protrude into outer margin (and beyond)

barplot(as.numeric(svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]), 
	ylim=c(-14,14), ylab="Within-Individual Change", col=col3, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="All Respondents\n(N=789)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-3,-3,4), labels=c("Dem.", "Indep.","Rep."))
axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]] - 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[3]], y1=svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[3]])
points(x=c(0.5,1.5,2.5), y=as.numeric(svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]), pch=19, cex=0.5)

title(ylab = "Within-Individual Change\n(Easier --- Harder)", outer = TRUE, line = 2)
title(sub="''Do you think it should be easier or harder for the President to keep documents secret from the public?''\nAverage within-individual changes from before to after election.", outer=T, line=-2, font.sub=2)

barplot(svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3], 
	ylim=c(-14,14), ylab="", col=col3, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="Low Political Knowledge\n(N=435)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-7,-7,-7), labels=c("Dem.", "Indep.","Rep."))
#axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3]- 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][1:3], y1=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][1:3])
points(x=c(0.5,1.5,2.5), y=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3], pch=19, cex=0.5)

barplot(svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6], 
	ylim=c(-14,14), ylab="", col=col3, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="High Political Knowledge\n(N=354)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-7,-7,2), labels=c("Dem.", "Indep.","Rep."))
#axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6]- 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][4:6], y1=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][4:6])
points(x=c(0.5,1.5,2.5), y=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6], pch=19, cex=0.5)

dev.off()


# in grayscale

col_gray<-c("gray40","gray60","gray80")

pdf(file="final_figure1.pdf", height=5,width=8)
#par(mfrow=c(1,3), mar=c(4, 4, 4, 0)) #c(bottom, left, top, right))
par(mfrow=c(1,3),
    oma = c(2, 4, 0, 0), # two rows of text at the outer left and bottom margin
    mar = c(0, 1, 3, 0), # space for one row of text at ticks and to separate plots
    xpd = NA)            # allow content to protrude into outer margin (and beyond)


barplot(as.numeric(svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]), 
	ylim=c(-14,14), ylab="Within-Individual Change", col=col_gray, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="All Respondents\n(N=789)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-3,-3,4), labels=c("Dem.", "Indep.","Rep."))
axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]] - 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[3]], y1=svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[3]])
points(x=c(0.5,1.5,2.5), y=as.numeric(svyby(~ pres_secrecy_change, ~ partyID7_3, dw, svymean, keep.var=TRUE, na.rm=T)[[2]]), pch=19, cex=0.5)

title(ylab = "Within-Individual Change\n(Easier --- Harder)", outer = TRUE, line = 2)
title(sub="''Do you think it should be easier or harder for the President to keep documents secret from the public?''\nAverage within-individual changes from before to after election.", outer=T, line=-2, font.sub=2)

barplot(svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3], 
	ylim=c(-14,14), ylab="", col=col_gray, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="Low Political Knowledge\n(N=435)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-7,-7,-7), labels=c("Dem.", "Indep.","Rep."))
#axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3]- 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][1:3], y1=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][1:3])
points(x=c(0.5,1.5,2.5), y=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][1:3], pch=19, cex=0.5)

barplot(svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6], 
	ylim=c(-14,14), ylab="", col=col_gray, space=0, border=NA,
	names.arg=c("","",""),cex.names=0.9, cex.main=1,cex.axis=0.9, cex.lab=0.9,
	main="High Political Knowledge\n(N=354)", axes=F)
text(x=c(0.5,1.5,2.5), y=c(-7,-7,2), labels=c("Dem.", "Indep.","Rep."))
#axis(side=2, at=seq(-12,12,2))
segments(lty=3, x0=c(0.5,1.5,2.5), x1=c(0.5,1.5,2.5), y0=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6]- 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][4:6], y1=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6]+ 1.645*svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[4]][4:6])
points(x=c(0.5,1.5,2.5), y=svyby(~ pres_secrecy_change, ~ partyID7_3+as.numeric(polknowl>5), dw, svymean, keep.var=TRUE, na.rm=T)[[3]][4:6], pch=19, cex=0.5)

dev.off()






# plot interaction terms

m_logit<-svyglm(pres_secrecy_change_dummy_harder~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)), family=quasibinomial() )

pe<-coef(m_logit)
vc<-vcov(m_logit)
sims <- 100000
simbetas <- mvrnorm(sims,pe,vc)

knowl_seq<-0:8
FDs_logit<-rep(NA,length(knowl_seq))
lower_logit<-rep(NA,length(knowl_seq))
upper_logit<-rep(NA,length(knowl_seq))

for (i in 1:length(knowl_seq)){
 xhyp0<-c(1,
 	0, 
	knowl_seq[i],
	svymean(~female, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~age, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~white, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~military_fam, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~education, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income_noanswer, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
 	0*knowl_seq[i]
 )
  
 xhyp1<-c(1,
 	1, 
	knowl_seq[i],
	svymean(~female, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~age, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~white, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~military_fam, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~education, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income_noanswer, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
 	1*knowl_seq[i]
 )
  

	logit_xhyp0<- 1/(1+exp(-(simbetas %*% xhyp0)))
	logit_xhyp1<- 1/(1+exp(-(simbetas %*% xhyp1)))
	firstdifferences<- logit_xhyp1 - logit_xhyp0
 	FDs_logit[i]<-quantile(firstdifferences,0.5)
 	lower_logit[i]<-quantile(firstdifferences,0.025)
 	upper_logit[i]<-quantile(firstdifferences,0.975)   
} 
 




m_linear<-svyglm(pres_secrecy_change~republican*polknowl+
	polknowl+female+age+white+military_fam+education+income+income_noanswer,design=subset(dw, as.numeric(partyID7_3!=2)))

pe<-coef(m_linear)
vc<-vcov(m_linear)
sims <- 100000
simbetas <- mvrnorm(sims,pe,vc)

knowl_seq<-0:8
FDs_OLS<-rep(NA,length(knowl_seq))
lower_OLS<-rep(NA,length(knowl_seq))
upper_OLS<-rep(NA,length(knowl_seq))

for (i in 1:length(knowl_seq)){
 xhyp0<-c(1,
 	0, 
	knowl_seq[i],
	svymean(~female, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~age, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~white, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~military_fam, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~education, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income_noanswer, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
 	0*knowl_seq[i]
 )
  
 xhyp1<-c(1,
 	1, 
	knowl_seq[i],
	svymean(~female, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~age, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~white, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~military_fam, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~education, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
	svymean(~income_noanswer, design=subset(dw, as.numeric(partyID7_3!=2)))[1],
 	1*knowl_seq[i]
 )
  

	firstdifferences<-(simbetas %*% xhyp1) - (simbetas %*% xhyp0)
 	FDs_OLS[i]<-quantile(firstdifferences,0.5)
 	lower_OLS[i]<-quantile(firstdifferences,0.025)
 	upper_OLS[i]<-quantile(firstdifferences,0.975)   
} 
 




col3<-c("#4292c6","#8c6bb1","#fb6a4a")


pdf(file="final_figureA3.pdf", width=10, height=6)
par(mfrow=c(1,2))

plot(knowl_seq, FDs_logit, type="l", lwd=2, 
	xlab="Political Knowledge", main="Interaction Between Partisanship and Political Knowledge", 
	ylab="Marginal Effect of Republican ID on Pr(Shift towards Greater Secrecy)", ylim=c(-0.5, 0.5), cex.main=0.9, cex.lab=0.9)
lines(knowl_seq, lower_logit, lty=2)
lines(knowl_seq, upper_logit, lty=2)
abline(h=0)

plot(knowl_seq, FDs_OLS, type="l", lwd=2, 
	xlab="Political Knowledge", main="Interaction Between Partisanship and Political Knowledge", 
	ylab="Marginal Effect of Republican ID on Individual Shift towards Greater Secrecy", ylim=c(-30, 40), cex.main=0.9, cex.lab=0.9)
lines(knowl_seq, lower_OLS, lty=2)
lines(knowl_seq, upper_OLS, lty=2)
abline(h=0)

dev.off()




