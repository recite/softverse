

library(foreign)



dataset<-read.dta("persuasion_v12.dta")
ice2<-read.dta("ideology_ice_v12.dta") # this file contains the imputed complete cases for liberal/conservative 
# imputation is done via the Stata ice procedure with one imputation
# you can ignore the warnings, they are about value labels missing
ice<-read.dta("persuasion_ice_v12.dta") # this file has the complete case imputed pretreatment responses, also using ice
temp<-merge(dataset, ice, by="oboe_w1id")
alldata<-merge(temp, ice2, by="oboe_w1id")
rm(temp)

# create the matrix of table assignments

TableAdj=matrix(data=0, nrow=length(dataset$sitetable), ncol=length(dataset$sitetable))
for (i in 1:length(dataset$sitetable)) {
for (j in 1:length(dataset$sitetable)) {
if (i!=j) { 
if (dataset$sitetable[i]==dataset$sitetable[j]) {
TableAdj[i,j]<-1
}}}}

 



### optional: normalize it to W; useful to find eigenvalues (rho must be bounded by reciprocal of min/max eignevalues); not used in the analysis below

 TableW=matrix(data=0, nrow=length(dataset$sitetable), ncol=length(dataset$sitetable))
 for (i in 1:length(dataset$sitetable)) {
 for (j in 1:length(dataset$sitetable)) {
 TableW[i,j]<-TableAdj[i,j]/sum(TableAdj[i,])
 }}


V<-eigen(TableW, symmetric=FALSE)



#### Create Vector of table mappings to read into Congdon programs:

TableMap<-list(map=NULL)
for (i in 1:length(dataset$sitetable)) {
for (j in 1:length(dataset$sitetable)) {
if (TableAdj[i,j]==1) TableMap<-list(map=c(TableMap$map, j))
}}

TableC<-list(C=0)
nadj<-0
for (i in 1:length(dataset$sitetable)) {
nadj<-sum(TableAdj[i,])+nadj
TableC<-list(C=c(TableC$C, nadj))
}

one<-rep(1, length(dataset$sitetable))
numTableNeigh<-sum(as.numeric(t(TableAdj%*%one)))


save.image("persuasion_replication.RData")


load("persuasion_replication.RData")


library(car)

I1.1<-as.numeric(ice$ice_PR_DEF_TAXRICH==1)
I1.2<-as.numeric(ice$ice_PR_DEF_TAXRICH==2)
I1.3<-as.numeric(ice$ice_PR_DEF_TAXRICH==3)
I1.4<-as.numeric(ice$ice_PR_DEF_TAXRICH==4)
I1.5<-as.numeric(ice$ice_PR_DEF_TAXRICH==5)

I2.1<-as.numeric(ice$icerev_PR_DEF_CUTPROG==1) # note that this item and the next one are "reversed coded" so
I2.2<-as.numeric(ice$icerev_PR_DEF_CUTPROG==2) # high values indicate liberal opinion, so that the ideological
I2.3<-as.numeric(ice$icerev_PR_DEF_CUTPROG==3) # items are oriented the same way.  The labeling of the items
I2.4<-as.numeric(ice$icerev_PR_DEF_CUTPROG==4) # makes no difference for estimation (everything replicates with
I2.5<-as.numeric(ice$icerev_PR_DEF_CUTPROG==5) # the items all reverse coded.

I3.1<-as.numeric(ice$icerev_PR_DEF_ENTITLE==1)
I3.2<-as.numeric(ice$icerev_PR_DEF_ENTITLE==2)
I3.3<-as.numeric(ice$icerev_PR_DEF_ENTITLE==3)
I3.4<-as.numeric(ice$icerev_PR_DEF_ENTITLE==4)
I3.5<-as.numeric(ice$icerev_PR_DEF_ENTITLE==5)

I4.1<-as.numeric(ice$ice_PR_DEF_DEFENSE==1)
I4.2<-as.numeric(ice$ice_PR_DEF_DEFENSE==2)
I4.3<-as.numeric(ice$ice_PR_DEF_DEFENSE==3)
I4.4<-as.numeric(ice$ice_PR_DEF_DEFENSE==4)
I4.5<-as.numeric(ice$ice_PR_DEF_DEFENSE==5)

I5.1<-as.numeric(ice$ice_PR_DEF_TAXBOTH==1) # note that taxboth and fedsales load weakly and that high values
I5.2<-as.numeric(ice$ice_PR_DEF_TAXBOTH==2) # indicate liberal opinion
I5.3<-as.numeric(ice$ice_PR_DEF_TAXBOTH==3)
I5.4<-as.numeric(ice$ice_PR_DEF_TAXBOTH==4)
I5.5<-as.numeric(ice$ice_PR_DEF_TAXBOTH==5)

I6.1<-as.numeric(ice$ice_PR_DEF_FEDSALES==1)
I6.2<-as.numeric(ice$ice_PR_DEF_FEDSALES==2)
I6.3<-as.numeric(ice$ice_PR_DEF_FEDSALES==3)
I6.4<-as.numeric(ice$ice_PR_DEF_FEDSALES==4)
I6.5<-as.numeric(ice$ice_PR_DEF_FEDSALES==5)





## create variables 
data<-list(N=length(dataset$sitetable), NN=as.numeric(numTableNeigh), 
map=as.numeric(TableMap$map), C=as.numeric(TableC$C), 
liberal=as.numeric(alldata$liberal),
conservative=as.numeric(alldata$conservative),
O1=as.numeric(alldata$oboe_PT_DEF_TAXRICH), 
O2=as.numeric(alldata$rev_PT_DEF_CUTPROG),  # note here as well this item and the next are reverse coded so liberal is high for all items
O3=as.numeric(alldata$rev_PT_DEF_ENTITLE), 
O4=as.numeric(alldata$oboe_PT_DEF_DEFENSE), 
O5=as.numeric(alldata$oboe_PT_DEF_TAXBOTH), 
O6=as.numeric(alldata$oboe_PT_DEF_FEDSALES), 
I1=as.numeric(alldata$oboe_PR_DEF_TAXRICH), 
I2=as.numeric(alldata$rev_PR_DEF_CUTPROG), 
I3=as.numeric(alldata$rev_PR_DEF_ENTITLE), 
I4=as.numeric(alldata$oboe_PR_DEF_DEFENSE), 
I1.1=I1.1, I1.2=I1.2, I1.3=I1.3, I1.4=I1.4, 
I2.1=I2.1, I2.2=I2.2, I2.3=I2.3, I2.4=I2.4, 
I3.1=I3.1, I3.2=I3.2, I3.3=I3.3, I3.4=I3.4, 
I4.1=I4.1, I4.2=I4.2, I4.3=I4.3, I4.4=I4.4, 
I5.1=I5.1, I5.2=I5.2, I5.3=I5.3, I5.4=I5.4, 
I6.1=I6.1, I6.2=I6.2, I6.3=I6.3, I6.4=I6.4, 
site1=as.numeric(alldata$site1.x),
site2=as.numeric(alldata$site2.x),
site3=as.numeric(alldata$site3.x),
site4=as.numeric(alldata$site4.x),
site5=as.numeric(alldata$site5.x),
site6=as.numeric(alldata$site6.x),
site7=as.numeric(alldata$site7.x),
site8=as.numeric(alldata$site8.x),
site9=as.numeric(alldata$site9.x),
site10=as.numeric(alldata$site10.x),
site11=as.numeric(alldata$site11.x),
site12=as.numeric(alldata$site12.x),
site13=as.numeric(alldata$site13.x),
site14=as.numeric(alldata$site14.x),
site15=as.numeric(alldata$site15.x),
site16=as.numeric(alldata$site16.x),
site17=as.numeric(alldata$site17.x),
site18=as.numeric(alldata$site18.x),
premissing=as.numeric(alldata$oboe_pre_missing))



dput(data, file="persuasion_replication_data.txt", control=NULL)




## create inits

inits<-list(
v=0,
eta=signif(rnorm(length(dataset$sitetable)), 4), 
e1=signif(rnorm(length(dataset$sitetable)), 4),
e2=signif(rnorm(length(dataset$sitetable)), 4),
e3=signif(rnorm(length(dataset$sitetable)), 4),
e4=signif(rnorm(length(dataset$sitetable)), 4),
e5=signif(rnorm(length(dataset$sitetable)), 4),
e6=signif(rnorm(length(dataset$sitetable)), 4),
lambda=signif(runif(4), 4),
b1=signif(runif(6), 4),
rho=signif(runif(11), 4),
a=signif(runif(3), 4),
s=signif(runif(3), 4),
d=signif(runif(3), 4),
f=signif(runif(3), 4),
g=signif(runif(3), 4),
h=signif(runif(3), 4),
q=signif(rnorm(4), 4),
w=signif(rnorm(4), 4),
e=signif(rnorm(4), 4),
r=signif(rnorm(4), 4),
t=signif(rnorm(4), 4),
y=signif(rnorm(4), 4),
c=rnorm(30),
s1=signif(rnorm(18), 4),
s2=signif(rnorm(18), 4),
s3=signif(rnorm(18), 4),
s4=signif(rnorm(18), 4),
s5=signif(rnorm(18), 4),
s6=signif(rnorm(18), 4),
k11_c1=-1, k11_c2=-.5, k11_c3=.5, k11_c4=1, 
k12_c1=-1, k12_c2=-.5, k12_c3=.5, k12_c4=1, 
k13_c1=-1, k13_c2=-.5, k13_c3=.5, k13_c4=1, 
k14_c1=-1, k14_c2=-.5, k14_c3=.5, k14_c4=1, 
k15_c1=-1, k15_c2=-.5, k15_c3=.5, k15_c4=1, 
k16_c1=-1, k16_c2=-.5, k16_c3=.5, k16_c4=1, 
k31_c1=-1, k31_c2=-.5, k31_c3=.5, k31_c4=1, 
k32_c1=-1, k32_c2=-.5, k32_c3=.5, k32_c4=1, 
k33_c1=-1, k33_c2=-.5, k33_c3=.5, k33_c4=1, 
k34_c1=-1, k34_c2=-.5, k34_c3=.5, k34_c4=1)

dput(inits, file="persuasion_inits1.txt", control=NULL)







