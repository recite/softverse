


library(mvtnorm)
library(arm)
library(BRugs)
library(R2OpenBUGS)
library(coda)
library(car)
library(foreign)

# Change this to your working directory.  Note this path makes Dropbox work at least on a windows machine
setwd("~/../Dropbox/UCR/research/bayes/funglee/persuasion/OBOE/Replication/ResultsInPaper/Tutorial/")


dataset<-read.dta(file.choose()) # read in a Stata file "tutorial_data.dta"


# create the matrix of table assignments

TableAdj=matrix(data=0, nrow=length(dataset$groupid), ncol=length(dataset$groupid))
for (i in 1:length(dataset$groupid)) {
  for (j in 1:length(dataset$groupid)) {
    if (i!=j) { 
      if (dataset$groupid[i]==dataset$groupid[j]) {
        TableAdj[i,j]<-1
      }}}}



#### Create Vector of table mappings to read into Congdon programs:

TableMap<-list(map=NULL)
for (i in 1:length(dataset$groupid)) {
  for (j in 1:length(dataset$groupid)) {
    if (TableAdj[i,j]==1) TableMap<-list(map=c(TableMap$map, j))
  }}

TableC<-list(C=0)
nadj<-0
for (i in 1:length(dataset$groupid)) {
  nadj<-sum(TableAdj[i,])+nadj
  TableC<-list(C=c(TableC$C, nadj))
}
map <- TableMap$map
C <- TableC$C

one<-rep(1, length(dataset$groupid))
numTableNeigh<-sum(as.numeric(t(TableAdj%*%one)))


# save.image("tutorial.RData")
# load("tutorial.RData")



## create data 


# set constants 
n_respondents <- length(dataset$groupid)
n_questions <- 5
n_responses <- 5
n_sites <- 3  
Cn <- numTableNeigh

# create matrices of the pre and post outcomes.  To modify this for your own use, just edit the variable names after the $
# The model requires there be a post item for each pre item.  You can include an arbitrary number of items/questions provided
# you have at least three to identify the latent variables.
O.pre <- as.matrix(cbind(dataset$preO1, dataset$preO2, dataset$preO3, dataset$preO4, dataset$preO5))
O.post <- as.matrix(cbind(dataset$postO1, dataset$postO2, dataset$postO3, dataset$postO4, dataset$postO5))
liberal<-dataset$liberal
conservative<-dataset$conservative
sites<-as.matrix(cbind(dataset$site2, dataset$site3))



# for the ordered model the constants have to be ordered within each item.  We just set the initial
# values as constants in the correct order.
Cuts<-NULL
for (j in 1:(n_questions*2)){
  threshold_priors <- -1
  for (k in 2:(n_responses-2)){
    threshold_priors <- cbind(threshold_priors, (-1)+((k-1)*2)/(n_responses-2))
  }
  threshold_priors <- cbind(threshold_priors, 1)
  Cuts<- rbind(Cuts, threshold_priors)
  rm(threshold_priors)
}
Cuts<- as.matrix(Cuts)



data<-list("O.pre", "O.post", "liberal", "conservative", "n_respondents", "n_questions",  "n_responses", "Cn", "C",  "map", "n_sites", "sites") 
inits <- function() {
  list(theta0=rnorm(n_respondents), lambda.0=Cuts[1:n_questions,], beta.0=Cuts[(n_questions+1):(n_questions*2),], 
       delta.theta=rnorm(n_respondents), delta.zeta=rmvnorm(n_respondents, rep(0, n_questions), diag(n_questions)),
       alpha1=rnorm(1), delta1=rnorm(1), delta3=rnorm(1), lambda.1=runif(n_questions),
       beta.1=rnorm(n_questions), beta.2=rnorm(n_questions), beta.3=rmvnorm(n_sites-1, rep(0, n_questions), diag(n_questions)), rho=rep(0.3, n_questions),
       tau.theta0=dunif(1))} 


# Output the data and inits files to the working directory for the example...
setwd("~/../Dropbox/UCR/research/bayes/funglee/persuasion/OBOE/Replication/ResultsInPaper/Tutorial/fullmodel_examples/ordinal")
bugs.data(data, dir=getwd(), digits=5, data.file="data.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits1.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits2.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits3.txt")

