

library(foreign)
library(arm)
library(BRugs)


dataset<-read.dta("ISAOBOEcommonspace.dta")


# recode these so that high values is liberal for all items:
temp<-as.numeric(dataset$all_CUTPROG_PR)
temp[as.numeric(dataset$all_CUTPROG_PR)==1]<-5
temp[as.numeric(dataset$all_CUTPROG_PR)==2]<-4
temp[as.numeric(dataset$all_CUTPROG_PR)==4]<-2
temp[as.numeric(dataset$all_CUTPROG_PR)==5]<-1
dataset$all_CUTPROG_PR<-temp
rm(temp)

temp<-as.numeric(dataset$all_ENTITLE_PR)
temp[as.numeric(dataset$all_ENTITLE_PR)==1]<-5
temp[as.numeric(dataset$all_ENTITLE_PR)==2]<-4
temp[as.numeric(dataset$all_ENTITLE_PR)==4]<-2
temp[as.numeric(dataset$all_ENTITLE_PR)==5]<-1
dataset$all_ENTITLE_PR<-temp
rm(temp)

# create treatment indicator: 1 = OBOE, 0 = RDD
dataset$treatment<-as.numeric(dataset$treatment)-1


## create variables 

I1 <- as.numeric(dataset$all_TAXRICH_PR)
I2 <- as.numeric(dataset$all_CUTPROG_PR)
I3 <- as.numeric(dataset$all_ENTITLE_PR)
I4 <- as.numeric(dataset$all_DEFENSE_PR)
N <- length(dataset$treatment)


data<-list("N", "I1", "I2", "I3", "I4")





inits <- function() {
list(
eta=signif(rnorm(length(dataset$treatment)), 4), 
lambda=signif(runif(4), 4),
k31_c1=-1, k31_c2=-.5, k31_c3=.5, k31_c4=1, 
k32_c1=-1, k32_c2=-.5, k32_c3=.5, k32_c4=1, 
k33_c1=-1, k33_c2=-.5, k33_c3=.5, k33_c4=1, 
k34_c1=-1, k34_c2=-.5, k34_c3=.5, k34_c4=1)}




setwd("C:/research/bayes/funglee/persuasion/OBOE/SampleProperties/")
bugs.data(data, dir=getwd(), digits=5, data.file="persuasion_sample_data.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="persuasion_sample_inits1.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="persuasion_sample_inits2.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="persuasion_sample_inits3.txt")





####################### RESULTS #######################


library(BRugs)
library(foreign)

setwd("C:/research/bayes/funglee/persuasion/OBOE/SampleProperties/")
x<-read.openbugs(stem="", quiet=FALSE)
# sample coda data only saved values for eta

results<-as.data.frame(rbind(x[[1]], x[[2]], x[[3]]))



eta.mean.all<-apply(results, 2, mean)
# eta.sd.all<-apply(results, 2, sd)

# done (but don't use below...):
# eta.dataset<-as.data.frame(cbind(eta.mean.all, dataset))
# write.dta(eta.dataset, file="eta_dataset.dta", version=7)


eta.mean.all<-(-1)*(eta.mean.all)


###


dataset<-read.dta("ISAOBOEcommonspace.dta")



# ideology scores common space graph
#op<-par(mfrow=c(1,1), mar=c(4,4,2,1)+0.1, oma=c(0,0,4,0))
plot(density(eta.mean.all), type = "n", main=paste("Common Space Ideology Scores"), xlab=("   (- Liberal)                                Ideology Score                            (+ Conservative)"), ylab=("Density"))# setting up coord. system
lines(density(eta.mean.all[dataset$treatment=="OBOE"]), type="l", col="maroon", lty=1, lwd=3)
lines(density(eta.mean.all[dataset$treatment=="OTHER"]), type="l", col="navy", lty=1, lwd=3)
legend(x=-1.8, y=0.60, bty="n", legend=paste(c("OBOE", "RDD")), fill=c("maroon", "navy"))
#par(op)



### BALANCE TEST FOR RANDOMIZATION STUDY 


library(RItools)
library(xtable)

dataset<-read.dta("balance_v12.dta")



dataset$minority<-dataset$black+dataset$hispanic+dataset$asian


xBalance(scale(tmean, center=TRUE, scale=TRUE)~oboe_PR_AGE+oboe_PR_SEX+oboe_PR_FAMINC+republican+democrat+minority+gradschool, strata=factor(dataset$site), data=dataset, report=c("all"))

temp.dataset<-dataset[complete.cases(dataset$tsd),]

xBalance(scale(tsd, center=TRUE, scale=TRUE)~oboe_PR_SEX+oboe_PR_FAMINC+republican+democrat+minority+gradschool, strata=factor(temp.dataset$site), data=temp.dataset, report=c("all"))
#oboe_PR_AGE+






