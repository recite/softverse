


library(mvtnorm)
library(arm)
library(BRugs)
library(R2OpenBUGS)
library(coda)
library(car)
library(foreign)

# Change this to your working directory.  Note this path makes Dropbox work at least on a windows machine
setwd("~/../Dropbox/UCR/research/bayes/funglee/persuasion/OBOE/Replication/ResultsInPaper/Tutorial")


dataset<-read.dta(file.choose()) # read in a Stata file "tutorial_data.dta"


# create the matrix of group assignments

TableAdj=matrix(data=0, nrow=length(dataset$groupid), ncol=length(dataset$groupid))
for (i in 1:length(dataset$groupid)) {
  for (j in 1:length(dataset$groupid)) {
    if (i!=j) { 
      if (dataset$groupid[i]==dataset$groupid[j]) {
        TableAdj[i,j]<-1
      }}}}



# Create Vector of group mappings to read into Congdon programs:

TableMap<-list(map=NULL)
for (i in 1:length(dataset$groupid)) {
  for (j in 1:length(dataset$groupid)) {
    if (TableAdj[i,j]==1) TableMap<-list(map=c(TableMap$map, j))
  }}

# count how many people (other than i) are at i's table and add that to i-1's count

TableC<-list(C=0)
nadj<-0
for (i in 1:length(dataset$groupid)) {
  nadj<-sum(TableAdj[i,])+nadj
  TableC<-list(C=c(TableC$C, nadj))
}
map <- TableMap$map
C <- TableC$C

one<-rep(1, length(dataset$groupid))
numTableNeigh<-sum(as.numeric(t(TableAdj%*%one)))


# save.image("tutorial.RData")
# load("tutorial.RData")



## create data 


# set constants 
n_respondents <- length(dataset$groupid)
n_questions <- 5
n_responses <- 5
n_sites <- 3  
Cn <- numTableNeigh

# create matrices of the pre and post outcomes.  To modify this for your own use, just edit the variable names after the $
# The model requires there be a post item for each pre item.  You can include an arbitrary number of items/questions provided
# you have at least three to identify the latent variables.
O.prex <- as.matrix(cbind(dataset$xpreO1, dataset$xpreO2, dataset$xpreO3, dataset$xpreO4, dataset$xpreO5))
O.postx <- as.matrix(cbind(dataset$xpostO1, dataset$xpostO2, dataset$xpostO3, dataset$xpostO4, dataset$xpostO5))
liberal<-dataset$liberal
conservative<-dataset$conservative
sites<-as.matrix(cbind(dataset$site2, dataset$site3))



data<-list("O.prex", "O.postx", "liberal", "conservative", "n_respondents", "n_questions",  "Cn", "C",  "map", "n_sites", "sites") 
inits <- function() {
  list(theta0=rnorm(n_respondents), lambda.0=rnorm(n_questions), beta.0=rnorm(n_questions), 
       delta.theta=rnorm(n_respondents), delta.zeta=rmvnorm(n_respondents, rep(0, n_questions), diag(n_questions)),
       alpha1=rnorm(1), delta1=rnorm(1), delta3=rnorm(1), lambda.1=runif(n_questions),
       beta.1=rnorm(n_questions), beta.2=rnorm(n_questions), beta.3=rmvnorm(n_sites-1, rep(0, n_questions), diag(n_questions)), 
       rho=rep(0.3, n_questions), tau.prex=runif(n_questions), tau.postx=runif(n_questions), tau.theta0=dunif(1))} 


# Output the data and inits files to the working directory
setwd("~/../Dropbox/UCR/research/bayes/funglee/persuasion/OBOE/Replication/ResultsInPaper/Tutorial/fullmodel_examples/linear")
bugs.data(data, dir=getwd(), digits=5, data.file="data.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits1.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits2.txt")
bugs.data(inits(), dir=getwd(), digits=3, data.file="inits3.txt")

