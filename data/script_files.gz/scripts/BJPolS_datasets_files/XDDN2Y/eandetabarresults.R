


library(arm)
library(BRugs)
library(foreign)
library(coda)
library(readstata13)


setwd("C:/Users/Kevin/Dropbox/UCR/research/bayes/funglee/persuasion/OBOE/Replication")

dataset<-read.dta13("persuasion_v12.dta")



# note this file reads in the random effects matrices estimated in the main model, so it does not have its own
# setup, model, data or initis files.  See the mainmodel subfolder to see those files.  The coda output in this
# directory is saved from a run of the main model.  

# As we note in the README.txt file in the main directory, the notation changed between iterations of the 
# paper, and the replication material retains the notation of the original paper.  To see the components
# of the model in the paper notation be certain to run the fullmodel_ordinal tutorial.  Once you do that
# you will see the parallels to the notation we use here.  Specifically, the policy-specific random effects
# are e1, e2, ... e6 (instead of zeta) and the latent random effect is etabar (instead of theta_delta). 

# This file reads in the coda files and exports the matrix to Stata for analysis.  The Stata .do file in this
# directory implements the descriptive tests for the associations with the random effects that we describe in 
# the paper, and also this .do file contains the descriptive analyses for the "small group polarization"
# descriptive tests that we report in the appendix.

results<-read.openbugs(stem="eresults_", quiet=FALSE)

x<-as.data.frame(rbind(results[[1]], results[[2]], results[[3]]))


# saved workspace as persuasion_e.RData

residuals.mean.all<-apply(x, 2, mean)

# residuals.sd.all<-apply(x, 2, sd)


residuals.means<-as.data.frame(matrix(data=residuals.mean.all,nrow=2793,ncol=7,dimnames=list(c(1:2793), c("e1", "e2", "e3", "e4", "e5", "e6", "etabar"))))



e.dataset<-cbind(residuals.means, dataset$oboe_w1id)


write.dta(e.dataset, file="eandetabar_dataset.dta", version=10)





