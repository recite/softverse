#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinyjs)
library(sjPlot)
library(tidyverse)
library(gridExtra)
library(grid)
library(texreg)


function(input, output) {

  load("data/html_list_CCREM_full.Rdata")
  load("data/html_list_CCREM_sub.Rdata")
  load("data/html_list_CCREM_full_onlyInterviewed.Rdata")
  load("data/html_list_CCREM_sub_onlyInterviewed.Rdata")
  
  load("data/html_list_GAM_Full.Rdata")
  load("data/html_list_GAM_Sub.Rdata")
  load("data/html_list_GAM_Full_onlyInterviewed.Rdata")
  load("data/html_list_GAM_Sub_onlyInterviewed.Rdata")
  
  plotIndicatorFull <- tibble(
    dv = c(
      "authoritarism",
      "polImportant",
      "polint",
      "system_army",
      "system_democracy",
      "system_experts",
      "system_leader",
      "trustCivilService",
      "trustInstSmall",
      "trustJustice",
      "trustParliament"
    ),
    indexLwr = c(
      1,
      25,
      49,
      73,
      97,
      121,
      145,
      169,
      193,
      217,
      241
    )
  )
  
  plotIndicatorSub <- tibble(
    dv = c(
      "democracy_ArmyTakeOver",
      "democracy_freeElection",
      "democracy_protectLiberty"
    ),
    indexLwr = c(
      1,
      16,
      31
    )
  )
  
  modelChoice <- tibble(
    apc = c(1,2),
    model = c("CCREM", "GAM")
  )
  
  filenameFull <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsFull", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", plotIndicatorFull$indexLwr[plotIndicatorFull$dv == input$dv], ".png", sep = ""))
      ))
  })
  
  filenameFull_onlyInterviewed <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsFull", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", plotIndicatorFull$indexLwr[plotIndicatorFull$dv == input$dv], "_", input$sample, ".png", sep = ""))
    ))
  })
  
  filenameDemImportant <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsSub", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", "DemImportant", ".png", sep = ""))
    ))
  })
  
  filenameDemImportant_onlyInterviewed <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsSub", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", "DemImportant", "_", input$sample, ".png", sep = ""))
    ))
  })
  
  filenameEssentials <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsSub", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", "Essentials", "_", plotIndicatorSub$indexLwr[plotIndicatorSub$dv == input$dv], ".png", sep = ""))
    ))
  })
  
  filenameEssentials_onlyInterviewed <- reactive({
    normalizePath(file.path( 
      as.character(paste("www/","plotsSub", "_", modelChoice$model[modelChoice$apc == input$model], "_", input$apc, "_", "Essentials", "_", plotIndicatorSub$indexLwr[plotIndicatorSub$dv == input$dv], "_", input$sample, ".png", sep = ""))
    ))
  })
  
  output$text <- renderText({
    
    if(input$model==2 & input$apc=="lifecycle"){
      paste("No visualized predictions of the life-cycle effects in the GAM model are available because age groups trichonomized. Please refer to the table panel to access life-cycle effects fo the GAM model.")
      
    }
  })
  
  
  output$plot <- renderImage({
    
    if( ( input$dv=="polImportant" | input$dv=="polint" | input$dv=="system_army" | input$dv=="system_democracy" | input$dv=="system_experts" | input$dv=="system_leader" | input$dv=="trustCivilService" | input$dv=="trustJustice" | input$dv=="trustParliament" | input$dv=="trustInstSmall" | input$dv=="authoritarism" ) & input$sample == "all" ) {
      return(list(
        src = filenameFull()
      ))
      
    }
      

    
  if(input$dv=="DemImportant" & input$sample == "all"){
    return(list(
      src = filenameDemImportant()
    ))
  }
      
    if((input$dv=="democracy_freeElection" | input$dv=="democracy_ArmyTakeOver" | input$dv=="democracy_protectLiberty") & input$sample == "all"){
      
      return(list(
        src = filenameEssentials()
      ))
    }

    
    if( ( input$dv=="polImportant" | input$dv=="polint" | input$dv=="system_army" | input$dv=="system_democracy" | input$dv=="system_experts" | input$dv=="system_leader" | input$dv=="trustCivilService" | input$dv=="trustJustice" | input$dv=="trustParliament" | input$dv=="trustInstSmall" | input$dv=="authoritarism" ) & input$sample == "onlyInterviewed" ) {
      return(list(
        src = filenameFull_onlyInterviewed()
      ))
      
    }
    
    
    
    if(input$dv=="DemImportant" & input$sample == "onlyInterviewed"){
      return(list(
        src = filenameDemImportant_onlyInterviewed()
      ))
    }
    
    if((input$dv=="democracy_freeElection" | input$dv=="democracy_ArmyTakeOver" | input$dv=="democracy_protectLiberty") & input$sample == "onlyInterviewed"){
      
      return(list(
        src = filenameEssentials_onlyInterviewed()
      ))
    }
    
    
      
}, deleteFile = FALSE)
  
  
  
  
  
  output$textWording <- renderText({
    
    if(input$dv=="system_democracy"){
        x <- paste("Question wording: I’m going to describe various types of political systems and ask what you think about each as a way of governing this country. For each one, would you say it is a very good, fairly good, fairly bad or very bad way of governing this country?
Having a democratic political system
")
        return(x)
      
    }
    
    if(input$dv=="system_leader"){
      x <- paste("Question wording: I’m going to describe various types of political systems and ask what you think about each as a way of governing this country. For each one, would you say it is a very good, fairly good, fairly bad or very bad way of governing this country?
Having a strong leader who does not have to bother with parliament and elections")
      return(x)
      
    }
    
    if(input$dv=="trustInstSmall"){
      x <- paste("Question wording: Please look at this card and tell me, for each item listed, how much confidence you have in them, is it a great deal, quite a lot, not very much or none at all?:  Parliament, Justice System, Civil Service")
      return(x)
      
    }
    
    if(input$dv=="polint"){
      x <- paste("Question wording: How interested would you say you are in politics?")
      return(x)
      
    }
    
    if(input$dv=="authoritarism"){
      x <- paste("Question wording: Here are two changes in our way of life that might take place in the near future. Please tell me for each one, if it were to happen whether you think it would be a good thing, a bad thing, or don’t you mind?
Greater respect for authority (good, bad, don’t mind)
            ")
      return(x)
      
    }
    
    if(input$dv=="democracy_freeElection"){
      x <- paste("Question wording: Many things are desirable, but not all of them are essential characteristics of democracy. Please tell me for each of the following things how essential you think it is as a characteristic of democracy. Use this scale where 1 means “not at all an essential characteristic of democracy” and 10 means it definitely is “an essential characteristic of democracy”: People choose their leaders in free elections
            ")
      return(x)
      
    }
    
    if(input$dv=="democracy_ArmyTakeOver"){
      x <- paste("Question wording: Many things are desirable, but not all of them are essential characteristics of democracy. Please tell me for each of the following things how essential you think it is as a characteristic of democracy. Use this scale where 1 means “not at all an essential characteristic of democracy” and 10 means it definitely is “an essential characteristic of democracy”: The army takes over when government is incompetent")
      return(x)
      
    }
    
    if(input$dv=="democracy_protectLiberty"){
      x <- paste("Question wording: Many things are desirable, but not all of them are essential characteristics of democracy. Please tell me for each of the following things how essential you think it is as a characteristic of democracy. Use this scale where 1 means “not at all an essential characteristic of democracy” and 10 means it definitely is “an essential characteristic of democracy”: Civil rights protect people from state oppression")
      return(x)
      
    }
    
    if(input$dv=="DemImportant"){
      x <- paste("Question wording: Please say, for each of the following, how important it is in your life: Politics.")
      return(x)
      
    }
    
    if(input$dv=="system_army"){
      x <- paste("Question wording: I’m going to describe various types of political systems and ask what you think about each as a way of governing this country. For each one, would you say it is a very good, fairly good, fairly bad or very bad way of governing this country?:
Having the army rule the country")
      return(x)
      
    }
    
    if(input$dv=="system_experts"){
      x <- paste("Question wording: I’m going to describe various types of political systems and ask what you think about each as a way of governing this country. For each one, would you say it is a very good, fairly good, fairly bad or very bad way of governing this country?: 
Having experts, not government, make decisions according to what they think is best for the country")
      return(x)
      
    }
    
    if(input$dv=="trustCivilService"){
      x <- paste("Question wording: Please look at this card and tell me, for each item listed, how much confidence you have in them, is it a great deal, quite a lot, not very much or none at all?: Civil Service")
      return(x)
      
    }
    
    if(input$dv=="polImportant"){
      x <- paste("Question wording: Please say, for each of the following, how important it is in your life: Politics.
")
      return(x)    
    }
    
    if(input$dv=="trustJustice"){
      x <- paste("Question wording: Please look at this card and tell me, for each item listed, how much confidence you have in them, is it a great deal, quite a lot, not very much or none at all?: Justice")
      return(x)
      
    }
    
    
    if(input$dv=="trustParliament"){
      x <- paste("Question wording: Please look at this card and tell me, for each item listed, how much confidence you have in them, is it a great deal, quite a lot, not very much or none at all?: Parliament")
      return(x)
    }
    
  })
  
  

  
  
  
  
  output$table <- renderText({

    if(input$model2==1 & input$dv2=="authoritarism" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[1]])

      return(table)

    }

    if(input$model2==1 & input$dv2=="polImportant" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[2]])
      

      return(table)

    }

    if(input$model2==1 & input$dv2=="polint" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[3]])
      

      return(table)

    }

    if(input$model2==1 & input$dv2=="system_army" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[4]])
      

      return(table)

    }


    if(input$model2==1 & input$dv2=="system_democracy" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[5]])

      return(table)

    }


    if(input$model2==1 & input$dv2=="system_experts" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[6]])

      return(table)

    }

    if(input$model2==1 & input$dv2=="system_leader" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[7]])

      return(table)

    }

    if(input$model2==1 & input$dv2=="trustCivilService" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[8]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="trustInstSmall" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[9]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="trustJustice" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[10]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="trustParliament" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Full[[11]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="DemImportant" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Sub[[1]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="democracy_ArmyTakeOver" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Sub[[2]])
      
      return(table)
    }

    if(input$model2==1 & input$dv2=="democracy_freeElection" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Sub[[3]])
      
      return(table)

    }

    if(input$model2==1 & input$dv2=="democracy_protectLiberty" & input$sample2 == "all"){

      table <- HTML(table_CCREM_Sub[[4]])

      return(table)

    }
    
    
    
    
    
    
    
    
    if(input$model2==2 & input$dv2=="authoritarism" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[1]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="polImportant" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[2]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="polint" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[3]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="system_army" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[4]])
      
      return(table)
      
    }
    
    
    if(input$model2==2 & input$dv2=="system_democracy" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[5]])
      
      return(table)
      
    }
    
    
    if(input$model2==2 & input$dv2=="system_experts" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[6]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="system_leader" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[7]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustCivilService" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[8]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustInstSmall" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[9]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustJustice" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[10]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustParliament" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Full[[11]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="DemImportant" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Sub[[1]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_ArmyTakeOver" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Sub[[2]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_freeElection" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Sub[[3]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_protectLiberty" & input$sample2 == "all"){
      
      table <- HTML(html_list_GAM_Sub[[4]])
      
      return(table)
      
    }
    
    
    #########################Only Interviewed Sample######################
    
    
    if(input$model2==1 & input$dv2=="authoritarism" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[1]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="polImportant" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[2]])
      
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="polint" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[3]])
      
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="system_army" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[4]])
      
      
      return(table)
      
    }
    
    
    if(input$model2==1 & input$dv2=="system_democracy" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[5]])
      
      return(table)
      
    }
    
    
    if(input$model2==1 & input$dv2=="system_experts" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[6]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="system_leader" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[7]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="trustCivilService" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[8]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="trustInstSmall" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[9]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="trustJustice" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[10]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="trustParliament" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Full_onlyInterviewed[[11]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="DemImportant" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Sub_onlyInterviewed[[1]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="democracy_ArmyTakeOver" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Sub_onlyInterviewed[[2]])
      
      return(table)
    }
    
    if(input$model2==1 & input$dv2=="democracy_freeElection" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Sub_onlyInterviewed[[3]])
      
      return(table)
      
    }
    
    if(input$model2==1 & input$dv2=="democracy_protectLiberty" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(table_CCREM_Sub_onlyInterviewed[[4]])
      
      return(table)
      
    }
    
    
    
    
    
    
    
    
    if(input$model2==2 & input$dv2=="authoritarism" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[1]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="polImportant" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[2]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="polint" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[3]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="system_army" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[4]])
      
      return(table)
      
    }
    
    
    if(input$model2==2 & input$dv2=="system_democracy" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[5]])
      
      return(table)
      
    }
    
    
    if(input$model2==2 & input$dv2=="system_experts" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[6]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="system_leader" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[7]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustCivilService" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[8]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustInstSmall" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[9]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustJustice" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[10]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="trustParliament" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Full_onlyInterviewed[[11]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="DemImportant" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Sub_onlyInterviewed[[1]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_ArmyTakeOver" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Sub_onlyInterviewed[[2]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_freeElection" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Sub_onlyInterviewed[[3]])
      
      return(table)
      
    }
    
    if(input$model2==2 & input$dv2=="democracy_protectLiberty" & input$sample2 == "onlyInterviewed"){
      
      table <- HTML(html_list_GAM_Sub_onlyInterviewed[[4]])
      
      return(table)
      
    }
    
    
    
    
    
  })
  
}

