#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinyjs)
library(shinycssloaders)


# Define UI for application that draws a histogram
navbarPage("Democratic Deconsolidation",
           
           tabPanel("Introduction",
                    tags$head(tags$style(
                      type="text/css",
                      "#plot img {max-width: 100%; width: 100%; height: auto}"
                    )),
                    mainPanel(
                      HTML(
                        paste(
                          h2("Introduction"),
                          p("This is an interactive appendix, accompanying the study “Are democracies dying one generation at a time?”."),
                        
                          h2("Content"),
                          
                          h3("Supplementary empirical evidence"),
                          p("Most of the supplementary empirical evidence can be accessed through the 'Plots' subpage."),
                          tags$ul(
                            tags$li("Explore results on additional countries (Polity IV score below 10) that were not reported in the main text"),
                            tags$li("Access full results on secondary indicators of support for democracy that we mentioned only briefly in the main text"),
                            tags$li("Access life-cycle effects which are controlled for in the analysis in the main text but not discussed in the main text"),
                            tags$li("Access the question wordings for each indicator"),
                            tags$li("Access regression tables")
                          ),
                          h3("Supplementary study information"),
                          tags$ul(
                            tags$li("Documentation and justification of deviations from the pre-analysis plan"),
                            tags$li("Documentation and assessment of differences between the results in this study and previous results from Foa / Mounk")
                          ),
                          h2("Usage"),
                          tags$ul(
                            tags$li("To access results on indicators or analytical models (GAM or rHAPC) of your choice, select “Plots” in the menu and choose the indicators/models that you are interested in"),
                            tags$li("To access life-cycle effects for GAM models or to access regression tables for the plots from the main text, choose “Tables” in the menu and choose the indicators/models of your interest")
                          ),
                          h2("Acknowledgement"),
                          div(p(HTML(paste0('This appendix was inspired by a Shiny app that was created by ',a(href="https://biblio.ugent.be/person/802002076543", "Ian Hussey"),' for which he kindly provided all R code.'))))
                        )
                      )
                    )
           ),
           
           tabPanel("Plots",
                    tags$head(tags$style("#plot{height:90vh !important;}")),
                    fluidPage(
                      fluidRow(
                        column(3,
                               radioButtons("model", "Model",
                                            choices = list("GAM (Standard model)" = 2, "rHAPC" = 1)
                               )),
                        column(3,
                               radioButtons("sample", "Sample",
                                            choices = list("Standard sample" = "onlyInterviewed", "Extended 2018 sample incl mixed-methods experiments" = "all")
                               )),
                        column(3,
                               radioButtons("apc", "Temporal effects",
                                            choices = list("Cohort" = "cohort", "Life-cycle" = "lifecycle")
                               )),
                        column(3,
                               selectInput("dv", "Aspect of Support for Democracy:",
                                           choices = list( 
                                             "Main: Political system: Democracy" =  "system_democracy", 
                                             "Main: Political system: Strong leader" =  "system_leader", 
                                             "Main: Trust in institutions" =  "trustInstSmall",
                                             "Suppl: Political interest" =  "polint", 
                                             "Suppl.: Culture: Authoritarism" = "authoritarism", 
                                             "Suppl.: Essentials of Democracy: Free Elections" = "democracy_freeElection" , 
                                             "Suppl.: Essentials Democracy: Army Takeover" = "democracy_ArmyTakeOver" , 
                                             "Suppl.: Essentials of Democracy: Protect Liberty" = "democracy_protectLiberty" , 
                                             "Suppl.: Importance of Democracy" = "DemImportant" , 
                                             "Suppl.: Political system: Army" = "system_army", 
                                             "Suppl.: Political system: Experts" =  "system_experts", 
                                             "Suppl.: Trust in civil service" =  "trustCivilService", 
                                             "Suppl.: Personal Importance of Politics" = "polImportant", 
                                             "Suppl.: Trust in justice" =  "trustJustice", 
                                             "Suppl.: Trust in parliament" =  "trustParliament" 
                                           ))
                        )
                      ),
                      textOutput("textWording"),
                      hr(),
                      br(),
                      textOutput("text"),
                      br(),
                      withSpinner(imageOutput("plot"))
                      
                    )
           ),
           tabPanel("Tables",
                    sidebarLayout(
                      sidebarPanel(
                        radioButtons("model2", "Model:",
                                     choices = list("GAM (Standard model)" = 2, "rHAPC" = 1)
                        ),
                        radioButtons("sample2", "Sample:",
                                     choices = list("Standard sample" = "onlyInterviewed", "Extended sample with mixed-methods" = "all")
                               ),
                        selectInput("dv2", "Aspect of Support for Democracy:",
                                    choices = list( 
                                      "Main: Political system: Democracy" =  "system_democracy", 
                                      "Main: Political system: Strong leader" =  "system_leader", 
                                      "Main: Trust in institutions" =  "trustInstSmall",
                                      "Main: Political interest" =  "polint", 
                                      "Suppl.: Culture: Authoritarism" = "authoritarism", 
                                      "Suppl.: Essentials of Democracy: Free Elections" = "democracy_freeElection" , 
                                      "Suppl.: Essentials Democracy: Army Takeover" = "democracy_ArmyTakeOver" , 
                                      "Suppl.: Essentials of Democracy: Protect Liberty" = "democracy_protectLiberty" , 
                                      "Suppl.: Importance of Democracy" = "DemImportant" , 
                                      "Suppl.: Political system: Army" = "system_army", 
                                      "Suppl.: Political system: Experts" =  "system_experts", 
                                      "Suppl.: Trust in civil service" =  "trustCivilService", 
                                      "Suppl.: Personal Importance of Politics" = "polImportant", 
                                      "Suppl.: Trust in justice" =  "trustJustice", 
                                      "Suppl.: Trust in parliament" =  "trustParliament" 
                                    )
                                    
                                    
                        )
                        
                      ),
                      mainPanel(
                        withSpinner(htmlOutput("table"))
                      )
                    )
           ),
           tabPanel("Method Description",
                    mainPanel(
                      HTML(
                        paste(
                          h2("Generalized Additive Model"),
                          p("The GAM model is specified with a standard smoothing spline, which enables us to estimate the smoothed nonlinear cohort effects. By applying this specification, we assume that the cohort effect is smoothly changing. We follow Grasso by including age as a categorical variable with three levels (15-29, 30-59, 60+) and control for period specific differences as fixed effects (Grasso, 2014):"),
                          img(src='GAM.PNG', align = "middle"),
                          h2("Robust Hierarchical APC Model"),
                          p("We used the robust HAPC technique (Bell and Jones, 2015) and work with the assumption that period trends are absent when examining citizenship norms over time. We included birth cohorts as random and fixed effects, which constrains period trends to 0 (Bell and Jones, 2015: 203). Still, period effects can to arise from the respondents’ social context, since they are included as random effects. We thus model respondents as nested in cohorts and periods as their distinct social contexts. In order to “assess the relative importance of the two contexts, cohort and period, in understanding individual differences” (Yang and Land, 2006: 87), we treat periods and cohorts as independent random variables (assuming a person born in 1965 might have been surveyed in either 2008 or 2017). This assumption is necessary because any combination of the two levels is conceivable (Rabash and Goldstein, 1994; Rabe-Hesketh and Skrondal, 2008: 473). Finally, due to the simultaneous occurrence of age, cohort and period effects, every APC statistical model requires the assumption that there are no countervailing temporal influences, which offset the impact of the other temporal effects."),
                            p("This specification is embedded in country fixed-effects multi-level regressions to account for different levels of norm acceptance in each country. In line with common practice (Dalton, 2008b; Yang and Land, 2006), we controlled for gender. As HAPC models may provide misleading results for linear cohort and period effects (Bell and Jones, 2017), we avoided the assumption of linear effects by including age and cohort terms with polynomials on the second and third order. Further, we divided cohorts into independent groups, separated into 17 categories by the five-year span when the individuals turned 18. For each dependent variable and each country, we ran robust cross-classified hierarchical age-period-cohort mixed regression with the following specification (Bell and Jones, 2015):  "),
                          img(src='rHAPC.PNG', align = "middle"),
                          h2("Predictions - Observed Values Approach"),
                          p("We use the observed values approach (OVA, Hanmer/Kalkan 2013) to calculate predictions for the cohort, period and lifecycle effects. Since the estimation of standard errors differs between GAM and rHAPC models, we employ two slightly different approaches to obtain measures of uncertainty for our predictions. We first describe the OVA for the GAM models: In a first step, we retrieve the predicted values and the standard errors from the model. Since GAM models differ from linear models, the 95 % confidence interval (t = 1.96) does not reflect the actual uncertainty in the fitted function. In order to receive a confidence interval, which properly includes the uncertainty of the measure, we employ simultaneous intervals (Simpson 2018). This method ensures that the 95 % confidence interval is actually credible and does so by estimating the appropriate critical value to multiply the standard errors with. Using Rubin's Imputation Rules (King et al. 2001), we calculate average predicted values (and their uncertainty) for each cohort and period. For age groups, we do not calculate predicted values, since they can be easily read from the regression tables. For rHAPC models, the overall idea of the OVA holds. However, when estimating standard errors for the predictions, we need to employ bootstrapping methods, since uncertainty cannot be analytically derived from mixed models. Using a parametric bootstrapping methods, we get standard errors for the single predictions of the fixed effects, e.g. cohort and lifecycle effects. For period effects, which enter the equation only as random effects, we do not report uncertainty measures. From this, we again apply Rubin's Imputation Rules to get average measures for each quantity of interest.")
                        )
                      )
                    )
             
           ),
           tabPanel("Deviations from Pre-Analysis Plan",
                    mainPanel(
                      HTML(
                        paste(
                          
                          h3("Pre-registration strategy"),
                          
                          
                          strong("Pre-registering observational data"),   
                          tags$br(),
                          "In order to pre-register the study prior to data access and thus to credibly claim that the analytical strategy was chosen blind to the results, we exploited the fact that the EVS 2019 questionnaire was published before the survey data was published.",
                          tags$br(),
                          
                          tags$br(),strong("Content of Pre-registration"),   
                          tags$br(),
                          "We pre-registered the following elements of the study: ",
                          tags$ul(
                            tags$li("Research question"), 
                            tags$li("Indicator selection"), 
                            tags$li("Country selection"), 
                            tags$li("Analytical strategy and syntax")
                          ),
                          strong("Timeline"),   
                          tags$br(),
                          "The study incorporates EVS data from two rounds of data releases. Before Release 1, we submitted a major pre-registration. ",   
                            tags$br(), 
                            tags$br(),
                          tags$em("EVS 2019 Release 1"), 
                          tags$br(),
                          "Date of Preregistration: Dec 14 2018",
                          tags$br(),
                          "Date of Data Release: Dec 18 2018",
                          tags$br(),
                          "Link to Preregistration: https://osf.io/wjszh/",
                          tags$br(),
                          tags$br(),
                          tags$em("EVS 2019 Release 2"), 
                          tags$br(),
                          "Date of Preregistration: July 4 2019 / July 13 2019 (Update)",
                          tags$br(),
                          "Date of Data Release: Dec 18 2018",
                          tags$br(),
                          "Link to Preregistration: https://osf.io/8fwqm / https://osf.io/btvgk (Update)",
                          h3("Deviations"),
                   
                          p("In several instances, the final analyses as reported in the manuscript deviates from the pre-analysis plan. In the following, we document and justify the deviations."),
                          
                          h4("Indicators"),
                          p("We preregistered attitudes towards expert governments as a primary variable of interest, ascribing it the same status as attitudes towards authoritarian governments. However, in the main text we only plot attitudes towards authoritarian governments and we only mention  briefly attitudes towards expert governments. Due to limitations in space, we decided that two analyses on abstract regime preferences (democracy, authoritarianism) would be sufficiently informative, considering that indicators on other types of attitudes should also be reported. Evidence on attitudes towards expert governments are reported in the Shiny Web Application."),
                          p("Note that the development of attitudes towards expert governments followed a similar trajectory as those indicators that are reported in the main text: there are no clear time trends or evidence for generational trends in direction of the democratic deconsolidation hypothesis. There is considerable increase for expert governments in the Netherlands and Switzerland which may deserve further country-specific attention. At the same time, there is generational decline in the acceptance of expert governments in Poland and considerable time trends in the same direction in Germany."),
                          
                          h4("Predictions"),
                          p("In the pre-registration plan (and in the accompanying analysis syntax), we did not specify how the plotted predictions would be calculated. In response to a reviewer suggestion, we decided to report predictions based on the observed-value-approach. This approach is preferrable to alternatives (such as predictions at representative values as the reported estimates include information on all observations in the sample."),
                          
                          h4("Errors"),
                          p("We fixed several minor or major mistakes that were part of the pre-registered analysis syntax. For example, we used the wrong variable to conduct the analysis on political interest. Hence, running the pre-registered analysis syntax may not replicate the results reported in the final study.")
                        )
                        
                      )
                    )
           ),
           tabPanel("Differences to previous studies",
                    mainPanel(
                      HTML(
                        paste(
                          h2("Differences to previous studies"),
                          
                          #### Fig 1 ####
                          
                          h3("Study"),
                          p("The democratic disconnect, 2016"),
                          
                          h4("DOI"),
                          p("10.1353/jod.2016.0049"),
                          
                          h4("Fig"),
                          p("Fig 1"),
                          
                          h4("Title"),
                          p("Essential to live in a country that is governed democratically, by age cohort"),
                          
                          h4("Original Interpretation"),
                          p("When asked to rate on a scale of 1 to 10 how essential it is for them to live in a democracy, 72 percent of those born before World War II check 10, the highest value. So do 55 percent of the same cohort in the Netherlands."),
                          p("But, as Figure 1 shows, the millennial generation (those born since 1980) has grown much more indifferent. Only one in three Dutch millennials accords maximal importance to living in a democracy; in the United States, that number is slightly lower, around 30 percent."),
                          
                          h4("Indicator"),
                          p("Importance of Democracy"),
                          
                          h4("Technique"),
                          p("cross-sectional,
                            age-diff=cohort"),
                          
                          
                          h4("Operationalization"),
                          p("acceptance of scale point 10"),
                          
                          
                          h4("Country"),
                          p("1. US, 2. EU"),
                          
                          h4("Our Assessment"),
                          p("Voeten demonstrated that the result is largely due to focus on the one scale point. In our analysis, we calculate average in which these dynamics are then less stark. "),
                          p(""), ##linebreak
                          p(""), ##linebreak
                       
                          
                          #### Fig 2 ####
                          
                          h3("Study"),
                          p("The democratic disconnect, 2016"),
                          
                          h4("DOI"),
                          p("10.1353/jod.2016.0049"),
                          
                          h4("Fig"),
                          p("Fig 2"),
                          
                          h4("Title"),
                          p("Having a democratic Political System is a bad or very bad way to run this country"),
                          
                          h4("Original Interpretation"),
                          p("
The decline in support for democracy is not just a story of the young being more critical than the old; it is, in the language of survey research, owed to a cohort effect rather than an “age” effect. Back in 1995, for example, only 16 percent of Americans born in the 1970s (then in their late teens or early twenties) believed that democracy was a bad political system for their country. Twenty years later, the number of antidemocrats in this same generational cohort had increased by around 4 percentage points, to 20 percent. The next cohort—comprising those born in the 1980s—is even more antidemocratic: In 2011, 24 percent of U.S. millennials (then in their late teens or early twenties) considered democracy to be a bad or very bad way of running the country. Although this trend was somewhat more moderate in Europe, it was nonetheless significant: In 2011, 13 percent of European youth (aged 16 to 24) expressed such a view, up from 8 percent among the same age group in the mid-1990s (see Figure 2)."),
                          
                          h4("Indicator"),
                          p("Regime Preferences: Democracy"),
                          
                          h4("Technique"),
                          p("two-wave comparison: 1995 & 2011"),
                          
                          
                          h4("Operationalization"),
                          p("democracy bad or very bad"),
                          
                          
                          h4("Country"),
                          p("1. US, 2. EU: Germany, Sweden, Spain, the Netherlands, Romania, Poland, and the United Kingdom"),
                          
                          h4("Our Assessment"),
                          p("In our data, there was a period effect between 99 and 2008 that may partially account for the findings in Figure 2. "),
                          p("However,  in our data the period effect occured only in: Austria, Bulgaria, Croatia, Czech, Republic, Netherlands. "), 
                          p("Examining the presence of period effects when only considering countries that were included in the Foa Mounk analysis:

declining period effect were found in the 2000s in: Netherlands
no period effects in 2000s in: Poland, Germany
very small effects in: Spain 
not in our sample: Romania, UK"), 
                          p("
In general: these investigations shows that there is not a lot of overlap between the country sample underlying Figure 2 and the country sample underlying our study"), ##linebreak
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Fig 3 ####
                          
                          h3("Study"),
                          p("The democratic disconnect, 2016"),
                          
                          h4("DOI"),
                          p("10.1353/jod.2016.0049"),
                          
                          h4("Fig"),
                          p("Fig 3"),
                          
                          h4("Title"),
                          p("The widening Political Apathy Gap                          "),
                          
                          h4("Original Interpretation"),
                          p("In fact, in both Western Europe and North America, interest in politics has rapidly and markedly declined among the young. At the same time, it has either remained stable or even increased among older cohorts. 
In 1990, both a majority of young Americans (those between the ages of 16 and 35) and a majority of older Americans (36 years and older) reported being fairly interested or very interested in politics—53 and 63 percent, respectively. By 2010, the share of young Americans professing an interest in politics had dropped by more than 12 percentage points and the share of older Americans had risen by 4 percentage points. As a result, the generation gap had widened from 10 percentage points to 26 percentage points. 
Among European respondents, who on the whole report less interest in politics than do their American counterparts, this phenomenon is even starker: The gap between young and old more than tripled between 1990 and 2010, from 4 to 14 percentage points. This is attributable almost solely to a rapid loss of interest amongyoung respondents. Whereas the share of Europeans aged 36 or older who were interested in politics remained stable at 52 percent, among the young that figured dropped from 48 to 38 percent"),
                          
                          h4("Indicator"),
                          p("Political Interest"),
                          
                          h4("Technique"),
                          p("two-wave comparison: 1990 and 2010"),
                          
                          
                          h4("Operationalization"),
                          p("farily or very interested"),
                          
                          
                          h4("Country"),
                          p("1. US
                            2. EU: Germany, the Netherlands, Poland, Romania, Spain, and Sweden"),
                          
                          h4("Our Assessment"),
                          p("one partial explanation of discrepancies between Figure 3 and our study might lie in the complex S-shaped curves in the developmeht of political interest across generations that our study has revealed and that is not visible in the Foa Mounk analysis as they dichotmized generation membership/age-groups."),
                          p("                           In addition, we observe a small uptick among the very young generations and the Foa Mounk data does not cover that because we use a more recent data source"), 
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Fig 4 ####
                          h3("Study"),
                          p("The democratic disconnect, 2016"),
                          
                          h4("DOI"),
                          p("10.1353/jod.2016.0049"),
                          
                          h4("Fig"),
                          p("Fig 4"),
                          
                          h4("Title"),
                          p("Support for autoritarianism by income in the US"),
                          
                          h4("Original Interpretation"),
                          p("In the United States, among all age cohorts, the share of citizens who believe that it would be better to have a “strong leader” who does not have to “bother with parliament and elections” has also risen over time: In 1995, 24 percent of respondents held this view; by 2011, that figure had increased to 32 percent. Meanwhile, the proportion of citizens who approve of “having experts, not government, make decisions according to what they think is best for the country” has grown from 36 to 49 percent. One reason for these changes is that whereas two decades ago affluent citizens were much more likely than people of lower income groups to defend democratic institutions, the wealthy are now moderately more likely than others to favor a strong leader who can ignore democratic institutions (see Figure 4 below).
"),
                          
                          h4("Indicator"),
                          p("Regime Preferences: Strong Leader"),
                          
                          h4("Technique"),
                          p("broken down by respondent's income
development of acceptance of strong leader across four survey waves"),
                          
                          
                          h4("Operationalization"),
                          p("sub-group mean"),
                          
                          
                          h4("Country"),
                          p("US"),
                          
                          h4("Our Assessment"),
                          p("Figure 4 only concerns the US which is not included in our sample. As noted by Norris (2017), the signs of democratic deconsolidation that can be observed in the US do not occur at the same magnitude or not at all in other (European) countries. Yet, Europe is the focus of our analysis.
 "),
                          p("Findings for EU are not reported in this Figure by Foa/Mounk"), 
                        
                           
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Figure 1 ####
                          h3("Study"),
                          p("The Signs of Deconsolidation, 2017"),
                          
                          h4("DOI"),
                          p("https://www.journalofdemocracy.org/sites/default/files/02_28.1_Foa%20%26%20Mounk%20pp%205-15.pdf"),
                          
                          h4("Fig"),
                          p("Fig 1"),
                          
                          h4("Title"),
                          p("Across the globe, the young are less invested in democracy"),
                          
                          h4("Original Interpretation"),
                          p("It is not just that the proportion of Americans who state that it is “essential” to live in a democracy, which stands at 72 percent among those born before World War II, has fallen to 30 percent among millennials. It is also that, contrary to Ronald Inglehart’s response   to our earlier essay in these pages,3 a similar cohort pattern is found across all longstanding democracies, including Great Britain, the Netherlands, Sweden, Australia, and New Zealand (see Figure 1). In virtually all cases, the generation gap is striking, with the proportion of younger citizens who believe it is essential to live in a democracy falling to a minority.
                            
                            "),
                          
                          h4("Indicator"),
                          p("Importance of democracy"),
                          
                          h4("Technique"),
                          p("replication of Fig 1 from 2016-article with more countries"),
                          
                          
                          h4("Operationalization"),
                          p("acceptance of scale point 10"),
                          
                          
                          h4("Country"),
                          p("Australia, UK, Netherlands, New Zealand, Sweden, US"),
                          
                          h4("Our Assessment"),
                          p("see above"), 
                          
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Figure 2 ####
                          h3("Study"),
                          p("The Signs of Deconsolidation, 2017"),
                          
                          h4("DOI"),
                          p("https://www.journalofdemocracy.org/sites/default/files/02_28.1_Foa%20%26%20Mounk%20pp%205-15.pdf"),
                          
                          h4("Fig"),
                          p("Fig 2"),
                          
                          h4("Title"),
                          p("Global rise in share of citizens wishing for a strong leader who does not have to bother with elections"),
                          
                          h4("Original Interpretation"),
                          p("The share of citizens who approve of having a strong leader who does not have to bother with parliament or elections, for example, has gone up markedly in most of the countries where the World Values Survey asked the question—including such varied places as Germany, the United States, Spain, Turkey, and Russia."),
                          
                          h4("Indicator"),
                          p("Regime Preferences: Strong Leader"),
                          
                          h4("Technique"),
                          p("comparions of 1995 and 2010 waves. dichotomized item"),
                          
                          
                          h4("Operationalization"),
                          p("dichotomized item"),
                          
                          
                          h4("Country"),
                          p("many all across the world"),
                          
                          h4("Our Assessment"),
                          p("most countries not in Europe. Within European countries the trends are not clear in Figure 2."), 
                          
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Figure 1 ####
                          h3("Study"),
                          p("The End of the Consolidation Paradigm, 2017"),
                          
                          h4("DOI"),
                          p("https://www.journalofdemocracy.org/sites/default/files/media/Journal%20of%20Democracy%20Web%20Exchange%20-%20Foa%20and%20Mounk%20reply--2_0.pdf"),
                          
                          h4("Fig"),
                          p("Fig 1"),
                          
                          h4("Title"),
                          p("Figure from Norris (2017): Approval of Democracy by Age Group, 1995-2011"                            ),
                          
                          h4("Original Interpretation"),
                          p(" Take the graph presented by Pippa Norris as counter-evidence to our thesis of eroding youth support in the United States: it clearly shows both a) that, at this point in time, young people are more critical of democracy than older people; and b) that young people at this point in time are more critical of democracy than young people had been in the past"),
                          
                          h4("Indicator"),
                          p("Regime Preferences: Democracy"),
                          
                          h4("Technique"),
                          p("generational analysis
                            acceptance of age  groups in different survey waves"),
                          
                          
                          h4("Operationalization"),
                          p("mean value of acceptance"),
                          
                          
                          h4("Country"),
                          p("US"),
                          
                          h4("Our Assessment"),
                          p("US sample. see above."), 
                          
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          
                          #### Figure 2 ####
                          h3("Study"),
                          p("The End of the Consolidation Paradigm, 2017"),
                          
                          h4("DOI"),
                          p("https://www.journalofdemocracy.org/sites/default/files/media/Journal%20of%20Democracy%20Web%20Exchange%20-%20Foa%20and%20Mounk%20reply--2_0.pdf"),
                          
                          h4("Fig"),
                          p("Fig 2"),
                          
                          h4("Title"),
                          p("Respondents Aged 15-24 have become Critical of Democracy at a Faster Rate than People Aged 65+"
                              
                              ),
                          
                          h4("Original Interpretation"),
                          p("Respondents Aged 15-24 have become Critical of Democracy at a Faster Rate than People Aged 65+
                            "),
                          
                          h4("Indicator"),
                          p("Regime Preferences: 
                              Democracy (negative)"),
                          
                          h4("Technique"),
                          p("Different in attitude dynamics among young and older individuals"),
                          
                          
                          h4("Operationalization"),
                          p("dichotomized"),
                          
                          
                          h4("Country"),
                          p("EU"),
                          
                          h4("Our Assessment"),
                          p("All analyses are based on extremely small sample sizes but the figure does not show uncertainty of the estimates.                             "),
                          p("
                            
                            The analysis does not take into account the possibiltiy that acceptance of democracy increases in both age-groups. In such a case (which is a frequent occurance in the data we analyzed) the analyses presented in Figure 2 is somewhat misleading."), 
                          
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p(""), ##linebreak
                          
                          
                          #### Figure 3 ####
                          h3("Study"),
                          p("The End of the Consolidation Paradigm, 2017"),
                          
                          h4("DOI"),
                          p("https://www.journalofdemocracy.org/sites/default/files/media/Journal%20of%20Democracy%20Web%20Exchange%20-%20Foa%20and%20Mounk%20reply--2_0.pdf"),
                          
                          h4("Fig"),
                          p("Fig 3"),
                          
                          h4("Title"),
                          p("Support for Democracy among European Youth (16-26) Respondents, 1999-2001 and 2017"
                            ),
                          
                          h4("Original Interpretation"),
                          p("In three countries (France, Italy, and Poland), only a minority of those aged 16 to 26 view democracy as the best form of government. In the UK, just over half of young respondents take this view. Even in Germany, which has so far shown less strong democratic deconsolidation than other countries, only about three in five respondents believe this"
                            ),
                          
                          h4("Indicator"),
                          p("Regime Preferences: Democracy (preferential)"),
                          
                          
                          
                          h4("Operationalization"),
                          p("one scale point"),
                          
                          
                          h4("Country"),
                          p("EU"),
                          
                          h4("Our Assessment"),
                          p("EVS 2017 does not contain similar items. (EVS 2017 would enable to conduct a similar analysis by calculating rank-orders of individual regime preferences, comparing intra-individually how individuals evaluates different regime types"), 
                          
                          
                          p(""), ##linebreak
                          p(""), ##linebreak
                          p("")
                          
                        )
                                               
                      )
                    )
           )
)
