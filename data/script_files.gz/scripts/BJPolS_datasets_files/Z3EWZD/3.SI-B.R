# Please run 1.main_results.R first

# Figure B.1
ch_refTermMChanges$termReform <- paste0(ch_refTermMChanges$session, '-', ch_refTermMChanges$reform)
ch_refTermMChanges$x <- 1
mean_pct <- with(ch_refTermMChanges, aggregate(women_pct, list(female,termReform), mean))
sd_pct <- with(ch_refTermMChanges, aggregate(women_pct, list(female,termReform), sd))
n_pct <- with(ch_refTermMChanges, aggregate(x, list(female,termReform), sum))
names(mean_pct) <- c('female', 'termReform', 'mean')
names(sd_pct) <- c('female', 'termReform', 'sd')
names(n_pct) <- c('female', 'termReform', 'n')
out_pct <- merge(mean_pct, sd_pct, by = c('female', 'termReform'))
out_pct <- merge(out_pct, n_pct, by = c('female', 'termReform'))
out_pct$se <- out_pct$sd/sqrt(out_pct$n)
out_pct$lb <- out_pct$mean + qnorm(0.025) * out_pct$se
out_pct$ub <- out_pct$mean + qnorm(0.975) * out_pct$se
out_pct <- out_pct[order(out_pct$termReform, out_pct$female),]

par(mar = c(5, 6, 2, 2))
reformPlot <- barplot(out_pct$mean, names.arg = c('Men\n(2010-2014)', 'Women\n(2010-2014)', 
	'Men\n(2014-2015)', 'Women\n(2014-2015)', 
	'Men\n(2015-2018)', 'Women\n(2015-2018)', 
	'Men\n(2018-2022)', 'Women\n(2018-2022)'),
	ylim = c(0, 25), cex.axis = 1.5, 
	ylab = c("Avg. Share of Portfolio on Women's Issues"), cex.lab = 1.75,
	col = c('grey85', 'grey85', 'grey85', 'grey85',
		'grey50', 'grey50', 'grey50', 'grey50'),
	border = FALSE)
legend('topleft', legend = c('Pre-Reform', 'Post-Reform'),
	fill = c('grey85', 'grey50'), cex = 1.75, bty = 'n',
	border = FALSE)
arrows(reformPlot, out_pct$ub, reformPlot, out_pct$lb, angle = 90, code = 3 , length=0.1)

# Figure B2
ch_refTerm$x <- 1
mean_pct <- with(ch_refTerm, aggregate(women_pct, list(female,magAnalysis), mean))
sd_pct <- with(ch_refTerm, aggregate(women_pct, list(female,magAnalysis), sd))
n_pct <- with(ch_refTerm, aggregate(x, list(female,magAnalysis), sum))
names(mean_pct) <- c('female', 'mag', 'mean')
names(sd_pct) <- c('female', 'mag', 'sd')
names(n_pct) <- c('female', 'mag', 'n')
out_pct <- merge(mean_pct, sd_pct, by = c('female', 'mag'))
out_pct <- merge(out_pct, n_pct, by = c('female', 'mag'))
out_pct$se <- out_pct$sd/sqrt(out_pct$n)
out_pct$lb <- out_pct$mean + qnorm(0.025) * out_pct$se
out_pct$ub <- out_pct$mean + qnorm(0.975) * out_pct$se
out_pct <- out_pct[order(out_pct$mag, out_pct$female),]

par(mar = c(5, 6, 2, 2))
reformPlot <- barplot(out_pct$mean, 
	names.arg = c('Men\n(M=2)', 'Women\n(M=2)', 
	'Men\n(M=3)', 'Women\n(M=3)', 
	'Men\n(M=4)', 'Women\n(M=4)', 
	'Men\n(M=5)', 'Women\n(M=5)', 
	'Men\n(M=6)', 'Women\n(M=6)', 
	'Men\n(M=7)', 'Women\n(M=7)', 
	'Men\n(M=8)', 'Women\n(M=8)'),
	ylim = c(0, 50), cex.axis = 1.5, 
	ylab = c("Avg. Share of Portfolio on Women's Issues"), cex.lab = 1.75,
	border = FALSE, 
	col = c('grey85', 'grey85', rep('grey50', 12)))
legend('topleft', legend = c('Pre-Reform', 'Post-Reform'),
	fill = c('grey85', 'grey50'), cex = 1.75, bty = 'n',
	border = FALSE)
arrows(reformPlot, out_pct$ub, reformPlot, out_pct$lb, angle = 90, code = 3 , length=0.1)

# Figure B.3
par(mar = c(6, 6, 4, 4))
boxplot(ch_refTermMChanges$women_pct[ch_refTermMChanges$termReform == '2010-2014-0'] ~ 
	ch_refTermMChanges$female[ch_refTermMChanges$termReform == '2010-2014-0'],
	xlab = '', names = c('Men', 'Women'), ylab = "Share of Portfolio on Women's Issues",
	cex.lab = 1.75, cex.axis = 1.75, ylim = c(0, 50))
boxplot(ch_refTermMChanges$women_pct[ch_refTermMChanges$termReform == '2014-2018-0'] ~ 
	ch_refTermMChanges$female[ch_refTermMChanges$termReform == '2014-2018-0'],
	xlab = '', names = c('Men', 'Women'), ylab = "Share of Portfolio on Women's Issues",
	cex.lab = 1.75, cex.axis = 1.75, ylim = c(0, 50))
boxplot(ch_refTermMChanges$women_pct[ch_refTermMChanges$termReform == '2014-2018-1'] ~ 
	ch_refTermMChanges$female[ch_refTermMChanges$termReform == '2014-2018-1'],
	xlab = '', names = c('Men', 'Women'), ylab = "Share of Portfolio on Women's Issues",
	cex.lab = 1.75, cex.axis = 1.75, ylim = c(0, 50))
boxplot(ch_refTermMChanges$women_pct[ch_refTermMChanges$termReform == '2018-2022-1'] ~ 
	ch_refTermMChanges$female[ch_refTermMChanges$termReform == '2018-2022-1'],
	xlab = '', names = c('Men', 'Women'), ylab = "Share of Portfolio on Women's Issues",
	cex.lab = 1.75, cex.axis = 1.75, ylim = c(0, 50))


# Figure B.4
ch_refTermMChangesParty$x <- 1
ch_refTermMChangesParty$partyReform <- paste0(ch_refTermMChangesParty$party, '-', ch_refTermMChangesParty$reform)
mean_pct <- with(ch_refTermMChangesParty, aggregate(women_pct, list(female, partyReform, reform, party), mean))
sd_pct <- with(ch_refTermMChangesParty, aggregate(women_pct, list(female, partyReform), sd))
n_pct <- with(ch_refTermMChangesParty, aggregate(x, list(female,partyReform), sum))
names(mean_pct) <- c('female', 'party_ref', 'reform', 'party', 'mean')
names(sd_pct) <- c('female', 'party_ref', 'sd')
names(n_pct) <- c('female', 'party_ref', 'n')
out_pct <- merge(mean_pct, sd_pct, by = c('female', 'party_ref'))
out_pct <- merge(out_pct, n_pct, by = c('female', 'party_ref'))
out_pct$se <- out_pct$sd/sqrt(out_pct$n)
out_pct$lb <- out_pct$mean + qnorm(0.025) * out_pct$se
out_pct$ub <- out_pct$mean + qnorm(0.975) * out_pct$se
out_pct <- out_pct[order(out_pct$party_ref, out_pct$female),]
# Remove parties that have only men or only women
out_pct <- subset(out_pct, !(party_ref %in% c('EVOP-1', 'PEV-1', 'PI-1', 
	'Poder-1', 'PRO-1', 'IC-0', 'IC-1', 'PL-0', 'PL-1')))

colorsGraph <- ifelse(out_pct$reform == 1, 'grey50', 'grey85')
labelsGraph <- ifelse(out_pct$female == 1, paste0('Women-', out_pct$party), paste0('Men-', out_pct$party))
par(mar = c(8, 6, 2, 2))
reformPlot <- barplot(out_pct$mean, 
	names.arg = labelsGraph, las = 2,
	ylim = c(0, 50), cex.axis = 1.5,
	axes = FALSE, 
	ylab = c("Avg. Share of Portfolio on Women's Issues"), cex.lab = 1.75,
	border = FALSE, 
	col = c(colorsGraph)
	)
legend('topleft', legend = c('Pre-Reform', 'Post-Reform'),
	fill = c('grey85', 'grey50'), cex = 1.75, bty = 'n',
	border = FALSE)
axis(2, at = seq(0, 50, 10), cex.axis = 1.5)
arrows(reformPlot, out_pct$ub, reformPlot, out_pct$lb, angle = 90, code = 3 , length=0.1)
