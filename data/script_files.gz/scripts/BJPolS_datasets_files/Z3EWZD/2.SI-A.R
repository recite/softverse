# Please run 1.main_results.R first

########## Descriptive stats ############
summary(ch_refTerm[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(ch_refTermMChanges[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_refTerm, session %in% c('2010-2014', '2018-2022'))[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_pre_post, bill_author %in% inSample)[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_refTerm, allSessions == 1)[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_refTermMChanges, allSessions == 1)[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_refTerm, session %in% c('2010-2014', '2018-2022') & l10_l18 == 1)[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
summary(subset(ch_refTerm, session == '2018-2022')[, c('women_pct', 'magAnalysis', 'female', 'magAnalysisWoman')])
