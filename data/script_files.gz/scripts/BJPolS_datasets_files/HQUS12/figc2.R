# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(foreign)

## First stage as a quantile regression
quantiles <- read.dta13("Results/quantiles.dta")

# Multiply quantiles with 100
quantiles$Quantile <- quantiles$Quantile * 100

quantiles_plot <- quantiles %>%
  mutate(Model = ifelse(OLS == 1, "OLS regression", "Quantile regression")) %>%
  ggplot(aes(x = as.numeric(Quantile), y = coef)) +
  geom_point(size = 1, position = position_dodge(width = 0.75)) + 
  geom_linerange(aes(ymin = ci_lower, ymax = ci_upper), position = position_dodge(width = 0.75)) +  
  geom_hline(aes(yintercept = 0), linetype = 2, color = "black") + 
  geom_vline(aes(xintercept = 95), linetype = 2, color = "red") + 
  theme_bw() +
  ylab("First-stage coefficient") + 
  xlab("Quantile") +
  scale_y_continuous() +
  scale_x_continuous(breaks = c(10, 20, 30, 40, 50, 60, 70, 80, 90, 100), labels = c("10", "20", "30", "40", "50", "60", "70", "80", "90", "OLS")) +
  #facet_grid(~ Model, scale = 'free_x')
  scale_color_manual(values = c("black", "blue"))
quantiles_plot

# Save the plot
ggsave("Plots/figc2.png", plot = quantiles_plot, width = 25, height = 20, units = "cm") 