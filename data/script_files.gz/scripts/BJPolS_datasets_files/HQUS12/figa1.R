# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(foreign)

election_level <- read.dta("Data/fragmentation_electionlevel.dta")

enpp_histogram <- ggplot(election_level, aes(x = enppadd_bw50)) +
  geom_density(color = "red", fill = "red", alpha = 0.6) +
  theme_bw() +
  scale_y_continuous(name = "Density", limits = c(0, 1.85)) +
  scale_x_continuous(name = "ENPP added by parties in the bandwidth", limits = c(0, 1.75)) +
  ggtitle("Instrument for ENPP")
enpp_histogram

totalparties_histogram <- ggplot(election_level, aes(x = inbw50)) +
  geom_histogram(alpha = 0.7) +
  theme_bw() +
  labs(x = "Number of parties inside the bandwidth", y = "Number of observations") +
  ggtitle("Instrument for absolute no. of parliamentary parties")
totalparties_histogram

# Putting together the two plots
distributions <- grid.arrange(
  enpp_histogram,
  totalparties_histogram, 
  ncol = 2, nrow = 1)
distributions

ggsave("Plots/figa1.png", plot = distributions, width = 30, height = 20, units = "cm")