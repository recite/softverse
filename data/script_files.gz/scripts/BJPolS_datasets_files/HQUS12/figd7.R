# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(foreign)

# Import data with main analyses
data <- read.dta("Results/analyses_final.dta")

# Make the plot
firststage_plot_secondid <- data %>%
  filter(Polynomials < 5) %>%
  filter(FE == "None")  %>%
  filter(Outcome == "Turnout")  %>%
  mutate(Polynomials = as.factor(Polynomials)) %>%
  ggplot(aes(x = Instruments, y = fstat, fill = Polynomials)) +
  geom_bar(stat = "identity", position = position_dodge(0.75), color = "gray30") +
  theme_bw() +
  scale_y_continuous(limits = c(0, 10), breaks = c(0, 2, 4, 6, 8, 10)) +
  ylab("F-test") + 
  scale_fill_brewer(palette = "YlGnBu") + 
  theme_minimal() +
  geom_hline(yintercept = 9, color = "red", linetype = "dashed", size = 1) +
  facet_wrap(.~ Predictor)
firststage_plot_secondid

# Save the plot
ggsave("Plots/figd7.png", plot = firststage_plot_secondid, width = 20, height = 15, units = "cm")