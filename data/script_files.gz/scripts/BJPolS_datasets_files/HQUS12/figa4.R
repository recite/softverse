# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(readxl)

election_level <- read.dta("Data/fragmentation_electionlevel.dta")

# Creating a theme for the plot
theme_base <- 
  theme_minimal(base_size=9)  + 
  theme(legend.position = c(0.85, 0.1),
        axis.text=element_text(size=12),axis.title.x=element_text(size=12),axis.title.y=element_text(size=12),
        plot.title = element_text(size=12, hjust= 0.5),
        legend.text = element_text(size=12))

# Generate variable for wasted votes
election_level$wasted_votes <- 100 - election_level$sum_pervote_parl

# Make the plot
wasted_votes <- ggplot(election_level, aes(x = enppadd_bw50, y = wasted_votes)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red",size = .5) +
  geom_point(alpha = 0.6) +
  stat_smooth(method = "lm", aes(colour = "Linear model")) +
  stat_smooth(method = "loess", linetype = "longdash", aes(colour = "LOESS")) +
  scale_colour_manual(name = " ", values = c("blue", "green3")) +
  # annotate("text", x = 0.5, y = -2, label = "F(1, 35) = 26.60", size = 4) +
  scale_y_continuous(limits = c(0, 100)) +
  theme_base +
  labs(x = "Effective number of parl parties added by parties within the bandwidth", y = "Wasted votes")
wasted_votes

# Save the plot
ggsave("Plots/figa4.png", plot = wasted_votes, width = 20, height = 20, units = "cm")