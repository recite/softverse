# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(foreign)
library(rdd)

bandwidths <- read.dta("Data/fragmentation_partylevel.dta")

bandwidths <- bandwidths %>%
  filter(bandwidths$distance_threshold_prop < 1)

# Check the p-value
DCdensity(bandwidths$distance_threshold_prop, plot = TRUE, cutpoint = 0)

# Make the plot
sorting_plot <- DCdensity(bandwidths$distance_threshold_prop, plot = TRUE, cutpoint = 0)
sorting_plot <- title(xlab = "Party's distance to the electoral threshold as a proportion of that threshold", ylab = "Density")
sorting_plot <- abline(v = 0, lty = 1, col = "grey50")