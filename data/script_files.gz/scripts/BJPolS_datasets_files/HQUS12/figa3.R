# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

library(tidyverse)
library(readxl)

placebos <- read_excel("Results/placebos.xlsx")

# Fix outcome labels
placebos$outcome[placebos$outcome == "year"] <- "Year"
placebos$outcome[placebos$outcome == "year_sq"] <- "Year squared"
placebos$outcome[placebos$outcome == "year_above_1989"] <- "Year above 1989"
placebos$outcome[placebos$outcome == "rile"] <- "Party L-R ideology"
placebos$outcome[placebos$outcome == "country_1"] <- "Albania"
placebos$outcome[placebos$outcome == "country_2"] <- "Armenia"
placebos$outcome[placebos$outcome == "country_3"] <- "Austria"
placebos$outcome[placebos$outcome == "country_4"] <- "Bolivia"
placebos$outcome[placebos$outcome == "country_5"] <- "Bulgaria"
placebos$outcome[placebos$outcome == "country_6"] <- "Croatia"
placebos$outcome[placebos$outcome == "country_7"] <- "Cyprus"
placebos$outcome[placebos$outcome == "country_8"] <- "Czech Republic"
placebos$outcome[placebos$outcome == "country_9"] <- "Denmark"
placebos$outcome[placebos$outcome == "country_10"] <- "Estonia"
placebos$outcome[placebos$outcome == "country_11"] <- "Georgia"
placebos$outcome[placebos$outcome == "country_12"] <- "Germany"
placebos$outcome[placebos$outcome == "country_13"] <- "Greece"
placebos$outcome[placebos$outcome == "country_14"] <- "Hungary"
placebos$outcome[placebos$outcome == "country_15"] <- "Iceland"
placebos$outcome[placebos$outcome == "country_16"] <- "Israel"
placebos$outcome[placebos$outcome == "country_17"] <- "Italy"
placebos$outcome[placebos$outcome == "country_18"] <- "Latvia"
placebos$outcome[placebos$outcome == "country_19"] <- "Lithuania"
placebos$outcome[placebos$outcome == "country_20"] <- "Macedonia"
placebos$outcome[placebos$outcome == "country_21"] <- "Mexico"
placebos$outcome[placebos$outcome == "country_22"] <- "Moldova"
placebos$outcome[placebos$outcome == "country_23"] <- "Montenegro"
placebos$outcome[placebos$outcome == "country_24"] <- "Netherlands"
placebos$outcome[placebos$outcome == "country_25"] <- "New Zealand"
placebos$outcome[placebos$outcome == "country_26"] <- "Norway"
placebos$outcome[placebos$outcome == "country_27"] <- "Peru"
placebos$outcome[placebos$outcome == "country_28"] <- "Poland"
placebos$outcome[placebos$outcome == "country_29"] <- "Romania"
placebos$outcome[placebos$outcome == "country_30"] <- "Russia"
placebos$outcome[placebos$outcome == "country_31"] <- "Seychelles"
placebos$outcome[placebos$outcome == "country_32"] <- "Slovakia"
placebos$outcome[placebos$outcome == "country_33"] <- "Slovenia"
placebos$outcome[placebos$outcome == "country_34"] <- "South Korea"
placebos$outcome[placebos$outcome == "country_35"] <- "Sweden"
placebos$outcome[placebos$outcome == "country_36"] <- "Taiwan"
placebos$outcome[placebos$outcome == "country_37"] <- "Turkey"
placebos$outcome[placebos$outcome == "country_38"] <- "Ukraine"


# Draw the actual plot
placebos_plot <- placebos %>%
  mutate(ci_upper = coefficient + 1.96 * std_error) %>%
  mutate(ci_lower = coefficient - 1.96 * std_error) %>%
  mutate(outcome = fct_reorder(outcome, coefficient)) %>%
  ggplot(aes(outcome, coefficient, show.legend = FALSE)) + 
  geom_hline(aes(yintercept = 0), linetype = 2, color = "red") + 
  coord_flip(ylim = c(-3, 3)) + 
  geom_linerange(aes(ymin = ci_lower, ymax = ci_upper), position = position_dodge(width = 0.75) ) + 
  geom_point(size = 1, position = position_dodge(width = 0.75) ) + 
  facet_grid(~ bandwidth, scale = 'free') + 
  theme_minimal(base_size = 9) +
  theme(legend.position = "none",
        panel.background = element_rect(fill = NA, color = "black")) +
  ylab(" ") + 
  xlab("") 
placebos_plot

ggsave("Plots/figa3.png", plot = placebos_plot, width = 20, height = 20, units = "cm") 