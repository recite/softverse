###################################################################################
# R replication file for ONLINE APPENDIX
# "When do the Wealthy Support Redistribution?," BJPS, forthcoming 
# G. Feierherd, L. Schiumerini, and S. Stokes 
###################################################################################

# Clean objects and set global environment

rm(list=ls(all=TRUE))
options(scipen=10, digits=2)
z_score = qnorm(1 - ((1 - .95)/2))

# Load packages 

library(foreign) 
require(sandwich) 
require(lmtest)  
library(plotrix) 
library(AER) 
library(xtable)
library(pastecs)
library(texreg)
library(lmtest)

# Set working directory and load main file and functions 

setwd("~/")

data <- read.dta("When do the Wealthy - Data.dta")

controldata <- data[data$control==1,]

source("When do the Wealthy - Functions.R") # Loads functions (explanation is provided in the source file.)


# 1 Balance tests ---------------------------------------------------------

covars <- c("gender", "age", "h_size", "earners", "owner", "cars", "control", 
            "placebo", "injust", "just", "kirch", "retired", 
            "unemployed", "jefe2", "educ", "inc", "nat")

datbal <- data[, covars]
datbal$incz <- scale(datbal$inc, center = T, scale = T)
datbal$carsz <- scale(datbal$cars, center = T, scale = T)
datbal$ownerz <- scale(datbal$owner, center = T, scale = T)

# Impute for missing values 

datbal$miss <- 0
datbal$miss[is.na(datbal$inc)] <- 1

datbal$inc[is.na(datbal$inc)] <- -1
datbal$earners[is.na(datbal$earners)] <- mean(datbal$earners, na.rm = TRUE)
datbal$owner[is.na(datbal$owner)] <- mean(datbal$owner, na.rm = TRUE)
datbal$cars[is.na(datbal$cars)] <- mean(datbal$cars, na.rm = TRUE)
datbal$h_size[is.na(datbal$h_size)] <- mean(datbal$h_size, na.rm = TRUE)


######################
# Natural experiment #
######################

# Figure A1: Balance Statistics: Quasi-Experiment -------------------------

gender<-cbind("Gender",sum(!is.na(datbal$gender)),with(datbal,t.test(gender~nat))$estimate[2],
              with(datbal,t.test(gender~nat))$estimate[1],
              with(datbal,t.test(gender~nat))[3],
              with(datbal,wilcox.test(gender~nat))[3])

age<-cbind("Age",sum(!is.na(datbal$age)),with(datbal,t.test(age~nat))$estimate[2],
           with(datbal,t.test(age~nat))$estimate[1],
           with(datbal,t.test(age~nat))[3],
           with(datbal,wilcox.test(age~nat))[3])

jefe<-cbind("Head of household",sum(!is.na(datbal$jefe2)),with(datbal,t.test(jefe2~nat))$estimate[2],
            with(datbal,t.test(jefe2~nat))$estimate[1],
            with(datbal,t.test(jefe2~nat))[3],
            with(datbal,wilcox.test(jefe2~nat))[3])

unemployed<-cbind("Unemployed",sum(!is.na(datbal$unemployed)),with(datbal,t.test(unemployed~nat))$estimate[2],
                  with(datbal,t.test(unemployed~nat))$estimate[1],
                  with(datbal,t.test(unemployed~nat))[3],
                  with(datbal,wilcox.test(unemployed~nat))[3])

retired<-cbind("Retired",sum(!is.na(datbal$retired)),with(datbal,t.test(retired~nat))$estimate[2],
               with(datbal,t.test(retired~nat))$estimate[1],
               with(datbal,t.test(retired~nat))[3],
               with(datbal,wilcox.test(retired~nat))[3])

educ<-cbind("Level of education",sum(!is.na(datbal$educ)),with(datbal,t.test(educ~nat))$estimate[2],
            with(datbal,t.test(educ~nat))$estimate[1],
            with(datbal,t.test(educ~nat))[3],
            with(datbal,wilcox.test(educ~nat))[3])

size<-cbind("Household size",sum(!is.na(datbal$h_size)),with(datbal,t.test(h_size~nat))$estimate[2],
            with(datbal,t.test(h_size~nat))$estimate[1],
            with(datbal,t.test(h_size~nat))[3],
            with(datbal,wilcox.test(h_size~nat))[3])

earners<-cbind("Number of wage earners",sum(!is.na(datbal$earners)),with(datbal,t.test(earners~nat))$estimate[2],
               with(datbal,t.test(earners~nat))$estimate[1],
               with(datbal,t.test(earners~nat))[3],
               with(datbal,wilcox.test(earners~nat))[3])

owner2<-cbind("Household owner",sum(!is.na(datbal$owner)),with(datbal,t.test(owner~nat))$estimate[2],
              with(datbal,t.test(owner~nat))$estimate[1],
              with(datbal,t.test(owner~nat))[3],
              with(datbal,wilcox.test(owner~nat))[3])

cars<-cbind("Number of cars owned",sum(!is.na(datbal$cars)),with(datbal,t.test(cars~nat))$estimate[2],
            with(datbal,t.test(cars~nat))$estimate[1],
            with(datbal,t.test(cars~nat))[3],
            with(datbal,wilcox.test(cars~nat))[3])

income<-cbind("Income",sum(!is.na(datbal$inc)),with(datbal,t.test(inc~nat))$estimate[2],
              with(datbal,t.test(inc~nat))$estimate[1],
              with(datbal,t.test(inc~nat))[3],
              with(datbal,wilcox.test(inc~nat))[3])

ideology<-cbind("Support for gov.",sum(!is.na(datbal$kirch)),with(datbal,t.test(kirch~nat))$estimate[2],
                with(datbal,t.test(kirch~nat))$estimate[1],
                with(datbal,t.test(kirch~nat))[3],
                with(datbal,wilcox.test(kirch~nat))[3])

miss<-cbind("Missing",sum(!is.na(datbal$miss)),with(datbal,t.test(miss~nat))$estimate[2],
            with(datbal,t.test(miss~nat))$estimate[1],
            with(datbal,t.test(miss~nat))[3],
            with(datbal,wilcox.test(miss~nat))[3])

balance <- as.table(rbind(gender,age,jefe,retired,educ,size,earners,owner2,income,ideology, unemployed, cars, miss),row.names=NULL)
balance <- matrix(data = balance, nrow = 13, ncol = 6, byrow = FALSE, dimnames = NULL)
colnames(balance)<-c("Covariate","N", "Mean treated","Mean untreated", "Diff in means", "Rank sum")
is.num <- sapply(balance, is.numeric)
balance[,3] <- lapply(balance[,3], round, 2)
balance[,4] <- lapply(balance[,4], round, 2)
results <- balance

pdf(file="nat_miss.pdf",family="Palatino", width=7,height=6.5)

textsize=0.9
parcex=0.9
at1=-0.35
at2=-0.15
at3=-0.9
xlim1=-0.85

xlim = c(xlim1,1); pchset = c(21,24,22,23); pchcolset = c("blue","yellow","red","darkgreen")

par(cex=parcex, mai = c(0.6, 0.35, 1.1, 0.35))

ny = nrow(results)

plot(x=NULL,axes=F, xlim=xlim, ylim=c(1,ny),xlab="",ylab="")

abline(v=c(0,0.05,0.1),lty=c(1,2,2), lwd=c(1,1,1))
axis(side=1,at=c(0,0.05,0.1,1),tick=TRUE, las=2, cex.axis=0.7)

axis(side=3,at=at1,labels="Mean\nTreated",tick=FALSE, padj=0.5,cex.axis=textsize)
axis(side=3,at=at2,labels="Mean\nUntreated",tick=FALSE, padj=0.5,cex.axis=textsize)
axis(side=3,at=0.5,labels="P-values",tick=FALSE, padj=0.5,cex.axis=textsize)

points(results[,5],ny:1, pch = 21, col = "blue", bg = "blue", cex=.9)
points(results[,6],ny:1, pch = 24, col = "red", bg = "red", cex=.9)

for(i in 1:ny) {
  text(at3,ny-i+1,results[i,1],adj = 0,cex=textsize) # variable name
  text(at1,ny-i+1,results[i,3], cex=textsize)        # treatment mean
  text(at2,ny-i+1,results[i,4], cex=textsize)        # control mean
}

for(i in seq(2,by=2,length.out=floor((ny-1)/2))) abline(h = i+0.5, lty = 3)

legend(x=.75, y=2.2, c("Diff-means", "Rank-sum"), pch=c(21,24), pt.bg = c("blue", "red"), cex=0.8, bty="n")

dev.off()


# Table A1: F-test of pre-treatment covariates ----------------------------

ftest1 <- lm(nat~gender+age+retired+educ+h_size+earners+kirch+unemployed+owner+inc+cars+miss, data=datbal)
ftest1$newse <- vcovHC(ftest1, type="HC2") # 

texreg(list(ftest1),
       dcolumn=FALSE,
       label="tab:ftest",
       custom.coef.names = c("Constant", "Gender","Age","Retired","Education","Household Size", "Wage Earners", "Gov. Supporter", "Unemployed", "Household Owner","Income",  "N. of Cars", "Missing"),
       caption="F-test of pre-treatment covariates on being assigned to the price hike. footnotesize{The dependent variable is treatment assignment. Robust standard errors in parentheses.}",
       stars = c(0.01, 0.05, 0.1),
       scriptsize=T,
       digits=3,
       include.fstatistic=T
)


######################
# Survey experiments #
######################

# Figure A2: Balancet ests: t-tests for survey experiments ----------------

bal.covar <- c("gender","age","retired","educ","h_size","earners","owner","inc",
               "kirch", "cars","unemployed", "miss")

nat.balance <- lapply(bal.covar, function(x) bal.surv(x, "placebo","injust", "just", datbal))

dm.pval1 <- sapply(nat.balance, function(x)  2*(1-pnorm(abs(x$dm.results1[[1]]/x$dm.results1[[2]]))))
dm.pval2 <- sapply(nat.balance, function(x)  2*(1-pnorm(abs(x$dm.results2[[1]]/x$dm.results2[[2]]))))
control <- sapply(nat.balance, function(x) x$dm.results1[[6]])
injust <- sapply(nat.balance, function(x) x$dm.results1[[5]])
just <- sapply(nat.balance, function(x) x$dm.results2[[5]])

balvar.names <-c("Gender","Age","Retired","Level of education","Household size","Number of wage earners",
                 "Household owner","Income","Support for gov.", "Number of cars owned", "Unemployed", "Missing")

baltable <- data.frame(covar = balvar.names, pvalue1=dm.pval1, pvalue2= dm.pval2, control=control, injust=injust, just=just)
baltable[,4] <- round(baltable[,4], 2)
baltable[,5] <- round(baltable[,5], 2)
baltable[,6] <- round(baltable[,6], 2)

results <- baltable

pdf(file="surv.pdf",family="Palatino", width=8,height=6.5)

textsize=0.9
parcex=0.9
xlim1=-1.1

xlim = c(xlim1,1); pchset = c(21,24,22,23); pchcolset = c("blue","yellow","red","darkgreen")

par(cex=parcex, mai = c(0.6, 0.35, 1.1, 0.35))

ny = nrow(results)

plot(x=NULL,axes=F, xlim=xlim, ylim=c(1,ny),xlab="",ylab="")

abline(v=c(0,0.05,0.1),lty=c(1,2,2), lwd=c(1,1,1))
axis(side=1,at=c(0,0.05,0.1,1),tick=TRUE, las=2, cex.axis=0.7)

axis(side=3,at=-.63,labels="Mean\nPlacebo",tick=FALSE, padj=0.5,cex.axis=textsize)
axis(side=3,at=-.41,labels="Mean\nIntra-class",tick=FALSE, padj=0.5,cex.axis=textsize)
axis(side=3,at=-.18,labels="Mean\nCross-class",tick=FALSE, padj=0.5,cex.axis=textsize)
axis(side=3,at=0.5,labels="P-values",tick=FALSE, padj=0.5,cex.axis=textsize)

points(results[,2],ny:1, pch = 21, col = "blue", bg = "blue", cex=.9)
points(results[,3],ny:1, pch = 24, col = "red", bg = "red", cex=.9)

for(i in 1:ny) {
  text(-1.15,ny-i+1,results[i,1],adj = 0,cex=textsize) # variable name
  text(-.63,ny-i+1,results[i,4], cex=textsize)        # control mean
  text(-.41,ny-i+1,results[i,5], cex=textsize)        # injust mean
  text(-.18,ny-i+1,results[i,6], cex=textsize)        # just mean
  
}

for(i in seq(2,by=2,length.out=floor((ny-1)/2))) abline(h = i+0.5, lty = 3)

legend(x=.75, y=8.5, c("Intra-class", "Cross-class"), pch=c(21,24), pt.bg = c("blue", "red"), cex=0.8, bty="n")

dev.off()

# Table A2: Summary of Dependent Variables --------------------------------

data$policy <- as.numeric(data$p1_1)
data$redistr <- as.numeric(data$p2_1)
data$unempl <- as.numeric(data$p2_2)
stat.desc(data[, c("policy", "redistr", "unempl")]) 

# LATE assumptions --------------------------------------------------------

# Table A3: F-test. First stage -------------------------------------------

ftest2 <- lm(lost~nat, data=data)
summary(ftest2)
ftest2$newse <- vcovHC(ftest2, type="HC2") # 

texreg(ftest2,
       dcolumn=FALSE,
       label="tab:ftest",
       custom.coef.names = c("Constant", "Geographic location (0,1)"),
       caption="F-test. First stage: regression of treatment receipt on treatment assignment.",
       stars = c(0.01, 0.05, 0.1),
       scriptsize=T,
       digits=3,
       include.fstatistic=T)



#########################################
# Extended results and robustness tests #
#########################################

# Intent-to-treat analysis ------------------------------------------------

# Table A4: Intention to Treat (ITT) estimates  ---------------------------

itt1 <- lm(p2_1z~nat, data=controldata)
summary(itt1)
itt1$newse <- vcovHC(itt1, type="HC2") # 
itt2 <- lm(p2_2z~nat, data=controldata)
summary(itt2)
itt2$newse <- vcovHC(itt2, type="HC2") # 

texreg(list(itt1,itt2),
       dcolumn=FALSE,
       label="itt",
       custom.coef.names = c("Constant", "Geographic location (0,1)"),
       caption="Intention to Treat (ITT) estimates: Attitudes towards redistribution and unemployment insurance by exposure to price hike.",
       stars = c(0.01, 0.05, 0.1),
       scriptsize=T,
       digits=3,
       include.fstatistic=T)


#Figure A5: ITT analysis of Resentment (H2) and Empathy (H3) -------------------

pdf(file="ITT_hyp2.pdf",family="Palatino", width=8.5,height=5.5)

pol <- model_itt(data,data$p1_1z,data$injust,data$placebo,data$nat); # same as summary(lm(p1_1z~injust, data=data[data$nat==1,], subset= placebo==1 | injust==1))
pu21 <- pol[3,1] + z_score*pol[4,1]
pu22 <- pol[3,2] + z_score*pol[4,2]
pl21 <- pol[3,1] - z_score*pol[4,1]
pl22 <- pol[3,2] - z_score*pol[4,2]

red <- model_itt(data,data$p2_1z,data$injust,data$placebo,data$nat)
ru21 <- red[3,1] + z_score*red[4,1]
ru22 <- red[3,2] + z_score*red[4,2]
rl21 <- red[3,1] - z_score*red[4,1]
rl22 <- red[3,2] - z_score*red[4,2]

une <-  model_itt(data,data$p2_2z,data$injust,data$placebo,data$nat)
uu21 <- une[3,1] + z_score*une[4,1]
uu22 <- une[3,2] + z_score*une[4,2]
ul21 <- une[3,1] - z_score*une[4,1]
ul22 <- une[3,2] - z_score*une[4,2]

# Initialize plotting window  

plot(x=c(), y=c(), ylim=c(-.75, .75), xlim=c(0,12), xlab="", 
     ylab="Standardized mean",  xaxt="n", type = "n", bty='n', axes=T, 
     main="Panel 1: ITT, Disadvantageous Intra-Class Inequality Aversion")

abline(h=0, lty=3)

axis(1,at=c(2,6,10),labels=c("Opinion about\n the policy","Redistribution",
                             "Unemployment\ninsurance"), mgp=c(3, 2, 0))
# Price Hike 

points(x=1, y=pol[3,1], pch=16, col="red", cex=1.5)
points(x=3, y=pol[3,2], pch=15, col="blue", cex=1.5)

lines(x=c(1,1), y=c(pl21, pu21), col="red", lty=1, lwd=3)
lines(x=c(3,3), y=c(pl22, pu22), lty=1, col="blue", lwd=3)

segments(1.05,pol[3,1],2.95,pol[3,2], lwd=4, lty=3, col="gray")

text(1-.5, pol[3,1], round(pol[3,1],2),srt=0, cex=1)
text(3+.5, pol[3,2], round(pol[3,2],2),srt=0, cex=1)

sig(ate=pol[3,3],se=pol[4,3],x=1,y=.75,f=1,est="CATE = ")

# Redistribution

points(x=5, y=red[3,1], pch=16, col="red", cex=1.5)
points(x=7, y=red[3,2], pch=15, col="blue", cex=1.5)

lines(x=c(5,5), y=c(rl21, ru21), col="red", lty=1, lwd=3)
lines(x=c(7,7), y=c(rl22, ru22), lty=1, col="blue", lwd=3)

segments(5.05,red[3,1],6.95,red[3,2], lwd=4, lty=3, col="gray")

text(5-.5, red[3,1],round(red[3,1],2),srt=0, cex=1)
text(7+.5, red[3,2],round(red[3,2],2),srt=0, cex=1)

sig(ate=red[3,3],se=red[4,3],x=6,y=.75,f=1,est="CATE = ")

# Unemployment insurance

points(x=9, y=une[3,1], pch=16, col="red", cex=1.5)
points(x=11, y=une[3,2], pch=15, col="blue", cex=1.5)

lines(x=c(9,9), y=c(ul21, uu21), col="red", lty=1, lwd=3)
lines(x=c(11,11), y=c(ul22, uu22), lty=1, col="blue", lwd=3)

segments(9.05,une[3,1],10.95,une[3,2], lwd=4, lty=3, col="gray")

text(9-.5, une[3,1],round(une[3,1],2),srt=0, cex=1)
text(11+.5, une[3,2],round(une[3,2],2),srt=0, cex=1)

sig(ate=une[3,3],se=une[4,3],x=10,y=.75,f=1,est="CATE = ")

legend(x=9,y=-.4,c("Treated-Placebo","Treated-intraclass\ninequality"), 
       lty=1, col=c('red', 'blue'), cex=.8, seg.len=0.8,
       text.width=.6, pch=c(16,15), bty = "n")
dev.off()


pdf(file="ITT_hyp3.pdf",family="Palatino", width=8.5,height=5.5)

pol <- model_itt(data,data$p1_1z,data$injust,data$placebo,data$nat) 

pu21 <- pol[1,1] + z_score*pol[2,1]
pu22 <- pol[1,2] + z_score*pol[2,2]
pl21 <- pol[1,1] - z_score*pol[2,1]
pl22 <- pol[1,2] - z_score*pol[2,2]

red <- model_itt(data,data$p2_1z,data$injust,data$placebo,data$nat)

ru21 <- red[1,1] + z_score*red[2,1]
ru22 <- red[1,2] + z_score*red[2,2]
rl21 <- red[1,1] - z_score*red[2,1]
rl22 <- red[1,2] - z_score*red[2,2]

une <- model_itt(data,data$p2_2z,data$injust,data$placebo,data$nat)

uu21 <- une[1,1] + z_score*une[2,1]
uu22 <- une[1,2] + z_score*une[2,2]
ul21 <- une[1,1] - z_score*une[2,1]
ul22 <- une[1,2] - z_score*une[2,2]

# Initialize plotting window  

plot(x=c(), y=c(), ylim=c(-.75, .75), xlim=c(0,12), xlab="", 
     ylab="Standardized mean",  xaxt="n", type = "n", bty='n', axes=T, 
     main="Panel 2: ITT, Advantageous Intra-Class Inequality Aversion")

abline(h=0, lty=3)

axis(1,at=c(2,6,10),labels=c("Opinion about\n the policy","Redistribution",
                             "Unemployment\ninsurance"), mgp=c(3, 2, 0))
# Price Hike 

points(x=1, y=pol[1,1], pch=16, col="red", cex=1.5)
points(x=3, y=pol[1,2], pch=15, col="blue", cex=1.5)

lines(x=c(1,1), y=c(pl21, pu21), col="red", lty=1, lwd=3)
lines(x=c(3,3), y=c(pl22, pu22), lty=1, col="blue", lwd=3)

segments(1.05,pol[1,1],2.95,pol[1,2], lwd=4, lty=3, col="gray")

text(1-.5, pol[1,1], round(pol[1,1],2),srt=0, cex=1)
text(3+.5, pol[1,2], round(pol[1,2],2),srt=0, cex=1)

sig(ate=pol[1,3],se=pol[2,3],x=1,y=.75,f=1,est="CATE = ")

# Redistribution

points(x=5, y=red[1,1], pch=16, col="red", cex=1.5)
points(x=7, y=red[1,2], pch=15, col="blue", cex=1.5)

lines(x=c(5,5), y=c(rl21, ru21), col="red", lty=1, lwd=3)
lines(x=c(7,7), y=c(rl22, ru22), lty=1, col="blue", lwd=3)

segments(5.05,red[1,1],6.95,red[1,2], lwd=4, lty=3, col="gray")

text(5-.5, red[1,1],round(red[1,1],2),srt=0, cex=1)
text(7+.5, red[1,2],round(red[1,2],2),srt=0, cex=1)

sig(ate=red[1,3],se=red[2,3],x=6,y=.75,f=1,est="CATE = ")

# Unemployment insurance

points(x=9, y=une[1,1], pch=16, col="red", cex=1.5)
points(x=11, y=une[1,2], pch=15, col="blue", cex=1.5)

lines(x=c(9,9), y=c(ul21, uu21), col="red", lty=1, lwd=3)
lines(x=c(11,11), y=c(ul22, uu22), lty=1, col="blue", lwd=3)

segments(9.05,une[1,1],10.95,une[1,2], lwd=4, lty=3, col="gray")

text(9-.5, une[1,1],round(une[1,1],2),srt=0, cex=1)
text(11+.5, une[1,2],round(une[1,2],2),srt=0, cex=1)

sig(ate=une[1,3],se=une[2,3],x=10,y=.75,f=1,est="CATE = ")

legend(x=9,y=-.4,c("Untreated-Placebo","Untreated-intraclass\ninequality"), 
       lty=1, col=c('red', 'blue'), cex=.8, seg.len=0.8,
       text.width=.6, pch=c(16,15), bty = "n")

dev.off()


################
# Full results #
################

full1 <- ivreg(p1_1z~injust*lost+just*lost,
               ~injust*nat+just*nat, data=data)
full1$newse <- vcovHC(full1, type="HC2") 

full2 <- ivreg(p2_1z~injust*lost+just*lost+control*lost,
               ~injust*nat+just*nat+control*nat, data=data)
full2$newse <- vcovHC(full2, type="HC2") 

full3 <- ivreg(p2_2z~injust*lost+just*lost+control*lost,
               ~injust*nat+just*nat+control*nat, data=data)
full3$newse <- vcovHC(full3, type="HC2") 


# Table A5: Full results of instrumental variables estimation -------------

texreg(list(full1,full2,full3),
       dcolumn=T,
       label="table:full",
       custom.model.names = c("Policy", "Redistribution", "Unemployment"),
       custom.coef.names = c("Constant", "Intraclass", "Treatment", "Crossclass", "Intraclass cdot Treatment", "Crossclass cdot Treatment", "Control", 
                             "Control cdot Treatment"),
       caption="Full results of instrumental variables estimation",
       stars = c(0.01, 0.05, 0.1),
       scriptsize=T,
       digits=3,
       include.fstatistic=F
)


###########################
# What role for ideology? #
###########################


# Presidential vote choice

data$presi<-NA
data$presi[mapply(grepl,"CFK",data$president)=="TRUE"]<-'CFK'
data$presi[mapply(grepl,"ALFONSIN",data$president)=="TRUE"]<-'ALFONSIN'
data$presi[mapply(grepl,"BINNER",data$president)=="TRUE"]<-'BINNER'
data$presi[mapply(grepl,"CARRIO",data$president)=="TRUE"]<-'CARRIO'
data$presi[mapply(grepl,"SAA",data$president)=="TRUE"]<-'R. SAA'
data$presi[mapply(grepl,"DUHALDE",data$president)=="TRUE"]<-'DUHALDE'
data$presi[mapply(grepl,"BLANCO",data$president)=="TRUE"]<-'BLANK/NULL'
data$presi[mapply(grepl,"ANULO",data$president)=="TRUE"]<-'BLANK/NULL'
data$presi[mapply(grepl,"OTRO",data$president)=="TRUE"]<-'OTHER'

data$presi <- ordered(data$presi,levels=c("BINNER","CFK","CARRIO","DUHALDE","ALFONSIN",
                                          "R. SAA","OTHER","BLANK/NULL"))

# Ideology measure based on presidential vote choice

data$ideology<-NA
data$ideology[data$presi=="CFK" | data$presi=="BINNER" ]<-1 # Leftists
data$ideology[is.na(data$ideology) & (data$presi=="ALFONSIN" |data$presi=="R. SAA"
                                    |data$presi=="DUHALDE" | data$presi=="CARRIO")] <-0 # Moderates & Conservatives


# Table A6: Declared vote choice in past presidential elections

print(xtable(cbind(table(data$presi),prop.table(table(data$presi))*100),digits=0)) 

#Table A7: Opinion about the policy. Percentage responses by ideology.
for (i in c(1:5)){
  data$policy[mapply(grepl,i,data$p1_1)=="TRUE"]<-i
  
}

tab1<-round(prop.table(table(data$policy,data$ideology),2)*100,digits=0)
rownames(tab1)<-c("1- Very bad","2",'3','4','5- Very good')
colnames(tab1)<-c("Moderate","Center-left")
print(xtable(tab1))

for (i in c(1:7)){
  data$redist[mapply(grepl,i,data$p2_1)=="TRUE"]<-i
  
}

#Table A8: Support for redistribution. Percentage responses by ideology.
tab2<-round(prop.table(table(data$redist,data$ideology),2)*100,digits=0)
rownames(tab2)<-c("1- Completely against","2",'3','4','5','6',"7- Completely in favor")
colnames(tab2)<-c("Moderate","Center-left")
print(xtable(tab2))


#Table A9: Support for unemployment insurance. Percentage responses by ideology
for (i in c(1:7)){
  data$unemp[mapply(grepl,i,data$p2_2)=="TRUE"]<-i
  
}

tab3<-round(prop.table(table(data$unemp,data$ideology),2)*100,digits=0)
rownames(tab3)<-c("1- Totally against","2",'3','4','5','6',"7- Totally in favor")
colnames(tab3)<-c("Moderate","Center-left")
print(xtable(tab3))

# Table A10: Regression of outcome measures on ideology
m1<-with(data,lm(p1_1z~ideology))
m2<-with(data,lm(p2_1z~ideology))
m3<-with(data,lm(p2_2z~ideology))

# Table A11: Regression of outcome measures on ideology -------------------

texreg(list(m1,m2,m3))



# Figure A6. Testing resentment by ideological subgroups

left<-subset(data,ideology==1)
mod<-subset(data,ideology==0)

# Top panel
pdf(file="plot_left.pdf",family="Palatino", width=8.5,height=5.5)
groups.iv(left,left$injust,left$placebo,left$lost,left$nat,
          indep.lab="",a=-.75,b=1.5,
          main.title="Leftists")
legend(x=9,y=-.4,c("Treated-Placebo","Treated-intraclass\ninequality"), 
       lty=1, col=c('red', 'blue'), cex=.8, seg.len=0.8,
       text.width=.6, pch=c(16,15), bty = "n")
dev.off()
# Bottom panel
pdf(file="plot_mod.pdf",family="Palatino", width=8.5,height=5.5)
groups.iv(mod,mod$injust,mod$placebo,mod$lost,mod$nat,
          indep.lab="",a=-1.5,b=1.2, main.title="Moderates/Conservatives")
dev.off()


# Figure A7: Testing altruism by ideology

pdf(file="crossid_appendix.pdf",family="Palatino", width=8.5,height=5.5)
groups.iv(data,data$just,data$placebo,data$lost,data$nat,
          indep.lab="",main.title="Moderates/Conservatives")
legend(x=9,y=-.4,c("Treated-Placebo","Treated-crossclass\ninequality"), 
       lty=1, col=c('red', 'blue'), cex=.8, seg.len=0.8,
       text.width=.6, pch=c(16,15), bty = "n")
dev.off()



