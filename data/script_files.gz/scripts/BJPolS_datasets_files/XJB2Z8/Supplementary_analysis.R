#This file replicates supplementary analysis in "The Role of Communities in the Transmission of Political Values: Evidence from Forced Population Transfers" (pp. 4-10 in the Appendix)
#Authors: Volha Charnysh (charnysh@mit.edu) and Leonid Peisakhin (leonid.peisakhin@nyu.edu)
#R version 3.4.0 (2017-04-21)
#Platform: x86_64-apple-darwin15.6.0 (64-bit)
#Running under: macOS  10.14.6


rm(list = ls())

# Install and load packages
packages <- c("openxlsx", "lpdensity", "rddensity", "rdrobust", "rdlocrand", "xtable", "stargazer")
invisible(lapply(packages, function(x) if (!require(x, character.only=T)){install.packages(x);library(x, character.only = T)}))

# Note the versions for packages used: 
#[1] stargazer_5.2.2 xtable_1.8-3    rdlocrand_0.5   rdrobust_0.99.4 rddensity_1.0   lpdensity_1.0  [7] openxlsx_4.1.0 

####################################################################################
##########  GEOGRAPHIC REGRESSION DISCONTINUITY ANALYSIS: APPENDIX pp 3-9    #######
###################################################################################

dat<-read.xlsx("election2015borders.xlsx")
dat$distAuM2<-ifelse(dat$Part=="AUS", dat$distAuM, -dat$distAuM)


dat1<-subset(dat, dat$Part=="AUS" | dat$Part=="RUS") #exclude the Prussian partition

mass2015a<-read.xlsx("ReligiosityAusRus2015.xlsx")
mass2015a$latlonInt<-mass2015a$lat*mass2015a$lon

X1<-mass2015a$distAuM2/1000 #convert from meters into kilometers

X2<-dat1$distAuM2/1000
DudaR1<-100*(dat1$DudaPiSR1/dat1$ValVotesR1)
KomorR1<-100*(dat1$KomorowskiPOR1/dat1$ValVotesR1)
TurnoutR1<-100*(dat1$ValVotesR1/dat1$NoVotersR1)

dat1$lotlanInt<-dat1$lon*dat1$lat
Z<-cbind(dat1$town, dat1$lon, dat1$lat, dat1$lotlanInt) 

############################################
##########  Table A1: Uniform Kernel #######
############################################

### 2015 presidential election, first round
out1 = rdrobust(mass2015a$PctMass, X1, covs=cbind(mass2015a$town, mass2015a$lon,mass2015a$lat, mass2015a$latlonInt), kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out1) 

out2 = rdrobust(TurnoutR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) 
summary(out2)

out3 = rdrobust(DudaR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) 
summary(out3)

out4 = rdrobust(KomorR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) 
summary(out4)

### 2015 parliamentary election 
out5 = rdrobust(dat1$Turnout, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) 
summary(out5)
out6 = rdrobust(dat1$PiS, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out6)
out7 = rdrobust(dat1$PO, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out7)

Coefficient<-c(round(out1$coef[1,],2), round(out2$coef[1,],2), round(out3$coef[1,],2), round(out4$coef[1,],2), round(out5$coef[1,],2), round(out6$coef[1,],2), round(out7$coef[1,],2))
SE<-c(round(out1$se[1,],2), round(out2$se[1,],2), round(out3$se[1,],2), round(out4$se[1,],2), round(out5$se[1,],2), round(out6$se[1,],2), round(out7$se[1,],2))
CIs<-c(paste(round(out1$ci[3,1],2), round(out1$ci[3,2],2), sep=", "), paste(round(out2$ci[3,1],2), round(out2$ci[3,2],2), sep=", "), paste(round(out3$ci[3,1],2), round(out3$ci[3,2],2), sep=", "), paste(round(out4$ci[3,1],2), round(out4$ci[3,2],2), sep=", "), paste(round(out5$ci[3,1],2), round(out5$ci[3,2],2), sep=", "), paste(round(out6$ci[3,1],2), round(out6$ci[3,2],2), sep=", "), paste(round(out7$ci[3,1],2), round(out7$ci[3,2],2), sep=", "))
Observations<-c(sum(out1$N), sum(out2$N), sum(out3$N), sum(out4$N), sum(out5$N), sum(out6$N), sum(out7$N))

Kernel<-c(out1$k, out2$k, out3$k, out4$k, out5$k, out6$k, out7$k)
Polynomial<-c(out1$p,out2$p,out3$p,out4$p,out5$p,out6$p,out7$p)
BandwidthType<-c(out1$bwselect,out2$bwselect, out3$bwselect, out4$bwselect, out5$bwselect, out6$bwselect, out7$bwselect)
BandwidthKM<-c(round(out1$bws[1,1], 2), round(out2$bws[1,1], 2), round(out3$bws[1,1],2), round(out4$bws[1,1],2), round(out5$bws[1,1],2), round(out6$bws[1,1],2), round(out7$bws[1,1],2))
EffectiveNUntreated<-c(out1$Nh[1],out2$Nh[1], out3$Nh[1], out4$Nh[1], out5$Nh[1], out6$Nh[1], out7$Nh[1]) 

#Note for some versions of RDrobust, code is EffectiveNUntreated<-c(out1$N_h[1], out2$N_h[1], out3$N_h[1], out4$N_h[1], out5$N_h[1], out6$N_h[1], out7$N_h[1])
 
EffectiveNTreated<-c(out1$Nh[2],out2$Nh[2], out3$Nh[2], out4$Nh[2], out5$Nh[2], out6$Nh[2], out7$Nh[2])

#Note for some versions of RDrobust, code is: EffectiveNTreated<-c(out1$N_h[2], out2$N_h[2], out3$N_h[2], out4$N_h[2], out5$N_h[2], out6$N_h[2], out7$N_h[2])

tableA1<-as.data.frame(rbind(Coefficient, SE, CIs, Observations, Kernel, Polynomial, BandwidthType, BandwidthKM, EffectiveNTreated, EffectiveNUntreated))
colnames(tableA1)<-c("Mass attendance","Turnout", "Law & Justice", "Civic Platform", "Turnout", "Law andd Justice", "Civic Platform")
rownames(tableA1)<-c("Coefficient", "Standard error (conventional)", "Robust bias-corrected CIs", "Observations", "Kernel type", "Polynomial", "Bandwidth type", "MSE-optimal bandwidth", "Effective # treated", "Effective # untreated")

xtable(tableA1)

############################################
##########  Table A2: Triangular Kernel ####  
############################################

out1 = rdrobust(mass2015a$PctMass, X1, covs=cbind(mass2015a$town, mass2015a$lat, mass2015a$lon, mass2015a$latlonInt), kernel = "Triangular", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out1) 
out2 = rdrobust(TurnoutR1, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out2) 
out3 = rdrobust(DudaR1, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out3)
out4 = rdrobust(KomorR1, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out4)
out5 = rdrobust(dat1$Turnout, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out5)
out6 = rdrobust(dat1$PiS, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1, all=TRUE) #
summary(out6)
out7 = rdrobust(dat1$PO, X2, covs=Z, kernel = "triangular", p = 1, bwselect = "mserd", scaleregul = 1) #
summary(out7)

Coefficient<-c(round(out1$coef[1,],2), round(out2$coef[1,],2), round(out3$coef[1,],2), round(out4$coef[1,],2), round(out5$coef[1,],2), round(out6$coef[1,],2), round(out7$coef[1,],2))
SE<-c(round(out1$se[1,],2), round(out2$se[1,],2), round(out3$se[1,],2), round(out4$se[1,],2), round(out5$se[1,],2), round(out6$se[1,],2), round(out7$se[1,],2))
CIs<-c(paste(round(out1$ci[3,1],2), round(out1$ci[3,2],2), sep=", "),paste(round(out2$ci[3,1],2), round(out2$ci[3,2],2), sep=", "), paste(round(out3$ci[3,1],2), round(out3$ci[3,2],2), sep=", "), paste(round(out4$ci[3,1],2), round(out4$ci[3,2],2), sep=", "), paste(round(out5$ci[3,1],2), round(out5$ci[3,2],2), sep=", "), paste(round(out6$ci[3,1],2), round(out6$ci[3,2],2), sep=", "), paste(round(out7$ci[3,1],2), round(out7$ci[3,2],2), sep=", "))
Observations<-c(sum(out1$N), sum(out2$N), sum(out3$N), sum(out4$N), sum(out5$N), sum(out6$N), sum(out7$N))

Kernel<-c(out1$k, out2$k, out3$k, out4$k, out5$k, out6$k, out7$k)
Polynomial<-c(out1$p, out2$p,out3$p,out4$p,out5$p,out6$p,out7$p)
BandwidthType<-c(out1$bwselect, out2$bwselect, out3$bwselect, out4$bwselect, out5$bwselect, out6$bwselect, out7$bwselect)
BandwidthKM<-c(round(out1$bws[1,1], 2),round(out2$bws[1,1], 2), round(out3$bws[1,1],2), round(out4$bws[1,1],2), round(out5$bws[1,1],2), round(out6$bws[1,1],2), round(out7$bws[1,1],2))
EffectiveNUntreated<-c(out1$Nh[1],out2$Nh[1], out3$Nh[1], out4$Nh[1], out5$Nh[1], out6$Nh[1], out7$Nh[1])
EffectiveNTreated<-c(out1$Nh[2],out2$Nh[2], out3$Nh[2], out4$Nh[2], out5$Nh[2], out6$Nh[2], out7$Nh[2])

#Alternative code for a different version of RDrobust: EffectiveNUntreated<-c(out1$N_h[1],out2$N_h[1], out3$N_h[1], out4$N_h[1], out5$N_h[1], out6$N_h[1], out7$N_h[1])
#Alternative code for a different RDrobust: EffectiveNTreated<-c(out1$N_h[2],out2$N_h[2], out3$N_h[2], out4$N_h[2], out5$N_h[2], out6$N_h[2], out7$N_h[2])

tableA2<-as.data.frame(rbind(Coefficient, SE, CIs, Observations, Kernel, Polynomial, BandwidthType, BandwidthKM, EffectiveNTreated, EffectiveNUntreated))
colnames(tableA2)<-c("Mass attendance", "Turnout", "Law & Justice", "Civic Platform", "Turnout", "Law and Justice", "Civic Platform")
rownames(tableA2)<-c("Coefficient", "Standard error (conventional)", "Robust bias-corrected CI", "Observations", "Kernel type", "Polynomial", "Bandwidth type", "MSE-optimal bandwidth", "Effective # treated", "Effective # untreated")

xtable(tableA2)

############################################
##########  Table A3: Placebo test:  #######
############################################

dat1$ShareHigherEdu2002<-(100*dat1$wyzsze2002)/(dat1$wyzsze2002 + dat1$policealne2002 + dat1$srednie.razem2002+ dat1$zas_zawod2002 + dat1$podstawowe_ukon2002 + dat1$podst_ieukoncz_bezwyk2002)
dat1$shareUrban<-100*(dat1$PopWMiastachDec2002/dat1$PopDec2002)
dat1$PrivEnt2002<-dat1$SektorPrywatny2002/(dat1$PopDec2002/1000)
dat1$PopDens2002<-dat1$PopDec2002/dat1$AreaKM2

out8 = rdrobust(dat1$ShareHigherEdu2002, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out8)  

out9 = rdrobust(dat1$shareUrban, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out9) 

out10 = rdrobust(dat1$PrivEnt2002, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out10)  

out11 = rdrobust(dat1$PopDens2002, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd", scaleregul = 1,all = TRUE) #
summary(out11)  

## create table: 
Coefficient<-c(round(out8$coef[1,],2),  round(out9$coef[1,],2), round(out10$coef[1,],2), round(out11$coef[1,],2))
SE<-c(round(out8$se[1,],2), round(out9$se[1,],2), round(out10$se[1,],2), round(out11$se[1,],2))
CIs<-c(paste(round(out8$ci[3,1],2), round(out8$ci[3,2],2), sep=", "), paste(round(out9$ci[3,1],2), round(out9$ci[3,2],2), sep=", "), paste(round(out10$ci[3,1],2), round(out10$ci[3,2],2), sep=", "), paste(round(out11$ci[3,1],2), round(out11$ci[3,2],2), sep=", "))
Observations<-c(sum(out8$N), sum(out9$N), sum(out10$N), sum(out11$N))
Kernel<-c(out8$k, out9$k, out10$k, out11$k)
Polynomial<-c(out8$p, out9$p, out10$p, out11$p)
BandwidthType<-c(out8$bwselect, out9$bwselect, out10$bwselect, out11$bwselect)
BandwidthKM<-c(round(out8$bws[1,1], 2), round(out9$bws[1,1],2), round(out10$bws[1,1],2), round(out11$bws[1,1],2))
EffectiveNUntreated<-c(out8$Nh[1], out9$Nh[1], out10$Nh[1], out11$Nh[1])
EffectiveNTreated<-c(out8$Nh[2], out9$Nh[2], out10$Nh[2], out11$Nh[2])

#Alternative code for different RD robust version: 
#EffectiveNUntreated<-c(out8$N_h[1], out9$N_h[1], out10$N_h[1], out11$N_h[1])
#EffectiveNTreated<-c(out8$N_h[2], out9$N_h[2], out10$N_h[2], out11$N_h[2])

tableA3<-as.data.frame(rbind(Coefficient, SE, CIs, Observations, Kernel, Polynomial, BandwidthType, BandwidthKM, EffectiveNTreated, EffectiveNUntreated))
colnames(tableA3)<-c("Share with higher edu", "Share urban", "Private enterprises per 1,000", "Population per km2")
rownames(tableA3)<-c("Coefficient", "Standard error (conventional)", "Robust bias-corrected CI", "Observations", "Kernel type", "Polynomial", "Bandwidth type", "MSE-optimal bandwidth", "Effective # treated", "Effective # untreated")
xtable(tableA3)


############################################
## Figure A.6. Create plots from table A1: #
############################################

dir.create("RD_Plots")

bandwidth1=rdrobust(mass2015a$PctMass, X1, covs=cbind(mass2015a$town, mass2015a$lat, mass2015a$lon, mass2015a$latlonInt), kernel = "uniform", p = 1, bwselect = "mserd")$bws[1, 1]
bandwidth2 = rdrobust(TurnoutR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd")$bws[1, 1]
bandwidth3 = rdrobust(DudaR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd")$bws[1, 1]
bandwidth4 = rdrobust(KomorR1, X2, covs=Z, kernel = "uniform", p = 1, bwselect = "mserd")$bws[1, 1]

pdf("./RD_Plots/Religiosity.pdf")
rdplot(mass2015a$PctMass[abs(X1) <= bandwidth1], X1[abs(X1) <= bandwidth1], p = 1, kernel = "uniform",  binselect = "qsmv", x.label="Distance to the Austrian border", y.label="Share of Catholics at mass", title="RD Plot: Religiosity in 2015")
dev.off()

pdf("./RD_Plots/TurnoutPres.pdf")
rdplot(TurnoutR1[abs(X2) <= bandwidth2], X2[abs(X2) <= bandwidth2],p = 1, kernel = "uniform", binselect = "qsmv", x.label="Distance to the Austrian border", y.label="Turnout", title="RD Plot: 2015 presidential election, round 1")
dev.off()

pdf("./RD_Plots/DudaPres.pdf")
rdplot(DudaR1[abs(X2) <= bandwidth3], X2[abs(X2) <= bandwidth3],p = 1, kernel = "uniform",  binselect = "qsmv", x.label="Distance to the Austrian border", y.label="Vote for Duda (Law and Justice)", title="RD Plot: 2015 presidential election, round 1")
dev.off()

pdf("./RD_Plots/KomorowskiPres.pdf")
rdplot(KomorR1[abs(X2) <= bandwidth4], X2[abs(X2) <= bandwidth4],p = 1, kernel = "uniform",  binselect = "qsmv", x.label="Distance to the Austrian border", y.label="Vote for Komorowski (Civic Platform)", title="RD Plot: 2015 presidential election, round 1")
dev.off()


####################################################################################
######## Table A4. Religiosity & 2015 parliamentary election, municipalities  ######
####################################################################################

d<-read.xlsx("municipalitiesTableA4.xlsx")
d$PctUSSR1<-100*d$PctUSSR
d$PctUSSR1<-100*d$PctUSSR

d$town<-ifelse(substr(d$Gmina, 1, 2)=="m.", 1, 0)
d$ShareAgric1939<-d$LudnoscRoln/d$LudnoscOgolem
d$masspartPct<-100*(d$MszaMK/d$L_wiernych)
summary(d$masspartPct)

reg0<-lm(masspartPct ~ PctUSSR1+town, data=d)
summary(reg0)

reg1<-lm(masspartPct ~ PctUSSR1+ town + ShareAgric1939 + ShareOver100  +distrail48 +log(TotPop48), data=d)
summary(reg1) 

d$TurnoutPres<-100*(d$ValVotesR1/d$NoVotersR1)
reg2<-lm(TurnoutPres ~ PctUSSR1+town, data=d)
summary(reg2)

reg3<-lm(TurnoutPres ~ PctUSSR1 + town + distrail48 + ShareAgric1939 + ShareOver100 + distrail48 +log(TotPop48), data=d)
summary(reg3) 

d$ShareDuda<-100*(d$DudaPiSR1/d$ValVotesR1)
reg4a<-lm(ShareDuda ~ PctUSSR1 + town + distrail48 + ShareAgric1939 + ShareOver100 + distrail48 +log(TotPop48), data=d)
summary(reg4a) 

d$ShareKom<-100*(d$KomorowskiPOR1/d$ValVotesR1)

reg4b<-lm(ShareKom ~ PctUSSR1 + town + distrail48 + ShareAgric1939 + ShareOver100 +log(TotPop48), data=d)
summary(reg4b) 

#Reproduce Table A4 in the paper
stargazer(reg0, reg1, reg2, reg3, reg4a, reg4b, digits=2, title="Religiosity and voting in the 2015 parliamentary election at the municipal level", star.cutoffs = c(0.05, 0.01, 0.001), omit = c("Constant") , omit.stat = c("rsq", "f", "ser"), dep.var.labels=c("Mass attendance", "Turnout", "Law and Justice", "Civic Platform"), covariate.labels = c("Share from USSR", "Town", "Share in Agriculture (1939)", "Large Farms (1939)", "Distance to Railway (1948)", "ln(Population in 1948)"))
