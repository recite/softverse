### Load required packages and data

library(foreign)
library(plyr)
library(survey)
library(ggplot2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

EB2019 <- read.dta("ZA7576_v1-0-0.dta")

## Define country labels

EB2019$country[EB2019$country == "DE-E Germany East"] <- "DE-E - Germany East"
EB2019$country[EB2019$country == "AT - Austria"] <- "AU - Austria"
EB2019$countrycode <- factor(gsub(" -.*","",EB2019$country))
EB2019$countrycode2 <- droplevels(EB2019$countrycode)

## Issue importance

EB2019$immsalience2.nat <- ifelse(EB2019$qa3a_9 == "Immigration", 1, 0) #%15
EB2019$immsalience2.per <- ifelse(EB2019$qa4a_9 == "Immigration", 1, 0) #%5

## Preference

EB2019$imm1 <- as.numeric.factor(mapvalues(EB2019$qb3_1, from = c("Very positive", "Fairly positive", "Fairly negative", "Very negative", "dk", "Inap. (not 1 in eu28)"), 
                                                         to = c(0, 0.33, 0.66, 1, 0.5, NA)))
EB2019$imm2 <- as.numeric.factor(mapvalues(EB2019$qb3_2, from = c("Very positive", "Fairly positive", "Fairly negative", "Very negative", "dk", "Inap. (not 1 in eu28)"), 
                                                         to = c(0, 0.33, 0.66, 1, 0.5, NA)))
EB2019$imm3 <- as.numeric.factor(mapvalues(EB2019$qd9_1, from = c("Totally agree", "Tend to agree", "Tend to disagree", "Totally disagree", "dk", "Inap. (not 1 in eu28)"), 
                                                         to = c(0, 0.33, 0.66, 1, 0.5, NA)))

EB2019$immind <- rowMeans(EB2019[c("imm1", "imm2", "imm3")], na.rm=TRUE)
EB2019$immind2 <- ifelse(EB2019$immind >= 0.66, "anti-immigration", ifelse(EB2019$immind <= 0.33, "pro-immigration", NA)) 

## Exclude countries with few observations

EB2019immsalience2countrymean <- as.data.frame(tapply(EB2019$immsalience2.per, EB2019$countrycode, mean, na.rm = T))
EB2019countryN <- as.data.frame(tapply(EB2019$immsalience2.per, EB2019$countrycode, function(x) {length(x[!is.na(x)])}))
EB2019immsalience2countryN <- EB2019immsalience2countrymean*EB2019countryN

EB2019immsalience2countryN$COUNTRYLAB <- rownames(EB2019immsalience2countryN)
colnames(EB2019immsalience2countryN) <- c("EB2019immsalience2countryN", "countrycode")

EB2019 <- merge(EB2019, EB2019immsalience2countryN, by = "countrycode")
EB2019 <- EB2019[(EB2019$EB2019immsalience2countryN >= 40 | EB2019$countrycode == "GB-UKM") & EB2019$countrycode != "MT",]

EB2019s <- svydesign(ids = ~1, strata = NULL, 
                     data = EB2019[!is.na(EB2019$w1),], weights = EB2019[!is.na(EB2019$w1),]$w1)

EB2019sEU <- svydesign(ids = ~1, strata = NULL, 
                       data = EB2019[!is.na(EB2019$w22),], weights = EB2019[!is.na(EB2019$w22),]$w22)

### Plots

# National (Figure 4A)

immsalience2.nat.by.immind2.country.EB2019 <- svyby(~immsalience2.nat, by=~immind2+countrycode, design=EB2019s, FUN = svymean, vartype = "ci", na.rm=TRUE)
colnames(immsalience2.nat.by.immind2.country.EB2019) <- c("immind2","sample", "immsalience2", "CIl", "CIu")
immsalience2.nat.by.immind2.total.EB2019 <- svyby(~immsalience2.nat, by=~immind2, design=EB2019sEU, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.nat.by.immind2.total.EB2019 <- cbind("Average", immsalience2.nat.by.immind2.total.EB2019)
colnames(immsalience2.nat.by.immind2.total.EB2019) <- c("sample", "immind2", "immsalience2", "CIl", "CIu")
immsalience2.nat.by.immind2.total.EB2019 <- immsalience2.nat.by.immind2.total.EB2019[c("immind2","sample", "immsalience2", "CIl", "CIu")]
immsalience2.nat.by.immind2.country.EB2019 <- rbind(immsalience2.nat.by.immind2.total.EB2019, immsalience2.nat.by.immind2.country.EB2019)
immsalience2.nat.by.immind2.country.EB2019$sample[immsalience2.nat.by.immind2.country.EB2019$sample == "DE-W"] <- "DE"
immsalience2.nat.by.immind2.country.EB2019$sample[immsalience2.nat.by.immind2.country.EB2019$sample == "GB-UKM"] <- "UK"

ggplot(data = immsalience2.nat.by.immind2.country.EB2019, aes(x = sample, y = immsalience2, group = immind2, fill = immind2, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(0,0.7) +
  xlab("") + ylab("Issue Importance (National)") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Pro-immigration"))

# Personal (Figure 4B)

immsalience2.per.by.immind2.country.EB2019 <- svyby(~immsalience2.per, by=~immind2+countrycode, design=EB2019s, FUN = svymean, vartype = "ci", na.rm=TRUE)
colnames(immsalience2.per.by.immind2.country.EB2019) <- c("immind2","sample", "immsalience2", "CIl", "CIu")
immsalience2.per.by.immind2.total.EB2019 <-svyby(~immsalience2.per, by=~immind2, design=EB2019sEU, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.per.by.immind2.total.EB2019 <- cbind("Average", immsalience2.per.by.immind2.total.EB2019)
colnames(immsalience2.per.by.immind2.total.EB2019) <- c("sample", "immind2", "immsalience2", "CIl", "CIu")
immsalience2.per.by.immind2.total.EB2019 <- immsalience2.per.by.immind2.total.EB2019[c("immind2","sample", "immsalience2", "CIl", "CIu")]
immsalience2.per.by.immind2.country.EB2019 <- rbind(immsalience2.per.by.immind2.total.EB2019, immsalience2.per.by.immind2.country.EB2019)
immsalience2.per.by.immind2.country.EB2019$sample[immsalience2.per.by.immind2.country.EB2019$sample == "DE-W"] <- "DE"
immsalience2.per.by.immind2.country.EB2019$sample[immsalience2.per.by.immind2.country.EB2019$sample == "GB-UKM"] <- "UK"

ggplot(data = immsalience2.per.by.immind2.country.EB2019, aes(x = sample, y = immsalience2, group = immind2, fill = immind2, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(-0.03,0.52) +
  xlab("") + ylab("Issue Importance (Personal)") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="none") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Pro-immigration"))
