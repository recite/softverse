### Load required packages

library(haven)
library(plyr)
library(survey)
library(ggplot2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

### ANES2020 (weights: V200010b)

ANES2020 <- read_dta("ANES2020/anes_timeseries_2020_stata_20210719.dta")

## Issue importance (#V202205y1-y16, V202207y1-y13, V202209y1-y9, and V202211y1-y9; #41. Immigration)

ANES2020$M1I1 <- ifelse(ANES2020$V202205y1 == 41, 1, 0)
ANES2020$M1I2 <- ifelse(ANES2020$V202205y2 == 41, 1, 0)
ANES2020$M1I3 <- ifelse(ANES2020$V202205y3 == 41, 1, 0)
ANES2020$M1I4 <- ifelse(ANES2020$V202205y4 == 41, 1, 0)
ANES2020$M1I5 <- ifelse(ANES2020$V202205y5 == 41, 1, 0)
ANES2020$M1I6 <- ifelse(ANES2020$V202205y6 == 41, 1, 0)
ANES2020$M1I7 <- ifelse(ANES2020$V202205y7 == 41, 1, 0)
ANES2020$M1I8 <- ifelse(ANES2020$V202205y8 == 41, 1, 0)
ANES2020$M1I9 <- ifelse(ANES2020$V202205y9 == 41, 1, 0)
ANES2020$M1I10 <- ifelse(ANES2020$V202205y10 == 41, 1, 0)
ANES2020$M1I11 <- ifelse(ANES2020$V202205y11 == 41, 1, 0)
ANES2020$M1I12 <- ifelse(ANES2020$V202205y12 == 41, 1, 0)
ANES2020$M1I13 <- ifelse(ANES2020$V202205y13 == 41, 1, 0)
ANES2020$M1I14 <- ifelse(ANES2020$V202205y14 == 41, 1, 0)
ANES2020$M1I15 <- ifelse(ANES2020$V202205y15 == 41, 1, 0)
ANES2020$M1I16 <- ifelse(ANES2020$V202205y16 == 41, 1, 0)

ANES2020$M2I1 <- ifelse(ANES2020$V202207y1 == 41, 1, 0)
ANES2020$M2I2 <- ifelse(ANES2020$V202207y2 == 41, 1, 0)
ANES2020$M2I3 <- ifelse(ANES2020$V202207y3 == 41, 1, 0)
ANES2020$M2I4 <- ifelse(ANES2020$V202207y4 == 41, 1, 0)
ANES2020$M2I5 <- ifelse(ANES2020$V202207y5 == 41, 1, 0)
ANES2020$M2I6 <- ifelse(ANES2020$V202207y6 == 41, 1, 0)
ANES2020$M2I7 <- ifelse(ANES2020$V202207y7 == 41, 1, 0)
ANES2020$M2I8 <- ifelse(ANES2020$V202207y8 == 41, 1, 0)
ANES2020$M2I9 <- ifelse(ANES2020$V202207y9 == 41, 1, 0)
ANES2020$M2I10 <- ifelse(ANES2020$V202207y10 == 41, 1, 0)
ANES2020$M2I11 <- ifelse(ANES2020$V202207y11 == 41, 1, 0)
ANES2020$M2I12 <- ifelse(ANES2020$V202207y12 == 41, 1, 0)
ANES2020$M2I13 <- ifelse(ANES2020$V202207y13 == 41, 1, 0)

ANES2020$M3I1 <- ifelse(ANES2020$V202211y1 == 41, 1, 0)
ANES2020$M3I2 <- ifelse(ANES2020$V202211y2 == 41, 1, 0)
ANES2020$M3I3 <- ifelse(ANES2020$V202211y3 == 41, 1, 0)
ANES2020$M3I4 <- ifelse(ANES2020$V202211y4 == 41, 1, 0)
ANES2020$M3I5 <- ifelse(ANES2020$V202211y5 == 41, 1, 0)
ANES2020$M3I6 <- ifelse(ANES2020$V202211y6 == 41, 1, 0)
ANES2020$M3I7 <- ifelse(ANES2020$V202211y7 == 41, 1, 0)
ANES2020$M3I8 <- ifelse(ANES2020$V202211y8 == 41, 1, 0)
ANES2020$M3I9 <- ifelse(ANES2020$V202211y9 == 41, 1, 0)

ANES2020$M4I1 <- ifelse(ANES2020$V202209y1 == 41, 1, 0)
ANES2020$M4I2 <- ifelse(ANES2020$V202209y2 == 41, 1, 0)
ANES2020$M4I3 <- ifelse(ANES2020$V202209y3 == 41, 1, 0)
ANES2020$M4I4 <- ifelse(ANES2020$V202209y4 == 41, 1, 0)
ANES2020$M4I5 <- ifelse(ANES2020$V202209y5 == 41, 1, 0)
ANES2020$M4I6 <- ifelse(ANES2020$V202209y6 == 41, 1, 0)
ANES2020$M4I7 <- ifelse(ANES2020$V202209y7 == 41, 1, 0)
ANES2020$M4I8 <- ifelse(ANES2020$V202209y8 == 41, 1, 0)
ANES2020$M4I9 <- ifelse(ANES2020$V202209y9 == 41, 1, 0)

# Combine all mentions of immigration as important

ANES2020$M1imm <- rowSums(ANES2020[c("M1I1", "M1I2", "M1I3", "M1I4", "M1I5", "M1I6", "M1I7", "M1I8", "M1I9", "M1I10", "M1I11", "M1I12", "M1I13", "M1I14", "M1I15", "M1I16")], na.rm=TRUE)
ANES2020$M1imm[ANES2020$V202205y1 < 0] <- NA
ANES2020$M2imm <- rowSums(ANES2020[c("M2I1", "M2I2", "M2I3", "M2I4", "M2I5", "M2I6", "M2I7", "M2I8", "M2I9", "M2I10", "M2I11", "M2I12", "M2I13")], na.rm=TRUE)
ANES2020$M3imm <- rowSums(ANES2020[c("M3I1", "M3I2", "M3I3", "M3I4", "M3I5", "M3I6", "M3I7", "M3I8", "M3I9")], na.rm=TRUE)
ANES2020$M4imm <- rowSums(ANES2020[c("M4I1", "M4I2", "M4I3", "M4I4", "M4I5", "M4I6", "M4I7", "M4I8", "M4I9")], na.rm=TRUE)
ANES2020$Mimm <- rowSums(ANES2020[c("M1imm", "M2imm", "M3imm", "M4imm")], na.rm=TRUE)
ANES2020$Mimm[ANES2020$V202205y1 < 0] <- NA
ANES2020$Mimm[ANES2020$Mimm > 1] <- 1

## Political interest

ANES2020$polint <- mapvalues(ANES2020$V201005, from = c(-9, 1:5), 
                             to = c(NA, 1, 0.75, 0.5, 0.25, 0))

## Preference

ANES2020$immlvl <- mapvalues(ANES2020$V202232, from = c(-9,-8,-7,-6,-5, 1:5), 
                                               to = c(NA,NA,NA,NA,NA,0, 0.25, 0.5, 0.75, 1))
ANES2020$immlvl2w <- ifelse(ANES2020$immlvl > 0.5, "anti-immigration", ifelse(ANES2020$immlvl < 0.5, "pro-immigration", NA)) 

###ANES2016

ANES2016 <- read_dta("ANES2016/anes_timeseries_2016_Stata13.dta")

## Issue importance (V162116a_1-10, V162118a_1-9, V162120a_1-6, V162122a_1-5; #41. Immigration)

ANES2016$M1I1 <- ifelse(ANES2016$V162116a_1 == 41, 1, 0)
ANES2016$M1I2 <- ifelse(ANES2016$V162116a_2 == 41, 1, 0)
ANES2016$M1I3 <- ifelse(ANES2016$V162116a_3 == 41, 1, 0)
ANES2016$M1I4 <- ifelse(ANES2016$V162116a_4 == 41, 1, 0)
ANES2016$M1I5 <- ifelse(ANES2016$V162116a_5 == 41, 1, 0)
ANES2016$M1I6 <- ifelse(ANES2016$V162116a_6 == 41, 1, 0)
ANES2016$M1I7 <- ifelse(ANES2016$V162116a_7 == 41, 1, 0)
ANES2016$M1I8 <- ifelse(ANES2016$V162116a_8 == 41, 1, 0)
ANES2016$M1I9 <- ifelse(ANES2016$V162116a_9 == 41, 1, 0)
ANES2016$M1I10 <- ifelse(ANES2016$V162116a_10 == 41, 1, 0)

ANES2016$M2I1 <- ifelse(ANES2016$V162118a_1 == 41, 1, 0)
ANES2016$M2I2 <- ifelse(ANES2016$V162118a_2 == 41, 1, 0)
ANES2016$M2I3 <- ifelse(ANES2016$V162118a_3 == 41, 1, 0)
ANES2016$M2I4 <- ifelse(ANES2016$V162118a_4 == 41, 1, 0)
ANES2016$M2I5 <- ifelse(ANES2016$V162118a_5 == 41, 1, 0)
ANES2016$M2I6 <- ifelse(ANES2016$V162118a_6 == 41, 1, 0)
ANES2016$M2I7 <- ifelse(ANES2016$V162118a_7 == 41, 1, 0)
ANES2016$M2I8 <- ifelse(ANES2016$V162118a_8 == 41, 1, 0)
ANES2016$M2I9 <- ifelse(ANES2016$V162118a_9 == 41, 1, 0)

ANES2016$M3I1 <- ifelse(ANES2016$V162120a_1 == 41, 1, 0)
ANES2016$M3I2 <- ifelse(ANES2016$V162120a_2 == 41, 1, 0)
ANES2016$M3I3 <- ifelse(ANES2016$V162120a_3 == 41, 1, 0)
ANES2016$M3I4 <- ifelse(ANES2016$V162120a_4 == 41, 1, 0)
ANES2016$M3I5 <- ifelse(ANES2016$V162120a_5 == 41, 1, 0)
ANES2016$M3I6 <- ifelse(ANES2016$V162120a_6 == 41, 1, 0)

ANES2016$M4I1 <- ifelse(ANES2016$V162122a_1 == 41, 1, 0)
ANES2016$M4I2 <- ifelse(ANES2016$V162122a_2 == 41, 1, 0)
ANES2016$M4I3 <- ifelse(ANES2016$V162122a_3 == 41, 1, 0)
ANES2016$M4I4 <- ifelse(ANES2016$V162122a_4 == 41, 1, 0)
ANES2016$M4I5 <- ifelse(ANES2016$V162122a_5 == 41, 1, 0)

ANES2016$M1imm <- rowSums(ANES2016[c("M1I1", "M1I2", "M1I3", "M1I4", "M1I5", "M1I6", "M1I7", "M1I8", "M1I9", "M1I10")], na.rm=TRUE)
ANES2016$M1imm[ANES2016$V162116a_1 < 0] <- NA
ANES2016$M2imm <- rowSums(ANES2016[c("M2I1", "M2I2", "M2I3", "M2I4", "M2I5", "M2I6", "M2I7", "M2I8", "M2I9")], na.rm=TRUE)
ANES2016$M3imm <- rowSums(ANES2016[c("M3I1", "M3I2", "M3I3", "M3I4", "M3I5", "M3I6")], na.rm=TRUE)
ANES2016$M4imm <- rowSums(ANES2016[c("M4I1", "M4I2", "M4I3", "M4I4", "M4I5")], na.rm=TRUE)
ANES2016$Mimm <- rowSums(ANES2016[c("M1imm", "M2imm", "M3imm", "M4imm")], na.rm=TRUE)
ANES2016$Mimm[ANES2016$V162116a_1 < 0] <- NA
ANES2016$Mimm[ANES2016$Mimm > 1] <- 1

## Preference

ANES2016$immlvl <- mapvalues(ANES2016$V162157, from = c(-9,-8,-7,-6, 1:5), 
                             to = c(NA,NA,NA,NA,0, 0.25, 0.5, 0.75, 1))
ANES2016$immlvl2w <- ifelse(ANES2016$immlvl > 0.5, "anti-immigration", ifelse(ANES2016$immlvl < 0.5, "pro-immigration", NA)) 

### ANES2012

ANES2012 <- read_dta("ANES2012/anes_timeseries_2012.dta")

## Issue importance

ANES2012$M1imm <- mapvalues(ANES2012$paprofile_mip, from = c(-9,-8,-6,-1, 1:15), 
                             to = c(NA,NA,NA,NA,1:15))
ANES2012$M1imm <- ifelse(ANES2012$M1imm == 11, 1, 0)

## Preference

ANES2012$immlvl <- mapvalues(ANES2012$immigpo_level, from = c(-9,-8,-7,-6, 1:5), 
                             to = c(NA,NA,NA,NA,0, 0.25, 0.5, 0.75, 1))
ANES2012$immlvl2w <- ifelse(ANES2012$immlvl > 0.5, "anti-immigration", ifelse(ANES2012$immlvl < 0.5, "pro-immigration", NA)) 

### ANES2008

ANES2008 <- as.data.frame(read_dta("ANES2008/anes_timeseries_2008_stata12.dta"))
ANES2008$ID <- ANES2008$V080001
ANES2008mip <- read_sav("ANES2008/anes_timeseries_2008_mip.sav")
ANES2008 <- merge(ANES2008, ANES2008mip, by = "ID")

## Issue Importance

#Most Important Political Problem: MIPPOL1_Code1 to MIPPOL1_Code8;MIPPOL1_Substantive1 to MIPPOL1_Substantive8
#Second Most Important Political Problem: MIPPOL2_Code1 to MIPPOL2_Code8; MIPPOL2_Substantive1 to MIPPOL2_Substantive8

ANES2008$M1I1 <- ifelse(ANES2008$MIPPOL1_Code1 == 41, 1, ifelse(ANES2008$MIPPOL1_Code1 == 99, NA, 0))
ANES2008$M1I2 <- ifelse(ANES2008$MIPPOL1_Code2 == 41, 1, ifelse(ANES2008$MIPPOL1_Code2 == 99, NA, 0))
ANES2008$M1I3 <- ifelse(ANES2008$MIPPOL1_Code3 == 41, 1, ifelse(ANES2008$MIPPOL1_Code3 == 99, NA, 0))
ANES2008$M1I4 <- ifelse(ANES2008$MIPPOL1_Code4 == 41, 1, ifelse(ANES2008$MIPPOL1_Code4 == 99, NA, 0))
ANES2008$M1I5 <- ifelse(ANES2008$MIPPOL1_Code5 == 41, 1, ifelse(ANES2008$MIPPOL1_Code5 == 99, NA, 0))
ANES2008$M1I6 <- ifelse(ANES2008$MIPPOL1_Code6 == 41, 1, ifelse(ANES2008$MIPPOL1_Code6 == 99, NA, 0))
ANES2008$M1I7 <- ifelse(ANES2008$MIPPOL1_Code7 == 41, 1, ifelse(ANES2008$MIPPOL1_Code7 == 99, NA, 0))
ANES2008$M1I8 <- ifelse(ANES2008$MIPPOL1_Code8 == 41, 1, ifelse(ANES2008$MIPPOL1_Code8 == 99, NA, 0))
ANES2008$M1imm <- rowSums(ANES2008[c("M1I1", "M1I2", "M1I3", "M1I4", "M1I5", "M1I6", "M1I7", "M1I8")], na.rm=TRUE)

ANES2008$M2I1 <- ifelse(ANES2008$MIPPOL2_Code1 == 41, 1, ifelse(ANES2008$MIPPOL2_Code1 == 99, NA, 0))
ANES2008$M2I2 <- ifelse(ANES2008$MIPPOL2_Code2 == 41, 1, ifelse(ANES2008$MIPPOL2_Code2 == 99, NA, 0))
ANES2008$M2I3 <- ifelse(ANES2008$MIPPOL2_Code3 == 41, 1, ifelse(ANES2008$MIPPOL2_Code3 == 99, NA, 0))
ANES2008$M2I4 <- ifelse(ANES2008$MIPPOL2_Code4 == 41, 1, ifelse(ANES2008$MIPPOL2_Code4 == 99, NA, 0))
ANES2008$M2I5 <- ifelse(ANES2008$MIPPOL2_Code5 == 41, 1, ifelse(ANES2008$MIPPOL2_Code5 == 99, NA, 0))
ANES2008$M2I6 <- ifelse(ANES2008$MIPPOL2_Code6 == 41, 1, ifelse(ANES2008$MIPPOL2_Code6 == 99, NA, 0))
ANES2008$M2I7 <- ifelse(ANES2008$MIPPOL2_Code7 == 41, 1, ifelse(ANES2008$MIPPOL2_Code7 == 99, NA, 0))
ANES2008$M2I8 <- ifelse(ANES2008$MIPPOL2_Code8 == 41, 1, ifelse(ANES2008$MIPPOL2_Code8 == 99, NA, 0))
ANES2008$M2imm <- rowSums(ANES2008[c("M2I1", "M2I2", "M2I3", "M2I4", "M2I5", "M2I6", "M2I7", "M2I8")], na.rm=TRUE)

ANES2008$Mimm <- rowSums(ANES2008[c("M1imm", "M2imm")], na.rm=TRUE)
ANES2008$Mimm[ANES2008$Mimm > 1] <- 1

## Preference

ANES2008$immlvl <- mapvalues(ANES2008$V085082, from = c(-9,-8,-2, 1:5), 
                             to = c(NA,NA,NA,0, 0.25, 0.5, 0.75, 1))
ANES2008$immlvl2w <- ifelse(ANES2008$immlvl > 0.5, "anti-immigration", ifelse(ANES2008$immlvl < 0.5, "pro-immigration", NA)) 

### PLOTS

ANES2020s <- svydesign(ids = ~1, strata = NULL, data = ANES2020[!is.na(ANES2020$V200010b),], weights = ANES2020$V200010b[!is.na(ANES2020$V200010b)])
ANES2016s <- svydesign(ids = ~1, strata = NULL, data = ANES2016[!is.na(ANES2016$V160102),], weights = ANES2016$V160102[!is.na(ANES2016$V160102)])
ANES2012s <- svydesign(ids = ~1, strata = NULL, data = ANES2012[!is.na(ANES2012$weight_web),], weights = ANES2012$weight_web[!is.na(ANES2012$weight_web)])
ANES2008s <- svydesign(ids = ~1, strata = NULL, data = ANES2008[!is.na(ANES2008$V080102a),], weights = ANES2008$V080102a[!is.na(ANES2008$V080102a)])

Mimm.by.immlvl2.2008 <- svyby(~Mimm, by=~immlvl2w, design=ANES2008s, FUN = svymean, vartype = "ci", na.rm=TRUE)
Mimm.by.immlvl2.2008 <- cbind("2008", Mimm.by.immlvl2.2008)
colnames(Mimm.by.immlvl2.2008) <- c("year", "immlvl2", "Mimm", "CIl", "CIu")
Mimm.by.immlvl2.2012 <- svyby(~M1imm, by=~immlvl2w, design=ANES2012s, FUN = svymean, vartype = "ci", na.rm=TRUE)
Mimm.by.immlvl2.2012 <- cbind("2012", Mimm.by.immlvl2.2012)
colnames(Mimm.by.immlvl2.2012) <- c("year", "immlvl2", "Mimm", "CIl", "CIu")
Mimm.by.immlvl2.2016 <- svyby(~Mimm, by=~immlvl2w, design=ANES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
Mimm.by.immlvl2.2016 <- cbind("2016", Mimm.by.immlvl2.2016)
colnames(Mimm.by.immlvl2.2016) <- c("year", "immlvl2", "Mimm", "CIl", "CIu")
Mimm.by.immlvl2.2020 <- svyby(~Mimm, by=~immlvl2w, design=ANES2020s, FUN = svymean, vartype = "ci", na.rm=TRUE)
Mimm.by.immlvl2.2020 <- cbind("2020", Mimm.by.immlvl2.2020)
colnames(Mimm.by.immlvl2.2020) <- c("year", "immlvl2", "Mimm", "CIl", "CIu")
Mimm.by.immlvl2 <- rbind(Mimm.by.immlvl2.2008, Mimm.by.immlvl2.2012, Mimm.by.immlvl2.2016, Mimm.by.immlvl2.2020)

### Figure 1: Salience by Preference

ggplot(data = Mimm.by.immlvl2, aes(x = year, y = Mimm, group = immlvl2, fill = immlvl2, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(-0.05,0.35) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference ", labels = c("Anti-immigration", "Pro-immigration"))
