### Load required packages and data

library(foreign)
library(plyr)
library(survey)
library(ggplot2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

CCES2016 <- read.dta("CCES16_Common_OUTPUT_Feb2018_VV.dta")

## Salience
CCES2016$immsalience <- as.numeric.factor(mapvalues(CCES2016$CC16_301d, 
                                         from = c("Very High Importance", "Somewhat High Importance", "Somewhat Low Importance", "Very Low Importance", "No Importance at All"), 
                                         to = c(1, 0.75, 0.5, 0.25, 0)))
CCES2016$immsalience2 <- ifelse(CCES2016$CC16_301d == "Very High Importance" | CCES2016$CC16_301d == "Somewhat High Importance", 1, 0)

## Preference

CCES2016$imm1 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_1, from = c("No", "Yes"), to = c(1, 0)))
CCES2016$imm2 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_2, from = c("No", "Yes"), to = c(0, 1)))
CCES2016$imm3 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_3, from = c("No", "Yes"), to = c(1, 0)))
CCES2016$imm4 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_4, from = c("No", "Yes"), to = c(0, 1)))
CCES2016$imm5 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_5, from = c("No", "Yes"), to = c(0, 1)))
CCES2016$imm6 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_6, from = c("No", "Yes"), to = c(1, 0)))
CCES2016$imm7 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_7, from = c("No", "Yes"), to = c(0, 1)))
CCES2016$imm8 <- as.numeric.factor(mapvalues(CCES2016$CC16_331_8, from = c("No", "Yes"), to = c(0, 1)))
CCES2016$immind <- (CCES2016$imm1 + CCES2016$imm2 + CCES2016$imm3 + CCES2016$imm4 + CCES2016$imm5 + CCES2016$imm6 + CCES2016$imm7 + CCES2016$imm8)/8
CCES2016$immind3 <- ifelse(CCES2016$immind >= 0.75, "anti-immigration", ifelse(CCES2016$immind <= 0.25, "pro-immigration", "neutral")) 

### Abortion as a comparison
## Salience
CCES2016$abosalience <- as.numeric.factor(mapvalues(CCES2016$CC16_301b, 
                                                from = c("Very High Importance", "Somewhat High Importance", "Somewhat Low Importance", "Very Low Importance", "No Importance at All"), 
                                                to = c(1, 0.75, 0.5, 0.25, 0)))
CCES2016$abosalience2 <- ifelse(CCES2016$CC16_301b == "Very High Importance" | CCES2016$CC16_301b == "Somewhat High Importance", 1, 0)
## Preference
CCES2016$abo1 <- as.numeric.factor(mapvalues(CCES2016$CC16_332a, from = c("Oppose", "Support"), to = c(1, 0)))
CCES2016$abo2 <- as.numeric.factor(mapvalues(CCES2016$CC16_332b, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$abo3 <- as.numeric.factor(mapvalues(CCES2016$CC16_332c, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$abo4 <- as.numeric.factor(mapvalues(CCES2016$CC16_332d, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$abo5 <- as.numeric.factor(mapvalues(CCES2016$CC16_332e, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$abo6 <- as.numeric.factor(mapvalues(CCES2016$CC16_332f, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$aboind <- (CCES2016$abo1 + CCES2016$abo2 + CCES2016$abo3 + CCES2016$abo4 + CCES2016$abo5 + CCES2016$abo6)/6
CCES2016$aboind3 <- ifelse(CCES2016$aboind >= 0.75, "pro-life", ifelse(CCES2016$aboind <= 0.25, "pro-choice", "neutral")) 

### Gun control as a comparison
## Salience
CCES2016$gunsalience <- as.numeric.factor(mapvalues(CCES2016$CC16_301a, 
                                                from = c("Very High Importance", "Somewhat High Importance", "Somewhat Low Importance", "Very Low Importance", "No Importance at All"), 
                                                to = c(1, 0.75, 0.5, 0.25, 0)))
CCES2016$gunsalience2 <- ifelse(CCES2016$CC16_301a == "Very High Importance" | CCES2016$CC16_301a == "Somewhat High Importance", 1, 0)
##Preference
CCES2016$gun1 <- as.numeric.factor(mapvalues(CCES2016$CC16_330a, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$gun2 <- as.numeric.factor(mapvalues(CCES2016$CC16_330b, from = c("Oppose", "Support"), to = c(1, 0)))
CCES2016$gun3 <- as.numeric.factor(mapvalues(CCES2016$CC16_330d, from = c("Oppose", "Support"), to = c(0, 1)))
CCES2016$gun4 <- as.numeric.factor(mapvalues(CCES2016$CC16_330e, from = c("Oppose", "Support"), to = c(1, 0)))
CCES2016$gunind <- (CCES2016$gun1 + CCES2016$gun2 + CCES2016$gun3 + CCES2016$gun4)/4
CCES2016$gunind3 <- ifelse(CCES2016$gunind >= 0.75, "pro-gun-control", ifelse(CCES2016$gunind <= 0.25, "anti-gun-control", "neutral")) 

### Gay marriage as a comparison
## Salience
CCES2016$gaysalience <- as.numeric.factor(mapvalues(CCES2016$CC16_301n, 
                                                from = c("Very High Importance", "Somewhat High Importance", "Somewhat Low Importance", "Very Low Importance", "No Importance at All"), 
                                                to = c(1, 0.75, 0.5, 0.25, 0)))
CCES2016$gaysalience2 <- ifelse(CCES2016$CC16_301n == "Very High Importance" | CCES2016$CC16_301f == "Somewhat High Importance", 1, 0)
## Preference
CCES2016$gay1 <- as.numeric.factor(mapvalues(CCES2016$CC16_335, from = c("Oppose", "Favor"), to = c(1, 0)))

### Political interest

CCES2016$polint <- as.numeric.factor(mapvalues(CCES2016$newsint, 
                                               from = c("Most of the time", "Some of the time", "Only now and then", "Hardly at all", "Don't know", "Skipped", "Not Asked"), 
                                               to = c(1, 0.66, 0.33, 0, NA, NA, NA)))
CCES2016$polint2 <- ifelse(CCES2016$newsint == "Most of the time", 1, 0)

### Combine in Plots (Figure A2)

CCES2016s <- svydesign(ids = ~1, strata = NULL, data = CCES2016, weights = CCES2016$commonweight_vv)

immsalience2.by.immatt3.CCES2016 <- svyby(~immsalience2, by=~immind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3.CCES2016 <- cbind("Immigration", immsalience2.by.immatt3.CCES2016)
colnames(immsalience2.by.immatt3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
abosalience2.by.aboind3.CCES2016 <- svyby(~abosalience2, by=~aboind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
abosalience2.by.aboind3.CCES2016 <- cbind("Abortion", abosalience2.by.aboind3.CCES2016)
colnames(abosalience2.by.aboind3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
gunsalience2.by.gunind3.CCES2016 <- svyby(~gunsalience2, by=~gunind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
gunsalience2.by.gunind3.CCES2016 <- cbind("Gun Control", gunsalience2.by.gunind3.CCES2016)
colnames(gunsalience2.by.gunind3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
gaysalience2.by.gay1.CCES2016 <- svyby(~gaysalience2, by=~gay1, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
gaysalience2.by.gay1.CCES2016 <- cbind("Gay Marriage", gaysalience2.by.gay1.CCES2016)
colnames(gaysalience2.by.gay1.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")

salience2.by.ind3.CCES2016 <- rbind(immsalience2.by.immatt3.CCES2016, abosalience2.by.aboind3.CCES2016, gunsalience2.by.gunind3.CCES2016, gaysalience2.by.gay1.CCES2016)
salience2.by.ind3.CCES2016$ind3 <- c("Oppose", "Neutral", "Support", 
                                     "Neutral", "Support", "Oppose", 
                                     "Oppose", "Neutral", "Support",
                                     "Support", "Oppose")
salience2.by.ind3.CCES2016$ind3 <- factor(salience2.by.ind3.CCES2016$ind3, levels = c("Oppose", "Neutral", "Support"))
salience2.by.ind3.CCES2016$Issue <- factor(salience2.by.ind3.CCES2016$Issue, levels = c("Immigration", "Abortion", "Gun Control", "Gay Marriage"))

ggplot(data = salience2.by.ind3.CCES2016, aes(x = Issue, y = salience2, group = ind3, fill = ind3, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(0,1) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") +
  scale_fill_grey(name = "Issue Preference ", labels = c("Oppose", "Neutral", "Support"))

# Political interest plot (Figure A3)

polint2.by.immatt3.CCES2016 <- svyby(~polint2, by=~immind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
polint2.by.immatt3.CCES2016 <- cbind("Immigration", polint2.by.immatt3.CCES2016)
colnames(polint2.by.immatt3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
abosalience2.by.aboind3.CCES2016 <- svyby(~polint2, by=~aboind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
abosalience2.by.aboind3.CCES2016 <- cbind("Abortion", abosalience2.by.aboind3.CCES2016)
colnames(abosalience2.by.aboind3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
gunsalience2.by.gunind3.CCES2016 <- svyby(~polint2, by=~gunind3, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
gunsalience2.by.gunind3.CCES2016 <- cbind("Gun Control", gunsalience2.by.gunind3.CCES2016)
colnames(gunsalience2.by.gunind3.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")
gaysalience2.by.gay1.CCES2016 <- svyby(~polint2, by=~gay1, design=CCES2016s, FUN = svymean, vartype = "ci", na.rm=TRUE)
gaysalience2.by.gay1.CCES2016 <- cbind("Gay Marriage", gaysalience2.by.gay1.CCES2016)
colnames(gaysalience2.by.gay1.CCES2016) <- c("Issue", "ind3", "salience2", "CIl", "CIu")

salience2.by.ind3.CCES2016 <- rbind(polint2.by.immatt3.CCES2016, abosalience2.by.aboind3.CCES2016, gunsalience2.by.gunind3.CCES2016, gaysalience2.by.gay1.CCES2016)
salience2.by.ind3.CCES2016$ind3 <- c("Oppose", "Neutral", "Support", 
                                     "Neutral", "Support", "Oppose", 
                                     "Oppose", "Neutral", "Support",
                                     "Support", "Oppose")
salience2.by.ind3.CCES2016$ind3 <- factor(salience2.by.ind3.CCES2016$ind3, levels = c("Oppose", "Neutral", "Support"))
salience2.by.ind3.CCES2016$Issue <- factor(salience2.by.ind3.CCES2016$Issue, levels = c("Immigration", "Abortion", "Gun Control", "Gay Marriage"))

ggplot(data = salience2.by.ind3.CCES2016, aes(x = Issue, y = salience2, group = ind3, fill = ind3, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(0,1) +
  xlab("") + ylab("Political Interest") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") +
  scale_fill_grey(name = "Issue Preference ", labels = c("Oppose", "Neutral", "Support"))