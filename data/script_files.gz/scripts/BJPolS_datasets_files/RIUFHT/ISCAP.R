as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}
library(plyr)
# Load data
load("201410.Rdata")
PENN201410 <- wave8
rm(wave8)
load("201611.Rdata")
PENN201611 <- wave12
rm(wave12)
load("201810.Rdata")
PENN201810 <- wave13
rm(wave13)
load("202010.Rdata")
PENN202010 <- wave15
rm(wave15)

### 2014 Pre-election

##Preference
PENN201410$immpath <- 0
PENN201410$immpath[PENN201410$RAN_RE23 == "SHOW A FIRST"] <- as.numeric.factor(mapvalues(PENN201410$RE23a[PENN201410$RAN_RE23 == "SHOW A FIRST"], 
                                                                                         from = c("Refused", "", "_duplicated_2", "_duplicated_3", "_duplicated_4", 
                                                                                                  "_duplicated_5", "_duplicated_6", "_duplicated_7", "_duplicated_8"), 
                                                                                         to = c(NA, 1, 5/6, 4/6, 3/6, 2/6, 1/6, 0, NA)))
PENN201410$immpath[PENN201410$RAN_RE23 == "SHOW B FIRST"] <- as.numeric.factor(mapvalues(PENN201410$RE23a[PENN201410$RAN_RE23 == "SHOW B FIRST"], 
                                                                                         from = c("Refused", "", "_duplicated_2", "_duplicated_3", "_duplicated_4", 
                                                                                                  "_duplicated_5", "_duplicated_6", "_duplicated_7", "_duplicated_8"), 
                                                                                         to = c(NA, 0, 1/6, 2/6, 3/6, 4/6, 5/6, 1, NA)))
PENN201410$immbord <- as.numeric.factor(mapvalues(PENN201410$POS5_2, from = c("Refused", "Strongly Favor", "Somewhat Favor", "Somewhat Oppose", "Strongly Oppose"), 
                                                  to = c(NA, 1, 0.66, 0.33, 0)))
#cor(PENN201410$immpath, PENN201410$immbord, use = "complete.obs")

PENN201410$immind <- rowMeans(PENN201410[c("immpath", "immbord")], na.rm=TRUE)
PENN201410$immind3w <- ifelse(PENN201410$immind > 0.5, "anti-immigration", ifelse(PENN201410$immind < 0.5, "pro-immigration", NA)) 
PENN201410$immind3s <- ifelse(PENN201410$immind >= 0.75, "anti-immigration", ifelse(PENN201410$immind <= 0.25, "pro-immigration", "neutral")) 

### 2016 Post-election

##Salience

PENN201611$immsalience2 <- ifelse(PENN201611$ME2 == "Immigration", 1, ifelse(is.na(PENN201611$ME2), NA, 0))
PENN201611$racsalience2 <- ifelse(PENN201611$ME2 == "Racism", 1, ifelse(is.na(PENN201611$ME2), NA, 0))
PENN201611$imrsalience2 <- PENN201611$immsalience2 + PENN201611$racsalience2

##Preference (one imperfect item)

PENN201611$immbord <- as.numeric.factor(mapvalues(PENN201611$POS5_b, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                  to = c(NA, 1, 0.66, 0.33, 0)))
PENN201611$immbord2 <- as.numeric.factor(mapvalues(PENN201611$POS5_b, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                  to = c(NA, 1, 1, 0, 0)))

# Immigration salience by preference

tapply(PENN201611$immsalience2, PENN201611$immbord2, mean, na.rm = T)
tapply(PENN201611$imrsalience2, PENN201611$immbord2, mean, na.rm = T)

by(PENN201611, PENN201611$immbord2, with, weighted.mean(immsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage
by(PENN201611, PENN201611$immbord2, with, weighted.mean(imrsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage

### 2018 Pre-election

##Salience

PENN201810$immsalience2 <- ifelse(PENN201810$ME2 == "Immigration", 1, ifelse(is.na(PENN201810$ME2), NA, 0))
PENN201810$racsalience2 <- ifelse(PENN201810$ME2 == "Racism", 1, ifelse(is.na(PENN201810$ME2), NA, 0))
PENN201810$imrsalience2 <- PENN201810$immsalience2 + PENN201810$racsalience2

##Preference

PENN201810$immpath2 <- as.numeric.factor(mapvalues(PENN201810$RE23_A, from = c("Refused", "Return illegal immigrants to their native countries", "", "_duplicated_3", "_duplicated_4", "_duplicated_5",
                                                                               "_duplicated_6", "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
                                                   to = c(NA, 1, NA, NA, NA, NA, NA, 0, NA)))
#Unclear continuous coding due to randomization
#PENN201810$immpath <- 0
#PENN201810$immpath[PENN201810$RAN_RE23 == 1] <- as.numeric.factor(mapvalues(PENN201810$RE23_A[PENN201810$RAN_RE23 == 1], from = c("Refused", "Return illegal immigrants to their native countries", "_duplicated_3", "_duplicated_4", "_duplicated_5",
#                                                                              "_duplicated_6", "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
#                                                  to = c(NA, 1, 4/6, 3/6, 2/6, 1/6, 0, NA)))
#PENN201810$immpath[PENN201810$RAN_RE23 == 2] <- as.numeric.factor(mapvalues(PENN201810$RE23_A[PENN201810$RAN_RE23 == 2], from = c("Refused", "Return illegal immigrants to their native countries", "_duplicated_3", "_duplicated_4", "_duplicated_5",
#                                                                               "_duplicated_6", "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
#                                                   to = c(NA, 1, 2/6, 3/6, 4/6, 5/6, 0, NA)))
PENN201810$immpath <- as.numeric.factor(mapvalues(PENN201810$RE23_A, from = c("Refused", "Return illegal immigrants to their native countries", "", "_duplicated_3", "_duplicated_4", "_duplicated_5",
                                                                              "_duplicated_6", "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
                                                                            to = c(NA, 1, 5/6, 4/6, 3/6, 2/6, 1/6, 0, NA)))

PENN201810$immbord <- as.numeric.factor(mapvalues(PENN201810$POS5_2, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                  to = c(NA, 1, 0.66, 0.33, 0)))
PENN201810$immbord2 <- as.numeric.factor(mapvalues(PENN201810$POS5_2, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                   to = c(NA, 1, 1, 0, 0)))

PENN201810$immind <- rowMeans(PENN201810[c("immpath", "immbord")], na.rm=TRUE)
PENN201810$immind3w <- ifelse(PENN201810$immind > 0.5, "anti-immigration", ifelse(PENN201810$immind < 0.5, "pro-immigration", NA)) 
PENN201810$immind3s <- ifelse(PENN201810$immind >= 0.75, "anti-immigration", ifelse(PENN201810$immind <= 0.25, "pro-immigration", "neutral")) 

# Immigration salience by preference

tapply(PENN201810$immsalience2, PENN201810$immbord2, mean, na.rm = T)
tapply(PENN201810$imrsalience2, PENN201810$immbord2, mean, na.rm = T)

tapply(PENN201810$immsalience2, PENN201810$immind3s, mean, na.rm = T)
tapply(PENN201810$imrsalience2, PENN201810$immind3s, mean, na.rm = T)

by(PENN201810, PENN201810$immind3s, with, weighted.mean(immsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage
by(PENN201810, PENN201810$immind3s, with, weighted.mean(imrsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage

### 2020 Pre-election

##Salience

PENN202010$immsalience2 <- ifelse(PENN202010$ME2 == "Immigration", 1, ifelse(is.na(PENN202010$ME2), NA, 0))
PENN202010$racsalience2 <- ifelse(PENN202010$ME2 == "Racism", 1, ifelse(is.na(PENN202010$ME2), NA, 0))
PENN202010$imrsalience2 <- PENN202010$immsalience2 + PENN202010$racsalience2

##Preference

PENN202010$immpath2 <- as.numeric.factor(mapvalues(PENN202010$RE23_A, from = c("Refused", "Return illegal immigrants to their native countries", "2", "3", "4", "5", "6",
                                                                               "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
                                                   to = c(NA, 1, NA, NA, NA, NA, NA, 0, NA)))
PENN202010$immpath <- as.numeric.factor(mapvalues(PENN202010$RE23_A, from = c("Refused", "Return illegal immigrants to their native countries", "2", "3", "4", "5", "6",
                                                                               "Create a pathway to U.S. citizenship for illegal immigrants", "DON'T KNOW"), 
                                                  to = c(NA, 1, 5/6, 4/6, 3/6, 2/6, 1/6, 0, NA)))
PENN202010$immbord <- as.numeric.factor(mapvalues(PENN202010$POS5_2, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                  to = c(NA, 1, 0.66, 0.33, 0)))
PENN202010$immbord2 <- as.numeric.factor(mapvalues(PENN202010$POS5_2, from = c("Refused", "Strongly favor", "Somewhat favor", "Somewhat oppose", "Strongly oppose"), 
                                                   to = c(NA, 1, 1, 0, 0)))
PENN202010$immind <- rowMeans(PENN202010[c("immpath", "immbord")], na.rm=TRUE)
PENN202010$immind3w <- ifelse(PENN202010$immind > 0.5, "anti-immigration", ifelse(PENN202010$immind < 0.5, "pro-immigration", NA)) 
PENN202010$immind3s <- ifelse(PENN202010$immind >= 0.75, "anti-immigration", ifelse(PENN202010$immind <= 0.25, "pro-immigration", "neutral")) 

# Immigration salience by preference

tapply(PENN202010$immsalience2, PENN202010$immbord2, mean, na.rm = T)
tapply(PENN202010$imrsalience2, PENN202010$immbord2, mean, na.rm = T)

tapply(PENN202010$immsalience2, PENN202010$immind3s, mean, na.rm = T)
tapply(PENN202010$imrsalience2, PENN202010$immind3s, mean, na.rm = T)

by(PENN202010, PENN202010$immind3s, with, weighted.mean(immsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage
by(PENN202010, PENN202010$immind3s, with, weighted.mean(imrsalience2, weight1, na.rm = T)) #applying survey weights increases the salience advantage

### Merge longitudinal dataset

PENN201410$year <- 2014
PENN2014 <- PENN201410[c("MNO", "immpath", "immbord", "immind", "immind3w", "immind3s")]
names(PENN2014) <- c("MNO", "immpath_2014", "immbord_2014", "immind_2014", "immind3w_2014", "immind3s_2014")
PENN201611$year <- 2016
PENN2016 <- PENN201611[c("MNO", "immbord", "immsalience2", "imrsalience2")]
names(PENN2016) <- c("MNO", "immbord_2016", "immsalience2_2016", "imrsalience2_2016")
PENN201810$year <- 2018
PENN201810$MNO <- PENN201810$mno
PENN2018 <- PENN201810[c("MNO", "immpath", "immbord", "immind", "immind3w", "immind3s", "immsalience2", "imrsalience2")]
names(PENN2018) <- c("MNO", "immpath_2018", "immbord_2018", "immind_2018", "immind3w_2018", "immind3s_2018", "immsalience2_2018", "imrsalience2_2018")
PENN202010$year <- 2020
PENN202010$MNO <- PENN202010$mno
PENN2020 <- PENN202010[c("MNO", "immpath", "immbord", "immind", "immind3w", "immind3s", "immsalience2", "imrsalience2")]
names(PENN2020) <- c("MNO", "immpath_2020", "immbord_2020", "immind_2020", "immind3w_2020", "immind3s_2020", "immsalience2_2020", "imrsalience2_2020")

PENNPANEL <- merge(PENN2014, PENN2016, by = "MNO")
PENNPANEL <- merge(PENNPANEL, PENN2018, by = "MNO")
PENNPANEL <- merge(PENNPANEL, PENN2020, by = "MNO")

cor(PENNPANEL$immind_2014, PENNPANEL$immind_2020, use = "complete.obs")
cor(PENNPANEL$immind_2014, PENNPANEL$immind_2018, use = "complete.obs")

tapply(PENNPANEL$immsalience2_2016, PENNPANEL$immind3s_2014, mean, na.rm = T)
tapply(PENNPANEL$immsalience2_2018, PENNPANEL$immind3s_2014, mean, na.rm = T)
tapply(PENNPANEL$immsalience2_2020, PENNPANEL$immind3s_2014, mean, na.rm = T)

### PLOTS

# 2018 plot

library(survey)

PENN201810s <- svydesign(ids = ~1, strata = NULL, data = PENN201810, weights = PENN201810$weight1)
PENN202010s <- svydesign(ids = ~1, strata = NULL, data = PENN202010, weights = PENN202010$weight1)

immsalience2.by.immatt3s.2018 <- svyby(~immsalience2, by=~immind3s, design=PENN201810s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2018 <- cbind("2018", immsalience2.by.immatt3s.2018)
colnames(immsalience2.by.immatt3s.2018) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
imrsalience2.by.immatt3s.2018 <- svyby(~imrsalience2, by=~immind3s, design=PENN201810s, FUN = svymean, vartype = "ci", na.rm=TRUE)
imrsalience2.by.immatt3s.2018 <- cbind("2018 ALT", imrsalience2.by.immatt3s.2018)
colnames(imrsalience2.by.immatt3s.2018) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
#immsalience2.by.immatt3s.2020 <- svyby(~immsalience2, by=~immind3s, design=PENN202010s, FUN = svymean, vartype = "ci", na.rm=TRUE)
#immsalience2.by.immatt3s.2020 <- cbind("2020", immsalience2.by.immatt3s.2020)
#colnames(immsalience2.by.immatt3s.2020) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
#imrsalience2.by.immatt3s.2020 <- svyby(~imrsalience2, by=~immind3s, design=PENN202010s, FUN = svymean, vartype = "ci", na.rm=TRUE)
#imrsalience2.by.immatt3s.2020 <- cbind("2020 ALT", imrsalience2.by.immatt3s.2020)
#colnames(imrsalience2.by.immatt3s.2020) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")

immsalience2.by.immatt3s <- rbind(immsalience2.by.immatt3s.2018, imrsalience2.by.immatt3s.2018)

library(ggplot2)

### Main PENN Figure: Salience by Preference

ggplot(data = immsalience2.by.immatt3s, aes(x = year, y = immsalience2, group = immind3s, fill = immind3s, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(-0.05,0.6) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Neutral", "Pro-immigration"))



