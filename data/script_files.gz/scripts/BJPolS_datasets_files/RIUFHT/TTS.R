### Load required packages and data

library(haven)
library(plyr)
library(survey)
library(ggplot2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

TTS2014 <- read_por("tts2014.por")

## Define country labels

TTS2014$COUNTRYLAB <- as_factor(TTS2014$COUNTRY)

## Issue importance

TTS2014$immsalience2 <- ifelse(TTS2014$Q0A == 4, 1, ifelse(TTS2014$Q0A == 99, NA, 0))

## Preferences

TTS2014$immany1i <- as.numeric(mapvalues(TTS2014$Q27A, from = c(1,2,3,98,99), to = c(1,0.5,0,NA,NA)))
TTS2014$immany2i <- as.numeric(mapvalues(TTS2014$Q27B, from = c(1,2,3,98,99), to = c(1,0.5,0,NA,NA)))
TTS2014$immany <- rowMeans(TTS2014[c("immany1i", "immany2i")], na.rm=TRUE)

TTS2014$immany2 <- as.factor(ifelse(TTS2014$immany == 1, "anti-immigration", ifelse(TTS2014$immany == 0, "pro-immigration", NA)))

## Exclude countries with less than 4%/40 issue salience

TTS2014immsalience2countrymean <- as.data.frame(tapply(TTS2014$immsalience2, TTS2014$COUNTRYLAB, mean, na.rm = T))
TTS2014countryN <- as.data.frame(tapply(TTS2014$immsalience2, TTS2014$COUNTRYLAB, function(x) {length(x[!is.na(x)])}))
TTS2014immsalience2countryN <- TTS2014immsalience2countrymean*TTS2014countryN

TTS2014immsalience2countryN$COUNTRYLAB <- rownames(TTS2014immsalience2countryN)
colnames(TTS2014immsalience2countryN) <- c("TTS2014immsalience2countryN", "COUNTRYLAB")

TTS2014 <- merge(TTS2014, TTS2014immsalience2countryN, by = "COUNTRYLAB")
TTS2014 <- TTS2014[TTS2014$TTS2014immsalience2countryN >= 40,]

## Exclude Turkey and Russia as non-democracies

TTS2014 <- TTS2014[TTS2014$COUNTRYLAB != "Turkey" & TTS2014$COUNTRYLAB != "Russia",]

### Figure 3: Immigration salience by binary preference across countries


TTS2014s <- svydesign(ids = ~1, strata = NULL, 
                        data = TTS2014, weights = TTS2014$WGHT3AC)

immsalience2.by.immany2.country.2014 <- svyby(~immsalience2, by=~immany2+COUNTRYLAB, design=TTS2014s, FUN = svymean, vartype = "ci", na.rm=TRUE)
colnames(immsalience2.by.immany2.country.2014) <- c("immany2","sample", "immsalience2", "CIl", "CIu")
immsalience2.by.immany2.total.2014 <-svyby(~immsalience2, by=~immany2, design=TTS2014s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immany2.total.2014 <- cbind("Average", immsalience2.by.immany2.total.2014)
colnames(immsalience2.by.immany2.total.2014) <- c("sample", "immany2", "immsalience2", "CIl", "CIu")
immsalience2.by.immany2.total.2014 <- immsalience2.by.immany2.total.2014[c("immany2","sample", "immsalience2", "CIl", "CIu")]
immsalience2.by.immany2.country.2014 <- rbind(immsalience2.by.immany2.total.2014, immsalience2.by.immany2.country.2014)

ggplot(data = immsalience2.by.immany2.country.2014, aes(x = sample, y = immsalience2, group = immany2, fill = immany2, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(-0.05,0.6) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Pro-immigration"))
