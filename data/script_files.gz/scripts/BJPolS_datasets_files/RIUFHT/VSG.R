### Load required packages and data

library(haven)
library(plyr)
library(survey)
library(ggplot2)
library(reshape2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

VSG <- read_dta("VSG2019.dta")

## Issue importance

VSG$immimp_2011 <- ifelse(VSG$imiss_c_baseline < 5, VSG$imiss_c_baseline, NA)
VSG$immimp_2011 <- (VSG$immimp_2011-5)/4*(-1)
VSG$immimp_2016 <- ifelse(VSG$imiss_c_2016 < 5, VSG$imiss_c_2016, NA)
VSG$immimp_2016 <- (VSG$immimp_2016-5)/4*(-1)
VSG$immimp_2017 <- ifelse(VSG$imiss_c_2017 < 5, VSG$imiss_c_2017, NA)
VSG$immimp_2017 <- (VSG$immimp_2017-5)/4*(-1)
VSG$immimp_2019 <- ifelse(VSG$imiss_c_2019 < 5, VSG$imiss_c_2019, NA)
VSG$immimp_2019 <- (VSG$immimp_2019-5)/4*(-1)

VSG$immimp2_2011 <- ifelse(VSG$imiss_c_baseline < 5, VSG$imiss_c_baseline, NA)
VSG$immimp2_2011 <- ifelse(VSG$immimp2_2011 == 1, 1, 0)
VSG$immimp2_2016 <- ifelse(VSG$imiss_c_2016 < 5, VSG$imiss_c_2016, NA)
VSG$immimp2_2016 <- ifelse(VSG$immimp2_2016 == 1, 1, 0)
VSG$immimp2_2017 <- ifelse(VSG$imiss_c_2017 < 5, VSG$imiss_c_2017, NA)
VSG$immimp2_2017 <- ifelse(VSG$immimp2_2017 == 1, 1, 0)
VSG$immimp2_2019 <- ifelse(VSG$imiss_c_2019 < 5, VSG$imiss_c_2019, NA)
VSG$immimp2_2019 <- ifelse(VSG$immimp2_2019 == 1, 1, 0)

VSG$immmii_2011 <- ifelse(VSG$imissf_baseline < 21, VSG$imissf_baseline, NA)
VSG$immmii_2011 <- ifelse(VSG$immmii_2011 == 3, 1, 0)

## Preference

VSG$immatt_2011 <- ifelse(VSG$immi_makedifficult_baseline < 6, VSG$immi_makedifficult_baseline, NA)
VSG$immatt_2011 <- (VSG$immatt_2011-6)/5*(-1)
VSG$immpro_2011 <- ifelse(VSG$immi_makedifficult_baseline < 9, VSG$immi_makedifficult_baseline, NA)
VSG$immpro_2011 <- ifelse(VSG$immpro_2011 == 1 | VSG$immpro_2011 == 2, 1, 0)
VSG$immant_2011 <- ifelse(VSG$immi_makedifficult_baseline < 9, VSG$immi_makedifficult_baseline, NA)
VSG$immant_2011 <- ifelse(VSG$immant_2011 == 4 | VSG$immant_2011 == 5, 1, 0)
VSG$immatt3_2011 <- ifelse(VSG$immi_makedifficult_baseline < 9, VSG$immi_makedifficult_baseline, NA)
VSG$immatt3_2011 <- ifelse(VSG$immatt3_2011 == 1 | VSG$immatt3_2011 == 2, 1,
                            ifelse(VSG$immatt3_2011 == 4 | VSG$immatt3_2011 == 5, 3, 2))
VSG$immatt2_2011 <- ifelse(VSG$immi_makedifficult_baseline == 1 | VSG$immi_makedifficult_baseline == 2, 0,
                           ifelse(VSG$immi_makedifficult_baseline == 4 | VSG$immi_makedifficult_baseline == 5, 1, NA))

VSG$immatt_2016 <- ifelse(VSG$immi_makedifficult_2016 < 6, VSG$immi_makedifficult_2016, NA)
VSG$immatt_2016 <- (VSG$immatt_2016-6)/5*(-1)
VSG$immpro_2016 <- ifelse(VSG$immi_makedifficult_2016 < 9, VSG$immi_makedifficult_2016, NA)
VSG$immpro_2016 <- ifelse(VSG$immpro_2016 == 1 | VSG$immpro_2016 == 2, 1, 0)
VSG$immant_2016 <- ifelse(VSG$immi_makedifficult_2016 < 9, VSG$immi_makedifficult_2016, NA)
VSG$immant_2016 <- ifelse(VSG$immant_2016 == 4 | VSG$immant_2016 == 5, 1, 0)
VSG$immatt3_2016 <- ifelse(VSG$immi_makedifficult_2016 < 9, VSG$immi_makedifficult_2016, NA)
VSG$immatt3_2016 <- ifelse(VSG$immatt3_2016 == 1 | VSG$immatt3_2016 == 2, 1,
                           ifelse(VSG$immatt3_2016 == 4 | VSG$immatt3_2016 == 5, 3, 2))
VSG$immatt2_2016 <- ifelse(VSG$immi_makedifficult_2016 == 1 | VSG$immi_makedifficult_2016 == 2, 0,
                           ifelse(VSG$immi_makedifficult_2016 == 4 | VSG$immi_makedifficult_2016 == 5, 1, NA))

VSG$immatt_2017 <- ifelse(VSG$immi_makedifficult_2017 < 6, VSG$immi_makedifficult_2017, NA)
VSG$immatt_2017 <- (VSG$immatt_2017-6)/5*(-1)
VSG$immpro_2017 <- ifelse(VSG$immi_makedifficult_2017 < 9, VSG$immi_makedifficult_2017, NA)
VSG$immpro_2017 <- ifelse(VSG$immpro_2017 == 1 | VSG$immpro_2017 == 2, 1, 0)
VSG$immant_2017 <- ifelse(VSG$immi_makedifficult_2017 < 9, VSG$immi_makedifficult_2017, NA)
VSG$immant_2017 <- ifelse(VSG$immant_2017 == 4 | VSG$immant_2017 == 5, 1, 0)
VSG$immatt3_2017 <- ifelse(VSG$immi_makedifficult_2017 < 9, VSG$immi_makedifficult_2017, NA)
VSG$immatt3_2017 <- ifelse(VSG$immatt3_2017 == 1 | VSG$immatt3_2017 == 2, 1,
                           ifelse(VSG$immatt3_2017 == 4 | VSG$immatt3_2017 == 5, 3, 2))
VSG$immatt2_2017 <- ifelse(VSG$immi_makedifficult_2017 == 1 | VSG$immi_makedifficult_2017 == 2, 0,
                           ifelse(VSG$immi_makedifficult_2017 == 4 | VSG$immi_makedifficult_2017 == 5, 1, NA))

VSG$immatt_2019 <- ifelse(VSG$immi_makedifficult_2019 < 6, VSG$immi_makedifficult_2019, NA)
VSG$immatt_2019 <- (VSG$immatt_2019-6)/5*(-1)
VSG$immpro_2019 <- ifelse(VSG$immi_makedifficult_2019 < 9, VSG$immi_makedifficult_2019, NA)
VSG$immpro_2019 <- ifelse(VSG$immpro_2019 == 1 | VSG$immpro_2019 == 2, 1, 0)
VSG$immant_2019 <- ifelse(VSG$immi_makedifficult_2019 < 9, VSG$immi_makedifficult_2019, NA)
VSG$immant_2019 <- ifelse(VSG$immant_2019 == 4 | VSG$immant_2019 == 5, 1, 0)
VSG$immatt3_2019 <- ifelse(VSG$immi_makedifficult_2019 < 9, VSG$immi_makedifficult_2019, NA)
VSG$immatt3_2019 <- ifelse(VSG$immatt3_2019 == 1 | VSG$immatt3_2019 == 2, 1,
                           ifelse(VSG$immatt3_2019 == 4 | VSG$immatt3_2019 == 5, 3, 2))
VSG$immatt2_2019 <- ifelse(VSG$immi_makedifficult_2019 == 1 | VSG$immi_makedifficult_2019 == 2, 0,
                           ifelse(VSG$immi_makedifficult_2019 == 4 | VSG$immi_makedifficult_2019 == 5, 1, NA))

## Create long data

VSGlong1 <- VSG[c("immimp_2011", "immimp_2016", "immimp_2017", "immimp_2019",
                 "weight1_2019", "immmii_2011")]
VSGlong1$ID <- seq.int(nrow(VSGlong1))
VSGlong2 <- VSG[c("immimp2_2011", "immimp2_2016", "immimp2_2017", "immimp2_2019")]
VSGlong2$ID <- seq.int(nrow(VSGlong1))
VSGlong3 <- VSG[c("immatt_2011", "immatt_2016", "immatt_2017", "immatt_2019")]
VSGlong3$ID <- seq.int(nrow(VSGlong3))
VSGlong4 <- VSG[c("immatt3_2011", "immatt3_2016", "immatt3_2017", "immatt3_2019")]
VSGlong4$ID <- seq.int(nrow(VSGlong4))
VSGlong5 <- VSG[c("immpro_2011", "immpro_2016", "immpro_2017", "immpro_2019")]
VSGlong5$ID <- seq.int(nrow(VSGlong5))
VSGlong6 <- VSG[c("immant_2011", "immant_2016", "immant_2017", "immant_2019")]
VSGlong6$ID <- seq.int(nrow(VSGlong6))
VSGlong7 <- VSG[c("immatt2_2011", "immatt2_2016", "immatt2_2017", "immatt2_2019")]
VSGlong7$ID <- seq.int(nrow(VSGlong7))

VSGlong1 <- melt(VSGlong1, id.vars = c("ID", "weight1_2019", "immmii_2011"))
VSGlong2 <- melt(VSGlong2, id.vars = c("ID"))
VSGlong3 <- melt(VSGlong3, id.vars = c("ID"))
VSGlong4 <- melt(VSGlong4, id.vars = c("ID"))
VSGlong5 <- melt(VSGlong5, id.vars = c("ID"))
VSGlong6 <- melt(VSGlong6, id.vars = c("ID"))
VSGlong7 <- melt(VSGlong7, id.vars = c("ID"))
VSGlong <- cbind(VSGlong1, VSGlong2[3], VSGlong3[3], VSGlong4[3], VSGlong5[3], VSGlong6[3], VSGlong7[3])
colnames(VSGlong) <- c("ID", "weight1_2019", "immmii_2011", "year", "immimp", "immimp2", "immatt", "immatt3", "immpro", "immant", "immatt2")
VSGlong$year <- gsub(".*_","", VSGlong$year)

VSGlongs <- svydesign(ids = ~1, strata = NULL, 
                      data = VSGlong)

VSGs <- svydesign(ids = ~1, strata = NULL, 
                  data = VSG)

# Figure A1: Immigration salience by binary preference across years

immmii.by.immatt.2011 <- svyby(~immmii_2011, by=~immatt3_2011, design=VSGs, FUN = svymean, vartype = "ci", na.rm=TRUE)
immmii.by.immatt.2011 <- cbind("2011", immmii.by.immatt.2011)
colnames(immmii.by.immatt.2011) <- c("sample","immatt3", "immsalience2", "CIl", "CIu")
immimp.by.immatt.2011 <- svyby(~immimp2_2011, by=~immatt3_2011, design=VSGs, FUN = svymean, vartype = "ci", na.rm=TRUE)
immimp.by.immatt.2011 <- cbind("2011 ALT", immimp.by.immatt.2011)
colnames(immimp.by.immatt.2011) <- c("sample","immatt3", "immsalience2", "CIl", "CIu")
immimp.by.immatt.2016 <- svyby(~immimp2_2016, by=~immatt3_2016, design=VSGs, FUN = svymean, vartype = "ci", na.rm=TRUE)
immimp.by.immatt.2016 <- cbind("2016 ALT", immimp.by.immatt.2016)
colnames(immimp.by.immatt.2016) <- c("sample","immatt3", "immsalience2", "CIl", "CIu")
immimp.by.immatt.2017 <- svyby(~immimp2_2017, by=~immatt3_2017, design=VSGs, FUN = svymean, vartype = "ci", na.rm=TRUE)
immimp.by.immatt.2017 <- cbind("2017 ALT", immimp.by.immatt.2017)
colnames(immimp.by.immatt.2017) <- c("sample","immatt3", "immsalience2", "CIl", "CIu")
immimp.by.immatt.2019 <- svyby(~immimp2_2019, by=~immatt3_2019, design=VSGs, FUN = svymean, vartype = "ci", na.rm=TRUE)
immimp.by.immatt.2019 <- cbind("2019 ALT", immimp.by.immatt.2019)
colnames(immimp.by.immatt.2019) <- c("sample","immatt3", "immsalience2", "CIl", "CIu")

immimp.by.immatt <- rbind(immmii.by.immatt.2011, immimp.by.immatt.2011, immimp.by.immatt.2016, immimp.by.immatt.2017, immimp.by.immatt.2019)
immimp.by.immatt$immatt3 <- c("Pro-immigration", "Neutral", "Anti-immigration", "Pro-immigration", "Neutral", "Anti-immigration", 
                              "Pro-immigration", "Neutral", "Anti-immigration", "Pro-immigration", "Neutral", "Anti-immigration", "Pro-immigration", "Neutral", "Anti-immigration")
immimp.by.immatt$immatt3 <- factor(immimp.by.immatt$immatt3, levels = c("Anti-immigration", "Neutral", "Pro-immigration"))

ggplot(data = immimp.by.immatt, aes(x = sample, y = immsalience2, group = factor(immatt3), fill = factor(immatt3), ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(0, 0.75) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Neutral", "Pro-immigration"))
