### Load required packages and data

library(foreign)
library(plyr)
library(survey)
library(ggplot2)

as.numeric.factor <- function(x) {as.numeric(levels(x))[x]}

BES2001 <- read.dta("BES2001/prepostagg.dta")
BES2005 <- read.dta("BES2005/2005BESb.dta")
BES2010 <- read.dta("BES2010/2010BESprepost.dta")
BES2015 <- read.dta("BES2015/bes_f2f_2015_v4.0.dta")

### 2001

## Issue importance

BES2001$immsalience2 <- ifelse(BES2001$bq4 == "immigration/asylum seekers", 1, ifelse(BES2001$bq4 == "not app", NA, 0))

## Preference

BES2001$immcrim <- as.numeric.factor(mapvalues(BES2001$cq16a, 
                                               from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "not ascertainable", "no mailback"), 
                                               to = c(1, 0.75, 0.5, 0.25, 0, NA, NA)))
BES2001$immecon <- as.numeric.factor(mapvalues(BES2001$cq16b, 
                                               from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "not ascertainable", "no mailback"), 
                                               to = c(0, 0.25, 0.5, 0.75, 1, NA, NA)))
BES2001$immjobs <- as.numeric.factor(mapvalues(BES2001$cq16c, 
                                               from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "not ascertainable", "no mailback"), 
                                               to = c(1, 0.75, 0.5, 0.25, 0, NA, NA)))
BES2001$immcult <- as.numeric.factor(mapvalues(BES2001$cq16d, 
                                               from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "not ascertainable", "no mailback"), 
                                               to = c(0, 0.25, 0.5, 0.75, 1, NA, NA)))
BES2001$immasyl <- as.numeric.factor(mapvalues(BES2001$cq16e, 
                                               from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "not ascertainable", "no mailback"), 
                                               to = c(1, 0.75, 0.5, 0.25, 0, NA, NA)))
BES2001$immind <- rowMeans(BES2001[c("immcrim", "immecon", "immjobs", "immcult", "immasyl")], na.rm=TRUE)
BES2001$immind3s <- ifelse(BES2001$immind >= 0.75, "anti-immigration", ifelse(BES2001$immind <= 0.25, "pro-immigration", "neutral")) 

### 2005

## Issue Importance

BES2005$immsalience2 <- ifelse(BES2005$bq2a == "asylum seekers" | BES2005$bq2a == "immigration/people coming to britain", 1, ifelse(BES2005$bq2a == "na", NA, 0))

#Preference

BES2005$immcult <- as.numeric.factor(mapvalues(BES2005$bq62b, 
                                                from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "refused", "don't know", "na", "not app"), 
                                                to = c(0, 0.25, 0.5, 0.75, 1, NA, NA, NA, NA)))
BES2005$immjobs <- as.numeric.factor(mapvalues(BES2005$bq62g, 
                                            from = c("stongly agree", "agree", "neither", "disagree", "strongly disagree", "refused", "don't know", "na", "not app"), 
                                            to = c(1, 0.75, 0.5, 0.25, 0, NA, NA, NA, NA)))
BES2005$immasyl <- as.numeric.factor(mapvalues(BES2005$bq34b, 
                                            from = c("lot better", "little better", "same", "little worse", "lot worse", "refused", "don't know", "na"), 
                                            to = c(0, 0.25, 0.5, 0.75, 1, NA, NA, NA)))
BES2005$immind <- rowMeans(BES2005[c("immcult", "immjobs", "immasyl")], na.rm=TRUE)
BES2005$immind3s <- ifelse(BES2005$immind >= 0.75, "anti-immigration", ifelse(BES2005$immind <= 0.25, "pro-immigration", "neutral")) 

### 2010

## Issue importance

BES2010$immsalience2 <- ifelse(BES2010$bq2_1 == "immigration", 1, 0)

## Preference

BES2010$immrace <- as.numeric.factor(mapvalues(BES2010$bq72_3, 
                                               from = c("strongly agree", "agree", "neither agree nor disagree", "disagree", "strongly disagree", "refused", "don't know", "not stated"), 
                                               to = c(0, 0.25, 0.5, 0.75, 1, NA, NA, NA)))
BES2010$immcrim <- as.numeric.factor(mapvalues(BES2010$bq72_4, 
                                               from = c("strongly agree", "agree", "neither agree nor disagree", "disagree", "strongly disagree", "refused", "don't know", "not stated"), 
                                               to = c(1, 0.75, 0.5, 0.25, 0, NA, NA, NA)))
BES2010$immecon <- as.numeric.factor(mapvalues(BES2010$bq72_5, 
                                               from = c("strongly agree", "agree", "neither agree nor disagree", "disagree", "strongly disagree", "refused", "don't know", "not stated"), 
                                               to = c(0, 0.25, 0.5, 0.75, 1, NA, NA, NA)))
BES2010$immasyl <- as.numeric.factor(mapvalues(BES2010$bq72_6, 
                                               from = c("strongly agree", "agree", "neither agree nor disagree", "disagree", "strongly disagree", "refused", "don't know", "not stated"), 
                                               to = c(1, 0.75, 0.5, 0.25, 0, NA, NA, NA)))
BES2010$immsitu <- as.numeric.factor(mapvalues(BES2010$bq37_2, 
                                               from = c("a lot better", "a little better", "the same", "a little worse", "a lot worse", "refused", "don't know", "not stated"), 
                                               to = c(0, 0.25, 0.5, 0.75, 1, NA, NA, NA)))
BES2010$immind <- rowMeans(BES2010[c("immrace", "immcrim", "immecon", "immasyl", "immsitu")], na.rm=TRUE)
BES2010$immind3s <- ifelse(BES2010$immind >= 0.75, "anti-immigration", ifelse(BES2010$immind <= 0.25, "pro-immigration", "neutral")) 

### 2015

## Issue importance

BES2015$immsalience2 <- ifelse(BES2015$a1_mii == "immigration", 1, 0)
BES2015$immsalienceALT <- as.numeric.factor(mapvalues(BES2015$j06, 
                                                      from = c("Very strongly", "Fairly strongly", "Not very strongly", "Don't know", "Not stated"), 
                                                      to = c(1, 0.5, 0, NA, NA)))
BES2015$immsalienceALT2 <- ifelse(BES2015$j06 == "Very strongly", 1, 0)

## Preference

BES2015$immecon <- as.numeric.factor(mapvalues(BES2015$j01, 
                                               from = c("7 Good for economy", "6", "5", "4", "3", "2", "1 Bad for economy", "Don't know", "Not stated"), 
                                               to = c(0, 0.167, 0.334, 0.5, 0.667, 0.834, 1, NA, NA)))
BES2015$immmany <- as.numeric.factor(mapvalues(BES2015$j05, from = c("Yes, too many", "No, not too many", "Don't know", "Not stated"), to = c(1, 0, NA, NA)))
BES2015$immind <- rowMeans(BES2015[c("immmany", "immecon")], na.rm=TRUE)
BES2015$immind3s <- ifelse(BES2015$immind >= 0.75, "anti-immigration", ifelse(BES2015$immind <= 0.25, "pro-immigration", "neutral")) 

### 2014-2023 Panel
#library(haven)
#BES1423 <- read_dta("BES2014-2023/BES2019_W20_Panel_v0.1.dta")
#save(BES1423, file = "BES1423.rdata")
load("BES2014-2023/BES1423.rdata")

# Weight variables: BES1423$wt_full_W7W8W9, BES1423$wt_full_W10, BES1423$wt_full_W11, BES1423$wt_new

BESp2015 <- as.data.frame(BES1423[BES1423$wave4 == 1,])
BESp2015 <- BESp2015[!is.na(BESp2015$wt_full_W4),] # remove a few obs with missing weights
BESp2017 <- as.data.frame(BES1423[BES1423$wave13 == 1,])
BESp2017 <- BESp2017[!is.na(BESp2017$wt_new_W13_result),] # remove a few obs with missing weights

# Issue importance (combine #12 immigration and #13 asylum)

BESp2015$immsalience2 <- ifelse(BESp2015$mii_catW4 == 12 | BESp2015$mii_catW4 == 13, 1, 0) # March 2015

BESp2017$immsalience2 <- ifelse(BESp2017$mii_catW13 == 12 | BESp2017$mii_catW13 == 13, 1, 0) # June 2017

# Preference

BESp2015$immlevl <- mapvalues(BESp2015$immigrationLevelW4, 
                              from = c(1:5, 9999), 
                              to = c(1, 0.75, 0.5, 0.25, 0, NA))

BESp2015$immecon <- ifelse(BESp2015$immigEconW4 == 9999, NA, BESp2015$immigEconW4)
BESp2015$immecon <- (BESp2015$immecon-7)/6*(-1)
BESp2015$immcult <- ifelse(BESp2015$immigCulturalW4 == 9999, NA, BESp2015$immigCulturalW4)
BESp2015$immcult <- (BESp2015$immcult-7)/6*(-1)
BESp2015$immind <- rowMeans(BESp2015[c("immlevl", "immecon", "immcult")], na.rm=TRUE)
BESp2015$immind3s <- ifelse(BESp2015$immind >= 0.75, "anti-immigration", ifelse(BESp2015$immind <= 0.25, "pro-immigration", "neutral")) 

BESp2017$immallo <- ifelse(BESp2017$immigSelfW13 == 9999, NA, BESp2017$immigSelfW13)
BESp2017$immallo <- (BESp2017$immallo-10)/10*(-1)

BESp2017$immecon <- ifelse(BESp2017$immigEconW13 == 9999, NA, BESp2017$immigEconW13)
BESp2017$immecon <- (BESp2017$immecon-7)/6*(-1)
BESp2017$immcult <- ifelse(BESp2017$immigCulturalW13 == 9999, NA, BESp2017$immigCulturalW13)
BESp2017$immcult <- (BESp2017$immcult-7)/6*(-1)
BESp2017$immind <- rowMeans(BESp2017[c("immallo", "immecon", "immcult")], na.rm=TRUE)
BESp2017$immind3s <- ifelse(BESp2017$immind >= 0.75, "anti-immigration", ifelse(BESp2017$immind <= 0.25, "pro-immigration", "neutral")) 

### Combine in Plots 

BES2005s <- svydesign(ids = ~1, strata = NULL, data = BES2005, weights = BES2005$postwtbr)
BES2010s <- svydesign(ids = ~1, strata = NULL, data = BES2010[!is.na(BES2010$postwgt),], weights = BES2010[!is.na(BES2010$postwgt),]$postwgt)
BESp2015s <- svydesign(ids = ~1, strata = NULL, data = BESp2015, weights = BESp2015$wt_full_W4)
BES2015s <- svydesign(ids = ~1, strata = NULL, data = BES2015, weights = BES2015$wt_combined_main_capped)
BESp2017s <- svydesign(ids = ~1, strata = NULL, data = BESp2017, weights = BESp2017$wt_new_W13_result)

immsalience2.by.immatt3s.2005 <- svyby(~immsalience2, by=~immind3s, design=BES2005s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2005 <- cbind("2005", immsalience2.by.immatt3s.2005)
colnames(immsalience2.by.immatt3s.2005) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
immsalience2.by.immatt3s.2010 <- svyby(~immsalience2, by=~immind3s, design=BES2010s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2010 <- cbind("2010", immsalience2.by.immatt3s.2010)
colnames(immsalience2.by.immatt3s.2010) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
immsalience2.by.immatt3s.2015p <- svyby(~immsalience2, by=~immind3s, design=BESp2015s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2015p <- cbind("2015p", immsalience2.by.immatt3s.2015p)
colnames(immsalience2.by.immatt3s.2015p) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")

immsalience2.by.immatt3s.2015 <- svyby(~immsalience2, by=~immind3s, design=BES2015s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2015 <- cbind("2015", immsalience2.by.immatt3s.2015)
colnames(immsalience2.by.immatt3s.2015) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
immsalienceALT2.by.immatt3s.2015 <- svyby(~immsalienceALT2, by=~immind3s, design=BES2015s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalienceALT2.by.immatt3s.2015 <- cbind("2015 ALT", immsalienceALT2.by.immatt3s.2015)
colnames(immsalienceALT2.by.immatt3s.2015) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")
immsalience2.by.immatt3s.2017p <- svyby(~immsalience2, by=~immind3s, design=BESp2017s, FUN = svymean, vartype = "ci", na.rm=TRUE)
immsalience2.by.immatt3s.2017p <- cbind("2017p", immsalience2.by.immatt3s.2017p)
colnames(immsalience2.by.immatt3s.2017p) <- c("year", "immind3s", "immsalience2", "CIl", "CIu")

immsalience2.by.immatt3s <- rbind(immsalience2.by.immatt3s.2005, immsalience2.by.immatt3s.2010, 
                                  immsalience2.by.immatt3s.2015p, immsalience2.by.immatt3s.2015, immsalienceALT2.by.immatt3s.2015, immsalience2.by.immatt3s.2017p)

### Figure 2: Salience by Preference

ggplot(data = immsalience2.by.immatt3s, aes(x = year, y = immsalience2, group = immind3s, fill = immind3s, ymax = CIl, ymin = CIu)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(position = position_dodge(width = 0.9), width = 0.1) + ylim(-0.05,0.6) +
  xlab("") + ylab("Issue Importance") + theme_bw() +
  theme(axis.text=element_text(size=12), axis.title=element_text(size=13, face="bold"), 
        legend.title = element_text(size = 13, face = "bold"),
        legend.text = element_text(size = 12)) + 
  theme(axis.text.x=element_text(angle=45,hjust=1), legend.position="top") + 
  scale_fill_grey(name = "Issue Preference", labels = c("Anti-immigration", "Neutral", "Pro-immigration"))
