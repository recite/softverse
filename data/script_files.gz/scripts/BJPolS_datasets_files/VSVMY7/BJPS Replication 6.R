#How Do Observers Assess Resolve?
#July 7, 2018
#BJPS Replication 6.R

#This file contains the replication code needed to replicate the analysis from Supplementary Appendix §1.3 - §1.4 (Fully-satured interactions for past behavior, heterogeneous treatment effects by respondent characteristics)

#To generate the necessary dataframes, either run BJPS Replication 1.R, or load the following saved objects:
library(here) #Avoids needing to setwd()
dat3 <- get(load(file="Resolve Conjoint Cleaned No US 070718.RData"))
dat_id <- get(load(file="Resolve Demographics 070718.RData"))

#Load parallel processing and recode functions in case you haven't run BJPS Replication 2.R - if not, you can skip to line 24
library(snow)
cl <- makeCluster(8,"SOCK")
clusterBootS2 <- function(data){
	i <- sample(unique(data$ID_numeric),length(unique(data$ID_numeric)),replace=TRUE)
	row.nums <- NULL
	for (j in 1:length(i)){
		row.nums <- c(row.nums, which(data$ID_numeric==i[j]))
	}
	return(data[row.nums,])
}

##### Full four-way interation for past actions
set.seed(43215)
# Function for fully-saturated past behavior interaction
bootConjoint <- function(...){
	temp <- clusterBootS2(dat3)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevBehavior + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("dat3", "bootConjoint", "clusterBootS2"))

system.time(boot.fullpast <- parSapply(cl, rep(1,1500), bootConjoint)) #156 seconds

#Extract quantities of interest
plot.fullpast <- cbind(apply(boot.fullpast, 1, mean), apply(boot.fullpast, 1, quantile, c(0.025)), apply(boot.fullpast, 1, quantile, c(0.05)), apply(boot.fullpast, 1, quantile, c(0.95)), apply(boot.fullpast,1,quantile, c(0.975)))[-1,]

#Now add baseline categories
plot.fullpastb <- rbind(rep(0,5), plot.fullpast[1,], rep(0,5), plot.fullpast[2,], rep(0,5), plot.fullpast[3:4,], rep(0,5), plot.fullpast[5,], rep(0,5), plot.fullpast[6,], rep(0,5), plot.fullpast[c(8,7),], rep(0,5), plot.fullpast[9,], rep(0,5), plot.fullpast[10:24,],rep(0,5), plot.fullpast[25:26,])

textLab <- c("Low Capabilities", "High Capabilities", "Low Stakes", "High Stakes", "Dictatorship", "Democracy", "Mixed",  "Ally", "Adversary", "Established Leader", "New Leader", "No Military Service", "Some Military Service", "Long Military Service", "Female Leader", "Male Leader", "Target, stood firm against ally, different leader", "Initiator, backed down vs adversary, different leader", "Initiator, backed down vs adversary, same leader", "Initiator, backed down vs ally, different leader", "Initiator, backed down vs ally, same leader", "Initiator, stood firm vs adversary, different leader", "Initiator, stood firm vs adversary, same leader", "Initiator, stood firm vs ally, different leader", "Initiator, stood firm vs ally, same leader", "Target, backed down vs adversary, different leader", "Target, backed down vs adversary, same leader", "Target, backed down vs ally, different leader", "Target, backed down vs ally, same leader", "Target, stood firm vs adversary, different leader", "Target, stood firm vs adversary, same leader", "Target, stood firm vs ally, same leader", "Nothing", "Mobilized troops", "Public threat")

#Now, resort levels of past behavior to make the plot easier to read
plot.fullpastb[17:32,] <- plot.fullpastb[c(21,19,29,28,27,18,20,26,17,30,24,23,22,25,32,31),]
textLab[17:32] <- textLab[c(c(21,19,29,28,27,18,20,26,17,30,24,23,22,25,32,31))]

##### Figure 7: Four-way interaction for past actions
# Clean up labels, etc. in post-production
dev.new(height=9, width=6.5)
par(mar=c(5.1,1.1,4.1,0), oma=c(0,4,0,0))
plot(plot.fullpastb[,1], nrow(plot.fullpastb):1, type="n", axes=FALSE, xlab="Average marginal component effect (AMCE)", ylab="",xlim=c(-0.3,0.2))

for (i in 1:nrow(plot.fullpastb)){
	points(plot.fullpastb[i,1], nrow(plot.fullpastb)-(i-1), pch=16)
	lines(plot.fullpastb[i,c(2,5)], rep(nrow(plot.fullpastb)-(i-1),2))
	lines(plot.fullpastb[i,c(3,4)], rep(nrow(plot.fullpastb)-(i-1),2), lwd=2)		
	text(-0.3, nrow(plot.fullpastb)-(i-1), textLab[i], cex=0.7)			
	}
abline(v=0)
axis(1)

####### Heterogeneous treatment effects by resopndent characteristics

#First, merge demographics into main dataset
dat.merge <- merge(dat3, dat_id, by="ID_numeric")

### By education

dat_merge$educ_di <- recode(dat_id$educ, binarize=TRUE, x=5, x2=8) #Split based on whether respondents have a 4 year college degree

lowEd <- subset(dat.merge, dat.merge$educ_di==0)
hiEd <- subset(dat.merge,dat.merge$educ_di==1)

#First for low-education
bootConjoint <- function(...){
	temp <- clusterBootS2(lowEd)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("lowEd", "hiEd", "bootConjoint", "clusterBootS2"))

system.time(boot.lowEd <- parSapply(cl, rep(1,1500), bootConjoint)) 

#Then for high-education
bootConjoint <- function(...){
	temp <- clusterBootS2(hiEd)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("lowEd", "hiEd", "bootConjoint", "clusterBootS2"))

system.time(boot.hiEd <- parSapply(cl, rep(1,1500), bootConjoint))

#Now, extract quantities of interest
plot.hiEd <- cbind(apply(boot.hiEd, 1, mean), apply(boot.hiEd, 1, quantile, c(0.025)), apply(boot.hiEd, 1, quantile, c(0.05)), apply(boot.hiEd, 1, quantile, c(0.95)), apply(boot.hiEd,1,quantile, c(0.975)))[-1,]

plot.lowEd <- cbind(apply(boot.lowEd, 1, mean), apply(boot.lowEd, 1, quantile, c(0.025)), apply(boot.lowEd, 1, quantile, c(0.05)), apply(boot.lowEd, 1, quantile, c(0.95)), apply(boot.lowEd,1,quantile, c(0.975)))[-1,]

#Now add baseline categories
plot.hiEdb <- rbind(rep(0,5), plot.hiEd[1,], rep(0,5), plot.hiEd[2,], rep(0,5), plot.hiEd[3:4,], rep(0,5), plot.hiEd[5,], rep(0,5), plot.hiEd[6,], rep(0,5), plot.hiEd[c(8,7),], rep(0,5), plot.hiEd[9,], rep(0,5), plot.hiEd[10,], rep(0,5), plot.hiEd[11,], rep(0,5), plot.hiEd[c(14,13,12),],rep(0,5), plot.hiEd[15:16,])

plot.lowEdb <- rbind(rep(0,5), plot.lowEd[1,], rep(0,5), plot.lowEd[2,], rep(0,5), plot.lowEd[3:4,], rep(0,5), plot.lowEd[5,], rep(0,5), plot.lowEd[6,], rep(0,5), plot.lowEd[c(8,7),], rep(0,5), plot.lowEd[9,], rep(0,5), plot.lowEd[10,], rep(0,5), plot.lowEd[11,], rep(0,5), plot.lowEd[c(14,13,12),],rep(0,5), plot.lowEd[15:16,])

textLab <- c("Low Capabilities", "High Capabilities", "Low Stakes", "High Stakes", "Dictatorship", "Democracy", "Mixed",  "Ally", "Adversary", "Established Leader", "New Leader", "No Military Service", "Some Military Service", "Long Military Service", "Female Leader", "Male Leader", "Target", "Initiator", "Against ally", "Against adversary", "Different leader, stood firm", "Same leader, stood firm", "Same leader, backed down", "Different leader, backed down", "Nothing", "Mobilized troops", "Public threat")

#### Figure 8: Heterogeneous treatment effects by education
## Clean labels, etc. in post-production

dev.new(height=9, width=6.5)
par(mar=c(5.1,1.1,4.1,0), oma=c(0,4,0,0))
plot(plot.hiEdb[,1], nrow(plot.hiEdb):1, type="n", axes=FALSE, xlab="Average marginal component effect (AMCE)", ylab="",xlim=c(-0.3,0.2))

for (i in 1:nrow(plot.hiEdb)){
	points(plot.hiEdb[i,1], nrow(plot.hiEdb)-(i-1), pch=16)
	points(plot.lowEdb[i,1], nrow(plot.lowEdb)-(i-1)-0.25, pch=15, col="grey")
	lines(plot.hiEdb[i,c(2,5)], rep(nrow(plot.hiEdb)-(i-1),2))
	lines(plot.lowEdb[i,c(2,5)], rep(nrow(plot.lowEdb)-(i-1)-0.25,2), col="grey")
	lines(plot.hiEdb[i,c(3,4)], rep(nrow(plot.hiEdb)-(i-1),2), lwd=2)	
	lines(plot.lowEdb[i,c(3,4)], rep(nrow(plot.hiEdb)-(i-1)-0.25,2), lwd=2, col="grey")		
	text(-0.3, nrow(plot.hiEdb)-(i-1), textLab[i], cex=0.7)			
	}
abline(v=0)
axis(1)

## By hawkishness

#Mean-split MI
dat.merge$mi2 <- rep(NA, nrow(dat.merge))
dat.merge$mi2[which(dat.merge$mi1 < mean(dat.merge$mi1, na.rm=TRUE))] <- 0
dat.merge$mi2[which(dat.merge$mi1 >= mean(dat.merge$mi1, na.rm=TRUE))] <- 1

lowMI <- subset(dat.merge, dat.merge$mi2==0)
hiMI <- subset(dat.merge,dat.merge$mi2==1)

#First for doves
bootConjoint <- function(...){
	temp <- clusterBootS2(lowMI)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("lowMI", "hiMI", "bootConjoint", "clusterBootS2"))

#And then for hawks
system.time(boot.lowMI <- parSapply(cl, rep(1,1500), bootConjoint))
bootConjoint <- function(...){
	temp <- clusterBootS2(hiMI)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("lowMI", "hiMI", "bootConjoint", "clusterBootS2"))

system.time(boot.hiMI <- parSapply(cl, rep(1,1500), bootConjoint))

#Now, extract quantities of interest
plot.hiMI <- cbind(apply(boot.hiMI, 1, mean), apply(boot.hiMI, 1, quantile, c(0.025)), apply(boot.hiMI, 1, quantile, c(0.05)), apply(boot.hiMI, 1, quantile, c(0.95)), apply(boot.hiMI,1,quantile, c(0.975)))[-1,]

plot.lowMI <- cbind(apply(boot.lowMI, 1, mean), apply(boot.lowMI, 1, quantile, c(0.025)), apply(boot.lowMI, 1, quantile, c(0.05)), apply(boot.lowMI, 1, quantile, c(0.95)), apply(boot.lowMI,1,quantile, c(0.975)))[-1,]

#Now add baseline categories
plot.hiMIb <- rbind(rep(0,5), plot.hiMI[1,], rep(0,5), plot.hiMI[2,], rep(0,5), plot.hiMI[3:4,], rep(0,5), plot.hiMI[5,], rep(0,5), plot.hiMI[6,], rep(0,5), plot.hiMI[c(8,7),], rep(0,5), plot.hiMI[9,], rep(0,5), plot.hiMI[10,], rep(0,5), plot.hiMI[11,], rep(0,5), plot.hiMI[c(14,13,12),],rep(0,5), plot.hiMI[15:16,])

plot.lowMIb <- rbind(rep(0,5), plot.lowMI[1,], rep(0,5), plot.lowMI[2,], rep(0,5), plot.lowMI[3:4,], rep(0,5), plot.lowMI[5,], rep(0,5), plot.lowMI[6,], rep(0,5), plot.lowMI[c(8,7),], rep(0,5), plot.lowMI[9,], rep(0,5), plot.lowMI[10,], rep(0,5), plot.lowMI[11,], rep(0,5), plot.lowMI[c(14,13,12),],rep(0,5), plot.lowMI[15:16,])

textLab <- c("Low Capabilities", "High Capabilities", "Low Stakes", "High Stakes", "Dictatorship", "Democracy", "Mixed",  "Ally", "Adversary", "Established Leader", "New Leader", "No Military Service", "Some Military Service", "Long Military Service", "Female Leader", "Male Leader", "Target", "Initiator", "Against ally", "Against adversary", "Different leader, stood firm", "Same leader, stood firm", "Same leader, backed down", "Different leader, backed down", "Nothing", "Mobilized troops", "Public threat")

#### Figure 9: Heterogeneous treatment effects by hawkishness
## Clean labels, etc. in post-production
dev.new(height=9, width=6.5)
par(mar=c(5.1,1.1,4.1,0), oma=c(0,4,0,0))
plot(plot.hiMIb[,1], nrow(plot.hiMIb):1, type="n", axes=FALSE, xlab="Average marginal component effect (AMCE)", ylab="",xlim=c(-0.3,0.2))

for (i in 1:nrow(plot.hiMIb)){
	points(plot.hiMIb[i,1], nrow(plot.hiMIb)-(i-1), pch=16)
	points(plot.lowMIb[i,1], nrow(plot.lowMIb)-(i-1)-0.25, pch=15, col="grey")
	lines(plot.hiMIb[i,c(2,5)], rep(nrow(plot.hiMIb)-(i-1),2))
	lines(plot.lowMIb[i,c(2,5)], rep(nrow(plot.lowMIb)-(i-1)-0.25,2), col="grey")
	lines(plot.hiMIb[i,c(3,4)], rep(nrow(plot.hiMIb)-(i-1),2), lwd=2)	
	lines(plot.lowMIb[i,c(3,4)], rep(nrow(plot.hiMIb)-(i-1)-0.25,2), lwd=2, col="grey")		
	text(-0.3, nrow(plot.hiMIb)-(i-1), textLab[i], cex=0.7)			
	}
abline(v=0)
axis(1)

## By partisanship

#Democrats versus Republicans
dems <- subset(dat.merge, dat.merge$Dems==1)
reps <- subset(dat.merge,dat.merge$Reps==1)

#First for Democrats
bootConjoint <- function(...){
	temp <- clusterBootS2(dems)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("dems", "reps", "bootConjoint", "clusterBootS2"))

system.time(boot.dems <- parSapply(cl, rep(1,1500), bootConjoint)) 

#And then for Republicans
bootConjoint <- function(...){
	temp <- clusterBootS2(reps)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("dems", "reps", "bootConjoint", "clusterBootS2"))

system.time(boot.reps <- parSapply(cl, rep(1,1500), bootConjoint)) 

#Extract quantities of interest
plot.reps <- cbind(apply(boot.reps, 1, mean), apply(boot.reps, 1, quantile, c(0.025)), apply(boot.reps, 1, quantile, c(0.05)), apply(boot.reps, 1, quantile, c(0.95)), apply(boot.reps,1,quantile, c(0.975)))[-1,]

plot.dems <- cbind(apply(boot.dems, 1, mean), apply(boot.dems, 1, quantile, c(0.025)), apply(boot.dems, 1, quantile, c(0.05)), apply(boot.dems, 1, quantile, c(0.95)), apply(boot.dems,1,quantile, c(0.975)))[-1,]

#Now add baseline categories
plot.repsb <- rbind(rep(0,5), plot.reps[1,], rep(0,5), plot.reps[2,], rep(0,5), plot.reps[3:4,], rep(0,5), plot.reps[5,], rep(0,5), plot.reps[6,], rep(0,5), plot.reps[c(8,7),], rep(0,5), plot.reps[9,], rep(0,5), plot.reps[10,], rep(0,5), plot.reps[11,], rep(0,5), plot.reps[c(14,13,12),],rep(0,5), plot.reps[15:16,])

plot.demsb <- rbind(rep(0,5), plot.dems[1,], rep(0,5), plot.dems[2,], rep(0,5), plot.dems[3:4,], rep(0,5), plot.dems[5,], rep(0,5), plot.dems[6,], rep(0,5), plot.dems[c(8,7),], rep(0,5), plot.dems[9,], rep(0,5), plot.dems[10,], rep(0,5), plot.dems[11,], rep(0,5), plot.dems[c(14,13,12),],rep(0,5), plot.dems[15:16,])

textLab <- c("Low Capabilities", "High Capabilities", "Low Stakes", "High Stakes", "Dictatorship", "Democracy", "Mixed",  "Ally", "Adversary", "Established Leader", "New Leader", "No Military Service", "Some Military Service", "Long Military Service", "Female Leader", "Male Leader", "Target", "Initiator", "Against ally", "Against adversary", "Different leader, stood firm", "Same leader, stood firm", "Same leader, backed down", "Different leader, backed down", "Nothing", "Mobilized troops", "Public threat")

#### Figure 10: Heterogeneous treatment effects by partisanship
## Clean labels, etc. in post-production

dev.new(height=9, width=6.5)
par(mar=c(5.1,1.1,4.1,0), oma=c(0,4,0,0))
plot(plot.repsb[,1], nrow(plot.repsb):1, type="n", axes=FALSE, xlab="Average marginal component effect (AMCE)", ylab="",xlim=c(-0.3,0.2))

for (i in 1:nrow(plot.repsb)){
	points(plot.repsb[i,1], nrow(plot.repsb)-(i-1), pch=16)
	points(plot.demsb[i,1], nrow(plot.demsb)-(i-1)-0.25, pch=15, col="grey")
	lines(plot.repsb[i,c(2,5)], rep(nrow(plot.repsb)-(i-1),2))
	lines(plot.demsb[i,c(2,5)], rep(nrow(plot.demsb)-(i-1)-0.25,2), col="grey")
	lines(plot.repsb[i,c(3,4)], rep(nrow(plot.repsb)-(i-1),2), lwd=2)	
	lines(plot.demsb[i,c(3,4)], rep(nrow(plot.repsb)-(i-1)-0.25,2), lwd=2, col="grey")		
	text(-0.3, nrow(plot.repsb)-(i-1), textLab[i], cex=0.7)			
	}
abline(v=0)
axis(1)

## By foreign policy interest

#Low Interest vs High Interest
h_interest <- subset(dat.merge, dat.merge$interestFP>0.5)
l_interest <- subset(dat.merge,dat.merge$interestFP<=0.5)

#First for high interest
bootConjoint <- function(...){
	temp <- clusterBootS2(h_interest)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("h_interest", "l_interest", "bootConjoint", "clusterBootS2"))

#And then for low interest
system.time(boot.h_interest <- parSapply(cl, rep(1,1500), bootConjoint)) 
bootConjoint <- function(...){
	temp <- clusterBootS2(l_interest)
	mod.temp <- lm(Chosen ~ Capabilities + Stakes + RegimeType + actor +  NewLeader + milService + maleLeader + prevRole + prevOpponent + prevActLdr + curBehavior, data=temp)
	return(coef(mod.temp))
}

clusterExport(cl, list("h_interest", "l_interest", "bootConjoint", "clusterBootS2"))

system.time(boot.l_interest <- parSapply(cl, rep(1,1500), bootConjoint))

#Extract quantities of interest (so to speak)
plot.l_interest <- cbind(apply(boot.l_interest, 1, mean), apply(boot.l_interest, 1, quantile, c(0.025)), apply(boot.l_interest, 1, quantile, c(0.05)), apply(boot.l_interest, 1, quantile, c(0.95)), apply(boot.l_interest,1,quantile, c(0.975)))[-1,]

plot.h_interest <- cbind(apply(boot.h_interest, 1, mean), apply(boot.h_interest, 1, quantile, c(0.025)), apply(boot.h_interest, 1, quantile, c(0.05)), apply(boot.h_interest, 1, quantile, c(0.95)), apply(boot.h_interest,1,quantile, c(0.975)))[-1,]

#Now add baseline categories
plot.l_interestb <- rbind(rep(0,5), plot.l_interest[1,], rep(0,5), plot.l_interest[2,], rep(0,5), plot.l_interest[3:4,], rep(0,5), plot.l_interest[5,], rep(0,5), plot.l_interest[6,], rep(0,5), plot.l_interest[c(8,7),], rep(0,5), plot.l_interest[9,], rep(0,5), plot.l_interest[10,], rep(0,5), plot.l_interest[11,], rep(0,5), plot.l_interest[c(14,13,12),],rep(0,5), plot.l_interest[15:16,])

plot.h_interestb <- rbind(rep(0,5), plot.h_interest[1,], rep(0,5), plot.h_interest[2,], rep(0,5), plot.h_interest[3:4,], rep(0,5), plot.h_interest[5,], rep(0,5), plot.h_interest[6,], rep(0,5), plot.h_interest[c(8,7),], rep(0,5), plot.h_interest[9,], rep(0,5), plot.h_interest[10,], rep(0,5), plot.h_interest[11,], rep(0,5), plot.h_interest[c(14,13,12),],rep(0,5), plot.h_interest[15:16,])

textLab <- c("Low Capabilities", "High Capabilities", "Low Stakes", "High Stakes", "Dictatorship", "Democracy", "Mixed",  "Ally", "Adversary", "Established Leader", "New Leader", "No Military Service", "Some Military Service", "Long Military Service", "Female Leader", "Male Leader", "Target", "Initiator", "Against ally", "Against adversary", "Different leader, stood firm", "Same leader, stood firm", "Same leader, backed down", "Different leader, backed down", "Nothing", "Mobilized troops", "Public threat")

## Figure 11: Heterogeneous treatment effects by foreign policy interest
## Clean up labels in post-production

dev.new(height=9, width=6.5)
par(mar=c(5.1,1.1,4.1,0), oma=c(0,4,0,0))
plot(plot.l_interestb[,1], nrow(plot.l_interestb):1, type="n", axes=FALSE, xlab="Average marginal component effect (AMCE)", ylab="",xlim=c(-0.3,0.2))

for (i in 1:nrow(plot.l_interestb)){
	points(plot.l_interestb[i,1], nrow(plot.l_interestb)-(i-1), pch=15, col="grey")
	points(plot.h_interestb[i,1], nrow(plot.h_interestb)-(i-1)-0.25, pch=16)
	lines(plot.l_interestb[i,c(2,5)], rep(nrow(plot.l_interestb)-(i-1),2), col="grey")
	lines(plot.h_interestb[i,c(2,5)], rep(nrow(plot.h_interestb)-(i-1)-0.25,2))
	lines(plot.l_interestb[i,c(3,4)], rep(nrow(plot.l_interestb)-(i-1),2), lwd=2, col="grey")	
	lines(plot.h_interestb[i,c(3,4)], rep(nrow(plot.l_interestb)-(i-1)-0.25,2), lwd=2)		
	text(-0.3, nrow(plot.l_interestb)-(i-1), textLab[i], cex=0.7)			
	}
abline(v=0)
axis(1)

