# Replication script for
# Heermann/Koos/Leuffen 2022
# Who Deserves European Solidarity? How recipient characteristics shape public support for international medical and financial aid during COVID-19 


#please set working directory to location of dataset
setwd()

#load packages

library(tidyverse)
library(ggplot2)
library(stargazer)
library(margins)
library(cregg)
library(sjPlot)
library(stats)
library(estimatr)
library(patchwork)

##############
#load data

##survey I (April 2020)
w1 <- read_csv("surveyI.csv")
##survey II (May 2021)
w2 <- read_csv("surveyII.csv")

##perform listwise deletion of control variables
w1_subset <- w1 %>% drop_na()
w2_subset <- w2 %>% drop_na()

##############
#Analysis Survey I

###models with binary subgroup variables WITHOUT listwise deletion of control variables

###VMA 1 (April/May 2020)
w1_medical_m1 <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU, weights = gewichtRESPONDI, data= w1)
w1_medical_m2 <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_medical_m3 <- lm(solidhlth ~ altruism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_medical_m4 <- lm(solidhlth ~ cosmopolitanism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_medical_m5 <- lm(solidhlth ~ EU_identity_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)

###VFA 1 (April/May 2020)
w1_econ_m1 <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU, weights = gewichtRESPONDI, data= w1)
w1_econ_m2 <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_econ_m3 <- lm(solidecon ~ altruism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_econ_m4 <- lm(solidecon ~ cosmopolitanism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)
w1_econ_m5 <- lm(solidecon ~ EU_identity_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1)


###models with binary subgroup variables WITH listwise deletion of controls

###VMA 1 (April/May 2020)
w1_medical_m1_ld <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU, weights = gewichtRESPONDI, data= w1_subset)
w1_medical_m2_ld <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_medical_m3_ld <- lm(solidhlth ~ altruism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_medical_m4_ld <- lm(solidhlth ~ cosmopolitanism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_medical_m5_ld <- lm(solidhlth ~ EU_identity_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)

###VFA 1 (April/May 2020)
w1_econ_m1_ld <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU, weights = gewichtRESPONDI, data= w1_subset)
w1_econ_m2_ld <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_econ_m3_ld <- lm(solidecon ~ altruism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_econ_m4_ld <- lm(solidecon ~ cosmopolitanism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)
w1_econ_m5_ld <- lm(solidecon ~ EU_identity_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRESPONDI, data= w1_subset)


#Models without weights

###VMA 1 (April/May 2020)
w1_medical_m1_unweighted <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU, data= w1_subset)
w1_medical_m2_unweighted <- lm(solidhlth ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_medical_m3_unweighted <- lm(solidhlth ~ altruism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_medical_m4_unweighted <- lm(solidhlth ~ cosmopolitanism_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_medical_m5_unweighted <- lm(solidhlth ~ EU_identity_binary* (vigAgesund + vigAnacht + vigABundesland + vigAnonEU) + altruism_binary + leftright + female + age + edu + income + ost, data= w1_subset)

###VFA 1 (April/May 2020)
w1_econ_m1_unweighted <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU, data= w1_subset)
w1_econ_m2_unweighted <- lm(solidecon ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_econ_m3_unweighted <- lm(solidecon ~ altruism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_econ_m4_unweighted <- lm(solidecon ~ cosmopolitanism_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, data= w1_subset)
w1_econ_m5_unweighted <- lm(solidecon ~ EU_identity_binary* (vigBgesund + vigBnacht + vigBBundesland + vigBnonEU) + altruism_binary + leftright + female + age + edu + income + ost, data= w1_subset)


##############
#Analysis Survey II

###models with binary subgroup variables WITHOUT listwise deletion of control variables

###VMA 2 (May 2021)
w2_med_m1 <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order, weights = gewichtRespondi, data= w2)
w2_med_m2 <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_med_m3 <- lm(Vig2Help_SQ001 ~ altruism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_med_m4 <- lm(Vig2Help_SQ001 ~ cosmopolitanism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_med_m5 <- lm(Vig2Help_SQ001 ~ EU_identity_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)

###VFA 2 (May 2021)
w2_econ_m1 <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order, weights = gewichtRespondi, data= w2)
w2_econ_m2 <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_econ_m3 <- lm(Vig1Help_SQ001 ~ altruism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_econ_m4 <- lm(Vig1Help_SQ001 ~ cosmopolitanism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_econ_m5 <- lm(Vig1Help_SQ001 ~ EU_identity_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)


###models with binary subgroup variables WITH listwise deletion of controls

###VMA 2 (May 2021)
w2_med_m1_ld <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order, weights = gewichtRespondi, data= w2_subset)
w2_med_m2_ld <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_med_m3_ld <- lm(Vig2Help_SQ001 ~ altruism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_med_m4_ld <- lm(Vig2Help_SQ001 ~ cosmopolitanism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_med_m5_ld <- lm(Vig2Help_SQ001 ~ EU_identity_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)

###VFA 2 (May 2021)
w2_econ_m1_ld <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order, weights = gewichtRespondi, data= w2_subset)
w2_econ_m2_ld <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_econ_m3_ld <- lm(Vig1Help_SQ001 ~ altruism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_econ_m4_ld <- lm(Vig1Help_SQ001 ~ cosmopolitanism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)
w2_econ_m5_ld <- lm(Vig1Help_SQ001 ~ EU_identity_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2_subset)


#Models without weights

###VMA 2 (May 2021)
w2_med_m1_unweighted <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order, data= w2_subset)
w2_med_m2_unweighted <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_med_m3_unweighted <- lm(Vig2Help_SQ001 ~ altruism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_med_m4_unweighted <- lm(Vig2Help_SQ001 ~ cosmopolitanism_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_med_m5_unweighted <- lm(Vig2Help_SQ001 ~ EU_identity_binary* (EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m) + Order + altruism_binary + leftright + female + age + edu + income + ost, data= w2_subset)

###VFA 2 (May 2021)
w2_econ_m1_unweighted <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order, data= w2_subset)
w2_econ_m2_unweighted <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order + altruism_binary + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_econ_m3_unweighted <- lm(Vig1Help_SQ001 ~ altruism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_econ_m4_unweighted <- lm(Vig1Help_SQ001 ~ cosmopolitanism_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, data= w2_subset)
w2_econ_m5_unweighted <- lm(Vig1Help_SQ001 ~ EU_identity_binary* (EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f) + Order + altruism_binary + leftright + female + age + edu + income + ost, data= w2_subset)


##############
#Output: Regression Tables

###Table A3
TA3 <- stargazer::stargazer(w1_medical_m1, w1_medical_m2, w1_medical_m3, w1_medical_m4, w1_medical_m5, 
                                   type             = "html",
                                   out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA3.html", 
                                   title            = "Support for bilateral medical aid (April/May 2020)",
                                   dep.var.labels   = "Support for bilateral medical aid",
                                   model.numbers    = TRUE,
                                   star.cutoffs = c(0.05, 0.01, 0.001))

###Table A4
TA4 <- stargazer::stargazer(w1_econ_m1, w1_econ_m2, w1_econ_m3, w1_econ_m4, w1_econ_m5, 
                                    type             = "html",
                                    out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA4.html", 
                                    title            = "Support for bilateral financial aid (April/May 2020)",
                                    dep.var.labels   = "Support for bilateral financial aid",
                                    model.numbers    = TRUE,
                                    star.cutoffs = c(0.05, 0.01, 0.001))

###Table A5
TA5 <- stargazer::stargazer(w2_med_m1, w2_med_m2, w2_med_m3, w2_med_m4, w2_med_m5,
                                   type             = "html",
                                   out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA5.html", 
                                   title            = "Support for EU medical aid (May 2021)",
                                   dep.var.labels   = "Support for EU medical aid",
                                   model.numbers    = TRUE,
                                   star.cutoffs = c(0.05, 0.01, 0.001))

###Table A6
TA6 <- stargazer::stargazer(w2_econ_m1, w2_econ_m2, w2_econ_m3, w2_econ_m4, w2_econ_m5,
                                    type             = "html",
                                    out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA6.html", 
                                    title            = "Support for EU financial aid (May 2021)",
                                    dep.var.labels   = "Support for EU financial aid",
                                    model.numbers    = TRUE,
                                    star.cutoffs = c(0.05, 0.01, 0.001))

###Table A8
TA8 <- stargazer::stargazer(w1_medical_m1_ld, w1_medical_m2_ld, w1_medical_m3_ld, w1_medical_m4_ld, w1_medical_m5_ld, 
                                   type             = "html",
                                   out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA8.html", 
                                   title            = "Support for bilateral medical aid (April/May 2020)",
                                   dep.var.labels   = "Support for bilateral medical aid",
                                   model.numbers    = TRUE,
                                   star.cutoffs = c(0.05, 0.01, 0.001))

###Table A9
TA9 <- stargazer::stargazer(w1_econ_m1_ld, w1_econ_m2_ld, w1_econ_m3_ld, w1_econ_m4_ld, w1_econ_m5_ld, 
                                    type             = "html",
                                    out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA9.html", 
                                    title            = "Support for bilateral financial aid (April/May 2020)",
                                    dep.var.labels   = "Support for bilateral financial aid",
                                    model.numbers    = TRUE,
                                    star.cutoffs = c(0.05, 0.01, 0.001))

###Table A10
TA10 <- stargazer::stargazer(w2_med_m1_ld, w2_med_m2_ld, w2_med_m3_ld, w2_med_m4_ld, w2_med_m5_ld,
                                      type             = "html",
                                      out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA10.html", 
                                      title            = "Support for EU medical aid (May 2021)",
                                      dep.var.labels   = "Support for EU medical aid",
                                      model.numbers    = TRUE,
                                      star.cutoffs = c(0.05, 0.01, 0.001))

###Table A11
TA11 <- stargazer::stargazer(w2_econ_m1_ld, w2_econ_m2_ld, w2_econ_m3_ld, w2_econ_m4_ld, w2_econ_m5_ld,
                                       type             = "html",
                                       out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA11.html", 
                                       title            = "Support for EU financial aid (May 2021)",
                                       dep.var.labels   = "Support for EU financial aid",
                                       model.numbers    = TRUE,
                                       star.cutoffs = c(0.05, 0.01, 0.001))

###Table A12
TA12 <- stargazer::stargazer(w1_medical_m1_unweighted, w1_medical_m2_unweighted, 
                                              w1_medical_m3_unweighted, w1_medical_m4_unweighted, w1_medical_m5_unweighted, 
                                              type             = "html",
                                              out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA12.html", 
                                              title            = "Support for bilateral medical aid (April/May 2020)",
                                              dep.var.labels   = "Support for bilateral medical aid",
                                              model.numbers    = TRUE,
                                              star.cutoffs = c(0.05, 0.01, 0.001))

###Table A13
TA13 <- stargazer::stargazer(w1_econ_m1_unweighted, w1_econ_m2_unweighted, 
                                               w1_econ_m3_unweighted, w1_econ_m4_unweighted, w1_econ_m5_unweighted, 
                                               type             = "html",
                                               out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA13.html", 
                                               title            = "Support for bilateral financial aid (April/May 2020)",
                                               dep.var.labels   = "Support for bilateral financial aid",
                                               model.numbers    = TRUE,
                                               star.cutoffs = c(0.05, 0.01, 0.001))

###Table A14
TA14 <- stargazer::stargazer(w2_med_m1_unweighted, w2_med_m2_unweighted, 
                                              w2_med_m3_unweighted, w2_med_m4_unweighted, w2_med_m5_unweighted,
                                              type             = "html",
                                              out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA14.html", 
                                              title            = "Support for EU medical aid (May 2021)",
                                              dep.var.labels   = "Support for EU medical aid",
                                              model.numbers    = TRUE,
                                              star.cutoffs = c(0.05, 0.01, 0.001))

###Table A15
TA15 <- stargazer::stargazer(w2_econ_m1_unweighted, w2_econ_m2_unweighted, 
                                               w2_econ_m3_unweighted, w2_econ_m4_unweighted, w2_econ_m5_unweighted,
                                               type             = "html",
                                               out = "C:/Users/Max Heermann/Nextcloud/Covid-Survey/BJPS/Tables/TA15.html", 
                                               title            = "Support for EU financial aid (May 2021)",
                                               dep.var.labels   = "Support for EU financial aid",
                                               model.numbers    = TRUE,
                                               star.cutoffs = c(0.05, 0.01, 0.001))


##############
#Output: Figure 2
#Effects of recipient characteristics on support for medical (Vignette Medical Aid, VMA) and financial aid (Vignette Financial Aid, VFA) in April 2020 (I + II) and May 2021(III + IV). 

### AMCE Plots for Figure 2 (models without listwise deletion)

w1_medical_w_margin <- margins(w1_medical_m1)
w1_medical_w_gg <- as_tibble(summary(w1_medical_w_margin))
w1_medical_w_gg <- w1_medical_w_gg %>% 
  mutate(factor = case_when(factor == "vigABundesland" ~ "Community: German region",
                            factor == "vigAnonEU" ~ "Community: non-EU",
                            factor == "vigAgesund" ~ "Control: Public health system",
                            factor == "vigAnacht" ~ "Costs: Medical risk"))
w1_medical_plot <- ggplot(data = w1_medical_w_gg, 
                          aes(x = factor(factor, level=c('Costs: Medical risk', 'Community: non-EU', 'Community: German region', 'Control: Public health system')), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VMA 1") +
  theme(axis.text=element_text(size=12))


w1_econ_w_margin <- margins(w1_econ_m1)
w1_econ_w_gg <- as_tibble(summary(w1_econ_w_margin))
w1_econ_w_gg <- w1_econ_w_gg %>% 
  mutate(factor = case_when(factor == "vigBBundesland" ~ "Community: German region",
                            factor == "vigBnonEU" ~ "Community: non-EU",
                            factor == "vigBgesund" ~ "Control: Fiscal discipline",
                            factor == "vigBnacht" ~ "Costs: Tax increase"))
w1_econ_plot <- ggplot(data = w1_econ_w_gg, 
                       aes(x = factor(factor, level=c('Costs: Tax increase', 'Community: non-EU', 'Community: German region', 'Control: Fiscal discipline')), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() +
  coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VFA 1") +
  theme(axis.text=element_text(size=12))


w2_med_margin <- margins(w2_med_m1)
w2_med_gg <- as_tibble(summary(w2_med_margin)) %>% filter(factor != "Order")
w2_med_gg <- w2_med_gg %>% 
  mutate(factor = case_when(factor == "EU_control_m" ~ "Backward Control: COVID policy",
                            factor == "EU_need_recode_m" ~ "Need: Wealth",
                            factor == "init_efficiency_m" ~ "Forward Control: Admin capacity",
                            factor == "EU_democ_m" ~ "Community Norms: Rule of law",
                            factor == "EU_refugee_m" ~ "Reciprocity: Refugee admission"))
w2_med_plot <- ggplot(data = w2_med_gg, aes(x = reorder(factor, -AME), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VMA 2") +
  theme(axis.text=element_text(size=12))

w2_econ_margin <- margins(w2_econ_m1)
w2_econ_gg <- as_tibble(summary(w2_econ_margin)) %>% filter(factor != "Order")
w2_econ_gg <- w2_econ_gg %>% 
  mutate(factor = case_when(factor == "EU_control_f" ~ "Backward Control: COVID policy",
                            factor == "EU_need_recode_f" ~ "Need: Wealth",
                            factor == "init_efficiency_f" ~ "Forward Control: Admin capacity",
                            factor == "EU_democ_f" ~ "Community Norms: Rule of law",
                            factor == "EU_refugee_f" ~ "Reciprocity: Refugee admission"))
w2_econ_plot <- ggplot(data = w2_econ_gg, aes(x = reorder(factor, -AME), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VFA 2") +
  theme(axis.text=element_text(size=12))


### Figure 2
w1_medical_plot + w1_econ_plot + w2_med_plot + w2_econ_plot +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Effects of recipient characteristics on support for medical and financial aid to EU member states",
                  tag_levels = 'I')


##############
#Output: Figure A1. 
#Marginal effects based on linear probability models for dichotomized dependent variables (April/May 2020 & May 2021)

w1 <- w1 %>% 
  mutate(medical_dicho = case_when(solidhlth >= 5 ~ 1, TRUE ~ 0)) %>% 
  mutate(econ_dicho = case_when(solidecon >= 5 ~ 1, TRUE ~ 0))

w2 <- w2 %>% 
  mutate(medical_dicho = case_when(Vig2Help_SQ001 >= 5 ~ 1, TRUE ~ 0)) %>% 
  mutate(econ_dicho = case_when(Vig1Help_SQ001 >= 5 ~ 1, TRUE ~ 0))


w1_medical_dicho <- glm(medical_dicho ~ vigAgesund + vigAnacht + vigABundesland + vigAnonEU, weights = gewichtRESPONDI, family="binomial", data= w1)

w1_medical_dicho_margin <- margins(w1_medical_dicho)
w1_medical_dicho_gg <- as_tibble(summary(w1_medical_dicho_margin)) %>% 
  mutate(factor = case_when(factor == "vigABundesland" ~ "Community: German region",
                            factor == "vigAnonEU" ~ "Community: non-EU",
                            factor == "vigAgesund" ~ "Control: Public health system",
                            factor == "vigAnacht" ~ "Costs: Medical risk"))

w1_medical_dicho_plot <- ggplot(data = w1_medical_dicho_gg, 
                                aes(x = factor(factor, level=c('Costs: Medical risk', 'Community: non-EU', 'Community: German region', 'Control: Public health system')), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-0.3, 0.3)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VMA 1") +
  theme(axis.text=element_text(size=11))


w1_econ_dicho <- glm(econ_dicho ~ vigBgesund + vigBnacht + vigBBundesland + vigBnonEU, weights = gewichtRESPONDI, family="binomial", data= w1)

w1_econ_dicho_margin <- margins(w1_econ_dicho)
w1_econ_dicho_gg <- as_tibble(summary(w1_econ_dicho_margin)) %>% 
  mutate(factor = case_when(factor == "vigBBundesland" ~ "Community: German region",
                            factor == "vigBnonEU" ~ "Community: non-EU",
                            factor == "vigBgesund" ~ "Control: Fiscal discipline",
                            factor == "vigBnacht" ~ "Costs: Tax increase"))

w1_econ_dicho_plot <- ggplot(data = w1_econ_dicho_gg, 
                             aes(x = factor(factor, level=c('Costs: Tax increase', 'Community: non-EU', 'Community: German region', 'Control: Fiscal discipline')), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-0.3, 0.3)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VFA 1") +
  theme(axis.text=element_text(size=11))


w2_med_dicho <- glm(medical_dicho ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m, weights = gewichtRespondi, family = "binomial", data= w2)

w2_med_dicho_margin <- margins(w2_med_dicho)
w2_med_dicho_gg <- as_tibble(summary(w2_med_dicho_margin))
w2_med_dicho_gg <- w2_med_dicho_gg %>% 
  mutate(factor = case_when(factor == "EU_control_m" ~ "Backward Control: COVID policy",
                            factor == "EU_need_recode_m" ~ "Need: Wealth",
                            factor == "init_efficiency_m" ~ "Forward Control: Administrative capacity",
                            factor == "EU_democ_m" ~ "Community Norms: Rule of law",
                            factor == "EU_refugee_m" ~ "Reciprocity: Refugee admission"))

w2_med_dicho_plot <- ggplot(data = w2_med_dicho_gg, aes(x = reorder(factor, -AME), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-0.3, 0.3)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VMA 2") +
  theme(axis.text=element_text(size=11))


w2_econ_dicho <- glm(econ_dicho ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f, weights = gewichtRespondi, family = "binomial", data= w2)

w2_econ_dicho_margin <- margins(w2_econ_dicho)
w2_econ_dicho_gg <- as_tibble(summary(w2_econ_dicho_margin))
w2_econ_dicho_gg <- w2_econ_dicho_gg %>% 
  mutate(factor = case_when(factor == "EU_control_f" ~ "Backward Control: COVID policy",
                            factor == "EU_need_recode_f" ~ "Need: Wealth",
                            factor == "init_efficiency_f" ~ "Forward Control: Administrative capacity",
                            factor == "EU_democ_f" ~ "Community Norms: Rule of law",
                            factor == "EU_refugee_f" ~ "Reciprocity: Refugee admission"))

w2_econ_dicho_plot <- ggplot(data = w2_econ_dicho_gg, aes(x = reorder(factor, -AME), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-0.3, 0.3)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "VFA 2") +
  theme(axis.text=element_text(size=11))


###Figure A1
w1_medical_dicho_plot + w1_econ_dicho_plot + w2_med_dicho_plot + w2_econ_dicho_plot +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Effects of recipient characteristics on support for medical and financial aid",
                  tag_levels = 'I')


##############
#Subgroup analyses

##Survey II

###data preparation
w2_mm <- w2 %>% 
  mutate(Control_backward_vfa = case_when(EU_control_f == "1" ~ "rapid implementation",
                                          EU_control_f == "0" ~ "slow implementation")) %>% 
  mutate(Need_vfa = case_when(EU_need_recode_f == "1" ~ "rich",
                              EU_need_recode_f == "0" ~ "poor")) %>% 
  mutate(Control_forward_vfa = case_when(init_efficiency_f == "1" ~ "efficient public administration",
                                         init_efficiency_f == "0" ~ "inefficient public administration")) %>% 
  mutate(Norms_vfa = case_when(EU_democ_f == "1" ~ "honors rule of law",
                               EU_democ_f == "0" ~ "violates rule of law")) %>% 
  mutate(Reciprocity_vfa = case_when(EU_refugee_f == "1" ~ "strongly participates",
                                     EU_refugee_f == "0" ~ "hardly participates")) %>% 
  mutate(Control_backward_vma = case_when(EU_control_m == "1" ~ "rapid implementation",
                                          EU_control_m == "0" ~ "slow implementation")) %>% 
  mutate(Need_vma = case_when(EU_need_recode_m == "1" ~ "rich",
                              EU_need_recode_m == "0" ~ "poor")) %>% 
  mutate(Control_forward_vma = case_when(init_efficiency_m == "1" ~ "efficient public administration",
                                         init_efficiency_m == "0" ~ "inefficient public administration")) %>% 
  mutate(Norms_vma = case_when(EU_democ_m == "1" ~ "honors rule of law",
                               EU_democ_m == "0" ~ "violates rule of law")) %>% 
  mutate(Reciprocity_vma = case_when(EU_refugee_m == "1" ~ "strongly participates",
                                     EU_refugee_m == "0" ~ "hardly participates"))

w2_mm <- w2_mm %>% 
  mutate(altru = case_when(altruism >= 5 ~ "high",
                           altruism < 5 ~ "low")) %>% 
  mutate(cosmo = case_when(cosmopolitanism >= 5 ~ "high",
                           cosmopolitanism < 5 ~ "low")) %>%
  mutate(euident = case_when(EU_identity > 2 ~ "European identity",
                             EU_identity < 3 ~ "National identity")) %>% 
  mutate(altru_restrict = case_when(altruism >= 6 ~ "high",
                                    altruism < 6 ~ "low")) %>% 
  mutate(altru3 = case_when(altruism > 4 ~ "high",
                            altruism == 4 ~ "middle",
                            altruism < 4 ~ "low")) %>% 
  mutate(cosmo3 = case_when(cosmopolitanism > 4 ~ "high",
                            cosmopolitanism == 4 ~ "middle",
                            cosmopolitanism < 4 ~ "low"))

w2_mm$altru          <- factor(w2_mm$altru)
w2_mm$altru3         <- factor(w2_mm$altru3)
w2_mm$altru_restrict <- factor(w2_mm$altru_restrict)
w2_mm$cosmo          <- factor(w2_mm$cosmo)
w2_mm$cosmo3         <- factor(w2_mm$cosmo3)
w2_mm$euident        <- factor(w2_mm$euident)

w2_mm$Need_vfa              <- as.factor(w2_mm$Need_vfa)
w2_mm$Control_backward_vfa  <- as.factor(w2_mm$Control_backward_vfa)
w2_mm$Control_forward_vfa   <- as.factor(w2_mm$Control_forward_vfa)
w2_mm$Norms_vfa             <- as.factor(w2_mm$Norms_vfa)
w2_mm$Reciprocity_vfa       <- as.factor(w2_mm$Reciprocity_vfa)
w2_mm$Need_vma              <- as.factor(w2_mm$Need_vma)
w2_mm$Control_backward_vma  <- as.factor(w2_mm$Control_backward_vma)
w2_mm$Control_forward_vma   <- as.factor(w2_mm$Control_forward_vma)
w2_mm$Norms_vma             <- as.factor(w2_mm$Norms_vma)
w2_mm$Reciprocity_vma       <- as.factor(w2_mm$Reciprocity_vma)

attr(w2_mm$Need_vfa, "label")              <- "Need: Wealth"
attr(w2_mm$Control_backward_vfa, "label")  <- "Backward Control: COVID policy"
attr(w2_mm$Control_forward_vfa, "label")   <- "Forward Control: Admin capacity"
attr(w2_mm$Norms_vfa, "label")             <- "Community Norms: Rule of law"
attr(w2_mm$Reciprocity_vfa, "label")       <- "Reciprocity: Refugee admission"
attr(w2_mm$Need_vma, "label")              <- "Need: Wealth"
attr(w2_mm$Control_backward_vma, "label")  <- "Backward Control: COVID policy"
attr(w2_mm$Control_forward_vma, "label")   <- "Forward Control: Admin capacity"
attr(w2_mm$Norms_vma, "label")             <- "Community Norms: Rule of law"
attr(w2_mm$Reciprocity_vma, "label")       <- "Reciprocity: Refugee admission"


###altruism

mm_by_altru_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                    id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru)
plot_mm_by_altru_f <- plot(mm_by_altru_f, group = "altru", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_altru_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                    id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru)
plot_mm_by_altru_m <- plot(mm_by_altru_m, group = "altru", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))


###altruism three groups
mm_by_altru3_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                     id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru3)
plot_mm_by_altru3_f <- plot(mm_by_altru3_f, group = "altru3", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_altru3_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                     id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru3)
plot_mm_by_altru3_m <- plot(mm_by_altru3_m, group = "altru3", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 5.5)) +
  theme(axis.text=element_text(size=11))


###alturism restricted

mm_by_altru_restrict_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                             id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru_restrict)

plot_mm_by_altru_restrict_f <- plot(mm_by_altru_restrict_f, group = "altru_restrict", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_altru_restrict_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                             id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~altru_restrict)
plot_mm_by_altru_restrict_m <- plot(mm_by_altru_restrict_m, group = "altru_restrict", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))


###cosmopolitanism  

mm_by_cosmo_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                    id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~cosmo)
plot_mm_by_cosmo_f <- plot(mm_by_cosmo_f, group = "cosmo", legend_title = "Cosmopolitanism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_cosmo_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                    id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~cosmo)
plot_mm_by_cosmo_m <- plot(mm_by_cosmo_m, group = "cosmo", legend_title = "Cosmopolitanism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))


###cosmopolitanism three groups

mm_by_cosmo3_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                     id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~cosmo3)
plot_mm_by_cosmo3_f <- plot(mm_by_cosmo3_f, group = "cosmo3", legend_title = "Cosmopolitanism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(3.5, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_cosmo3_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                     id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~cosmo3)
plot_mm_by_cosmo3_m <- plot(mm_by_cosmo3_m, group = "cosmo3", legend_title = "Cosmopolitanism") +
  ggtitle("Medical Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(3.5, 5.5)) +
  theme(axis.text=element_text(size=11))


###EU identity

mm_by_euident_f <- cj(w2_mm, Vig1Help_SQ001 ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                      id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~euident)
plot_mm_by_euident_f <- plot(mm_by_euident_f, group = "euident", legend_title = "Identity", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))

mm_by_euident_m <- cj(w2_mm, Vig2Help_SQ001 ~ Need_vma + Control_backward_vma + Control_forward_vma + Norms_vma + Reciprocity_vma, 
                      id = ~id, weights = ~gewichtRespondi, estimate = "mm", by = ~euident)
plot_mm_by_euident_m <- plot(mm_by_euident_m, group = "euident", legend_title = "Identity") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5.5)) +
  theme(axis.text=element_text(size=11))


##Survey I

###data preparation
w1_mm <- w1 %>% 
  mutate(Control_vfa = case_when(vigBgesund == "1" ~ "past fiscal discipline",
                                 vigBgesund == "0" ~ "overly generous spending")) %>%
  mutate(Control_vma = case_when(vigAgesund == "1" ~ "well-developed healthcare system",
                                 vigAgesund == "0" ~ "past cuts to healthcare system")) %>%
  mutate(Community_vfa = case_when(vigB_region == "1" ~ "fin aid to another German region",
                                   vigB_region == "2" ~ "fin aid to EU country",
                                   vigB_region == "3" ~ "fin aid to non-EU country")) %>%
  mutate(Community_vma = case_when(vigA_region == "1" ~ "med aid to another German region",
                                   vigA_region == "2" ~ "med aid to EU country",
                                   vigA_region == "3" ~ "med aid to non-EU country")) %>%
  mutate(Costs_vfa = case_when(vigBnacht == "0" ~ "no change in tax rates",
                               vigBnacht == "1" ~ "higher tax rates")) %>%
  mutate(Costs_vma = case_when(vigAnacht == "0" ~ "disadvantages unlikely",
                               vigAnacht == "1" ~ "disadvantages cannot be ruled out")) 

w1_mm <- w1_mm %>% 
  mutate(altru = case_when(altruism >= 5 ~ "high",
                           altruism < 5 ~ "low")) %>%
  mutate(cosmo = case_when(cosmopolitanism >= 5 ~ "high",
                           cosmopolitanism < 5 ~ "low")) %>%
  mutate(euident = case_when(EU_identity > 2 ~ "European identity",
                             EU_identity < 3 ~ "National identity")) %>% 
  mutate(altru_restrict = case_when(altruism >= 6 ~ "high",
                                    altruism < 6 ~ "low")) %>% 
  mutate(altru3 = case_when(altruism > 4 ~ "high",
                            altruism == 4 ~ "middle",
                            altruism < 4 ~ "low")) %>% 
  mutate(cosmo3 = case_when(cosmopolitanism > 4 ~ "high",
                            cosmopolitanism == 4 ~ "middle",
                            cosmopolitanism < 4 ~ "low"))

w1_mm$altru          <- factor(w1_mm$altru)
w1_mm$altru3         <- factor(w1_mm$altru3)
w1_mm$altru_restrict <- factor(w1_mm$altru_restrict)
w1_mm$cosmo          <- factor(w1_mm$cosmo)
w1_mm$cosmo3         <- factor(w1_mm$cosmo3)
w1_mm$euident        <- factor(w1_mm$euident)

w1_mm$Control_vfa   <- factor(w1_mm$Control_vfa)
w1_mm$Control_vma   <- factor(w1_mm$Control_vma)
w1_mm$Community_vfa <- factor(w1_mm$Community_vfa)
w1_mm$Community_vma <- factor(w1_mm$Community_vma)
w1_mm$Costs_vfa     <- factor(w1_mm$Costs_vfa)
w1_mm$Costs_vma     <- factor(w1_mm$Costs_vma)

attr(w1_mm$Control_vfa, "label") <- "Control: Fiscal Discipline"
attr(w1_mm$Control_vma, "label") <- "Control: Public Health System"
attr(w1_mm$Community_vfa, "label") <- "Political Community"
attr(w1_mm$Community_vma, "label") <- "Political Community"
attr(w1_mm$Costs_vfa, "label") <- "Costs: Tax Increase"
attr(w1_mm$Costs_vma, "label") <- "Costs: Medical Risk"


###altruism

mm_w1_by_altru_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                       id = ~id, ~gewichtRESPONDI, estimate = "mm", by = ~altru)

plot_mm_w1_by_altru_f <- plot(mm_w1_by_altru_f, group = "altru", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_altru_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma,
                       id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~altru)

plot_mm_w1_by_altru_m <- plot(mm_w1_by_altru_m, group = "altru", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6)) +
  theme(axis.text=element_text(size=11))


###altruism 3 groups

mm_w1_by_altru3_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                        id = ~id, ~gewichtRESPONDI, estimate = "mm", by = ~altru3)

plot_mm_w1_by_altru3_f <- plot(mm_w1_by_altru3_f, group = "altru3", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2, 6)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_altru3_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma,
                        id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~altru3)

plot_mm_w1_by_altru3_m <- plot(mm_w1_by_altru3_m, group = "altru3", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2, 6)) +
  theme(axis.text=element_text(size=11))


###altruism restricted

mm_w1_by_altru_restrict_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                                id = ~id, ~gewichtRESPONDI, estimate = "mm", by = ~altru_restrict)

plot_mm_w1_by_altru_restrict_f <- plot(mm_w1_by_altru_restrict_f, group = "altru_restrict", legend_title = "Altruism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 6.5)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_altru_restrict_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma,
                                id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~altru_restrict)

plot_mm_w1_by_altru_restrict_m <- plot(mm_w1_by_altru_restrict_m, group = "altru_restrict", legend_title = "Altruism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 6.5)) +
  theme(axis.text=element_text(size=11))


### Cosmopolitanism

mm_w1_by_cosmo_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                       id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~cosmo)
plot_mm_w1_by_cosmo_f <- plot(mm_w1_by_cosmo_f, group = "cosmo", legend_title = "Cosmopolitanism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6.5)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_cosmo_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma, 
                       id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~cosmo)
plot_mm_w1_by_cosmo_m <- plot(mm_w1_by_cosmo_m, group = "cosmo", legend_title = "Cosmopolitanism") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6.5)) +
  theme(axis.text=element_text(size=11))


### Cosmopolitanism 3 groups

mm_w1_by_cosmo3_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                        id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~cosmo3)
plot_mm_w1_by_cosmo3_f <- plot(mm_w1_by_cosmo3_f, group = "cosmo3", legend_title = "Cosmopolitanism", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6.5)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_cosmo3_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma, 
                        id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~cosmo3)
plot_mm_w1_by_cosmo3_m <- plot(mm_w1_by_cosmo3_m, group = "cosmo3", legend_title = "Cosmopolitanism") +
  ggtitle("Medical Aid") +
  scale_color_grey(na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6.5)) +
  theme(axis.text=element_text(size=11))

plot_mm_w1_by_cosmo3_m + plot_mm_w1_by_cosmo3_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Cosmopolitanism",
                  tag_levels = 'I')


###EU identity

mm_w1_by_euident_f <- cj(w1_mm, solidecon ~ Control_vfa + Community_vfa + Costs_vfa, 
                         id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~euident)
plot_mm_w1_by_euident_f <- plot(mm_w1_by_euident_f, group = "euident", feature_headers = TRUE, legend_title = "Identity", legend_pos = "none") +
  ggtitle("Financial Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6)) +
  theme(axis.text=element_text(size=11))

mm_w1_by_euident_m <- cj(w1_mm, solidhlth ~ Control_vma + Community_vma + Costs_vma, 
                         id = ~id, weights = ~gewichtRESPONDI, estimate = "mm", by = ~euident)
plot_mm_w1_by_euident_m <- plot(mm_w1_by_euident_m, group = "euident", legend_title = "Identity") +
  ggtitle("Medical Aid") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(2.5, 6)) +
  theme(axis.text=element_text(size=11))


##############
#Output: subgroup analysis figures

#Figure 3: Altruism (Survey II)
plot_mm_by_altru_m + plot_mm_by_altru_f +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Altruism",
                  tag_levels = 'I')

#Figure 4: EU identity (Survey II)
plot_mm_by_euident_m + plot_mm_by_euident_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: European identity",
                  tag_levels = 'I')

#Figure 5: Cosmopolitanism (Survey II)
plot_mm_by_cosmo_m + plot_mm_by_cosmo_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Cosmopolitanism",
                  tag_levels = 'I')

#Figure A2: Altruism (Survey I)
plot_mm_w1_by_altru_m + plot_mm_w1_by_altru_f +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Altruism",
                  tag_levels = 'I')

#Figure A3: EU identity (Survey I)
plot_mm_w1_by_euident_m + plot_mm_w1_by_euident_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: European identity",
                  tag_levels = 'I')

#Figure A4: Cosmopolitanism (Survey I)
plot_mm_w1_by_cosmo_m + plot_mm_w1_by_cosmo_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Cosmopolitanism",
                  tag_levels = 'I')

#Figure A5: Altruism (3 groups, Survey II)
plot_mm_by_altru3_m + plot_mm_by_altru3_f +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Altruism",
                  tag_levels = 'I')

#Figure A6: Cosmopolitanism (3 groups, Survey II)
plot_mm_by_cosmo3_m + plot_mm_by_cosmo3_f + 
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Cosmopolitanism",
                  tag_levels = 'I')

#Figure A11: Altruism (alternative classification, Survey I)
plot_mm_w1_by_altru_restrict_m + plot_mm_w1_by_altru_restrict_f +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Altruism",
                  tag_levels = 'I')

#Figure A12: Altruism (alternative classification, Survey II)
plot_mm_by_altru_restrict_m + plot_mm_by_altru_restrict_f +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Support for aid among respondent subgroups: Altruism",
                  tag_levels = 'I')


##############
#Appendix K: Interaction effects between altruism and reciprocity/backward control

##altruism x reciprocity
w2_med_altru_m1 <- lm(Vig2Help_SQ001 ~ EU_control_m + EU_need_recode_m + init_efficiency_m + EU_democ_m + as.factor(altruism_binary) * as.factor(EU_refugee_m) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_econ_altru_m1 <- lm(Vig1Help_SQ001 ~ EU_control_f + EU_need_recode_f + init_efficiency_f + EU_democ_f + as.factor(altruism_binary)* as.factor(EU_refugee_f) + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)

int_reci_w2_med <- plot_model(w2_med_altru_m1, type = "pred", terms = c("altruism_binary", "EU_refugee_m"), legend.title = "Reciprocity") +
  labs(x = "Altruism", y = "Support for Medical Aid", title = "Predicted Values VMA 2")
int_reci_w2_econ <- plot_model(w2_econ_altru_m1, type = "pred", terms = c("altruism_binary","EU_refugee_f"), legend.title = "Reciprocity") +
  labs(x = "Altruism", y = "Support for Financial Aid", title = "Predicted Values VFA 2")

###Figure A7
int_reci_w2_med + int_reci_w2_econ +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Interaction Effects: Altruismus x Reciprocity",
                  tag_levels = 'I')


##altruism x control
w2_med_altru_m2 <- lm(Vig2Help_SQ001 ~ as.factor(altruism_binary)* as.factor(EU_control_m) + EU_need_recode_m + init_efficiency_m + EU_democ_m + EU_refugee_m + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)
w2_econ_altru_m2 <- lm(Vig1Help_SQ001 ~ as.factor(altruism_binary)* as.factor(EU_control_f) + EU_need_recode_f + init_efficiency_f + EU_democ_f + EU_refugee_f + Order + cosmopolitanism_binary + EU_identity_binary + leftright + female + age + edu + income + ost, weights = gewichtRespondi, data= w2)

int_control_w2_med <- plot_model(w2_med_altru_m2, type = "pred", terms = c("altruism_binary", "EU_control_m"), legend.title = "Control: COVID Policy") +
  labs(x = "Altruism", y = "Support for Medical Aid", title = "Predicted Values VMA 2")
int_control_w2_econ <- plot_model(w2_econ_altru_m2, type = "pred", terms = c("altruism_binary", "EU_control_f"), legend.title = "Control: COVID Policy") +
  labs(x = "Altruism", y = "Support for Financial Aid", title = "Predicted Values VFA 2")

###Figure A8
int_control_w2_med + int_control_w2_econ +
  plot_layout(ncol = 2) +
  plot_annotation(title = "Interaction Effects: Altruismus x Control",
                  tag_levels = 'I')


##############
#Appendix L: Additional medical and financial aid vignette experiments (November 2020)

##load and prepare data
w_add <- read_csv("surveyIII.csv")

w_add <- w_add %>% mutate(migration_binary = case_when(migration <  5 ~ 0,
                                                       migration >= 5 ~ 1))

##main analysis of vignettes
w_add_medical <- lm(init1 ~ Preparedness + Medical_risk + Reciprocity, weights = gewichtRESPONDI_W2, data= w_add)

w_add_medical_margin <- margins(w_add_medical)
w_add_medical_gg <- as_tibble(summary(w_add_medical_margin)) %>% 
  mutate(factor = case_when(factor == "Medical_risk" ~ "Costs: Medical risk", 
                            factor == "Reciprocity" ~ "Reciprocity: Medical aid",
                            factor == "Preparedness" ~ "Backward Control: COVID policy"))

w_add_medical_plot <- ggplot(data = w_add_medical_gg, aes(x = factor(factor, level=c('Costs: Medical risk', 'Reciprocity: Medical aid', 'Backward Control: COVID policy')), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "Medical Aid") +
  theme(axis.text=element_text(size=10))


w_add_econ <- lm_robust(EUvig ~ EU_kontrolle + EU_need + EU_effizienz + EU_demok + EU_flucht, clusters = id_w2, se_type = "stata", weights = gewichtRESPONDI_W2, data= w_add)

w_add_econ_margin <- margins(w_add_econ)
w_add_econ_gg <- as_tibble(summary(w_add_econ_margin))
w_add_econ_gg <- w_add_econ_gg %>% 
  mutate(factor = case_when(factor == "EU_kontrolle" ~ "Backward Control: COVID policy",
                            factor == "EU_need" ~ "Need: Wealth",
                            factor == "EU_effizienz" ~ "Forward Control: Admin capacity",
                            factor == "EU_demok" ~ "Community Norms: Rule of law",
                            factor == "EU_flucht" ~ "Reciprocity: Refugee admission"))

w_add_econ_plot <- ggplot(data = w_add_econ_gg, aes(x = reorder(factor, -AME), y = AME, ymin = lower, ymax = upper)) +
  scale_y_continuous(limits = c(-1.25, 1.25)) +
  geom_hline(yintercept = 0, color = "black", linetype="dashed") +
  geom_pointrange() + coord_flip() +
  labs(x = NULL, y = "Average Marginal Component Effect", title = "Financial Aid") +
  theme(axis.text=element_text(size=10))

##Figure A9
w_add_medical_plot + w_add_econ_plot + 
  plot_layout(ncol=2) + 
  plot_annotation(title = "Effects of recipient characteristics on support for medical and financial aid (November 2020)",
                  tag_levels = 'I')


##subgroup analysis according to migration attitudes
w_add_mm <- w_add %>% 
  mutate(Control_backward_vfa = case_when(EU_kontrolle == "1" ~ "rapid implementation",
                                          EU_kontrolle == "0" ~ "slow implementation")) %>% 
  mutate(Need_vfa = case_when(EU_need == "1" ~ "rich",
                              EU_need == "0" ~ "poor")) %>% 
  mutate(Control_forward_vfa = case_when(EU_effizienz == "1" ~ "efficient public administration",
                                         EU_effizienz == "0" ~ "inefficient public administration")) %>% 
  mutate(Norms_vfa = case_when(EU_demok == "1" ~ "honors rule of law",
                               EU_demok == "0" ~ "violates rule of law")) %>% 
  mutate(Reciprocity_vfa = case_when(EU_flucht == "1" ~ "strongly participates",
                                     EU_flucht == "0" ~ "hardly participates")) %>% 
  mutate(migration_binary = case_when(migration <  5 ~ "pro migration",
                                      migration >= 5 ~ "against migration"))

w_add_mm$migration_binary <- as.factor(w_add_mm$migration_binary)
w_add_mm$EU_kontrolle     <- as.factor(w_add_mm$EU_kontrolle)
w_add_mm$EU_need          <- as.factor(w_add_mm$EU_need)
w_add_mm$EU_effizienz     <- as.factor(w_add_mm$EU_effizienz)
w_add_mm$EU_demok         <- as.factor(w_add_mm$EU_demok)
w_add_mm$EU_flucht        <- as.factor(w_add_mm$EU_flucht)

w_add_mm$Need_vfa              <- as.factor(w_add_mm$Need_vfa)
w_add_mm$Control_backward_vfa  <- as.factor(w_add_mm$Control_backward_vfa)
w_add_mm$Control_forward_vfa   <- as.factor(w_add_mm$Control_forward_vfa)
w_add_mm$Norms_vfa             <- as.factor(w_add_mm$Norms_vfa)
w_add_mm$Reciprocity_vfa       <- as.factor(w_add_mm$Reciprocity_vfa)

attr(w_add_mm$Need_vfa, "label")              <- "Need: Wealth"
attr(w_add_mm$Control_backward_vfa, "label")  <- "Backward Control: COVID policy"
attr(w_add_mm$Control_forward_vfa, "label")   <- "Forward Control: Admin capacity"
attr(w_add_mm$Norms_vfa, "label")             <- "Community Norms: Rule of law"
attr(w_add_mm$Reciprocity_vfa, "label")       <- "Reciprocity: Refugee admission"


w_add_mm_migration <- cj(w_add_mm, EUvig ~ Need_vfa + Control_backward_vfa + Control_forward_vfa + Norms_vfa + Reciprocity_vfa, 
                      id = ~id_w2, weights = ~gewichtRESPONDI_W2, estimate = "mm", by = ~migration_binary)

##Figure A10
w_add_mm_migration_plot <- plot(w_add_mm_migration, group = "migration_binary", legend_title = "Migration") +
  ggtitle("Financial Aid (November 2020)") +
  scale_color_manual(values=c("black", "darkgrey"), na.translate = FALSE) +
  scale_x_continuous(limits = c(3, 5)) +
  theme(axis.text=element_text(size=11))
w_add_mm_migration_plot


############################
#Appendix N: Public support for the ‘Next Generation EU’ recovery program in Germany

##prepare data
w_add <- w_add %>% mutate(vote_intention = case_when(inst_v5 == 1 ~ "CDU/CSU",
                                               inst_v5 == 2 ~ "SPD",
                                               inst_v5 == 3 ~ "FDP",
                                               inst_v5 == 4 ~ "Die Linke",
                                               inst_v5 == 5 ~ "AfD",
                                               inst_v5 == 6 ~ "Bündnis 90/Die Grünen",
                                               inst_v5 == 7 ~ "other"))

w_add <- w_add %>% mutate(eurecoveryd3agree = case_when(EU == 1 ~ "disagree",
                                                  EU == 2 ~ "disagree",
                                                  EU == 3 ~ "disagree",
                                                  EU == 4 ~ "neither",
                                                  EU == 5 ~ "agree",
                                                  EU == 6 ~ "agree",
                                                  EU == 7 ~ "agree"))

w_add_eurecovery <- w_add %>% filter(!is.na(eurecoveryd3agree))

w_add_partysubgroups_eurecovery <- w_add %>% filter(!is.na(eurecoveryd3agree)) %>% 
  filter(!is.na(vote_intention)) %>% 
  filter(vote_intention != "other")

##plot overall support
eurecovery_w_add <- ggplot(data = w_add_eurecovery,
                        mapping = aes(x = eurecoveryd3agree)) +
  geom_bar(position = "dodge",
           mapping = aes(y = ..prop.., group=1)) +
  expand_limits(y = c(0, 0.7)) +
  labs(x = "Support",
       y = "Proportion",
       title = "All respondents")

###plot support by party
eurecovery_byparty_w_add <- ggplot(data = w_add_partysubgroups_eurecovery,
                                mapping = aes(x = eurecoveryd3agree)) +
  geom_bar(position = "dodge",
           mapping = aes(y = ..prop.., group = vote_intention)) +
  facet_wrap(~ vote_intention, ncol = 3) +
  expand_limits(y = c(0, 0.7)) +
  labs(x = "Support",
       y = "Proportion",
       title = "Respondents by vote intention")

###A13
eurecovery_w_add / eurecovery_byparty_w_add + 
  plot_annotation(title = "Support for 'Next Generation EU' recovery program", tag_levels = 'I')

