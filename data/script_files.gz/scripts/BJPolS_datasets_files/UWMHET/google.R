# "Media's Influence on LGBTQ Support Across Africa" by Stephen Winkler

# Code to generate Google search trends Figures/Tables:
#   - Figure A.7 (google searches in Kenya)
#   - Figure A.8 (google searches in Kenya & UK)
#   - Table A.18 (rising topics in Kenya)
#   - Table A.19 (rising topics in 10 random countries)

rm(list=ls()) # clear environment
source("Rprofile.R") # setup Rprofile (load packages, etc.)

# Load data
kenya_2017 <- read.csv("data-raw/google_search/KE_2017_gay.csv" ) 
uk_2017 <- read.csv("data-raw/google_search/UK_2017_gay.csv")

# Format data
colnames(kenya_2017) <- c("date", "number") #meaningful column names
kenya_2017 <- kenya_2017[-1,] #remove extra row
kenya_2017$number <- as.character(kenya_2017$number) #convert to character first so that ..
kenya_2017$number <- as.numeric(kenya_2017$number) # when we convert to numeric it doesn't use factors.
kenya_2017 <- kenya_2017 %>% mutate(country = "Kenya") # add column for country
kenya_2017$date = as.Date (kenya_2017$date, "%m/%d") # convert date to Date format

colnames(uk_2017) <- c("date", "number") #meaningful column names
uk_2017 <- uk_2017[-1,] #remove extra row
uk_2017$number <- as.character(uk_2017$number) #convert to character first so that ..
uk_2017$number <- as.numeric(uk_2017$number) # when we convert to numeric it doesn't use factors.
uk_2017 <- uk_2017 %>% mutate(country = "United Kingdom") # add column for country
uk_2017$date = as.Date (uk_2017$date, "%m/%d") # convert date to Date format

joined_data <- rbind(kenya_2017, uk_2017) 
joined_data$country <- as.factor(joined_data$country)

# Plot Kenya Trends for 2017
google_ke_17 <- 
  ggplot(kenya_2017, aes(date, number)) +
  geom_line() + geom_point() + 
  ylim(0,100) +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(date_breaks = "1 month", # show labels for every month
               date_labels = "%b %d" ) + # formate labels to show Month and Day
  ylab("Relative Interest over Time (Percent)") + theme_bw()
  #ggtitle("Relative Interest in Google Searches for 'Gay' (Jan 23-Oct 15, 2017 in Kenya)")
google_ke_17
ggsave(filename = "figures/google_ke_17.pdf", plot = google_ke_17,
       width = 8, height = 4) #Save it to directory

# Plot UK Trends for 2017
google_uk_17 <- 
  ggplot(uk_2017, aes(date, number)) +
  geom_line() + geom_point() + 
  ylim(0,100) +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(date_breaks = "1 month", # show labels for every month
               date_labels = "%b %d" ) + # formate labels to show Month and Day
  ylab("Relative Interest over Time (Percent)") + theme_bw()
#ggtitle("Relative Interest in Google Searches for 'Gay' (Jan 23-Oct 15, 2017 in Kenya)")
google_uk_17
ggsave(filename = "figures/google_uk_17.pdf", plot = google_uk_17,
       width = 8, height = 4) #Save it to directory

# Plot Kenya & UK Trends for 2017
google_uk_ke_17 <- 
  ggplot(joined_data, aes(x=date, y=number, linetype = country, color = country)) +
  geom_line( ) +
  scale_colour_grey(start=0,end=0.1) +
  #scale_color_manual(name = "Country ",
  #                   values = c("black", "gray80")) + 
  #values = rev(brewer.pal(5, "Paired"))) +
  ylim(0,100) +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(date_breaks = "1 month", # show labels for every month
               date_labels = "%b %d" ) + # formate labels to show Month and Day
  ylab("Relative Interest over Time (Percent)") + theme_bw()
#ggtitle("Relative Interest in Google Searches for 'Gay' (Jan 23-Oct 15, 2017 in Kenya)")
google_uk_ke_17
ggsave(filename = "figures/google_uk_ke_17.pdf", plot = google_uk_ke_17,
       width = 9, height = 4) #Save it to directory

# Top Topics in Kenya for period which I have radio content
ke_topics <- read.csv("data-raw/google_search/KE_2017_related_topics.csv",
                      header = TRUE, sep = ",") %>%
#  dplyr::select(-X) %>%
  dplyr::filter(row_number() <6)
columns <- c("Top Topics", "Relative Popularity", "Rising Topics")
colnames(ke_topics) <- columns

# Generate Latex table of top topics in Kenya: Table A.18
stargazer(ke_topics, summary = FALSE, colnames = TRUE, rownames = FALSE,
          label = "kenya_topics")

# Rising topics in 10 random countries
myData <- readRDS("data/afrobarometer.rds")
myData <- subset(myData, !is.na(sexuality)) # remove countries w/o data
set.seed(1616)
sample(unique(myData$country), 10, replace = FALSE)

topics <- read.csv("data-raw/google_search/topics_2012to2017/all_topics.csv",
                   header = TRUE, sep = ",") %>%
  dplyr::select(-Popularity.1)
columns <- c("Country", "Top Topics", "Relative Popularity", "Rising Topics")
colnames(topics) <- columns

# Generate Latex table of top topics in 10 random countries: Table A.19
stargazer(topics, summary = FALSE, colnames = TRUE, rownames = FALSE,
          label = "all_topics")
