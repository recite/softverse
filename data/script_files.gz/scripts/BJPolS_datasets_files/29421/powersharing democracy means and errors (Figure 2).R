
#This file creates Figure 2 for:
#Strøm, Kaare, Scott Gates, Benjamin A.T. Graham and Håvard Strand. “Inclusion, Dispersion, and Constraint: Powersharing in the World’s States, 1975-2010.” 


rm(list=ls(all=TRUE))
#setwd("/Users/bengraham1/Dropbox/Collaborative Research/Powersharing/Dataset Introduction Paper/Country Year Data/")
library(foreign)
library(Hmisc)
d <- read.dta("for democracy pic June2013.dta")

attach(d)

#war groups
incdem_mean<- mean(na.omit(d$inclusive[d$aclp_democracy==1]))
incautoc_mean<- mean(na.omit(d$inclusive[d$aclp_democracy==0]))
incmeans<-c(incdem_mean, incautoc_mean)

funcdem_mean<- mean(na.omit(d$funcdisp[d$aclp_democracy==1]))
funcautoc_mean<- mean(na.omit(d$funcdisp[d$aclp_democracy==0]))
funcmeans<-c(funcdem_mean, funcautoc_mean)

terrdem_mean<- mean(na.omit(d$terrdisp[d$aclp_democracy==1]))
terrautoc_mean<- mean(na.omit(d$terrdisp[d$aclp_democracy==0]))
terrmeans<-c(terrdem_mean, terrautoc_mean)


stderr <- function(x) sqrt(var(x,na.rm=TRUE)/length(na.omit(x)))


incdem_se<- stderr(inclusive[d$aclp_democracy==1])
incautoc_se<- stderr(inclusive[d$aclp_democracy==0])
incses<-c(incdem_se, incautoc_se)

funcdem_se<- stderr(funcdisp[d$aclp_democracy==1])
funcautoc_se<-stderr(funcdisp[d$aclp_democracy==0])
funcses<-c(funcdem_se, funcautoc_se)

terrdem_se<- stderr(terrdisp[d$aclp_democracy==1])
terrautoc_se<- stderr(terrdisp[d$aclp_democracy==0])
terrses<-c(terrdem_se, terrautoc_se)

regmeans <- rbind(incmeans, funcmeans, terrmeans)

groupmeans <- c(incautoc_mean, funcautoc_mean, terrautoc_mean, incdem_mean, funcdem_mean, terrdem_mean)
groupses <- c(incautoc_se, funcautoc_se, terrautoc_se, incdem_se, funcdem_se, terrdem_se)


cihighs <-(groupmeans+(1.96*groupses))
cihighs


cilows <-(groupmeans-(1.96*groupses))
cilows

rawnames<-c('Democracies','Autocracies')
fnames<-factor(rawnames)

colnames(regmeans)<-rawnames

par(mar=c(4,10,5,1))

dotchart(regmeans, labels=c('Inclusive Powersharing', 'Constraining Powersharing', 'Dispersive Powersharing'), 
xlim=c(-.5,.6), pch=19) 
abline (v=0, lty=5)

mtext("Figure 2: Mean Values of Powersharing" , side = 3, cex = 1.5, line = 2.2, at=-.33)
mtext("by Regime Type", side = 3, cex = 1.5, line = .8, at=-.33)
mtext("Each type of powersharing has a standard deviation of one and an overall mean of zero.", side = 1, cex = .8, line = 2.2, at = -.33)

#stop here to keep it simple


SEQ<- seq(10)


 for(i in 1:3){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i], SEQ[i]), lwd=2)
 }

 for(i in 4:6){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i+2], SEQ[i+2]), lwd=2)
 }

 for(i in 7:9){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i+4], SEQ[i+4]), lwd=2)
 }
