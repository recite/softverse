####################################################################################
#
# Replication material for "Do Disabled Candidates Represent Disabled Citizens?"
# Stefanie Reher
# British Journal of Political Science, 2020
#
####################################################################################

### Contents:
  # Preparation
  # 1) Descriptives: disability among citizens and candidates (Table 1)
  # 2) Effects of disability on citizen and candidate preferences (Figure 2; Tables S3 + S4)
  # [Generate dyad data: external script]
  # 3) Effects of shared disability on dyadic preference congruence (Figure 3; Tables S5 + S6)
  # 4) Supplementary Information: Table S2; Figue S1; Figure S2


### Clear, install and load packages

rm(list=ls())

install.packages("survey")
install.packages("stargazer")
install.packages("ggplot2")
install.packages("gmodels")
install.packages("lmerTest")
install.packages("dplyr")
install.packages("tidyr")

library(survey)
library(stargazer)
library(ggplot2)
library(gmodels)
library(lmerTest)
library(dplyr)
library(tidyr)

# Set working directory: enter path to folder where replication files are saved and generated files will be stored:
setwd("[...]")

####################################################################################

# Load datasets for 1) and 2)

# Citizen data: BES Internet Panel, Wave 6
BES <- read.csv("BES.csv")

# Candidate data: 2015 Representative Audit of Britain
RAB <- read.csv("RAB.csv")

# Apply weights (BES poststratification weight, RAB weight to adjust to numbers of party candidates in election)

BES.w <- svydesign(ids = ~1, data = BES, weights = ~wt_core_W6)
RAB.w <- svydesign(ids = ~1, data = RAB, weights = ~weight)

####################################################################################

### 1) Descriptives: disability among citizens and candidates (Table 1 and in text)

### Percentage of disabled citizens and candidates

# Citizens: 
length(BES$id)
prop.table(svytable(~disability, design = BES.w))

# Candidates:
length(RAB$id)
prop.table(table(RAB$disability)) # raw numbers 
prop.table(svytable(~disability, design = RAB.w)) # weighted

### Disabled candidates by party (Table 1)
table(RAB$disability, RAB$party)
table(RAB$disability)


####################################################################################

# 2) Effects of disability on citizen and candidate preferences (Figure 2)

#### Left-right
BES$lr.sample.BES <- NA
BES$lr.sample.BES[!is.na(BES$lr.n) & !is.na(BES$disability) & !is.na(BES$female) & 
                    !is.na(BES$age) & !is.na(BES$party)] <- 1
BES.lr <- subset(BES, !is.na(BES$lr.sample.BES))
BES.w.lr <- svydesign(ids = ~1, data = BES.lr, weights = BES.lr$wt_core_W6)

RAB$lr.sample.RAB <- NA
RAB$lr.sample.RAB[!is.na(RAB$lr.n) & !is.na(RAB$disability) & !is.na(RAB$female) & 
                    !is.na(RAB$age) & !is.na(RAB$party1)] <- 1
RAB.lr <- subset(RAB, !is.na(RAB$lr.sample.RAB))
RAB.w.lr <- svydesign(ids = ~1, data = RAB.lr, weights = RAB.lr$weight)

# Model 1: disability, female, age
lr.model1.BES <- (svyglm(lr.n ~ disability + female + age, design=BES.w.lr))
summary(lr.model1.BES) 
length(lr.model1.BES$fitted.values)

lr.model1.RAB <- svyglm(lr.n ~ disability + female + age, design=RAB.w.lr)
summary(lr.model1.RAB)
length(lr.model1.RAB$fitted.values)

# Model 2: + party
lr.model2.BES <- (svyglm(lr.n ~ disability + female + age + party, design=BES.w.lr))
summary(lr.model2.BES)

lr.model2.RAB <- svyglm(lr.n ~ disability + female + age + party1, design=RAB.w.lr)
summary(lr.model2.RAB) 

##########################################

### Public spending cuts

BES$pubspend1.sample.BES <- NA
BES$pubspend1.sample.BES[!is.na(BES$pubspend1.n) & !is.na(BES$disability) & !is.na(BES$female) & 
                           !is.na(BES$age) & !is.na(BES$party)] <- 1
BES.pubspend1 <- subset(BES, !is.na(BES$pubspend1.sample.BES))
BES.w.pubspend1 <- svydesign(ids = ~1, data = BES.pubspend1, weights = BES.pubspend1$wt_core_W6)

RAB$pubspend1.sample.RAB <- NA
RAB$pubspend1.sample.RAB[!is.na(RAB$pubspend1.n) & !is.na(RAB$disability) & !is.na(RAB$female) & 
                           !is.na(RAB$age) & !is.na(RAB$party1)] <- 1
RAB.pubspend1 <- subset(RAB, !is.na(RAB$pubspend1.sample.RAB))
RAB.w.pubspend1 <- svydesign(ids = ~1, data = RAB.pubspend1, weights = RAB.pubspend1$weight)

# Model 1: disability, female, age
pubspend1.model1.BES <- (svyglm(pubspend1.n ~ disability + female + age, design=BES.w.pubspend1))
summary(pubspend1.model1.BES) 
length(pubspend1.model1.BES$fitted.values)

pubspend1.model1.RAB <- svyglm(pubspend1.n ~ disability + female + age, design=RAB.w.pubspend1)
summary(pubspend1.model1.RAB) 
length(pubspend1.model1.RAB$fitted.values) 

# Model 2: + party
pubspend1.model2.BES <- (svyglm(pubspend1.n ~ disability + female + age + party, design=BES.w.pubspend1))
summary(pubspend1.model2.BES) 

pubspend1.model2.RAB <- svyglm(pubspend1.n ~ disability + female + age + party1, design=RAB.w.pubspend1)
summary(pubspend1.model2.RAB) 

#######################################

#### NHS spending

BES$nhsspend1.sample.BES <- NA
BES$nhsspend1.sample.BES[!is.na(BES$nhsspend1.n) & !is.na(BES$disability) & !is.na(BES$female) & 
                           !is.na(BES$age) & !is.na(BES$party)] <- 1
BES.nhsspend1 <- subset(BES, !is.na(BES$nhsspend1.sample.BES))
BES.w.nhsspend1 <- svydesign(ids = ~1, data = BES.nhsspend1, weights = BES.nhsspend1$wt_core_W6)

RAB$nhsspend1.sample.RAB <- NA
RAB$nhsspend1.sample.RAB[!is.na(RAB$nhsspend1.n) & !is.na(RAB$disability) & !is.na(RAB$female) & 
                           !is.na(RAB$age) & !is.na(RAB$party1)] <- 1
RAB.nhsspend1 <- subset(RAB, !is.na(RAB$nhsspend1.sample.RAB))
RAB.w.nhsspend1 <- svydesign(ids = ~1, data = RAB.nhsspend1, weights = RAB.nhsspend1$weight)

# Model 1: only disability, female, age
nhsspend1.model1.BES <- (svyglm(nhsspend1.n ~ disability + female + age, design=BES.w.nhsspend1))
summary(nhsspend1.model1.BES) 
length(nhsspend1.model1.BES$fitted.values)

nhsspend1.model1.RAB <- svyglm(nhsspend1.n ~ disability + female + age, design=RAB.w.nhsspend1)
summary(nhsspend1.model1.RAB) 
length(nhsspend1.model1.RAB$fitted.values)

# Model 2: + party
nhsspend1.model2.BES <- (svyglm(nhsspend1.n ~ disability + female + age + party, design=BES.w.nhsspend1))
summary(nhsspend1.model2.BES) 

nhsspend1.model2.RAB <- svyglm(nhsspend1.n ~ disability + female + age + party1, design=RAB.w.nhsspend1)
summary(nhsspend1.model2.RAB) 


#######################################

#### Redistribution

BES$redist.sample.BES <- NA
BES$redist.sample.BES[!is.na(BES$redist.n) & !is.na(BES$disability) & !is.na(BES$female) & 
                        !is.na(BES$age) & !is.na(BES$party)] <- 1
BES.redist <- subset(BES, !is.na(BES$redist.sample.BES))
BES.w.redist <- svydesign(ids = ~1, data = BES.redist, weights = BES.redist$wt_core_W6)

RAB$redist.sample.RAB <- NA
RAB$redist.sample.RAB[!is.na(RAB$redist.n) & !is.na(RAB$disability) & !is.na(RAB$female) & 
                        !is.na(RAB$age) & !is.na(RAB$party1)] <- 1
RAB.redist <- subset(RAB, !is.na(RAB$redist.sample.RAB))
RAB.w.redist <- svydesign(ids = ~1, data = RAB.redist, weights = RAB.redist$weight)

# Model 1: disability, female, age
redist.model1.BES <- (svyglm(redist.n ~ disability + female + age, design=BES.w.redist))
summary(redist.model1.BES) 
length(redist.model1.BES$fitted.values)

redist.model1.RAB <- svyglm(redist.n ~ disability + female + age, design=RAB.w.redist)
summary(redist.model1.RAB) 
length(redist.model1.RAB$fitted.values)

# Model 2: + party
redist.model2.BES <- (svyglm(redist.n ~ disability + female + age + party, design=BES.w.redist))
summary(redist.model2.BES) 

redist.model2.RAB <- svyglm(redist.n ~ disability + female + age + party1, design=RAB.w.redist)
summary(redist.model2.RAB)

#######################################

#### FIGURE 2

#### Left-right

lr.labels <- c("Sample", "Model", "Coefficient", "SE")
lr.row1 <- c("Citizens", "Across parties", 
             summary(lr.model1.BES)$coefficients[2,1], summary(lr.model1.BES)$coefficients[2,2] )
lr.row2 <- c("Citizens", "Within parties", 
             summary(lr.model2.BES)$coefficients[2,1], summary(lr.model2.BES)$coefficients[2,2] )
lr.row5 <- c("Candidates", "Across parties", 
             summary(lr.model1.RAB)$coefficients[2,1], summary(lr.model1.RAB)$coefficients[2,2] )
lr.row6 <- c("Candidates", "Within parties", 
             summary(lr.model2.RAB)$coefficients[2,1], summary(lr.model2.RAB)$coefficients[2,2] )

lr.allmodels <- data.frame(rbind(lr.row1,lr.row2,lr.row5,lr.row6))
names(lr.allmodels) <- lr.labels
lr.allmodels$Coefficient <- as.numeric(as.character(lr.allmodels$Coefficient))
lr.allmodels$SE <- as.numeric(as.character(lr.allmodels$SE))
Model <- factor(lr.allmodels$Model, levels=c("Within parties", "Across parties"))

interval <- 1.96  # 95% multiplier for CI
lr.plot <- ggplot(lr.allmodels, aes(colour = Sample))
lr.plot <- lr.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
lr.plot <- lr.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
lr.plot <- lr.plot + ggtitle("          (a) Left-right position") + theme(plot.title = element_text(hjust = 1, size=50))
lr.plot <- lr.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(lr.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("lr.png", dpi=300)


#### Public spending

pubspend1.labels <- c("Sample", "Model", "Coefficient", "SE")
pubspend1.row1 <- c("Citizens", "Across parties", 
                    summary(pubspend1.model1.BES)$coefficients[2,1], summary(pubspend1.model1.BES)$coefficients[2,2] )
pubspend1.row2 <- c("Citizens", "Within parties", 
                    summary(pubspend1.model2.BES)$coefficients[2,1], summary(pubspend1.model2.BES)$coefficients[2,2] )
pubspend1.row5 <- c("Candidates", "Across parties", 
                    summary(pubspend1.model1.RAB)$coefficients[2,1], summary(pubspend1.model1.RAB)$coefficients[2,2] )
pubspend1.row6 <- c("Candidates", "Within parties", 
                    summary(pubspend1.model2.RAB)$coefficients[2,1], summary(pubspend1.model2.RAB)$coefficients[2,2] )

pubspend1.allmodels <- data.frame(rbind(pubspend1.row1,pubspend1.row2,pubspend1.row5,pubspend1.row6))
names(pubspend1.allmodels) <- pubspend1.labels
pubspend1.allmodels$Coefficient <- as.numeric(as.character(pubspend1.allmodels$Coefficient))
pubspend1.allmodels$SE <- as.numeric(as.character(pubspend1.allmodels$SE))
pubspend1.allmodels$Model <- ordered(c("Across parties", "Within parties"))

pubspend1.plot <- ggplot(pubspend1.allmodels, aes(colour = Sample))
pubspend1.plot <- pubspend1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
pubspend1.plot <- pubspend1.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                       ymax = Coefficient + SE*interval),
                                                   lwd = 1/2, position = position_dodge(width = 1/2),
                                                   shape = 19, fill = "WHITE")
pubspend1.plot <- pubspend1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
pubspend1.plot <- pubspend1.plot + ggtitle("(b) Public spending") + theme(plot.title = element_text(hjust = 0.5)) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(pubspend1.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("pub.png", dpi=300)


#### NHS spending

nhsspend1.labels <- c("Sample", "Model", "Coefficient", "SE")
nhsspend1.row1 <- c("Citizens", "Across parties", 
                    summary(nhsspend1.model1.BES)$coefficients[2,1], summary(nhsspend1.model1.BES)$coefficients[2,2] )
nhsspend1.row2 <- c("Citizens", "Within parties", 
                    summary(nhsspend1.model2.BES)$coefficients[2,1], summary(nhsspend1.model2.BES)$coefficients[2,2] )
nhsspend1.row5 <- c("Candidates", "Across parties", 
                    summary(nhsspend1.model1.RAB)$coefficients[2,1], summary(nhsspend1.model1.RAB)$coefficients[2,2] )
nhsspend1.row6 <- c("Candidates", "Within parties", 
                    summary(nhsspend1.model2.RAB)$coefficients[2,1], summary(nhsspend1.model2.RAB)$coefficients[2,2] )

nhsspend1.allmodels <- data.frame(rbind(nhsspend1.row1,nhsspend1.row2,nhsspend1.row5,nhsspend1.row6))
names(nhsspend1.allmodels) <- nhsspend1.labels
nhsspend1.allmodels$Coefficient <- as.numeric(as.character(nhsspend1.allmodels$Coefficient))
nhsspend1.allmodels$SE <- as.numeric(as.character(nhsspend1.allmodels$SE))
nhsspend1.allmodels$Model <- ordered(c("Across parties", "Within parties"))

nhsspend1.plot <- ggplot(nhsspend1.allmodels, aes(colour = Sample))
nhsspend1.plot <- nhsspend1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
nhsspend1.plot <- nhsspend1.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                       ymax = Coefficient + SE*interval),
                                                   lwd = 1/2, position = position_dodge(width = 1/2),
                                                   shape = 19, fill = "WHITE")
nhsspend1.plot <- nhsspend1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
nhsspend1.plot <- nhsspend1.plot + ggtitle("(c) NHS spending") + theme(plot.title = element_text(hjust = 0.5)) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(nhsspend1.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("nhs.png", dpi=300)

#### Redistribution

redist.labels <- c("Sample", "Model", "Coefficient", "SE")
redist.row1 <- c("Citizens", "Across parties", 
                 summary(redist.model1.BES)$coefficients[2,1], summary(redist.model1.BES)$coefficients[2,2] )
redist.row2 <- c("Citizens", "Within parties", 
                 summary(redist.model2.BES)$coefficients[2,1], summary(redist.model2.BES)$coefficients[2,2] )
redist.row5 <- c("Candidates", "Across parties", 
                 summary(redist.model1.RAB)$coefficients[2,1], summary(redist.model1.RAB)$coefficients[2,2] )
redist.row6 <- c("Candidates", "Within parties", 
                 summary(redist.model2.RAB)$coefficients[2,1], summary(redist.model2.RAB)$coefficients[2,2] )

redist.allmodels <- data.frame(rbind(redist.row1,redist.row2,redist.row5,redist.row6))
names(redist.allmodels) <- redist.labels
redist.allmodels$Coefficient <- as.numeric(as.character(redist.allmodels$Coefficient))
redist.allmodels$SE <- as.numeric(as.character(redist.allmodels$SE))

redist.plot <- ggplot(redist.allmodels, aes(colour = Sample))
redist.plot <- redist.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
redist.plot <- redist.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                 ymax = Coefficient + SE*interval),
                                             lwd = 1/2, position = position_dodge(width = 1/2),
                                             shape = 19, fill = "WHITE")
redist.plot <- redist.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
redist.plot <- redist.plot + ggtitle("(d) Redistribution")+ theme(plot.title = element_text(hjust = 0.5))
print(redist.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("red.png", dpi=300)

#########################################################################################

### Tables S3 + S4

stargazer(lr.model1.BES, lr.model1.RAB, 
          lr.model2.BES, lr.model2.RAB,
          pubspend1.model1.BES, pubspend1.model1.RAB, 
          pubspend1.model2.BES, pubspend1.model2.RAB,
          type="html",  out="TableS3.doc", star.cutoffs = c(0.05, 0.01, 0.001))

stargazer(nhsspend1.model1.BES, nhsspend1.model1.RAB, 
          nhsspend1.model2.BES, nhsspend1.model2.RAB,
          redist.model1.BES, redist.model1.RAB, 
          redist.model2.BES, redist.model2.RAB,
          type="html",  out="TableS4.doc", star.cutoffs = c(0.05, 0.01, 0.001))
# adjust asterisks to output

##########################################################################################
##########################################################################################

# ANALYSIS OF DYAD DATA: 

# Run script "Reher_BJPolS_2020_generate-dyad-data.R" to generate dyad data
source("Reher_BJPolS_2020_generate-dyad-data.R")

##########################################################################################
##########################################################################################

# 3) Effects of shared disability on dyadic preference congruence (Figure 3; Tables S5 + S6)

#### Labour 

dyad <- read.csv("dyads.lab.csv")

m.lr <- lmer(cong.lr~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.lr)
m.pub <- lmer(cong.pub~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.pub)
m.nhs <- lmer(cong.nhs~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.nhs)
m.red <- lmer(cong.red~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.red)

class(m.lr) <- "lmerMod"
class(m.pub) <- "lmerMod"
class(m.nhs) <- "lmerMod"
class(m.red) <- "lmerMod"

##### Table S5

stargazer(m.lr, m.pub, m.nhs, m.red, type="html", out="lab.dyad.doc")
# adjust asterisks to output

##### Figure 3

### Left-right
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.lr)$coefficients[2,1], summary(m.lr)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.lr)$coefficients[3,1], summary(m.lr)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.lr)$coefficients[4,1], summary(m.lr)$coefficients[4,2] )

t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.lr <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.lr  + scale_colour_manual(values = c("Black")))
ggsave("dyad.lab-lr.png", dpi=300)

### Public spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.pub)$coefficients[2,1], summary(m.pub)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.pub)$coefficients[3,1], summary(m.pub)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.pub)$coefficients[4,1], summary(m.pub)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.pub <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.pub + scale_colour_manual(values = c("Black")))
ggsave("dyad.lab-pub.png", dpi=300)

### NHS spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.nhs)$coefficients[2,1], summary(m.nhs)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.nhs)$coefficients[3,1], summary(m.nhs)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.nhs)$coefficients[4,1], summary(m.nhs)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.nhs <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.nhs + scale_colour_manual(values = c("Black")))
ggsave("dyad.lab-nhs.png", dpi=300)

### Redistribution
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.red)$coefficients[2,1], summary(m.red)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.red)$coefficients[3,1], summary(m.red)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.red)$coefficients[4,1], summary(m.red)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.red <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.red + scale_colour_manual(values = c("Black")))
ggsave("dyad.lab-red.png", dpi=300)

#########################################################################

#### LibDems 

dyad <- read.csv("dyads.lib.csv")

m.lr <- lmer(cong.lr~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.lr)
m.pub <- lmer(cong.pub~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.pub)
m.nhs <- lmer(cong.nhs~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.nhs)
m.red <- lmer(cong.red~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.red)

class(m.lr) <- "lmerMod"
class(m.pub) <- "lmerMod"
class(m.nhs) <- "lmerMod"
class(m.red) <- "lmerMod"

##### Table S5

stargazer(m.lr, m.pub, m.nhs, m.red, type="html", out="lib.dyad.doc")
# adjust asterisks to output

##### Figure 3

### Left-right
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.lr)$coefficients[2,1], summary(m.lr)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.lr)$coefficients[3,1], summary(m.lr)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.lr)$coefficients[4,1], summary(m.lr)$coefficients[4,2] )

t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.lr <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.lr  + scale_colour_manual(values = c("Black")))
ggsave("dyad.lib-lr.png", dpi=300)

### Public spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.pub)$coefficients[2,1], summary(m.pub)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.pub)$coefficients[3,1], summary(m.pub)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.pub)$coefficients[4,1], summary(m.pub)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.pub <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.pub + scale_colour_manual(values = c("Black")))
ggsave("dyad.lib-pub.png", dpi=300)

### NHS spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.nhs)$coefficients[2,1], summary(m.nhs)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.nhs)$coefficients[3,1], summary(m.nhs)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.nhs)$coefficients[4,1], summary(m.nhs)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.nhs <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.nhs + scale_colour_manual(values = c("Black")))
ggsave("dyad.lib-nhs.png", dpi=300)

### Redistribution
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.red)$coefficients[2,1], summary(m.red)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.red)$coefficients[3,1], summary(m.red)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.red)$coefficients[4,1], summary(m.red)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.red <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.red + scale_colour_manual(values = c("Black")))
ggsave("dyad.lib-red.png", dpi=300)


#########################################################################

#### Greens 

dyad <- read.csv("dyads.gre.csv")

m.lr <- lmer(cong.lr~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.lr)
m.pub <- lmer(cong.pub~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.pub)
m.nhs <- lmer(cong.nhs~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.nhs)
m.red <- lmer(cong.red~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.red)

class(m.lr) <- "lmerMod"
class(m.pub) <- "lmerMod"
class(m.nhs) <- "lmerMod"
class(m.red) <- "lmerMod"

##### Table S6

stargazer(m.lr, m.pub, m.nhs, m.red, type="html", out="gre.dyad.doc")
# adjust asterisks to output

##### Figure 3

### Left-right
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.lr)$coefficients[2,1], summary(m.lr)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.lr)$coefficients[3,1], summary(m.lr)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.lr)$coefficients[4,1], summary(m.lr)$coefficients[4,2] )

t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.lr <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.lr  + scale_colour_manual(values = c("Black")))
ggsave("dyad.gre-lr.png", dpi=300)

### Public spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.pub)$coefficients[2,1], summary(m.pub)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.pub)$coefficients[3,1], summary(m.pub)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.pub)$coefficients[4,1], summary(m.pub)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.pub <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.pub + scale_colour_manual(values = c("Black")))
ggsave("dyad.gre-pub.png", dpi=300)

### NHS spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.nhs)$coefficients[2,1], summary(m.nhs)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.nhs)$coefficients[3,1], summary(m.nhs)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.nhs)$coefficients[4,1], summary(m.nhs)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.nhs <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.nhs + scale_colour_manual(values = c("Black")))
ggsave("dyad.gre-nhs.png", dpi=300)

### Redistribution
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.red)$coefficients[2,1], summary(m.red)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.red)$coefficients[3,1], summary(m.red)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.red)$coefficients[4,1], summary(m.red)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.red <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.red + scale_colour_manual(values = c("Black")))
ggsave("dyad.gre-red.png", dpi=300)


#########################################################################

#### UKIP 

dyad <- read.csv("dyads.ukip.csv")

m.lr <- lmer(cong.lr~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.lr)
m.pub <- lmer(cong.pub~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.pub)
m.nhs <- lmer(cong.nhs~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.nhs)
m.red <- lmer(cong.red~disabvc + agediff + gendersame + (1|idnew) + (1|idcand), data=dyad, weights=wt_core_W6)
summary(m.red)

class(m.lr) <- "lmerMod"
class(m.pub) <- "lmerMod"
class(m.nhs) <- "lmerMod"
class(m.red) <- "lmerMod"

##### Table S6

stargazer(m.lr, m.pub, m.nhs, m.red, type="html", out="ukip.dyad.doc")
# adjust asterisks to output

##### Figure 3

### Left-right
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.lr)$coefficients[2,1], summary(m.lr)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.lr)$coefficients[3,1], summary(m.lr)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.lr)$coefficients[4,1], summary(m.lr)$coefficients[4,2] )

t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.lr <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.lr  + scale_colour_manual(values = c("Black")))
ggsave("dyad.ukip-lr.png", dpi=300)

### Public spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.pub)$coefficients[2,1], summary(m.pub)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.pub)$coefficients[3,1], summary(m.pub)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.pub)$coefficients[4,1], summary(m.pub)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.pub <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.pub + scale_colour_manual(values = c("Black")))
ggsave("dyad.ukip-pub.png", dpi=300)

### NHS spending
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.nhs)$coefficients[2,1], summary(m.nhs)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.nhs)$coefficients[3,1], summary(m.nhs)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.nhs)$coefficients[4,1], summary(m.nhs)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.nhs <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.nhs + scale_colour_manual(values = c("Black")))
ggsave("dyad.ukip-nhs.png", dpi=300)

### Redistribution
t1.labels <- c("Disability", "Coefficient", "SE")
t1.row1 <- c("D voters/D candidates",  
             0, 0)
t1.row2 <- c("D voters/ND candidates",
             summary(m.red)$coefficients[2,1], summary(m.red)$coefficients[2,2] )
t1.row3 <- c("ND voters/D candidates", 
             summary(m.red)$coefficients[3,1], summary(m.red)$coefficients[3,2] )
t1.row4 <- c("ND voters/ND candidates", 
             summary(m.red)$coefficients[4,1], summary(m.red)$coefficients[4,2] )
t1 <- data.frame(rbind(t1.row1,t1.row2,t1.row3,t1.row4))
names(t1) <- t1.labels
t1$Coefficient <- as.numeric(as.character(t1$Coefficient))
t1$SE <- as.numeric(as.character(t1$SE))
t1$Disability <- as.character(t1$Disability)
t1$Disability <- factor(t1$Disability, levels=c("ND voters/ND candidates", "ND voters/D candidates", 
                                                "D voters/ND candidates", "D voters/D candidates"), ordered=TRUE)

t1.plot <- ggplot(t1)
t1.plot <- t1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
t1.plot <- t1.plot + geom_pointrange(aes(x = Disability, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
t1.plot <- t1.plot + ggtitle("") + ylim(-0.1,0.1)
t1.plot.lab.red <- t1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=14),
        axis.title.x = element_text(size=14)) 
print(t1.plot.lab.red + scale_colour_manual(values = c("Black")))
ggsave("dyad.ukip-red.png", dpi=300)


#################################################################################
#################################################################################
#################################################################################

#### 4) Supplementary Information

#### Table S2: Prevalence of disability by age group and gender among voters and candidates

# Disability by age group: citizens
BES.w$agegroup1 <- NA
BES.w$agegroup1[BES.w$age>17 & BES.w$age<36] <- 1
BES.w$agegroup1[BES.w$age>35 & BES.w$age<51] <- 2
BES.w$agegroup1[BES.w$age>50 & BES.w$age<66] <- 3
BES.w$agegroup1[BES.w$age>65] <- 4

citizens <- svytable(~disability+agegroup1, BES.w)
svychisq(~disability+agegroup1, BES.w)
summary(citizens, statistic="Chisq")

# Disability by age group: candidates 
RAB.w$agegroup1 <- NA
RAB.w$agegroup1[RAB.w$age<36] <- 1
RAB.w$agegroup1[RAB.w$age>35 & RAB.w$age<51] <- 2
RAB.w$agegroup1[RAB.w$age>50 & RAB.w$age<66] <- 3
RAB.w$agegroup1[RAB.w$age>65] <- 4

candidates <- svytable(~disability+agegroup1, RAB.w)
svychisq(~disability+agegroup1, RAB.w)
summary(candidates, statistic="Chisq")

# Disability by gender: citizens
citizens <- svytable(~disability+female, BES.w)
svychisq(~disability+female, BES.w)
summary(citizens, statistic="Chisq")

# Disability by gender: candidates
candidates <- svytable(~disability+female, RAB.w)
svychisq(~disability+female, RAB.w)
summary(candidates, statistic="Chisq")

##########################################################################

#### Tables S3, S4, S5, S6: see above 

##########################################################################

#### Figure S1: Means and distributions of policy positions of disabled and non-disabled citizens and candidates

dev.off()
plot.new()
png("distributions.png")
par(mfrow=c(2,2), mar=c(3,1.5,3,1.5)+0.5)

### Left right

# Citizen means
svyby(~lr.n, ~disability, BES.w, svymean, na.rm=T)
# Candidate means
svyby(~lr.n, ~disability, RAB.w, svymean, na.rm=T)

BES.nd <- subset(BES, BES$disability==0 & !is.na(lr.n))
sum.BES.nd <- sum(BES.nd$wt_core_W6)
sum.BES.nd
BES.d <- subset(BES, BES$disability==1 & !is.na(lr.n))
sum.BES.d <- sum(BES.d$wt_core_W6)
sum.BES.d
RAB.nd <- subset(RAB, RAB$disability==0 & !is.na(lr.n))
sum.RAB.nd <- sum(RAB.nd$weight)
RAB.d <- subset(RAB, RAB$disability==1 & !is.na(lr.n))
sum.RAB.d <- sum(RAB.d$weight)

plot(density(RAB.nd$lr.n, weights=RAB.nd$weight/sum.RAB.nd, bw=0.05, from=0, to=1, na.rm=T), 
      main="", xlab="", ylab="", ylim=c(0, 2.5))
lines(density(RAB.d$lr.n, weights=RAB.d$weight/sum.RAB.d, bw=0.05, from=0, to=1, na.rm=T), 
      main="", col="darkgrey")
lines(density(BES.nd$lr.n, weights=BES.nd$wt_core_W6/sum.BES.nd, bw=0.05, from=0, to=1, na.rm=T), 
      col="black", lty=2, main="")
lines(density(BES.d$lr.n, weights=BES.d$wt_core_W6/sum.BES.d, bw=0.05, from=0, to=1, na.rm=T), 
      main="", lty=2, col="darkgrey")
abline(v=0.439, col="black") # insert means calculated above: RAB nd
abline(v=0.440, col="darkgrey") # RAB d
abline(v=0.514, col="black", lty=2) # BES nd
abline(v=0.486, col="darkgrey", lty=2) # BES d
title("Left-right")


### Public spending

# Citizen means
svyby(~pubspend1.n, ~disability, BES.w, svymean, na.rm=T)
# Candidate means
svyby(~pubspend1.n, ~disability, RAB.w, svymean, na.rm=T)

BES.nd <- subset(BES, BES$disability==0 & !is.na(pubspend1.n))
sum.BES.nd <- sum(BES.nd$wt_core_W6)
sum.BES.nd
BES.d <- subset(BES, BES$disability==1 & !is.na(pubspend1.n))
sum.BES.d <- sum(BES.d$wt_core_W6)
sum.BES.d
RAB.nd <- subset(RAB, RAB$disability==0 & !is.na(pubspend1.n))
sum.RAB.nd <- sum(RAB.nd$weight)
RAB.d <- subset(RAB, RAB$disability==1 & !is.na(pubspend1.n))
sum.RAB.d <- sum(RAB.d$weight)

plot(density(RAB.nd$pubspend1.n, weights=RAB.nd$weight/sum.RAB.nd, bw=0.1, from=0, to=1, na.rm=T), 
     main="", xlab="", ylab="", ylim=c(0, 2.5))
lines(density(RAB.d$pubspend1.n, weights=RAB.d$weight/sum.RAB.d, bw=0.1, from=0, to=1, na.rm=T), 
      main="", col="darkgrey")
lines(density(BES.nd$pubspend1.n, weights=BES.nd$wt_core_W6/sum.BES.nd, bw=0.1, from=0, to=1, na.rm=T), 
      col="black", lty=2, main="")
lines(density(BES.d$pubspend1.n, weights=BES.d$wt_core_W6/sum.BES.d, bw=0.1, from=0, to=1, na.rm=T), 
      main="", lty=2, col="darkgrey")
abline(v=0.389, col="black") # insert means calculated above: RAB nd
abline(v=0.307, col="darkgrey") # RAB d
abline(v=0.354, col="black", lty=2) # BES nd
abline(v=0.273, col="darkgrey", lty=2) # BES d
title("Public spending")

### NHS cuts

# Citizen means
svyby(~nhsspend1.n, ~disability, BES.w, svymean, na.rm=T)
# Candidate means
svyby(~nhsspend1.n, ~disability, RAB.w, svymean, na.rm=T)

BES.nd <- subset(BES, BES$disability==0 & !is.na(nhsspend1.n))
sum.BES.nd <- sum(BES.nd$wt_core_W6)
sum.BES.nd
BES.d <- subset(BES, BES$disability==1 & !is.na(nhsspend1.n))
sum.BES.d <- sum(BES.d$wt_core_W6)
sum.BES.d
RAB.nd <- subset(RAB, RAB$disability==0 & !is.na(nhsspend1.n))
sum.RAB.nd <- sum(RAB.nd$weight)
RAB.d <- subset(RAB, RAB$disability==1 & !is.na(nhsspend1.n))
sum.RAB.d <- sum(RAB.d$weight)

plot(density(RAB.nd$nhsspend1.n, weights=RAB.nd$weight/sum.RAB.nd, bw=0.1, from=0, to=1, na.rm=T), 
     main="", xlab="", ylab="", ylim=c(0, 2.5))
lines(density(RAB.d$nhsspend1.n, weights=RAB.d$weight/sum.RAB.d, bw=0.1, from=0, to=1, na.rm=T), 
      main="", col="darkgrey")
lines(density(BES.nd$nhsspend1.n, weights=BES.nd$wt_core_W6/sum.BES.nd, bw=0.1, from=0, to=1, na.rm=T), 
      col="black", lty=2, main="")
lines(density(BES.d$nhsspend1.n, weights=BES.d$wt_core_W6/sum.BES.d, bw=0.1, from=0, to=1, na.rm=T), 
      main="", lty=2, col="darkgrey")
abline(v=0.316, col="black") # insert means calculated above: RAB nd
abline(v=0.214, col="darkgrey") # RAB d
abline(v=0.253, col="black", lty=2) # BES nd
abline(v=0.184, col="darkgrey", lty=2) # BES d
title("NHS spending")

### Redistribution

# Citizen means
svyby(~redist.n, ~disability, BES.w, svymean, na.rm=T)
# Candidate means
svyby(~redist.n, ~disability, RAB.w, svymean, na.rm=T)

BES.nd <- subset(BES, BES$disability==0 & !is.na(redist.n))
sum.BES.nd <- sum(BES.nd$wt_core_W6)
sum.BES.nd
BES.d <- subset(BES, BES$disability==1 & !is.na(redist.n))
sum.BES.d <- sum(BES.d$wt_core_W6)
sum.BES.d
RAB.nd <- subset(RAB, RAB$disability==0 & !is.na(redist.n))
sum.RAB.nd <- sum(RAB.nd$weight)
RAB.d <- subset(RAB, RAB$disability==1 & !is.na(redist.n))
sum.RAB.d <- sum(RAB.d$weight)

plot(density(RAB.nd$redist.n, weights=RAB.nd$weight/sum.RAB.nd, bw=0.05, from=0, to=1, na.rm=T), 
     main="", xlab="", ylab="", ylim=c(0, 2.5))
lines(density(RAB.d$redist.n, weights=RAB.d$weight/sum.RAB.d, bw=0.05, from=0, to=1, na.rm=T), 
      main="", col="darkgrey")
lines(density(BES.nd$redist.n, weights=BES.nd$wt_core_W6/sum.BES.nd, bw=0.05, from=0, to=1, na.rm=T), 
      col="black", lty=2, main="")
lines(density(BES.d$redist.n, weights=BES.d$wt_core_W6/sum.BES.d, bw=0.05, from=0, to=1, na.rm=T), 
      main="", lty=2, col="darkgrey")
abline(v=0.419, col="black") # insert means calculated above: RAB nd
abline(v=0.350, col="darkgrey") # RAB d
abline(v=0.466, col="black", lty=2) # BES nd
abline(v=0.371, col="darkgrey", lty=2) # BES d
title("Redistribution")
dev.off()

#############################################################################


#### FIGURE S2: Effects of disability on policy preferences of citizens and candidates, 
#               controlling for education and income


### Left right

# Model 1: disability, female, age, income, edu
lr.model1.BES <- (svyglm(lr.n ~ disability + female + age + eduage + incomeh.RAB, design=BES.w.lr))
summary(lr.model1.BES) 
length(lr.model1.BES$fitted.values)

lr.model1.RAB <- svyglm(lr.n ~ disability + female + age + eduage + income, design=RAB.w.lr)
summary(lr.model1.RAB) 
length(lr.model1.RAB$fitted.values)

# Model 2: + party
lr.model2.BES <- (svyglm(lr.n ~ disability + female + age + party + eduage + incomeh.RAB, design=BES.w.lr))
summary(lr.model2.BES) 

lr.model2.RAB <- svyglm(lr.n ~ disability + female + age + party1 + eduage + income, design=RAB.w.lr)
summary(lr.model2.RAB) 


### Public spending 

# Model 1: disability, female, age, income, edu
pubspend1.model1.BES <- (svyglm(pubspend1.n ~ disability + female + age + eduage + incomeh.RAB, design=BES.w.pubspend1))
summary(pubspend1.model1.BES) 
length(pubspend1.model1.BES$fitted.values)

pubspend1.model1.RAB <- svyglm(pubspend1.n ~ disability + female + age + eduage + income, design=RAB.w.pubspend1)
summary(pubspend1.model1.RAB$fitted.values) 

# Model 2: + party
pubspend1.model2.BES <- (svyglm(pubspend1.n ~ disability + female + age + party + eduage + incomeh.RAB, design=BES.w.pubspend1))
summary(pubspend1.model2.BES) 

pubspend1.model2.RAB <- svyglm(pubspend1.n ~ disability + female + age + party1 + eduage + income, design=RAB.w.pubspend1)
summary(pubspend1.model2.RAB) 

### NHS spending

# Model 1: disability, female, age, income, edu
nhsspend1.model1.BES <- (svyglm(nhsspend1.n ~ disability + female + age + eduage + incomeh.RAB, design=BES.w.nhsspend1))
summary(nhsspend1.model1.BES) 
length(nhsspend1.model1.BES$fitted.values)

nhsspend1.model1.RAB <- svyglm(nhsspend1.n ~ disability + female + age + eduage + income, design=RAB.w.nhsspend1)
summary(nhsspend1.model1.RAB) 

# Model 2: + party
nhsspend1.model2.BES <- (svyglm(nhsspend1.n ~ disability + female + age + party + eduage + incomeh.RAB, design=BES.w.nhsspend1))
summary(nhsspend1.model2.BES) 

nhsspend1.model2.RAB <- svyglm(nhsspend1.n ~ disability + female + age + party1 + eduage + income, design=RAB.w.nhsspend1)
summary(nhsspend1.model2.RAB) 

### Redistribution

# Model 1: only disability, female, age
redist.model1.BES <- (svyglm(redist.n ~ disability + female + age + eduage + incomeh.RAB, design=BES.w.redist))
summary(redist.model1.BES) 
length(redist.model1.BES$fitted.values)

redist.model1.RAB <- svyglm(redist.n ~ disability + female + age + eduage + income, design=RAB.w.redist)
summary(redist.model1.RAB) 

# Model 2: + party
redist.model2.BES <- (svyglm(redist.n ~ disability + female + age + party + eduage + incomeh.RAB, design=BES.w.redist))
summary(redist.model2.BES) 

redist.model2.RAB <- svyglm(redist.n ~ disability + female + age + party1 + eduage + income, design=RAB.w.redist)
summary(redist.model2.RAB) 

##### Table of results 

stargazer(lr.model1.BES, lr.model1.RAB, 
          lr.model2.BES, lr.model2.RAB,
          pubspend1.model1.BES, pubspend1.model1.RAB, 
          pubspend1.model2.BES, pubspend1.model2.RAB,
          type="html",  out="edu-income-models1.doc", star.cutoffs = c(0.05, 0.01, 0.001))

stargazer(nhsspend1.model1.BES, nhsspend1.model1.RAB, 
          nhsspend1.model2.BES, nhsspend1.model2.RAB,
          redist.model1.BES, redist.model1.RAB, 
          redist.model2.BES, redist.model2.RAB,
          type="html",  out="edu-income-models2.doc", star.cutoffs = c(0.05, 0.01, 0.001))

# Adjusts asterisks based on output


### Coefficient plots

### Left-right

lr.labels <- c("Sample", "Model", "Coefficient", "SE")
lr.row1 <- c("Citizens", "Across parties", 
             summary(lr.model1.BES)$coefficients[2,1], summary(lr.model1.BES)$coefficients[2,2] )
lr.row2 <- c("Citizens", "Within parties", 
             summary(lr.model2.BES)$coefficients[2,1], summary(lr.model2.BES)$coefficients[2,2] )
lr.row5 <- c("Candidates", "Across parties", 
             summary(lr.model1.RAB)$coefficients[2,1], summary(lr.model1.RAB)$coefficients[2,2] )
lr.row6 <- c("Candidates", "Within parties", 
             summary(lr.model2.RAB)$coefficients[2,1], summary(lr.model2.RAB)$coefficients[2,2] )
lr.allmodels <- data.frame(rbind(lr.row1,lr.row2,lr.row5,lr.row6))
names(lr.allmodels) <- lr.labels
lr.allmodels$Coefficient <- as.numeric(as.character(lr.allmodels$Coefficient))
lr.allmodels$SE <- as.numeric(as.character(lr.allmodels$SE))
Model <- factor(lr.allmodels$Model, levels=c("Within parties", "Across parties"))

lr.plot <- ggplot(lr.allmodels, aes(colour = Sample))
lr.plot <- lr.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
lr.plot <- lr.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                         ymax = Coefficient + SE*interval),
                                     lwd = 1/2, position = position_dodge(width = 1/2),
                                     shape = 19, fill = "WHITE")
lr.plot <- lr.plot + ggtitle("          (a) Left-right position") + theme(plot.title = element_text(hjust = 1, size=50))
lr.plot <- lr.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank()) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(lr.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("lr-eduin.png", dpi=300)


### Public spending

pubspend1.labels <- c("Sample", "Model", "Coefficient", "SE")
pubspend1.row1 <- c("Citizens", "Across parties", 
                    summary(pubspend1.model1.BES)$coefficients[2,1], summary(pubspend1.model1.BES)$coefficients[2,2] )
pubspend1.row2 <- c("Citizens", "Within parties", 
                    summary(pubspend1.model2.BES)$coefficients[2,1], summary(pubspend1.model2.BES)$coefficients[2,2] )
pubspend1.row5 <- c("Candidates", "Across parties", 
                    summary(pubspend1.model1.RAB)$coefficients[2,1], summary(pubspend1.model1.RAB)$coefficients[2,2] )
pubspend1.row6 <- c("Candidates", "Within parties", 
                    summary(pubspend1.model2.RAB)$coefficients[2,1], summary(pubspend1.model2.RAB)$coefficients[2,2] )

pubspend1.allmodels <- data.frame(rbind(pubspend1.row1,pubspend1.row2,pubspend1.row5,pubspend1.row6))
names(pubspend1.allmodels) <- pubspend1.labels
pubspend1.allmodels$Coefficient <- as.numeric(as.character(pubspend1.allmodels$Coefficient))
pubspend1.allmodels$SE <- as.numeric(as.character(pubspend1.allmodels$SE))
pubspend1.allmodels$Model <- ordered(c("Across parties", "Within parties"))

pubspend1.plot <- ggplot(pubspend1.allmodels, aes(colour = Sample))
pubspend1.plot <- pubspend1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
pubspend1.plot <- pubspend1.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                       ymax = Coefficient + SE*interval),
                                                   lwd = 1/2, position = position_dodge(width = 1/2),
                                                   shape = 19, fill = "WHITE")
pubspend1.plot <- pubspend1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
pubspend1.plot <- pubspend1.plot + ggtitle("(b) Public spending") + theme(plot.title = element_text(hjust = 0.5)) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(pubspend1.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("pub-eduin.png", dpi=300)

### Nhs spending

nhsspend1.labels <- c("Sample", "Model", "Coefficient", "SE")
nhsspend1.row1 <- c("Citizens", "Across parties", 
                    summary(nhsspend1.model1.BES)$coefficients[2,1], summary(nhsspend1.model1.BES)$coefficients[2,2] )
nhsspend1.row2 <- c("Citizens", "Within parties", 
                    summary(nhsspend1.model2.BES)$coefficients[2,1], summary(nhsspend1.model2.BES)$coefficients[2,2] )
nhsspend1.row5 <- c("Candidates", "Across parties", 
                    summary(nhsspend1.model1.RAB)$coefficients[2,1], summary(nhsspend1.model1.RAB)$coefficients[2,2] )
nhsspend1.row6 <- c("Candidates", "Within parties", 
                    summary(nhsspend1.model2.RAB)$coefficients[2,1], summary(nhsspend1.model2.RAB)$coefficients[2,2] )
nhsspend1.allmodels <- data.frame(rbind(nhsspend1.row1,nhsspend1.row2,nhsspend1.row5,nhsspend1.row6))
names(nhsspend1.allmodels) <- nhsspend1.labels
nhsspend1.allmodels$Coefficient <- as.numeric(as.character(nhsspend1.allmodels$Coefficient))
nhsspend1.allmodels$SE <- as.numeric(as.character(nhsspend1.allmodels$SE))
nhsspend1.allmodels$Model <- ordered(c("Across parties", "Within parties"))

nhsspend1.plot <- ggplot(nhsspend1.allmodels, aes(colour = Sample))
nhsspend1.plot <- nhsspend1.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
nhsspend1.plot <- nhsspend1.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                       ymax = Coefficient + SE*interval),
                                                   lwd = 1/2, position = position_dodge(width = 1/2),
                                                   shape = 19, fill = "WHITE")
nhsspend1.plot <- nhsspend1.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
nhsspend1.plot <- nhsspend1.plot + ggtitle("(c) NHS spending") + theme(plot.title = element_text(hjust = 0.5)) + theme(legend.position = "none") +
  theme(axis.text.x = element_text(color="black",size = 12), axis.text.y = element_text(color="black",size=12),
        axis.title.x = element_text(size=12)) 
print(nhsspend1.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("nhs-small-eduin.png", dpi=300)

### Redistribution

redist.labels <- c("Sample", "Model", "Coefficient", "SE")
redist.row1 <- c("Citizens", "Across parties", 
                 summary(redist.model1.BES)$coefficients[2,1], summary(redist.model1.BES)$coefficients[2,2] )
redist.row2 <- c("Citizens", "Within parties", 
                 summary(redist.model2.BES)$coefficients[2,1], summary(redist.model2.BES)$coefficients[2,2] )
redist.row5 <- c("Candidates", "Across parties", 
                 summary(redist.model1.RAB)$coefficients[2,1], summary(redist.model1.RAB)$coefficients[2,2] )
redist.row6 <- c("Candidates", "Within parties", 
                 summary(redist.model2.RAB)$coefficients[2,1], summary(redist.model2.RAB)$coefficients[2,2] )
redist.allmodels <- data.frame(rbind(redist.row1,redist.row2,redist.row5,redist.row6))
names(redist.allmodels) <- redist.labels
redist.allmodels$Coefficient <- as.numeric(as.character(redist.allmodels$Coefficient))
redist.allmodels$SE <- as.numeric(as.character(redist.allmodels$SE))

redist.plot <- ggplot(redist.allmodels, aes(colour = Sample))
redist.plot <- redist.plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
redist.plot <- redist.plot + geom_pointrange(aes(x = Model, y = Coefficient, ymin = Coefficient - SE*interval,
                                                 ymax = Coefficient + SE*interval),
                                             lwd = 1/2, position = position_dodge(width = 1/2),
                                             shape = 19, fill = "WHITE")
redist.plot <- redist.plot + coord_flip() + theme_bw() + theme(axis.title.y=element_blank())
redist.plot <- redist.plot + ggtitle("(d) Redistribution")+ theme(plot.title = element_text(hjust = 0.5))
print(redist.plot + scale_colour_manual(values = c("gray45", "Black")))
ggsave("red-eduin.png", dpi=300)



