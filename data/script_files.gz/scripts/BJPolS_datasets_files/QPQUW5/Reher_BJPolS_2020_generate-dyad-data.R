####################################################################################
#
# Replication material for "Do Disabled Candidates Represent Disabled Citizens?"
# Stefanie Reher
# British Journal of Political Science, 2020
#
####################################################################################

### THIS SCRIPT IS CALLED AND RUN FROM THE MAIN SCRIPT 

# Generate separate data frames for each party, containing respondents who indicated having voted for the party in 2015 GE
BES.lab <- subset(BES, BES$party=="Labour")
BES.lib <- subset(BES, BES$party=="LibDem")
BES.ukip <- subset(BES, BES$party=="UKIP")
BES.gre <- subset(BES, BES$party=="Greens")
BES.con <- subset(BES, BES$party=="Conservatives")

### Reshape data frame for each party into long and save

### Labour
# Generate counter/new id
length(BES.lab$id)
BES.lab$idnew <- seq(1, 5971, 1)
# Duplicate each row 128 times (number of Labour candidates who answered disability question)
BES.lab.long <- do.call(rbind, replicate(128, BES.lab, simplify=FALSE))
# Generate counter to match with candidate data
BES.lab.long <- ddply(BES.lab.long, .(idnew), mutate, idcand = seq_along(idnew))
write.csv(BES.lab.long, "BES.lab.long.csv")

### LibDems
# Generate counter/new id
length(BES.lib$id)
BES.lib$idnew <- seq(1, 1648, 1)
# Duplicate each row 216 times
BES.lib.long <- do.call(rbind, replicate(216, BES.lib, simplify=FALSE))
# Generate counter to match with candidate data
BES.lib.long <- ddply(BES.lib.long, .(idnew), mutate, idcand = seq_along(idnew))
write.csv(BES.lib.long, "BES.lib.long.csv")

### Greens
# Generate counter/new id
length(BES.gre$id)
BES.gre$idnew <- seq(1, 808, 1)
# Duplicate each row 170 times
BES.gre.long <- do.call(rbind, replicate(183, BES.gre, simplify=FALSE))
# Generate counter to match with candidate data
BES.gre.long <- ddply(BES.gre.long, .(idnew), mutate, idcand = seq_along(idnew))
write.csv(BES.gre.long, "BES.gre.long.csv")

### UKIP 
# Generate counter/new id
length(BES.ukip$id)
BES.ukip$idnew <- seq(1, 1928, 1)
# Duplicate each row 87 times
BES.ukip.long <- do.call(rbind, replicate(87, BES.ukip, simplify=FALSE))
length(BES.ukip.long$id)
# generate counter to match with candidate data
BES.ukip.long <- ddply(BES.ukip.long, .(idnew), mutate, idcand = seq_along(idnew))
write.csv(BES.ukip.long, "BES.ukip.long.csv")

### Conservatives
# Generate counter/new id
length(BES.con$id)
BES.con$idnew <- seq(1, 5963, 1)
# Duplicate each row 58 times
BES.con.long <- do.call(rbind, replicate(58, BES.con, simplify=FALSE))
# Generate counter to match with candidate data
BES.con.long <- ddply(BES.con.long, .(idnew), mutate, idcand = seq_along(idnew))
write.csv(BES.con.long, "BES.con.long.csv")


#### Prepare candidate datasets for merging
keep1 <- c("id", "disability", "female", "age", "eduage", "income", "party1", "lr.n", "pubspend1.n", 
           "nhsspend1.n", "redist.n")
RAB.reduced <- RAB[!is.na(RAB$disability),keep1]

# Rename variables to distinguish from voter-level variables
RAB.reduced$disability.can <- RAB.reduced$disability
RAB.reduced$female.can <- RAB.reduced$female
RAB.reduced$age.can <- RAB.reduced$age
RAB.reduced$eduage.can <- RAB.reduced$eduage
RAB.reduced$income.can <- RAB.reduced$income
RAB.reduced$party.can <- RAB.reduced$party1
RAB.reduced$lr.n.can <- RAB.reduced$lr.n
RAB.reduced$pubspend1.n.can <- RAB.reduced$pubspend1.n
RAB.reduced$nhsspend1.n.can <- RAB.reduced$nhsspend1.n
RAB.reduced$redist.n.can <- RAB.reduced$redist.n

keep2 <- c("id", "disability.can", "female.can", "age.can", "eduage.can", "income.can", "party.can", 
           "lr.n.can", "pubspend1.n.can", "nhsspend1.n.can", "redist.n.can")
RAB.reduced <- RAB.reduced[,keep2]

# Split candidate data into separate frames for parties
RAB.lab <- subset(RAB.reduced, RAB.reduced$party.can=="Labour")
RAB.lib <- subset(RAB.reduced, RAB.reduced$party.can=="LibDem")
RAB.ukip <- subset(RAB.reduced, RAB.reduced$party.can=="UKIP")
RAB.gre <- subset(RAB.reduced, RAB.reduced$party.can=="Greens")
RAB.con <- subset(RAB.reduced, RAB.reduced$party.can=="Conservatives")

#### Generate dyad datasets: merge voter and candidate data frames for each party
#### Generate dyad-level variables: preference congruence, shared disability, shared gender, age difference

### Labour 

length(RAB.lab$id)
RAB.lab$idcand <- seq(1, 128, 1)
lab.joined <- left_join(BES.lab.long, RAB.lab, by = "idcand")
# Drop voters with missing data on disability
lab.joined <- lab.joined %>% drop_na(disability)

# Generate congruence measures
lab.joined$cong.lr <- 1-abs(lab.joined$lr.n - lab.joined$lr.n.can)
lab.joined$cong.pub <- 1-abs(lab.joined$pubspend1.n - lab.joined$pubspend1.n.can)
lab.joined$cong.nhs <- 1-abs(lab.joined$nhsspend1.n - lab.joined$nhsspend1.n.can)
lab.joined$cong.red <- 1-abs(lab.joined$redist.n - lab.joined$redist.n.can)

# Generate shared disability measure
lab.joined$disabvc <- NA
lab.joined$disabvc[lab.joined$disability==0 & lab.joined$disability.can==0] <-  "ndnd"
lab.joined$disabvc[lab.joined$disability==1 & lab.joined$disability.can==0] <-  "dnd"
lab.joined$disabvc[lab.joined$disability==0 & lab.joined$disability.can==1] <-  "ndd"
lab.joined$disabvc[lab.joined$disability==1 & lab.joined$disability.can==1] <-  "dd"
lab.joined$disabvc <- as.factor(lab.joined$disabvc)

# Generate age difference measure
lab.joined$agediff <- lab.joined$age - lab.joined$age.can

# Generate shared gender measure
lab.joined$gendersame <- NA
lab.joined$gendersame[lab.joined$female==0 & lab.joined$female.can==0] <- 1
lab.joined$gendersame[lab.joined$female==1 & lab.joined$female.can==1] <- 1
lab.joined$gendersame[lab.joined$female==0 & lab.joined$female.can==1] <- 0
lab.joined$gendersame[lab.joined$female==1 & lab.joined$female.can==0] <- 0

write.csv(lab.joined, "dyads.lab.csv")

### LibDems

length(RAB.lib$id)
RAB.lib$idcand <- seq(1, 216, 1)
lib.joined <- left_join(BES.lib.long, RAB.lib, by = "idcand")
lib.joined <- lib.joined %>% drop_na(disability)

# Generate congruence measures
lib.joined$cong.lr <- 1-abs(lib.joined$lr.n - lib.joined$lr.n.can)
lib.joined$cong.pub <- 1-abs(lib.joined$pubspend1.n - lib.joined$pubspend1.n.can)
lib.joined$cong.nhs <- 1-abs(lib.joined$nhsspend1.n - lib.joined$nhsspend1.n.can)
lib.joined$cong.red <- 1-abs(lib.joined$redist.n - lib.joined$redist.n.can)

# Generate shared disability measure
lib.joined$disabvc <- NA
lib.joined$disabvc[lib.joined$disability==0 & lib.joined$disability.can==0] <-  "ndnd"
lib.joined$disabvc[lib.joined$disability==1 & lib.joined$disability.can==0] <-  "dnd"
lib.joined$disabvc[lib.joined$disability==0 & lib.joined$disability.can==1] <-  "ndd"
lib.joined$disabvc[lib.joined$disability==1 & lib.joined$disability.can==1] <-  "dd"
lib.joined$disabvc <- as.factor(lib.joined$disabvc)

# Generate age difference measure
lib.joined$agediff <- lib.joined$age - lib.joined$age.can

# Generate shared gender measure
lib.joined$gendersame <- NA
lib.joined$gendersame[lib.joined$female==0 & lib.joined$female.can==0] <- 1
lib.joined$gendersame[lib.joined$female==1 & lib.joined$female.can==1] <- 1
lib.joined$gendersame[lib.joined$female==0 & lib.joined$female.can==1] <- 0
lib.joined$gendersame[lib.joined$female==1 & lib.joined$female.can==0] <- 0

write.csv(lib.joined, "dyads.lib.csv")

### Greens (incl. Scottish Greens)

length(RAB.gre$id)
RAB.gre$idcand <- seq(1, 183, 1)
gre.joined <- left_join(BES.gre.long, RAB.gre, by = "idcand")
gre.joined <- gre.joined %>% drop_na(disability)

# Generate congruence measures
gre.joined$cong.lr <- 1-abs(gre.joined$lr.n - gre.joined$lr.n.can)
gre.joined$cong.pub <- 1-abs(gre.joined$pubspend1.n - gre.joined$pubspend1.n.can)
gre.joined$cong.nhs <- 1-abs(gre.joined$nhsspend1.n - gre.joined$nhsspend1.n.can)
gre.joined$cong.red <- 1-abs(gre.joined$redist.n - gre.joined$redist.n.can)

# Generate shared disability measure
gre.joined$disabvc <- NA
gre.joined$disabvc[gre.joined$disability==0 & gre.joined$disability.can==0] <-  "ndnd"
gre.joined$disabvc[gre.joined$disability==1 & gre.joined$disability.can==0] <-  "dnd"
gre.joined$disabvc[gre.joined$disability==0 & gre.joined$disability.can==1] <-  "ndd"
gre.joined$disabvc[gre.joined$disability==1 & gre.joined$disability.can==1] <-  "dd"
gre.joined$disabvc <- as.factor(gre.joined$disabvc)

# Generate age difference measure
gre.joined$agediff <- gre.joined$age - gre.joined$age.can

# Generate shared gender measure
gre.joined$gendersame <- NA
gre.joined$gendersame[gre.joined$female==0 & gre.joined$female.can==0] <- 1
gre.joined$gendersame[gre.joined$female==1 & gre.joined$female.can==1] <- 1
gre.joined$gendersame[gre.joined$female==0 & gre.joined$female.can==1] <- 0
gre.joined$gendersame[gre.joined$female==1 & gre.joined$female.can==0] <- 0

write.csv(gre.joined, "dyads.gre.csv")

### UKIP

length(RAB.ukip$id)
RAB.ukip$idcand <- seq(1, 87, 1)
ukip.joined <- left_join(BES.ukip.long, RAB.ukip, by = "idcand")
ukip.joined <- ukip.joined %>% drop_na(disability)

# Generate congruence measures
ukip.joined$cong.lr <- 1-abs(ukip.joined$lr.n - ukip.joined$lr.n.can)
ukip.joined$cong.pub <- 1-abs(ukip.joined$pubspend1.n - ukip.joined$pubspend1.n.can)
ukip.joined$cong.nhs <- 1-abs(ukip.joined$nhsspend1.n - ukip.joined$nhsspend1.n.can)
ukip.joined$cong.red <- 1-abs(ukip.joined$redist.n - ukip.joined$redist.n.can)

# Generate shared disability measure
ukip.joined$disabvc <- NA
ukip.joined$disabvc[ukip.joined$disability==0 & ukip.joined$disability.can==0] <-  "ndnd"
ukip.joined$disabvc[ukip.joined$disability==1 & ukip.joined$disability.can==0] <-  "dnd"
ukip.joined$disabvc[ukip.joined$disability==0 & ukip.joined$disability.can==1] <-  "ndd"
ukip.joined$disabvc[ukip.joined$disability==1 & ukip.joined$disability.can==1] <-  "dd"
ukip.joined$disabvc <- as.factor(ukip.joined$disabvc)

# Generate age difference measure
ukip.joined$agediff <- ukip.joined$age - ukip.joined$age.can

# Generate shared gender measure
ukip.joined$gendersame <- NA
ukip.joined$gendersame[ukip.joined$female==0 & ukip.joined$female.can==0] <- 1
ukip.joined$gendersame[ukip.joined$female==1 & ukip.joined$female.can==1] <- 1
ukip.joined$gendersame[ukip.joined$female==0 & ukip.joined$female.can==1] <- 0
ukip.joined$gendersame[ukip.joined$female==1 & ukip.joined$female.can==0] <- 0

write.csv(ukip.joined, "dyads.ukip.csv")

### Conservatives

length(RAB.con$id)
RAB.con$idcand <- seq(1, 58, 1)
con.joined <- left_join(BES.con.long, RAB.con, by = "idcand")
con.joined <- con.joined %>% drop_na(disability)

# Generate congruence measures
con.joined$cong.lr <- 1-abs(con.joined$lr.n - con.joined$lr.n.can)
con.joined$cong.pub <- 1-abs(con.joined$pubspend1.n - con.joined$pubspend1.n.can)
con.joined$cong.nhs <- 1-abs(con.joined$nhsspend1.n - con.joined$nhsspend1.n.can)
con.joined$cong.red <- 1-abs(con.joined$redist.n - con.joined$redist.n.can)

# Generate shared disability measure
con.joined$disabvc <- NA
con.joined$disabvc[con.joined$disability==0 & con.joined$disability.can==0] <-  "ndnd"
con.joined$disabvc[con.joined$disability==1 & con.joined$disability.can==0] <-  "dnd"
con.joined$disabvc[con.joined$disability==0 & con.joined$disability.can==1] <-  "ndd"
con.joined$disabvc[con.joined$disability==1 & con.joined$disability.can==1] <-  "dd"
con.joined$disabvc <- as.factor(con.joined$disabvc)

# Generate age difference measure
con.joined$agediff <- con.joined$age - con.joined$age.can

# Generate shared gender measure
con.joined$gendersame <- NA
con.joined$gendersame[con.joined$female==0 & con.joined$female.can==0] <- 1
con.joined$gendersame[con.joined$female==1 & con.joined$female.can==1] <- 1
con.joined$gendersame[con.joined$female==0 & con.joined$female.can==1] <- 0
con.joined$gendersame[con.joined$female==1 & con.joined$female.can==0] <- 0

write.csv(con.joined, "dyads.con.csv")