##This file prepares the ESS data for analysis.

library(dplyr)
library(readstata13)
library(tidyr)
library(data.table)
library(vdemdata)

completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}

location <- "/Users/dillonlaaker/Dropbox/shocks_replication/"


##############################################
#Cleaning ESS Data
##############################################

setwd(paste(location, "data/raw", sep = ""))

##ess <- read.dta13("ess_incomefixed.dta")
##save(ess, file = "ess_incomefixed.Rdata")
load("ess_incomefixed.Rdata")

##create single variable for survey year
ess <- ess %>% ## Recodes those with survey year with the start year of their ESS Round
    mutate(syear = recode(essround, '1'='2002', '2'='2004', '3'='2006', '4'='2008', '5'='2010', '6'='2012', '7'='2014', 	'8'='2016')) %>%    
    mutate(syear = ifelse(!is.na(inwyr), inwyr, syear)) %>%
    mutate(syear = ifelse(!is.na(inwyys), inwyys, syear)) %>%
    as.data.frame()

ess <- ess %>%
	mutate(imm1 = ifelse(imsmetn==1 | imsmetn==2, 0, ifelse(imsmetn==3 | imsmetn==4, 1, NA))) %>%
	mutate(imm2 = ifelse(imdfetn==1 | imdfetn==2, 0, ifelse(imdfetn==3 | imdfetn==4, 1, NA))) %>%
	mutate(imm3 = ifelse(impcntr==1 | impcntr==2, 0, ifelse(impcntr==3 | impcntr==4, 1, NA))) %>%
	mutate(imm11 = ifelse(imsmetn==1 | imsmetn==2 | imsmetn==3, 0, ifelse(imsmetn==4, 1, NA))) %>%
	mutate(imm22 = ifelse(imdfetn==1 | imdfetn==2 | imdfetn==3, 0, ifelse(imdfetn==4, 1, NA))) %>%
	mutate(imm33 = ifelse(impcntr==1 | impcntr==2 | impcntr==3, 0, ifelse(impcntr==4, 1, NA))) %>%
	mutate(imm13a = ifelse(imm1+imm2+imm3>0, 1, ifelse(imm1+imm2+imm3==0, 0, NA))) %>%
	mutate(imm13b = ifelse(imm11+imm22+imm33>0, 1, ifelse(imm11+imm22+imm33==0, 0, NA))) %>%
	mutate(imm4 = ifelse(imbgeco>=0 & imbgeco<=4, 1, ifelse(imbgeco>=5 & imbgeco<=10, 0, NA))) %>%
	mutate(imm5 = ifelse(imueclt>=0 & imueclt<=4, 1, ifelse(imueclt>=5 & imueclt<=10, 0, NA))) %>%
	mutate(imm6 = ifelse(imwbcnt>=0 & imwbcnt<=4, 1, ifelse(imwbcnt>=5 & imwbcnt<=10, 0, NA))) %>%
	mutate(immigration = imm13a + imm13b + imm4 + imm5 + imm6) %>% #main dependent variable
	mutate(racial = ifelse(imdfetn - imsmetn > 0, 1, 0)) %>%	
	mutate(minority = ifelse(blgetmg==1, 1, ifelse(blgetmg==2, 0, NA))) %>%	
	mutate(locationtype = domicil - 1) %>%
	mutate(female = ifelse(gndr==2, 1, ifelse(gndr==1, 0, NA))) %>%
	mutate(feduc = ifelse(edulvlfa>0 & edulvlfa<6, edulvlfa-1, NA)) %>%
	mutate(meduc = ifelse(edulvlma>0 & edulvlma<6, edulvlma-1, NA)) %>%
	mutate(peduc = meduc + feduc) %>%
	mutate(union = ifelse(mbtru==1 | mbtru==2, 1, ifelse(mbtru==3, 0, NA))) %>%
	mutate(pcitizen = ifelse(mocntr+facntr==2, 1, ifelse(facntr+mocntr>=3 & facntr+mocntr<=4, 0, NA))) %>%	
	mutate(econview = 10 - stfeco) %>%
	mutate(incdif = 5 - gincdif) %>%
	as.data.frame()

ess <- within(ess,{country1<-as.numeric(factor(paste0(cntry)))})
names(ess)[names(ess)=="agea"] <- "age"	
names(ess)[names(ess)=="lrscale"] <- "lrideology"	
names(ess)[names(ess)=="uempla"] <- "unemployed"	
names(ess)[names(ess)=="eduyrs"] <- "educationy"
names(ess)[names(ess)=="edulvla"] <- "education"
ess$education[ess$education==55] <- NA
ess$cohort <- ess$yrbrn

ess$postsecondary <- NA
ess$postsecondary[ess$educationy>=16] <- 1
ess$postsecondary[ess$educationy<16] <- 0

ess$secondary <- NA
ess$secondary[ess$educationy>=12] <- 1
ess$secondary[ess$educationy<12] <- 0


ess$funemploy14 <- NA
ess$funemploy14[ess$emprf14==1 | ess$emprf14==2] <- 0
ess$funemploy14[ess$emprf14==3 | ess$emprf14==4] <- 1

ess$foccupation14 <- NA
ess$foccupation14[ess$occf14==1 | ess$occf14a==1] <- "High-skilled"
ess$foccupation14[ess$occf14==2 | ess$occf14a==2] <- "High-skilled"
ess$foccupation14[ess$occf14==4 | ess$occf14a==4] <- "High-skilled"
ess$foccupation14[ess$occf14b==1] <- "High-skilled"
ess$foccupation14[ess$occf14b==2] <- "High-skilled"

ess$foccupation14[ess$occf14==3 | ess$occf14a==3] <- "Medium-skilled"
ess$foccupation14[ess$occf14==5 | ess$occf14a==5] <- "Medium-skilled"
ess$foccupation14[ess$occf14==8 | ess$occf14a==8] <- "Medium-skilled"
ess$foccupation14[ess$occf14b==3] <- "Medium-skilled"
ess$foccupation14[ess$occf14b==4] <- "Medium-skilled"
ess$foccupation14[ess$occf14b==6] <- "Medium-skilled"
ess$foccupation14[ess$occf14b==9] <- "Medium-skilled"

ess$foccupation14[ess$occf14==6 | ess$occf14a==6] <- "Low-skilled"
ess$foccupation14[ess$occf14==7 | ess$occf14a==7] <- "Low-skilled"
ess$foccupation14[ess$occf14b==5] <- "Low-skilled"
ess$foccupation14[ess$occf14b==7] <- "Low-skilled"
ess$foccupation14[ess$occf14b==8] <- "Low-skilled"
ess$foccupation14[ess$funemploy14==1] <- "Low-skilled"
ess$foccupation14[is.na(ess$foccupation14) & !is.na(ess$funemploy14)] <- "Low-skilled"

ess$foccupation14 <- as.factor(ess$foccupation14)
ess <- within(ess, foccupation14 <- relevel(foccupation14, ref = "High-skilled"))


ess$munemploy14 <- NA
ess$munemploy14[ess$emprm14==1 | ess$emprm14==2] <- 0
ess$munemploy14[ess$emprm14==3 | ess$emprm14==4] <- 1

ess$moccupation14 <- NA
ess$moccupation14[ess$occm14==1 | ess$occm14a==1] <- "High-skilled"
ess$moccupation14[ess$occm14==2 | ess$occm14a==2] <- "High-skilled"
ess$moccupation14[ess$occm14==4 | ess$occm14a==4] <- "High-skilled"
ess$moccupation14[ess$occm14b==1] <- "High-skilled"
ess$moccupation14[ess$occm14b==2] <- "High-skilled"

ess$moccupation14[ess$occm14==3 | ess$occm14a==3] <- "Medium-skilled"
ess$moccupation14[ess$occm14==5 | ess$occm14a==5] <- "Medium-skilled"
ess$moccupation14[ess$occm14==8 | ess$occm14a==8] <- "Medium-skilled"
ess$moccupation14[ess$occm14b==3] <- "Medium-skilled"
ess$moccupation14[ess$occm14b==4] <- "Medium-skilled"
ess$moccupation14[ess$occm14b==6] <- "Medium-skilled"
ess$moccupation14[ess$occm14b==9] <- "Medium-skilled"

ess$moccupation14[ess$occm14==6 | ess$occm14a==6] <- "Low-skilled"
ess$moccupation14[ess$occm14==7 | ess$occm14a==7] <- "Low-skilled"
ess$moccupation14[ess$occm14b==5] <- "Low-skilled"
ess$moccupation14[ess$occm14b==7] <- "Low-skilled"
ess$moccupation14[ess$occm14b==8] <- "Low-skilled"
ess$moccupation14[ess$munemploy14==1] <- "Low-skilled"
ess$moccupation14[is.na(ess$moccupation14) & !is.na(ess$munemploy14)] <- "Low-skilled"

ess$moccupation14 <- as.factor(ess$moccupation14)
ess <- within(ess, moccupation14 <- relevel(moccupation14, ref = "High-skilled"))

ess <- ess[ess$brncntr==1, ] #restricts to only respondents who are citizens of country. 
ess <- ess[ess$ctzcntr==1, ] #restricts to only respondents who are citizens of country.

ess <- within(ess,{c<-as.numeric(factor(paste0(country, yrbrn)))})

ess <- completeFun(ess, c("country", "female", "pcitizen", "minority", "feduc", "peduc", "cohort", "age", "lrideology", "educationy", "income", "union", "locationtype", "foccupation14", "moccupation14"))

##RTI and Offshorability Data (from Johnston and Owens)
setwd(paste(location, "data/econdata", sep = ""))

rti <- read.dta13("rti.dta")
rti <- select(rti, rti, offshorable, manufacture, isco88)
rti$v1 <- 1 
rti$v2 <- ave(rti$v1, rti$isco88, FUN = seq_along)
rti$v2[rti$v2>1] <- NA
rti <- completeFun(rti, "v2")
rti <- rti[,-c(5,6)]

rti1 <- rti
colnames(rti1) <- c("rti_co", "offshorable_co", "manufacture_co", "iscoco")
ess$iscoco[ess$iscoco==100] <- 110
ess <- merge(ess, rti1, by=c("iscoco"), all.x=TRUE, all.y=FALSE)

rti1 <- rti
isco <- read.csv("isco.csv")
isco$x2 <- 1
rti1 <- merge(isco, rti1, by=c("isco88"), all=TRUE)
rti1 <- completeFun(rti1, c("rti", "isco08"))
rti1$rti <- ave(rti1$rti, rti1$isco08, FUN = mean)
rti1$offshorable <- ave(rti1$offshorable, rti1$isco08, FUN = mean)
rti1$manufacture <- ave(rti1$manufacture, rti1$isco08, FUN = mean)
rti1$manufacture <- round(rti1$manufacture)
rti1$v1 <- 1 
rti1$v2 <- ave(rti1$v1, rti1$isco08, FUN = seq_along)
rti1$v2[rti1$v2>1] <- NA
rti1 <- completeFun(rti1, "v2")

rti1 <- rti1[,c(3,7,8,9)]
colnames(rti1) <- c("isco08", "rti_08", "offshorable_08", "manufacture_08")

ess <- merge(ess, rti1, by=c("isco08"), all.x=TRUE, all.y=FALSE)

ess <- ess %>%
    mutate(rti = ifelse(!is.na(rti_co), rti_co, rti_08)) %>%
    mutate(offshorable = ifelse(!is.na(offshorable_co), offshorable_co, offshorable_08)) %>%
    mutate(manufacture = ifelse(!is.na(manufacture_co), manufacture_co, manufacture_08)) %>%
    as.data.frame()

ess <- select(ess, age, country, essround, pspwght, income, syear, imsmetn, imdfetn, impcntr, imbgeco, imueclt, imwbcnt, imm1, imm2, imm3, imm11, imm22, imm33, imm13a, imm13b, imm4, imm5, imm6, immigration, racial, minority, locationtype, female, feduc, meduc, peduc, union, pcitizen, country1, foccupation14, moccupation14, cohort, lrideology, educationy, education, unemployed, econview, datalim, iscoco, isco08, rti, offshorable, manufacture, incdif, postsecondary, secondary, c)

isco <- rti <- rti1 <- NULL


#####################
##Unemployment Data##
#####################

setwd("~/Library/CloudStorage/Box-Box/macroshocks/ess/economic")
unemp <- read.csv("ess_unemployment.csv")

for(i in 18:25){
  ess$year <- ess$cohort + i
  d <- merge(ess, unemp, by=c("country", "year"), all.x=TRUE, all.y=FALSE)
  d <- d %>%
    mutate(unemployment = ifelse(syear<year, NA, unemployment)) %>%
    as.data.frame()
  o <- c("unemployment")
  n <- paste0(o, i, sep = "")	
  setnames(d, old = o, new = n)
  ess <- d
  print(i)
}

ess$unemployment_1825 <- rowMeans(cbind(ess$unemployment18, ess$unemployment19, ess$unemployment20, ess$unemployment21, ess$unemployment22, ess$unemployment23, ess$unemployment24, ess$unemployment25), na.rm = T)

s <- which( colnames(ess)=="unemployment18")
l <- which( colnames(ess)=="unemployment25")
ess <- subset(ess, select = -c(s:l))

ess$employment_1825 <- log(ess$employment_1825)

d <- unemp <- NULL


########################
##Economic Shocks Data##
########################

setwd("~/Library/CloudStorage/Box-Box/macroshocks/ess/economic")
shock <- read.csv("ess_gdpshock.csv")

for(i in 0:58){
	ess$year <- ess$cohort + i
	d <- merge(ess, shock, by=c("country", "year"), all.x=TRUE, all.y=FALSE)
	d <- d %>%
    		mutate(shock6 = ifelse(syear<year, 0, shock6)) %>%	
		mutate(shock5 = ifelse(syear<year, 0, shock5)) %>%
		mutate(shock4 = ifelse(syear<year, 0, shock4)) %>%
		mutate(shock3 = ifelse(syear<year, 0, shock3)) %>%
		mutate(shock2 = ifelse(syear<year, 0, shock2)) %>%
		mutate(shock1 = ifelse(syear<year, 0, shock1)) %>%
		mutate(shocka = ifelse(syear<year, 0, shocka)) %>%
		mutate(shockcont = ifelse(syear<year, 0, shockcont)) %>%
		mutate(pt4 = ifelse(syear<year, 0, pt4)) %>%
		as.data.frame()
	o <- c("pt4", "shocka", "shock6", "shock5", "shock4", "shock3", "shock2", "shock1", "shockcont")
	n <- paste0(o, i, sep = "")	
	setnames(d, old = o, new = n)
	ess <- d
	print(i)
}

ess <- ess %>%
	mutate(shock4_29comb=shock42+shock43+shock44+shock45+shock46+shock47+shock48+shock49) %>%
	mutate(shock4_1017comb=shock410+shock411+shock412+shock413+shock414+shock415+shock416+shock417) %>%
	mutate(shock4_1825comb=shock418+shock419+shock420+shock421+shock422+shock423+shock424+shock425) %>%
	mutate(shock4_2633comb=shock426+shock427+shock428+shock429+shock430+shock431+shock432+shock433) %>%
	mutate(shock4_3441comb=shock434+shock435+shock436+shock437+shock438+shock439+shock440+shock441) %>%
	mutate(shock4_4249comb=shock442+shock443+shock444+shock445+shock446+shock447+shock448+shock449) %>%
	mutate(shock4_5057comb=shock450+shock451+shock452+shock453+shock454+shock455+shock456+shock457) %>%
		
	mutate(shock4_29 = ifelse(shock4_29comb>=1 & shock4_29comb<=8, 1, shock4_29comb)) %>%
	mutate(shock4_1017 = ifelse(shock4_1017comb>=1 & shock4_1017comb<=8, 1, shock4_1017comb)) %>%
	mutate(shock4_1825 = ifelse(shock4_1825comb>=1 & shock4_1825comb<=8, 1, shock4_1825comb)) %>%
	mutate(shock4_2633 = ifelse(shock4_2633comb>=1 & shock4_2633comb<=8, 1, shock4_2633comb)) %>%
	mutate(shock4_3441 = ifelse(shock4_3441comb>=1 & shock4_3441comb<=8, 1, shock4_3441comb)) %>%
	mutate(shock4_4249 = ifelse(shock4_4249comb>=1 & shock4_4249comb<=8, 1, shock4_4249comb)) %>%	
	mutate(shock4_5057 = ifelse(shock4_5057comb>=1 & shock4_5057comb<=8, 1, shock4_5057comb)) %>%

	mutate(shock4_1025comb=shock4_1017comb + shock4_1825comb) %>%
	mutate(shock4_1425comb=shock414+shock415+shock416+shock417+shock4_1825comb) %>%
	mutate(shock4_1625comb=shock416+shock417+shock4_1825comb) %>%
	mutate(shock4_1725comb=shock417+shock4_1825comb) %>%
	mutate(shock4_1926comb=shock419+shock420+shock421+shock422+shock423+shock424+shock425+shock426) %>%
	mutate(shock4_1821comb=shock418+shock419+shock420+shock421) %>%
	mutate(shock4_2225comb=shock422+shock423+shock424+shock425) %>%
	mutate(shock4_2629comb=shock426+shock427+shock428+shock429) %>%
	mutate(shock4_3033comb=shock430+shock431+shock432+shock433) %>%
  
	mutate(shock4_1025 = ifelse(shock4_1025comb>=1 & shock4_1025comb<=20, 1, shock4_1025comb)) %>%
	mutate(shock4_1425 = ifelse(shock4_1425comb>=1 & shock4_1425comb<=20, 1, shock4_1425comb)) %>%
	mutate(shock4_1625 = ifelse(shock4_1625comb>=1 & shock4_1625comb<=20, 1, shock4_1625comb)) %>%
	mutate(shock4_1725 = ifelse(shock4_1725comb>=1 & shock4_1725comb<=20, 1, shock4_1725comb)) %>%
	mutate(shock4_1926 = ifelse(shock4_1926comb>=1 & shock4_1926comb<=20, 1, shock4_1926comb)) %>%
	mutate(shock4_1821 = ifelse(shock4_1821comb>=1 & shock4_1821comb<=20, 1, shock4_1821comb)) %>%
	mutate(shock4_2225 = ifelse(shock4_2225comb>=1 & shock4_2225comb<=20, 1, shock4_2225comb)) %>%
	mutate(shock4_2629 = ifelse(shock4_2629comb>=1 & shock4_2629comb<=20, 1, shock4_2629comb)) %>%
	mutate(shock4_3033 = ifelse(shock4_3033comb>=1 & shock4_3033comb<=20, 1, shock4_3033comb)) %>%
	
	mutate(shock1_1825comb = shock118+shock119+shock120+shock121+shock122+shock123+shock124+shock125) %>%
	mutate(shock2_1825comb = shock218+shock219+shock220+shock221+shock222+shock223+shock224+shock225) %>%
	mutate(shock3_1825comb = shock318+shock319+shock320+shock321+shock322+shock323+shock324+shock325) %>%
	mutate(shock5_1825comb = shock518+shock519+shock520+shock521+shock522+shock523+shock524+shock525) %>%
	mutate(shock6_1825comb = shock618+shock619+shock620+shock621+shock622+shock623+shock624+shock625) %>%

	mutate(shock1_1825 = ifelse(shock1_1825comb>=1 & shock1_1825comb<=8, 1, shock1_1825comb)) %>%
	mutate(shock2_1825 = ifelse(shock2_1825comb>=1 & shock2_1825comb<=8, 1, shock2_1825comb)) %>%
	mutate(shock3_1825 = ifelse(shock3_1825comb>=1 & shock3_1825comb<=8, 1, shock3_1825comb)) %>%
	mutate(shock5_1825 = ifelse(shock5_1825comb>=1 & shock5_1825comb<=8, 1, shock5_1825comb)) %>%
	mutate(shock6_1825 = ifelse(shock6_1825comb>=1 & shock6_1825comb<=8, 1, shock6_1825comb)) %>%
	
	mutate(pt4_1825comb=pt418+pt419+pt420+pt421+pt422+pt423+pt424+pt425) %>%
	mutate(pt4_1825 = ifelse(pt4_1825comb>=1 & pt4_1825comb<=8, 1, pt4_1825comb)) %>%

	mutate(shocka_1825comb=shocka18+shocka19+shocka20+shocka21+shocka22+shocka23+shocka24+shocka25) %>%
	mutate(shocka_1825 = ifelse(shocka_1825comb>=1 & shocka_1825comb<=8, 1, shocka_1825comb)) %>%

	mutate(shockcont_1825 = shockcont18 + shockcont19 + shockcont20 + shockcont21 + shockcont22 + shockcont23 + 	shockcont24 	+ shockcont25) %>%
	mutate(shockcont_1825 = log(abs(shockcont_1825*100) + 1)) %>%

	mutate(shockoutside = ifelse(shock4_29==1 | shock4_1017==1 | shock4_2633==1 | shock4_3441==1 | shock4_4249==1 | shock4_5057==1, 1, 0)) %>%
	
	as.data.frame()

s <- which( colnames(ess)=="pt40")
l <- which( colnames(ess)=="shockcont58")
ess <- subset(ess, select = -c(s:l))

d <- shock <- NULL

##################
##Democracy Data##
##################

dem <- data.table::setDT(vdemdata::vdem)
dem$country_name[dem$country_name=="United Kingdom"] <- "uk"
dem$country_name[dem$country_name=="Czech Republic"] <- "czech"
dem$country_name <- tolower(dem$country_name)
dem <- dem[dem$year>=1850, c("country_name", "year", "v2peedueq", "v2x_polyarchy", "e_peaveduc", "v2xeg_eqdr")]

c <- levels(as.factor(ess$country))
dem$ind <- 0
for(i in 1:length(c)){
	cc <- c[i]
	dem$ind[dem$country_name==cc] <- 1
}

dem <- dem[dem$ind==1, -c("ind")]
colnames(dem) <- c("country", "year", "eduq", "dem", "aveedu", "eqdr")

for(i in 0:49){
	ess$year <- ess$cohort + i
	d <- merge(ess, dem, by=c("country", "year"), all.x=TRUE, all.y=FALSE)
	o <- c("eduq", "dem", "aveedu", "eqdr")
	n <- paste0(o, i, sep = "")	
	setnames(d, old = o, new = n)
	ess <- d
	print(i)
}

ess <- ess %>%
	mutate(dem_01 = (dem0+dem1)/2) %>%	
	mutate(dem_29 = (dem2+dem3+dem4+dem5+dem6+dem7+dem8+dem9)/8) %>%
	mutate(dem_1017 = (dem10+dem11+dem12+dem13+dem14+dem15+dem16+dem17)/8) %>%
	mutate(dem_1825 = (dem18+dem19+dem20+dem21+dem22+dem23+dem24+dem25)/8) %>%
	mutate(dem_2633 = (dem26+dem27+dem28+dem29+dem30+dem31+dem32+dem33)/8) %>%
	mutate(dem_3441 = (dem34+dem35+dem36+dem37+dem38+dem39+dem40+dem41)/8) %>%
	mutate(dem_4249 = (dem42+dem43+dem44+dem45+dem46+dem47+dem48+dem49)/8) %>%

	mutate(eduq_01 = (eduq0+eduq1)/2) %>%	
	mutate(eduq_29 = (eduq2+eduq3+eduq4+eduq5+eduq6+eduq7+eduq8+eduq9)/8) %>%
	mutate(eduq_1017 = (eduq10+eduq11+eduq12+eduq13+eduq14+eduq15+eduq16+eduq17)/8) %>%
	mutate(eduq_1825 = (eduq18+eduq19+eduq20+eduq21+eduq22+eduq23+eduq24+eduq25)/8) %>%
	mutate(eduq_2633 = (eduq26+eduq27+eduq28+eduq29+eduq30+eduq31+eduq32+eduq33)/8) %>%
	mutate(eduq_3441 = (eduq34+eduq35+eduq36+eduq37+eduq38+eduq39+eduq40+eduq41)/8) %>%
	mutate(eduq_4249 = (eduq42+eduq43+eduq44+eduq45+eduq46+eduq47+eduq48+eduq49)/8) %>%

	mutate(aveedu_01 = (aveedu0+aveedu1)/2) %>%		
	mutate(aveedu_29 = (aveedu2+aveedu3+aveedu4+aveedu5+aveedu6+aveedu7+aveedu8+aveedu9)/8) %>%
	mutate(aveedu_1017 = (aveedu10+aveedu11+aveedu12+aveedu13+aveedu14+aveedu15+aveedu16+aveedu17)/8) %>%
	mutate(aveedu_1825 = (aveedu18+aveedu19+aveedu20+aveedu21+aveedu22+aveedu23+aveedu24+aveedu25)/8) %>%
	mutate(aveedu_2633 = (aveedu26+aveedu27+aveedu28+aveedu29+aveedu30+aveedu31+aveedu32+aveedu33)/8) %>%
	mutate(aveedu_3441 = (aveedu34+aveedu35+aveedu36+aveedu37+aveedu38+aveedu39+aveedu40+aveedu41)/8) %>%
	mutate(aveedu_4249 = (aveedu42+aveedu43+aveedu44+aveedu45+aveedu46+aveedu47+aveedu48+aveedu49)/8) %>%
	
	mutate(eqdr_01 = (eqdr0+eqdr1)/2) %>%			
	mutate(eqdr_29 = (eqdr2+eqdr3+eqdr4+eqdr5+eqdr6+eqdr7+eqdr8+eqdr9)/8) %>%
	mutate(eqdr_1017 = (eqdr10+eqdr11+eqdr12+eqdr13+eqdr14+eqdr15+eqdr16+eqdr17)/8) %>%
	mutate(eqdr_1825 = (eqdr18+eqdr19+eqdr20+eqdr21+eqdr22+eqdr23+eqdr24+eqdr25)/8) %>%
	mutate(eqdr_2633 = (eqdr26+eqdr27+eqdr28+eqdr29+eqdr30+eqdr31+eqdr32+eqdr33)/8) %>%
	mutate(eqdr_3441 = (eqdr34+eqdr35+eqdr36+eqdr37+eqdr38+eqdr39+eqdr40+eqdr41)/8) %>%
	mutate(eqdr_4249 = (eqdr42+eqdr43+eqdr44+eqdr45+eqdr46+eqdr47+eqdr48+eqdr49)/8) %>%
	
	as.data.frame()



s <- which( colnames(ess)=="eduq0")
l <- which( colnames(ess)=="eqdr49")
ess <- subset(ess, select = -c(s:l))

d <- dem <- NULL


#########################
##Current Economic Data##
#########################


data <- read.csv("mpd2020.csv")
data$country <- tolower(data$country)
data$country[data$country=="united kingdom"] <- "uk"
data$country[data$country=="czech republic"] <- "czech"
data$country[data$country=="russian federation"] <- "russia"
data$ind <- 0
c <- c("austria", "belgium", "bulgaria", "croatia", "czech", "denmark", "estonia", "finland", "france", "germany", "greece", "hungary", "iceland", "italy", "netherlands", "norway", "portugal", "russia", "slovenia", "spain", "sweden", "switzerland","uk")
for(i in 1:length(c)){
	cc <- c[i]
	data$ind[data$country==cc] <- 1	
}
data <- data[data$ind==1,-c(1,6)]
data <- data[data$year>=1900,]
data$gdppc <- as.numeric(gsub(",","",as.character(data$gdppc)))
data$pop <- as.numeric(gsub(",","",as.character(data$pop)))
data$gdp <- (as.numeric(data$gdppc) * as.numeric(data$pop))/1000000

data <- data %>%
    group_by(country) %>%
    arrange(year) %>%
    mutate(lag1 = lag(gdp, n=1L, default = NA)) %>%
    mutate(growth = (gdp - lag1)/lag1 ) %>% 
    as.data.frame()

gdp <- data
gdp <- gdp[,c(1,2,5)]
gdp <- completeFun(gdp, "gdp")

for(i in 10:25){
	ess$year <- ess$cohort + i
	d <- merge(ess, gdp, by=c("country", "year"), all.x=TRUE, all.y=FALSE)
	o <- c("gdp")
	n <- paste0(o, i, sep = "")	
	setnames(d, old = o, new = n)
	ess <- d
	print(i)
}

ess <- ess %>%
	mutate(gdp_1017=gdp10+gdp11+gdp12+gdp13+gdp14+gdp15+gdp16+gdp17) %>%
	as.data.frame()
	
s <- which( colnames(ess)=="gdp10")
l <- which( colnames(ess)=="gdp25")
ess <- subset(ess, select = -c(s:l))

ess <- completeFun(ess, c("shock4_1825", "eduq_1017", "aveedu_1017"))




setwd(paste(location, "data/final", sep = ""))
save(ess, file = "ess_main.Rdata")
