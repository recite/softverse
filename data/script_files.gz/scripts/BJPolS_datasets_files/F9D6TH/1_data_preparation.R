

## REPLICATION MATERIAL FOR
## HOW DOES UNCERTAINTY AFFECT VOTERS' PREFERENCES?
## BRITISH JOURNAL OF POLITICAL SCIENCE
## AUTHOR: LOVE CHRISTENSEN


####################################
###### FILE 1: DATA PREPARATION ####
####################################

# This file prepares the qualtrics data for the analysis. Note that the resulting data set is saved as "dat_uncertainty_BJPS_cleaned.RData," which is later read by the analysis script (2_models.R)
# This script is not necessary to run before running the actual analysis, since the analysis file reads the cleaned data.

## read packages
library(qualtRics)
library(tidyverse)
library(lmtest)
library(car)
library(estimatr)
library(gridExtra)
library(readstata13)
library(reshape2)
library(lubridate)

## This command sets the directory were the file currently is as the working directory for OSX
## If you use windows, or if this command does not work for other reasons, manually put in the directory to where the 1_data_preparation.R is
## Note that all files are read and written relative to this path (hence the output/tables and output/figures directory)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## read qualtrics data
load("../data/dat_attitude_uncert.RData")

## drop unnecessary variables
dat <- dat %>% dplyr::select(
  -c(FL_15_DO,
     FL_25_DO,
     FL_20_DO,
     FL_11_DO,
     RandomNumber,
     LessThan60,
     mw_control_DO,
     ct_control_DO,
     tpp_control_DO,
     Expert,
     Partisan,
     Status,
     Progress,
     `Duration (in seconds)`,
     Finished,
     RecordedDate,
     RecipientLastName,
     RecipientFirstName,
     ExternalReference,
     DistributionChannel,
     UserLanguage,
     country,
     RecipientEmail,
     feedback_text)
)

## drop if not assigned to treatment or control
dat <- dat %>% filter(is.na(Condition) == FALSE)

####################################################
############# MINIMUM WAGE REFORM ##################
####################################################

## split question list into treatment variables
## for experts
mw_split_expert <- strsplit(dat$mw_expert_DO, "\\|") %>% sapply(function(x) x[2]) 
mw_treatment_expert <- strsplit(mw_split_expert, "_") %>% sapply(function(x) x[2])
dat$mw_treatment_expert <- mw_treatment_expert

## for partisans
mw_split_partisan <- strsplit(dat$mw_partisan_DO, "\\|") %>% sapply(function(x) x[2]) 
mw_treatment_partisan <- strsplit(mw_split_partisan, "_") %>% sapply(function(x) x[2])
dat$mw_treatment_partisan <- mw_treatment_partisan

## generate one sender treatment variable
dat$mw_forecast <- dat$mw_treatment_expert
dat$mw_forecast[dat$Condition == "Partisan"] <- dat$mw_treatment_partisan[dat$Condition == "Partisan"]

## generate forecast variables
dat$mw_forecast_uncertain <- ifelse(nchar(dat$mw_forecast) > 2, 1, 0)
dat$mw_forecast_uncertain <- ifelse(is.na(dat$mw_forecast) == FALSE, dat$mw_forecast_uncertain, NA)
dat$mw_forecast_low <- NA
dat$mw_forecast_high <- NA
dat$mw_forecast_low <- ifelse(nchar(dat$mw_forecast) > 2, substr(dat$mw_forecast, 1, 2), NA)
dat$mw_forecast_high <- ifelse(nchar(dat$mw_forecast) > 2, substr(dat$mw_forecast, 3, 4), NA)

## make numerical variable of forecast variables
dat$mw_forecast <- ifelse(dat$mw_forecast_uncertain == 1, NA, dat$mw_forecast)

dat$mw_forecast <- ifelse(substr(dat$mw_forecast, 1, 1) == "p", 
                                 substr(dat$mw_forecast, 2, 2), 
                                 paste("-", substr(dat$mw_forecast, 2, 2), sep =""))

dat$mw_forecast_low <- ifelse(substr(dat$mw_forecast_low, 1, 1) == "p", 
                          substr(dat$mw_forecast_low, 2, 2), 
                          paste("-", substr(dat$mw_forecast_low, 2, 2), sep =""))

dat$mw_forecast_high <- ifelse(substr(dat$mw_forecast_high, 1, 1) == "p", 
                              substr(dat$mw_forecast_high, 2, 2), 
                              paste("-", substr(dat$mw_forecast_high, 2, 2), sep =""))

dat <- dat %>% mutate(mw_forecast = as.numeric(mw_forecast),
                      mw_forecast_low = as.numeric(mw_forecast_low),
                      mw_forecast_high = as.numeric(mw_forecast_high))

dat$mw_forecast_center <- ifelse(dat$mw_forecast_uncertain == 1,
                                 (dat$mw_forecast_low + dat$mw_forecast_high)/2,
                                 dat$mw_forecast)

dat$mw_forcast_uncertain_large <- 0
dat$mw_forecast_uncertain_large <- ifelse(abs(dat$mw_forecast_high - dat$mw_forecast_low) > 2,
                                          1,
                                          0)

dat$mw_forecast_uncertain_small <- 0
dat$mw_forecast_uncertain_small <- ifelse(abs(dat$mw_forecast_high - dat$mw_forecast_low) == 2,
                                          1,
                                          0)

dat$mw_forecast_uncertain_magnitude <- 0 
dat$mw_forecast_uncertain_magnitude <- ifelse(dat$mw_forecast_uncertain_small == 1, 1, dat$mw_forecast_uncertain_magnitude)
dat$mw_forecast_uncertain_magnitude <- ifelse(dat$mw_forecast_uncertain_large == 1, 2, dat$mw_forecast_uncertain_magnitude)
dat$mw_forecast_uncertain_magnitude <- ifelse(dat$mw_forecast_uncertain == 0, 0, dat$mw_forecast_uncertain_magnitude)

dat$mw_forecast_increase <- 0
dat$mw_forecast_increase[dat$mw_forecast_low > 0 | dat$mw_forecast > 0] <- 1

dat$mw_forecast_decrease <- 0
dat$mw_forecast_decrease[dat$mw_forecast_high <= 0 | dat$mw_forecast < 0] <- 1

## merge outcome variables across treatment conditions
dat$mw_likert <- NA
dat$mw_likert[dat$Condition == "Expert"] <- dat$mw_likert_e[dat$Condition == "Expert"]
dat$mw_likert[dat$Condition == "Partisan"] <- dat$mw_likert_p[dat$Condition == "Partisan"]

dat$mw_qual <- NA
dat$mw_qual[dat$Condition == "Expert"] <- dat$mw_qual_e[dat$Condition == "Expert"]
dat$mw_qual[dat$Condition == "Partisan"] <- dat$mw_qual_p[dat$Condition == "Partisan"]

dat$mw_qual_increase <- ifelse(dat$mw_qual == 1, 1, 0)

dat$mw_quant <- NA
dat$mw_quant[dat$Condition == "Expert"] <- dat$mw_quant_e_1[dat$Condition == "Expert"]
dat$mw_quant[dat$Condition == "Partisan"] <- dat$mw_quant_p_1[dat$Condition == "Partisan"]

dat$mw_cert <- NA
dat$mw_cert[dat$Condition == "Expert"] <- dat$mw_cert_e[dat$Condition == "Expert"]
dat$mw_cert[dat$Condition == "Partisan"] <- dat$mw_cert_p[dat$Condition == "Partisan"]

dat$mw_ideal <- NA
dat$mw_ideal[dat$Condition == "Expert"] <- dat$mw_ideal_e[dat$Condition == "Expert"]
dat$mw_ideal[dat$Condition == "Partisan"] <- dat$mw_ideal_p[dat$Condition == "Partisan"]

## recode qualitative belief variable
dat <- dat %>% mutate(mw_qual_increase= ifelse(mw_qual == 1, 1, 0))

## generate variable indicating predictions in both loss and gain domain
dat$mw_forecast_crossing <- ifelse(dat$mw_forecast_low < 0 & dat$mw_forecast_high >= 0,
                                1, 0)

dat$mw_forecast_crossing <- ifelse(dat$mw_forecast_uncertain == 0 & dat$Condition != "Control",
                                   0,
                                   dat$mw_forecast_crossing)

dat$mw_forecast_inc <- ifelse(dat$mw_forecast_center > 0, 1, 0)
dat$mw_forecast_dec <- ifelse(dat$mw_forecast_center < 0, 1, 0)



####################################################
############## CORPORATE TAX REFORM ################
####################################################

## split question list into treatment variables
## for experts
ct_split_expert <- strsplit(dat$ct_expert_DO, "\\|") %>% sapply(function(x) x[2]) 
ct_treatment_expert <- strsplit(ct_split_expert, "_") %>% sapply(function(x) x[2])
dat$ct_treatment_expert <- ct_treatment_expert

## for partisans
ct_split_partisan <- strsplit(dat$ct_partisan_DO, "\\|") %>% sapply(function(x) x[2]) 
ct_treatment_partisan <- strsplit(ct_split_partisan, "_") %>% sapply(function(x) x[2])
dat$ct_treatment_partisan <- ct_treatment_partisan

## generate one treatment variable
dat$ct_forecast <- dat$ct_treatment_expert
dat$ct_forecast[dat$Condition == "Partisan"] <- dat$ct_treatment_partisan[dat$Condition == "Partisan"]

## generate forecast variables

dat$ct_forecast_uncertain <- ifelse(nchar(dat$ct_forecast) > 2, 1, 0)
dat$ct_forecast_uncertain <- ifelse(is.na(dat$ct_forecast) == FALSE, dat$ct_forecast_uncertain, NA)
dat$ct_forecast_low <- NA
dat$ct_forecast_high <- NA
dat$ct_forecast_low <- ifelse(nchar(dat$ct_forecast) > 2, substr(dat$ct_forecast, 1, 2), NA)
dat$ct_forecast_high <- ifelse(nchar(dat$ct_forecast) > 2, substr(dat$ct_forecast, 3, 4), NA)

## make numerical variable of forecast variables
dat$ct_forecast <- ifelse(dat$ct_forecast_uncertain == 1, NA, dat$ct_forecast)

dat$ct_forecast <- ifelse(substr(dat$ct_forecast, 1, 1) == "p", 
                          substr(dat$ct_forecast, 2, 2), 
                          paste("-", substr(dat$ct_forecast, 2, 2), sep =""))

dat$ct_forecast_low <- ifelse(substr(dat$ct_forecast_low, 1, 1) == "p", 
                              substr(dat$ct_forecast_low, 2, 2), 
                              paste("-", substr(dat$ct_forecast_low, 2, 2), sep =""))

dat$ct_forecast_high <- ifelse(substr(dat$ct_forecast_high, 1, 1) == "p", 
                               substr(dat$ct_forecast_high, 2, 2), 
                               paste("-", substr(dat$ct_forecast_high, 2, 2), sep =""))

dat <- dat %>% mutate(ct_forecast = as.numeric(ct_forecast),
                      ct_forecast_low = as.numeric(ct_forecast_low),
                      ct_forecast_high = as.numeric(ct_forecast_high))

dat$ct_forecast_center <- ifelse(dat$ct_forecast_uncertain == 1,
                                 (dat$ct_forecast_low + dat$ct_forecast_high)/2,
                                 dat$ct_forecast)

dat$ct_forcast_uncertain_large <- 0
dat$ct_forecast_uncertain_large <- ifelse(abs(dat$ct_forecast_high - dat$ct_forecast_low) > 2,
                                          1,
                                          0)

dat$ct_forecast_uncertain_small <- 0
dat$ct_forecast_uncertain_small <- ifelse(abs(dat$ct_forecast_high - dat$ct_forecast_low) == 2,
                                          1,
                                          0)

dat$ct_forecast_uncertain_magnitude <- 0 
dat$ct_forecast_uncertain_magnitude <- ifelse(dat$ct_forecast_uncertain_small == 1, 1, dat$ct_forecast_uncertain_magnitude)
dat$ct_forecast_uncertain_magnitude <- ifelse(dat$ct_forecast_uncertain_large == 1, 2, dat$ct_forecast_uncertain_magnitude)
dat$ct_forecast_uncertain_magnitude <- ifelse(dat$ct_forecast_uncertain == 0, 0, dat$ct_forecast_uncertain_magnitude)

dat$ct_forecast_increase <- 0
dat$ct_forecast_increase[dat$ct_forecast_low > 0 | dat$ct_forecast > 0] <- 1

dat$ct_forecast_decrease <- 0
dat$ct_forecast_decrease[dat$ct_forecast_high <= 0 | dat$ct_forecast < 0] <- 1


## merge outcome variables
dat$ct_likert <- NA
dat$ct_likert[dat$Condition == "Expert"] <- dat$ct_likert_e[dat$Condition == "Expert"]
dat$ct_likert[dat$Condition == "Partisan"] <- dat$ct_likert_p[dat$Condition == "Partisan"]

dat$ct_qual <- NA
dat$ct_qual[dat$Condition == "Expert"] <- dat$ct_qual_e[dat$Condition == "Expert"]
dat$ct_qual[dat$Condition == "Partisan"] <- dat$ct_qual_p[dat$Condition == "Partisan"]

dat$ct_qual_increase <- ifelse(dat$ct_qual == 1, 1, 0)

dat$ct_quant <- NA
dat$ct_quant[dat$Condition == "Expert"] <- dat$ct_quant_e_1[dat$Condition == "Expert"]
dat$ct_quant[dat$Condition == "Partisan"] <- dat$ct_quant_p_1[dat$Condition == "Partisan"]

dat$ct_cert <- NA
dat$ct_cert[dat$Condition == "Expert"] <- dat$ct_cert_e[dat$Condition == "Expert"]
dat$ct_cert[dat$Condition == "Partisan"] <- dat$ct_cert_p[dat$Condition == "Partisan"]

dat$ct_ideal <- NA
dat$ct_ideal[dat$Condition == "Expert"] <- dat$ct_ideal_e[dat$Condition == "Expert"]
dat$ct_ideal[dat$Condition == "Partisan"] <- dat$ct_ideal_p[dat$Condition == "Partisan"]

## recode qualitative belief variable
dat <- dat %>% mutate(ct_qual_increase= ifelse(ct_qual == 1, 1, 0))

## generate variable indicating predictions in both loss and gain domain
dat$ct_forecast_crossing <- ifelse(dat$ct_forecast_low < 0 & dat$ct_forecast_high >= 0,
                                   1, 0)

dat$ct_forecast_crossing <- ifelse(dat$ct_forecast_uncertain == 0 & dat$Condition != "Control",
                                   0,
                                   dat$ct_forecast_crossing)

dat$ct_forecast_inc <- ifelse(dat$ct_forecast_center > 0, 1, 0)
dat$ct_forecast_dec <- ifelse(dat$ct_forecast_center < 0, 1, 0)

####################################################
################## TPP REFORM ######################
####################################################

## split question list into treatment variables
## for experts
tpp_split_expert <- strsplit(dat$tpp_expert_DO, "\\|") %>% sapply(function(x) x[2]) 
tpp_treatment_expert <- strsplit(tpp_split_expert, "_") %>% sapply(function(x) x[2])
dat$tpp_treatment_expert <- tpp_treatment_expert

## for partisans
tpp_split_partisan <- strsplit(dat$tpp_partisan_DO, "\\|") %>% sapply(function(x) x[2]) 
tpp_treatment_partisan <- strsplit(tpp_split_partisan, "_") %>% sapply(function(x) x[2])
dat$tpp_treatment_partisan <- tpp_treatment_partisan

## generate one treatment variable
dat$tpp_forecast <- dat$tpp_treatment_expert
dat$tpp_forecast[dat$Condition == "Partisan"] <- dat$tpp_treatment_partisan[dat$Condition == "Partisan"]

## generate forecast variables

dat$tpp_forecast_uncertain <- ifelse(nchar(dat$tpp_forecast) > 2, 1, 0)
dat$tpp_forecast_uncertain <- ifelse(is.na(dat$tpp_forecast) == FALSE, dat$tpp_forecast_uncertain, NA)
dat$tpp_forecast_low <- NA
dat$tpp_forecast_high <- NA
dat$tpp_forecast_low <- ifelse(nchar(dat$tpp_forecast) > 2, substr(dat$tpp_forecast, 1, 2), NA)
dat$tpp_forecast_high <- ifelse(nchar(dat$tpp_forecast) > 2, substr(dat$tpp_forecast, 3, 4), NA)

## make numerical variable of forecast variables
dat$tpp_forecast <- ifelse(dat$tpp_forecast_uncertain == 1, NA, dat$tpp_forecast)

dat$tpp_forecast <- ifelse(substr(dat$tpp_forecast, 1, 1) == "p", 
                          substr(dat$tpp_forecast, 2, 2), 
                          paste("-", substr(dat$tpp_forecast, 2, 2), sep =""))

dat$tpp_forecast_low <- ifelse(substr(dat$tpp_forecast_low, 1, 1) == "p", 
                              substr(dat$tpp_forecast_low, 2, 2), 
                              paste("-", substr(dat$tpp_forecast_low, 2, 2), sep =""))

dat$tpp_forecast_high <- ifelse(substr(dat$tpp_forecast_high, 1, 1) == "p", 
                               substr(dat$tpp_forecast_high, 2, 2), 
                               paste("-", substr(dat$tpp_forecast_high, 2, 2), sep =""))

dat <- dat %>% mutate(tpp_forecast = as.numeric(tpp_forecast),
                      tpp_forecast_low = as.numeric(tpp_forecast_low),
                      tpp_forecast_high = as.numeric(tpp_forecast_high))

dat$tpp_forecast_center <- ifelse(dat$tpp_forecast_uncertain == 1,
                                 (dat$tpp_forecast_low + dat$tpp_forecast_high)/2,
                                 dat$tpp_forecast)

dat$tpp_forcast_uncertain_large <- 0
dat$tpp_forecast_uncertain_large <- ifelse(abs(dat$tpp_forecast_high - dat$tpp_forecast_low) > 2,
                                          1,
                                          0)

dat$tpp_forecast_uncertain_small <- 0
dat$tpp_forecast_uncertain_small <- ifelse(abs(dat$tpp_forecast_high - dat$tpp_forecast_low) == 2,
                                          1,
                                          0)

dat$tpp_forecast_uncertain_magnitude <- 0 
dat$tpp_forecast_uncertain_magnitude <- ifelse(dat$tpp_forecast_uncertain_small == 1, 1, dat$tpp_forecast_uncertain_magnitude)
dat$tpp_forecast_uncertain_magnitude <- ifelse(dat$tpp_forecast_uncertain_large == 1, 2, dat$tpp_forecast_uncertain_magnitude)
dat$tpp_forecast_uncertain_magnitude <- ifelse(dat$tpp_forecast_uncertain == 0, 0, dat$tpp_forecast_uncertain_magnitude)

dat$tpp_forecast_increase <- 0
dat$tpp_forecast_increase[dat$tpp_forecast_low > 0 | dat$tpp_forecast > 0] <- 1

dat$tpp_forecast_decrease <- 0
dat$tpp_forecast_decrease[dat$tpp_forecast_high <= 0 | dat$tpp_forecast < 0] <- 1

## merge outcome variables
dat$tpp_likert <- NA
dat$tpp_likert[dat$Condition == "Expert"] <- dat$tpp_likert_e[dat$Condition == "Expert"]
dat$tpp_likert[dat$Condition == "Partisan"] <- dat$tpp_likert_p[dat$Condition == "Partisan"]

dat$tpp_qual <- NA
dat$tpp_qual[dat$Condition == "Expert"] <- dat$tpp_qual_e[dat$Condition == "Expert"]
dat$tpp_qual[dat$Condition == "Partisan"] <- dat$tpp_qual_p[dat$Condition == "Partisan"]

dat$tpp_qual_increase <- ifelse(dat$tpp_qual == 1, 1, 0)

dat$tpp_quant <- NA
dat$tpp_quant[dat$Condition == "Expert"] <- dat$tpp_quant_e_1[dat$Condition == "Expert"]
dat$tpp_quant[dat$Condition == "Partisan"] <- dat$tpp_quant_p_1[dat$Condition == "Partisan"]

dat$tpp_cert <- NA
dat$tpp_cert[dat$Condition == "Expert"] <- dat$tpp_cert_e[dat$Condition == "Expert"]
dat$tpp_cert[dat$Condition == "Partisan"] <- dat$tpp_cert_p[dat$Condition == "Partisan"]

dat$tpp_ideal <- NA
dat$tpp_ideal[dat$Condition == "Expert"] <- dat$tpp_ideal_e[dat$Condition == "Expert"]
dat$tpp_ideal[dat$Condition == "Partisan"] <- dat$tpp_ideal_p[dat$Condition == "Partisan"]


## recode qualitative belief variable
dat <- dat %>% mutate(tpp_qual_increase= ifelse(tpp_qual == 1, 1, 0))

## generate variable indicating predictions in both loss and gain domain
dat$tpp_forecast_crossing <- ifelse(dat$tpp_forecast_low < 0 & dat$tpp_forecast_high >= 0,
                                   1, 0)

dat$tpp_forecast_crossing <- ifelse(dat$tpp_forecast_uncertain == 0 & dat$Condition != "Control",
                                   0,
                                   dat$tpp_forecast_crossing)

dat$tpp_forecast_inc <- ifelse(dat$tpp_forecast_center > 0, 1, 0)
dat$tpp_forecast_dec <- ifelse(dat$tpp_forecast_center < 0, 1, 0)


## republican vs democrat high prediction
tpp_split_partisan2 <- strsplit(dat$tpp_partisan_DO, "\\|") %>% sapply(function(x) x[2]) 
tpp_treatment_partisan2 <- strsplit(tpp_split_partisan2, "_") %>% sapply(function(x) x[3])
dat$tpp_treatment_partisan2 <- tpp_treatment_partisan2
dat$tpp_rep_high <- ifelse(dat$tpp_treatment_partisan2 == "prh", 1, 0)
dat$tpp_rep_high <- ifelse(dat$Condition == "Expert", 0, dat$tpp_rep_high)
dat$tpp_dem_high <- ifelse(dat$tpp_treatment_partisan2 == "pdh", 1, 0)
dat$tpp_dem_high <- ifelse(dat$Condition == "Expert", 0, dat$tpp_dem_high)



##########################
### MERGING COVARIATES ###
##########################

dat_covariates <- read.dta13("../data/respondent_covariates.dta")
names(dat_covariates)[1] <- "rid"
dat_covariates$rid <- tolower(dat_covariates$rid)
attributes(dat$rid)$label <- NULL
dat <- dat %>% left_join(dat_covariates, by = c("rid" = "rid"))

##############################
##### RECODING COVARIATES ####
##############################

## education:
dat <- dat %>% 
  mutate(educ_college_degree = ifelse(education == "Associate Degree" | 
                                 education == "Bachelor's degree" |
                                 education == "Doctorate degree" |
                                 education == "Masters degree",
                               1, 0))

dat <- dat %>% 
  mutate(educ_highschool_voc_degree = ifelse(education == "High school graduate" | 
                                        education == "Some college or vocational training, no degree",
                                      1, 0))

dat <- dat %>% 
  mutate(educ_no_highschool = ifelse(education == "No high school diploma",
                                             1, 0))
## income
dat <- dat %>%
  mutate(income_less50K = ifelse(hhi == "Less than $14,999" |
                                   hhi == "$15,000 to $19,999" |
                                   hhi == "$20,000 to $24,999" |
                                   hhi == "$25,000 to $29,999" |
                                   hhi == "$30,000 to $34,999" |
                                   hhi == "$35,000 to $39,999" |
                                   hhi == "$40,000 to $44,999" |
                                   hhi == "$45,000 to $49,999",
                                 1, 0))

dat <- dat %>%
  mutate(income_50K100K = ifelse(hhi == "$50,000 to $54,999" |
                                   hhi == "$55,000 to $59,999" |
                                   hhi == "$60,000 to $64,999" |
                                   hhi == "$65,000 to $69,999" |
                                   hhi == "$70,000 to $74,999" |
                                   hhi == "$75,000 to $79,999" |
                                   hhi == "$80,000 to $84,999" |
                                   hhi == "$85,000 to $89,999" |
                                   hhi == "$90,000 to $94,999" |
                                   hhi == "$95,000 to $99,999",
                                 1, 0))

dat <- dat %>%
  mutate(income_100K150K = ifelse(hhi == "$100,000 to $124,999" |
                                   hhi == "$125,000 to $149,999",
                                 1, 0))

dat <- dat %>%
  mutate(income_150Kabove = ifelse(hhi == "$150,000 to $174,999" |
                                    hhi == "$175,000 to $199,999" |
                                     hhi == "$200,000 to $249,999" |
                                     hhi == "$250,000 and above",
                                  1, 0))

## gender
dat <- dat %>%
  mutate(female = ifelse(gender == "F", 1, 0))

## age
dat <- dat %>%
  mutate(age2 = age*age)

## generate sampling periods
## second sampling period started 2018-09-06
dat <- dat %>% mutate(response_day = round_date(StartDate, unit = "day"))
dat <- dat %>% mutate(sample_period = ifelse(response_day < "2018-09-06 UTC", 1, 2))
dat <- dat %>% filter(is.na(female) == FALSE)

dat$democrat <- ifelse(dat$partisanship == 1, 1, 0)
dat$republican <- ifelse(dat$partisanship == 2, 1, 0)
dat$independent <- ifelse(dat$partisanship == 3, 1, 0)


dat <- dat %>%
  mutate(partisan = ifelse(Condition == "Partisan", 1, 0))



## spread includes zero:


dat <- dat %>%
  mutate(mw_spread_0 = ifelse(mw_forecast_center >= -mw_forecast_uncertain_magnitude &
                                mw_forecast_center <= mw_forecast_uncertain_magnitude, 1, 0),
         ct_spread_0 = ifelse(ct_forecast_center >= -ct_forecast_uncertain_magnitude &
                                ct_forecast_center <= ct_forecast_uncertain_magnitude, 1, 0),
         tpp_spread_0 = ifelse(tpp_forecast_center >= -tpp_forecast_uncertain_magnitude &
                                tpp_forecast_center <= tpp_forecast_uncertain_magnitude, 1, 0)
         )


# note that loss domain for MW implies high forecasts since outcome is unemployment
dat <- dat %>%
  mutate(mw_loss_domain = ifelse(mw_forecast_center + mw_forecast_uncertain_magnitude > 0, 1, 0),
         ct_loss_domain = ifelse(ct_forecast_center + ct_forecast_uncertain_magnitude < 0, 1, 0),
         tpp_loss_domain = ifelse(tpp_forecast_center + tpp_forecast_uncertain_magnitude < 0, 1, 0)
  )

# drop variables that were only used in recoding
dat <- dat %>% dplyr::select(-ends_with("_e"))
dat <- dat %>% dplyr::select(-ends_with("_e_1"))
dat <- dat %>% dplyr::select(-ends_with("_p"))
dat <- dat %>% dplyr::select(-ends_with("_p_1"))
dat <- dat %>% dplyr::select(-ends_with("_large"))
dat <- dat %>% dplyr::select(-ends_with("_small"))
dat <- dat %>% dplyr::select(-ends_with("_DO"))
dat <- dat %>% dplyr::select(-ends_with("Date"))
dat <- dat %>% dplyr::select(-ends_with("_expert"))
dat <- dat %>% dplyr::select(-ends_with("_partisan"))
dat <- dat %>% dplyr::select(-ends_with("_forecast"))
dat <- dat %>% dplyr::select(-ends_with("sample_period"))
dat <- dat %>% dplyr::select(-ends_with("responsestatus"))


# save cleaned file
save(dat, file = "../data/dat_uncertainty_BJPS_cleaned.RData")

