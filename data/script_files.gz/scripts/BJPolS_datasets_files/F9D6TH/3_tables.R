


## REPLICATION MATERIAL FOR
## HOW DOES UNCERTAINTY AFFECT VOTERS' PREFERENCES?
## BRITISH JOURNAL OF POLITICAL SCIENCE
## AUTHOR: LOVE CHRISTENSEN


####################################
########### FILE 3: TABLES #########
####################################

############################################
## PLEASE RUN 2_models.R BEFORE THIS FILE ##
############################################

library(Hmisc)
library(tables)

## All tables are exported as .tex files to "../output/tables/"

################################################
################# TABLE 3  #####################
################################################

name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_quant_mod1",
                "mw_ideal_mod1",
                "ct_quant_mod1",
                "ct_ideal_mod1",
                "tpp_quant_mod1",
                "tpp_ideal_mod1")

paste(model.list[1])

cat("", file="../output/tables/tab_first_stage.tex")
cat( "\\begin{table}[H]
     \\caption{Predictions Affect Outcome Beliefs but not Idealistic Preferences}
     \\label{tab:first_stage}  
     \\begin{center}
     \\begin{adjustbox}{max width=1.25\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     &  Outcome belief & Idealistic preference &  Outcome belief & Idealistic preference &  Outcome belief & Idealistic preference \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_first_stage.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_mod1$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_ideal_mod1$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", ct_quant_mod1$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_ideal_mod1$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", tpp_quant_mod1$coefficients[i + 1]), sig.list.symbol[5], " & ",
      sprintf("%.2f", tpp_ideal_mod1$coefficients[i + 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_first_stage.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_ideal_mod1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_ideal_mod1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_ideal_mod1$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_first_stage.tex")
  
}

cat("\\midrule Center + Center $\\times$ Partisan = 0 (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_ideal_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", ct_ideal_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_quant_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_ideal_f1$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage.tex")

cat("Spread + Spread $\\times$ Partisan = 0 (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_ideal_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", ct_ideal_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_quant_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_ideal_f2$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_mod1$N), " & ", 
    sprintf("%.0f", mw_ideal_mod1$N), " & ",
    sprintf("%.0f", ct_quant_mod1$N), " & ", 
    sprintf("%.0f", ct_ideal_mod1$N), " & ",
    sprintf("%.0f", tpp_quant_mod1$N), " & ",
    sprintf("%.0f", tpp_ideal_mod1$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares. Robust standard errors in parentheses. Outcome belief is a measure of the respondent's expectation of the effect of the reform on the respective outcome variables. Idealistic preference measures the principled support for the policy on a seven-point Likert scale. The wording of questions are available in the appendix. Rows six and seven show p-values from two F-tests of the marginal effect of \\emph{prediction center} and \\emph{prediction spread} when partisans are senders.  \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_first_stage.tex")


###########################################
################## TABLE 4 ################
###########################################

name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_likert_mod1",
                "ct_likert_mod1",
                "tpp_likert_mod1")

cat("", file="../output/tables/tab_reduced_form.tex")
cat( "\\begin{table}[H]
     \\caption{Predictions Affect Support for Reforms}
     \\label{tab:redform} 
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{3}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{1}{c}{Minimum Wage}	  & \\multicolumn{1}{c}{Corporate Tax} & \\multicolumn{1}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_reduced_form.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_likert_mod1$coefficients[i + 1]), sig.list.symbol[1], " & ",
      sprintf("%.2f", ct_likert_mod1$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", tpp_likert_mod1$coefficients[i + 1]), sig.list.symbol[3], " \\\\ \n ",
      append=T, file="../output/tables/tab_reduced_form.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_likert_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_mod1$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_reduced_form.tex")
  
}

cat("\\midrule Center + Center $\\times$ Partisan = 0 (\\emph{p}) & ", 
    sprintf("%.2f", mw_likert_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", tpp_likert_f1$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_reduced_form.tex")

cat("Spread + Spread $\\times$ Partisan = 0 (\\emph{p}) & ",  
    sprintf("%.2f", mw_likert_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", tpp_likert_f2$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_reduced_form.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_likert_mod1$N), " & ", 
    sprintf("%.0f", ct_likert_mod1$N), " & ",
    sprintf("%.0f", tpp_likert_mod1$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_reduced_form.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
	\\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares. Robust standard errors in parentheses. Higher values imply stronger support for the policy.  Rows six and seven show p-values from two F-tests of the marginal effect of \\emph{prediction center} and \\emph{prediction spread} when partisans are senders. \\\\\\hspace{\\textwidth}
$^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_reducedform}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_reduced_form.tex")

#########################################################
######### IV, instrumenting quantitative beliefs ########
#########################################################

name.list <- c("Beliefs")
model.list1 <- c("mw_likert_iv1",
                "ct_likert_iv1",
                "tpp_likert_iv1")

cat("", file="../output/tables/tab_iv.tex")
cat( "\\begin{table}[H]
     \\caption{Instrumented Beliefs Affect Reform Support}
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{3}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{1}{c}{Minimum Wage}	  & \\multicolumn{1}{c}{Corporate Tax} & \\multicolumn{1}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_iv.tex")

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list1))
  sig.list.symbol <- vector(length = length(model.list1))
  for(j in 1:length(model.list1)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list1[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat("Outcome belief", " & ", 
      sprintf("%.2f", mw_likert_iv1$coefficients[i + 1]), sig.list.symbol[1], " &  ",
      sprintf("%.2f", ct_likert_iv1$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", tpp_likert_iv1$coefficients[i + 1]), sig.list.symbol[3], "  \\\\ \n ",
      append=T, file="../output/tables/tab_iv.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_likert_iv1$std.error[i + 1]), ") &  ", 
      "(", sprintf("%.2f", ct_likert_iv1$std.error[i + 1]), ") &  ",
      "(", sprintf("%.2f", tpp_likert_iv1$std.error[i + 1]), ")   \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_iv.tex")
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_likert_iv1$N), " & ", 
    sprintf("%.0f", ct_likert_iv1$N), " & ",
    sprintf("%.0f", tpp_likert_iv1$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_iv.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    	\\caption*{\\footnotesize{\\textbf{Note:}  All models are estimated using 2SLS. Robust standard errors in parentheses. Higher values imply stronger support for the policy. The first stage is presented in table \\ref{tab:first_stage}. The outcome belief variables for minimum wage and corporate tax are percentage point increase in unemployment rate and employment rate, respectively, and for Trans-Pacific Partnership in millions of manufacturing jobs. \\\\\\hspace{\\textwidth}
$^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_iv}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_iv.tex")


########## TABLE: IDEALISTIC PREFERENCES AND REFORM SUPPORT ###############

name.list <- c("Idealistic preference")

model.list <- c("mw_likert_ideal1",
                "mw_likert_ideal2",
                "ct_likert_ideal1",
                "ct_likert_ideal2",
                "tpp_likert_ideal1",
                "tpp_likert_ideal2")

cat("", file="../output/tables/tab_idealistic.tex")
cat( "\\begin{table}[H]
     \\caption{Idealistic Preferences Predict Support for Reform}
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_idealistic.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_likert_ideal1$coefficients[i + 1]), sig.list.symbol[1], " & ",
      sprintf("%.2f", mw_likert_ideal2$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", ct_likert_ideal1$coefficients[i + 1]), sig.list.symbol[3], " & ",
      sprintf("%.2f", ct_likert_ideal2$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", tpp_likert_ideal1$coefficients[i + 1]), sig.list.symbol[5], " & ",
      sprintf("%.2f", tpp_likert_ideal2$coefficients[i + 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_idealistic.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_likert_ideal1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_likert_ideal2$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_ideal1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_likert_ideal2$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_likert_ideal1$std.error[i + 1]), ") & ",  
      "(", sprintf("%.2f", tpp_likert_ideal2$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_idealistic.tex")
  
}

cat("\\midrule Demographic controls & ", 
    "", " & ",
    "Yes", " & ",
    "", " & ",
    "Yes", " & ", 
    "", " & ", 
    "Yes", " \\\\ \n ",
    append=T, file="../output/tables/tab_idealistic.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_likert_ideal1$N), " & ",
    sprintf("%.0f", mw_likert_ideal2$N), " & ",
    sprintf("%.0f", ct_likert_ideal1$N), " & ",
    sprintf("%.0f", ct_likert_ideal2$N), " & ",
    sprintf("%.0f", tpp_likert_ideal1$N), " & ",
    sprintf("%.0f", tpp_likert_ideal2$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_idealistic.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
        	\\caption*{\\footnotesize{\\textbf{Note:}  All models are estimated using least squares. Robust standard errors in parentheses. Support for reform is measured on on a seven-point Likert scale, where higher values imply stronger support for reform. Demographic controls include age, education, income and gender.\\\\\\hspace{\\textwidth}
$^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_ideal_likert}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_idealistic.tex")



#############################################################
############### QUALITATIVE BELIEFS #########################
#############################################################


name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_qual_mod1",
                "ct_qual_mod1",
                "tpp_qual_mod1")

paste(model.list[1])

cat("", file="../output/tables/tab_first_stage_qual.tex")
cat( "\\begin{table}[H]
     \\caption{Effects of Treatments on Qualitative Outcome Beliefs}
     \\label{tab:first_stage_qual}  
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{3}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{1}{c}{Minimum Wage}	  & \\multicolumn{1}{c}{Corporate Tax} & \\multicolumn{1}{c}{Trans-Pacific Partnership}  \\\\
     &  Outcome belief  &  Outcome belief  &  Outcome belief  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_first_stage_qual.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_qual_mod1$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", ct_qual_mod1$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", tpp_qual_mod1$coefficients[i + 1]), sig.list.symbol[3], " \\\\ \n ",
      append=T, file="../output/tables/tab_first_stage_qual.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_qual_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_qual_mod1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_qual_mod1$std.error[i + 1]), ") \\\\[.25cm] \n ",
      append=T, file="../output/tables/tab_first_stage_qual.tex")
  
}

cat("\\midrule  Center + Center $\\times$ Partisan = 0 (\\emph{p}) & ", 
    sprintf("%.2f", mw_qual_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", ct_qual_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", tpp_qual_f1$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage_qual.tex")

cat("Spread + Spread $\\times$ Partisan = 0 (\\emph{p}) & ", 
    sprintf("%.2f", mw_qual_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", ct_qual_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", tpp_qual_f2$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage_qual.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_qual_mod1$N), " & ", 
    sprintf("%.0f", ct_qual_mod1$N), " & ", 
    sprintf("%.0f", tpp_qual_mod1$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_first_stage_qual.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. Qualitative is a binary variable refering to whether the respondent believes that the reform will lead to an increase in the outcome variable for each respective reform. The wording of questions are available in the appendix. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_first_stage_qual.tex")




###########################################
#### IV QUALITATIVE BELIEFS ###############
###########################################


name.list <- c("Beliefs")
model.list1 <- c("mw_likert_iv2",
                 "ct_likert_iv2",
                 "tpp_likert_iv2")

cat("", file="../output/tables/tab_iv_qual.tex")
cat( "\\begin{table}[H]
     \\caption{Instrumented Qualitative Beliefs Affect Reform Support}
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{3}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{1}{c}{Minimum Wage}	  & \\multicolumn{1}{c}{Corporate Tax} & \\multicolumn{1}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_iv_qual.tex")

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list1))
  sig.list.symbol <- vector(length = length(model.list1))
  for(j in 1:length(model.list1)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list1[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat("Qualitative belief increase", " & ", 
      sprintf("%.2f", mw_likert_iv2$coefficients[i + 1]), sig.list.symbol[1], " &  ",
      sprintf("%.2f", ct_likert_iv2$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", tpp_likert_iv2$coefficients[i + 1]), sig.list.symbol[3], "  \\\\ \n ",
      append=T, file="../output/tables/tab_iv_qual.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_likert_iv2$std.error[i + 1]), ") &  ", 
      "(", sprintf("%.2f", ct_likert_iv2$std.error[i + 1]), ") &  ",
      "(", sprintf("%.2f", tpp_likert_iv2$std.error[i + 1]), ")   \\\\[.25cm] \n ",
      append=T, file="../output/tables/tab_iv_qual.tex")
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_likert_iv2$N), " & ", 
    sprintf("%.0f", ct_likert_iv2$N), " & ",
    sprintf("%.0f", tpp_likert_iv2$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_iv_qual.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:}  All models are estimated using 2SLS. Robust standard errors in parentheses.The first stage is identical to the main specification but using an indicator variable for an increase in outcome beliefs as the dependent variable. The first stage is presented in table \\ref{tab:first_stage_qual}.\\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_iv_qual}
    \\end{center}
    \\end{table}",
    append=T, file="../output/tables/tab_iv_qual.tex")


###########################################################
###################### ROBUSTNESS #########################
###########################################################

############## DIFFERENCE OF MEANS ########################


name.list <- c("Prediction increase", 
               "Prediction spread", 
               "Partisan sender",
               "Prediction increase $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_quant_dom",
                "mw_ideal_dom",
                "mw_likert_dom",
                "ct_quant_dom",
                "ct_ideal_dom",
                "ct_likert_dom",
                "tpp_quant_dom",
                "tpp_ideal_dom",
                "tpp_likert_dom")
paste(model.list[1])

cat("", file="../output/tables/tab_dom.tex")
cat( "\\begin{table}[H]
     \\caption{Results are Robust to a Difference of Means Specification}
     \\label{tab:dom}  
     \\begin{center}
     \\begin{adjustbox}{max width=1.25\\textwidth}
     \\begin{tabular}{l*{9}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Minimum Wage}	  & \\multicolumn{3}{c}{Corporate Tax} & \\multicolumn{3}{c}{Trans-Pacific Partnership}  \\\\
     &  Outcome beliefs &  Idealistic preference &  Support  &  Outcome beliefs &  Idealistic preference &  Support  &  Outcome beliefs &  Idealistic preference &  Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_dom.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_dom$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_ideal_dom$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", mw_likert_dom$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_quant_dom$coefficients[i + 1]), sig.list.symbol[4], " & ", 
      sprintf("%.2f", ct_ideal_dom$coefficients[i + 1]), sig.list.symbol[5], " & ", 
      sprintf("%.2f", ct_likert_dom$coefficients[i + 1]), sig.list.symbol[6], " & ", 
      sprintf("%.2f", tpp_quant_dom$coefficients[i + 1]), sig.list.symbol[7], " & ", 
      sprintf("%.2f", tpp_ideal_dom$coefficients[i + 1]), sig.list.symbol[8], " & ", 
      sprintf("%.2f", tpp_likert_dom$coefficients[i + 1]), sig.list.symbol[9], " \\\\ \n ",
      append=T, file="../output/tables/tab_dom.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_dom$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_ideal_dom$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", mw_likert_dom$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_dom$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_ideal_dom$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_likert_dom$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_dom$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_ideal_dom$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_dom$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_dom.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_dom$N), " & ", 
    sprintf("%.0f", mw_ideal_dom$N), " & ", 
    sprintf("%.0f", mw_likert_dom$N), " & ", 
    sprintf("%.0f", ct_quant_dom$N), " & ", 
    sprintf("%.0f", ct_ideal_dom$N), " & ", 
    sprintf("%.0f", ct_likert_dom$N), " & ",
    sprintf("%.0f", tpp_quant_dom$N), " & ", 
    sprintf("%.0f", tpp_ideal_dom$N), " & ", 
    sprintf("%.0f", tpp_likert_dom$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_dom.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. \\emph{Prediction increase} is a dummy indicating whether \\emph{prediction center} is greater than zero. The reference category are predictions were \\emph{prediction center} is either 0 or decreasing. \\emph{Prediction spread} is a dummy indicating whether there are conflicting predictions. Changing the reference category to be predictions when \\emph{prediction center} = 0 and adding the variable \\emph{prediction decrease} produces the same results.    \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_dom.tex")


####################################################
################# ORDERED PROBIT ###################
####################################################


name.list <- c("Prediction center", 
               "Prediction spread", 
               "Partisan sender",
               "Prediction center $\\times$ partisan sender",
               "Prediction spread $\\times$ partisan sender")

model.list <- c("mw_ideal_oprob",
                "mw_likert_oprob",
                "ct_ideal_oprob",
                "ct_likert_oprob",
                "tpp_ideal_oprob",
                "tpp_likert_oprob")
paste(model.list[1])

cat("", file="../output/tables/tab_oprob.tex")
cat( "\\begin{table}[H]
     \\caption{Sensitivity: Ordered Probit Results for Idealistic Preference and Support}
     \\label{tab:oprob}  
     \\begin{center}
     \\begin{adjustbox}{max width=1.5\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     &  Idealistic &  Support  &  Idealistic &  Support &  Idealistic &  Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_oprob.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  n.list <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste("summary(", model.list[j], ")$coefficients[", i, ", 3]", sep = "")))
    n.list <- 
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(2*pt(sig.list[j], 
                                      eval(parse(text = paste(model.list[j], "$n" , sep = ""))), 
                                      lower = FALSE) <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(2*pt(sig.list[j], 
                                      eval(parse(text = paste(model.list[j], "$n" , sep = ""))),
                                      lower = FALSE) <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(2*pt(sig.list[j],
                                      eval(parse(text = paste(model.list[j], "$n" , sep = ""))),
                                      lower = FALSE) <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.3f", summary(mw_ideal_oprob)$coefficients[i, 1]), sig.list.symbol[1], " & ", 
      sprintf("%.3f", summary(mw_likert_oprob)$coefficients[i, 1]), sig.list.symbol[2], " & ",
      sprintf("%.3f", summary(ct_ideal_oprob)$coefficients[i, 1]), sig.list.symbol[3], " & ", 
      sprintf("%.3f", summary(ct_likert_oprob)$coefficients[i, 1]), sig.list.symbol[4], " & ", 
      sprintf("%.3f", summary(tpp_ideal_oprob)$coefficients[i, 1]), sig.list.symbol[5], " & ", 
      sprintf("%.3f", summary(tpp_likert_oprob)$coefficients[i, 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_oprob.tex")
  
  cat(" & ", 
      "(", sprintf("%.3f", summary(mw_ideal_oprob)$coefficients[i, 2]), ") & ",
      "(", sprintf("%.3f", summary(mw_likert_oprob)$coefficients[i, 2]), ") & ",
      "(", sprintf("%.3f", summary(ct_ideal_oprob)$coefficients[i, 2]), ") & ",
      "(", sprintf("%.3f", summary(ct_likert_oprob)$coefficients[i, 2]), ") & ",
      "(", sprintf("%.3f", summary(tpp_ideal_oprob)$coefficients[i, 2]), ") & ", 
      "(", sprintf("%.3f", summary(tpp_likert_oprob)$coefficients[i, 2]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_oprob.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_ideal_oprob$n), " & ", 
    sprintf("%.0f", mw_likert_oprob$n), " & ", 
    sprintf("%.0f", ct_ideal_oprob$n), " & ", 
    sprintf("%.0f", ct_likert_oprob$n), " & ",
    sprintf("%.0f", tpp_ideal_oprob$n), " & ", 
    sprintf("%.0f", tpp_likert_oprob$n), " \\\\ \n ",
    append=T, file="../output/tables/tab_oprob.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using ordered probit regression. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_oprob.tex")


#######################################################
############## DROPPING SINGLE FORECASTS ##############
#######################################################


name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_quant_uncert",
                "mw_likert_uncert",
                "ct_quant_uncert",
                "ct_likert_uncert",
                "tpp_quant_uncert",
                "tpp_likert_uncert")

paste(model.list[1])

cat("", file="../output/tables/tab_uncert_only.tex")
cat( "\\begin{table}[H]
     \\caption{Dropping Single Prediction Treatments: Outcome Beliefs and Support}
     \\label{tab:nosingle}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     &  Outcome belief & Support &  Outcome belief & Support &  Outcome belief & Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_uncert_only.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_uncert$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_likert_uncert$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", ct_quant_uncert$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_likert_uncert$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", tpp_quant_uncert$coefficients[i + 1]), sig.list.symbol[5], " & ",
      sprintf("%.2f", tpp_likert_uncert$coefficients[i + 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_uncert_only.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_uncert$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_uncert$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_uncert$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_uncert$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_uncert$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_uncert$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_uncert_only.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_uncert$N), " & ", 
    sprintf("%.0f", mw_likert_uncert$N), " & ",
    sprintf("%.0f", ct_quant_uncert$N), " & ", 
    sprintf("%.0f", ct_likert_uncert$N), " & ",
    sprintf("%.0f", tpp_quant_uncert$N), " & ",
    sprintf("%.0f", tpp_likert_uncert$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_uncert_only.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_uncert_only.tex")

##########################################################
################## RISK PREFERENCES ######################
##########################################################

##################### ATTITUDES ##########################

name.list <- c("Prediction center",
               "Prediction spread",
               "Risk seeking",
               "Age",
               "Female",
               "College degree",
               "No high school",
               "Inc $\\leq$ 50K",
               "Inc 100K150K",
               "Inc $\\geq$ 150K",
               "Spread $\\times$ risk seeking")

model.list <- c("mw_likert_rp1",
                "mw_likert_rp2",
                "mw_likert_rp3",
                "ct_likert_rp1",
                "ct_likert_rp2",
                "ct_likert_rp3",
                "tpp_likert_rp1",
                "tpp_likert_rp2",
                "tpp_likert_rp3")

paste(model.list[1])

cat("", file="../output/tables/tab_riskpref.tex")
cat( "\\begin{table}[H]
     \\caption{Heterogeneity: Risk Preferences and Support}
     \\label{tab:riskpref}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{9}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Minimum Wage}	  & \\multicolumn{3}{c}{Corporate Tax}  & \\multicolumn{3}{c}{Trans-Pacific Partnership} \\\\
     &  All & Expert &  Partisan & All &  Expert & Partisan & All &  Expert & Partisan \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_riskpref.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_likert_rp1$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_likert_rp2$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", mw_likert_rp3$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_likert_rp1$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", ct_likert_rp2$coefficients[i + 1]), sig.list.symbol[5], " & ", 
      sprintf("%.2f", ct_likert_rp3$coefficients[i + 1]), sig.list.symbol[6], " & ", 
      sprintf("%.2f", tpp_likert_rp1$coefficients[i + 1]), sig.list.symbol[7], " & ", 
      sprintf("%.2f", tpp_likert_rp2$coefficients[i + 1]), sig.list.symbol[8], " & ", 
      sprintf("%.2f", tpp_likert_rp3$coefficients[i + 1]), sig.list.symbol[9], " \\\\ \n ",
      append=T, file="../output/tables/tab_riskpref.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_likert_rp1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_likert_rp2$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", mw_likert_rp3$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_rp1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_likert_rp2$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_rp3$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_rp1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_rp2$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_rp3$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_riskpref.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_likert_rp1$N), " & ", 
    sprintf("%.0f", mw_likert_rp2$N), " & ",
    sprintf("%.0f", mw_likert_rp3$N), " & ", 
    sprintf("%.0f", ct_likert_rp1$N), " & ",
    sprintf("%.0f", ct_likert_rp2$N), " & ",
    sprintf("%.0f", ct_likert_rp3$N), " & ",
    sprintf("%.0f", tpp_likert_rp1$N), " & ",
    sprintf("%.0f", tpp_likert_rp2$N), " & ",
    sprintf("%.0f", tpp_likert_rp3$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_riskpref.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The first column per reform includes both the expert treatment and the partisan treatment, while the second and third column subsets the sample only to expert and partisan treatments, respectively. Risk seeking is measured on a 0-10 scale, where higher values indicate higher levels of risk seeking. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_riskpref.tex")

##################### BELIEFS ###########################


name.list <- c("Prediction center",
               "Prediction spread",
               "Risk seeking",
               "Age",
               "Female",
               "College degree",
               "No high school",
               "Inc $\\leq$ 50K",
               "Inc 100K150K",
               "Inc $\\geq$ 150K",
               "Spread $\\times$ risk seeking")

model.list <- c("mw_quant_rp1",
                "mw_quant_rp2",
                "mw_quant_rp3",
                "ct_quant_rp1",
                "ct_quant_rp2",
                "ct_quant_rp3",
                "tpp_quant_rp1",
                "tpp_quant_rp2",
                "tpp_quant_rp3")

paste(model.list[1])

cat("", file="../output/tables/tab_quant_riskpref.tex")
cat( "\\begin{table}[H]
     \\caption{Heterogeneity: Risk Preferences and Beliefs}
     \\label{tab:quant_riskpref}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{9}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Minimum Wage}	  & \\multicolumn{3}{c}{Corporate Tax}  & \\multicolumn{3}{c}{Trans-Pacific Partnership} \\\\
     &  All & Expert &  Partisan & All &  Expert & Partisan & All &  Expert & Partisan \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_quant_riskpref.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_rp1$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_quant_rp2$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", mw_quant_rp3$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_quant_rp1$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", ct_quant_rp2$coefficients[i + 1]), sig.list.symbol[5], " & ", 
      sprintf("%.2f", ct_quant_rp3$coefficients[i + 1]), sig.list.symbol[6], " & ", 
      sprintf("%.2f", tpp_quant_rp1$coefficients[i + 1]), sig.list.symbol[7], " & ", 
      sprintf("%.2f", tpp_quant_rp2$coefficients[i + 1]), sig.list.symbol[8], " & ", 
      sprintf("%.2f", tpp_quant_rp3$coefficients[i + 1]), sig.list.symbol[9], " \\\\ \n ",
      append=T, file="../output/tables/tab_quant_riskpref.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_rp1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_quant_rp2$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", mw_quant_rp3$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_quant_rp1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_rp2$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_quant_rp3$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_quant_rp1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_quant_rp2$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_quant_rp3$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_quant_riskpref.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_rp1$N), " & ", 
    sprintf("%.0f", mw_quant_rp2$N), " & ",
    sprintf("%.0f", mw_quant_rp3$N), " & ", 
    sprintf("%.0f", ct_quant_rp1$N), " & ",
    sprintf("%.0f", ct_quant_rp2$N), " & ",
    sprintf("%.0f", ct_quant_rp3$N), " & ",
    sprintf("%.0f", tpp_quant_rp1$N), " & ",
    sprintf("%.0f", tpp_quant_rp2$N), " & ",
    sprintf("%.0f", tpp_quant_rp3$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_quant_riskpref.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The first column per reform includes both the expert treatment and the partisan treatment, while the second and third column subsets the sample only to expert and partisan treatments, respectively. Risk seeking is measured on a 0-10 scale, where higher values indicate higher levels of risk seeking. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_quant_riskpref.tex")

##########################################################
############## PARTISAN HETEROGENEITY ####################
##########################################################


########### TPP: PARTY CUE TREATMENT #############



name.list <- c("Prediction center", 
               "Democrat", 
               "Republican",
               "Prediction spread",
               "Republican forecast high",
               "Age",
               "Female",
               "College degree",
               "No high school",
               "Income $\\leq$ 50K",
               "Income 100K-150K",
               "Income $\\geq$ 150K",
               "Prediction center $\\times$ Democrat",
               "Prediction center $\\times$ Republican",
               "Prediction spread $\\times$ Democrat",
               "Prediction spread $\\times$ Republican",
               "Prediction spread $\\times$ Democrat $\\times$ Republican high",
               "Prediction spread $\\times$ Republican $\\times$ Republican high")

model.list <- c("tpp_quant_part",
                "tpp_likert_part")

paste(model.list[1])

cat("", file="../output/tables/tab_parthet_tpp.tex")
cat( "\\begin{table}[H]
     \\caption{Heterogeneity: Partisanship on Beliefs and Support for Trans-Pacific Partnership}
     \\label{tab:parthet_tpp_exp}  
     \\begin{center}
     \\begin{adjustbox}{width = .7\\textwidth}
     \\begin{tabular}{l*{10}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Trans-Pacific Partnership} \\\\
     &  Beliefs & Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_parthet_tpp.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", tpp_quant_part$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", tpp_likert_part$coefficients[i + 1]), sig.list.symbol[2], " \\\\ \n ",
      append=T, file="../output/tables/tab_parthet_tpp.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", tpp_quant_part$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f",  tpp_likert_part$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_parthet_tpp.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", tpp_quant_part$N), " & ", 
    sprintf("%.0f", tpp_likert_part$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_tpp.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\emph{Democrat} and \\emph{Republican} are dummy variables, indicating what party a respondent identifies with. \\emph{Independents} are the reference category. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_parthet_tpp.tex")


#### TPP EXPERT SENDERS #####

name.list <- c("Prediction center", 
               "Democrat", 
               "Republican",
               "Prediction spread",
               "Age",
               "Female",
               "College degree",
               "No high school",
               "Income $\\leq$ 50K",
               "Income 100K-150K",
               "Income $\\geq$ 150K",
               "Prediction center $\\times$ Democrat",
               "Prediction center $\\times$ Republican",
               "Prediction spread $\\times$ Democrat",
               "Prediction spread $\\times$ Republican")

model.list <- c("tpp_quant_exp",
                "tpp_likert_exp")

paste(model.list[1])

cat("", file="../output/tables/tab_exphet_tpp.tex")
cat( "\\begin{table}[H]
     \\caption{Heterogeneity: Partisanship on Beliefs and Support for Trans-Pacific Partnership when Experts are Senders}
     \\label{tab:parthet_tpp}  
     \\begin{center}
     \\begin{adjustbox}{width = .7\\textwidth}
     \\begin{tabular}{l*{10}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Trans-Pacific Partnership} \\\\
     &  Beliefs & Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_exphet_tpp.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", tpp_quant_exp$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", tpp_likert_exp$coefficients[i + 1]), sig.list.symbol[2], " \\\\ \n ",
      append=T, file="../output/tables/tab_exphet_tpp.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", tpp_quant_exp$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f",  tpp_likert_exp$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_exphet_tpp.tex")
  
}

cat("\\midrule F-test: Prediction center $\\times$ Democrat = Prediction center $\\times$ Republican (\\emph{p}) & ", 
    sprintf("%.2f", tpp_quant_exphet_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_likert_exphet_f1$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_exphet_tpp.tex")

cat("F-test: Prediction center $\\times$ Democrat $\\times$ Partisan =  Prediction center $\\times$ Republican $\\times$ Partisan (\\emph{p}) & ", 
    sprintf("%.2f", tpp_quant_exphet_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", tpp_likert_exphet_f2$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_exphet_tpp.tex")



cat("\\midrule Observations & ", 
    sprintf("%.0f", tpp_quant_exp$N), " & ", 
    sprintf("%.0f", tpp_likert_exp$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_exphet_tpp.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\emph{Democrat} and \\emph{Republican} are dummy variables, indicating what party a respondent identifies with. \\emph{Independents} are the reference category. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_exphet_tpp.tex")

### MW AND CT

name.list <- c("Prediction center", 
               "Democrat", 
               "Partisan sender",
               "Republican",
               "Prediction spread",
               "Age",
               "Female",
               "College degree",
               "No high school",
               "Income $\\leq$ 50K",
               "Income 100K-150K",
               "Income $\\geq$ 150K",
               "Prediction center $\\times$ Democrat",
               "Prediction center $\\times$ Partisan",
               "Democrat $\\times$ Partisan",
               "Prediction center $\\times$ Republican",
               "Republican $\\times$ Partisan",
               "Prediction spread $\\times$ Democrat",
               "Prediction spread $\\times$ Partisan",
               "Prediction spread $\\times$ Republican",
               "Prediction center $\\times$ Democrat $\\times$ Partisan",
               "Prediction center $\\times$ Republican $\\times$ Partisan",
               "Prediciton spread $\\times$ Democrat $\\times$ Partisan",
               "Prediciton spread $\\times$ Republican $\\times$ Partisan")

model.list <- c("mw_quant_part",
                "mw_likert_part",
                "ct_quant_part",
                "ct_likert_part")

paste(model.list[1])

cat("", file="../output/tables/tab_parthet_mwct.tex")
cat( "\\begin{table}[H]
     \\caption{Partisan Heterogeneity: Beliefs and Support for Minimum Wage and Corporate Tax Reforms}
     \\label{tab:parthet_mwct}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{4}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} \\\\
     & Outcome beliefs & Support & Outcome beliefs & Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_parthet_mwct.tex")


for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_part$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_likert_part$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", ct_quant_part$coefficients[i + 1]), sig.list.symbol[3], " & ",
      sprintf("%.2f", ct_likert_part$coefficients[i + 1]), sig.list.symbol[4], " \\\\ \n ",
      append=T, file="../output/tables/tab_parthet_mwct.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_part$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_likert_part$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_part$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_likert_part$std.error[i + 1]), ") \\\\[.25cm] \n ",
      append=T, file="../output/tables/tab_parthet_mwct.tex")
  
}

cat("\\midrule F-test: Prediction center $\\times$ Democrat = Prediction center $\\times$ Republican (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_part_f1$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_likert_part_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_part_f1$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_part_f1$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_mwct.tex")

cat("F-test: Prediction center $\\times$ Democrat $\\times$ Partisan =  Prediction center $\\times$ Republican $\\times$ Partisan (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_part_f2$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_likert_part_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_part_f2$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_part_f2$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_mwct.tex")

cat("F-test: Prediction spread $\\times$ Democrat =  Prediction spread $\\times$ Republican (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_part_f3$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_likert_part_f3$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_part_f3$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_part_f3$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_mwct.tex")

cat("F-test: Prediction spread $\\times$ Democrat $\\times$ Partisan =  Prediction spread $\\times$ Republican $\\times$ Partisan (\\emph{p}) & ", 
    sprintf("%.2f", mw_quant_part_f4$`Pr(>F)`[2]), " & ", 
    sprintf("%.2f", mw_likert_part_f4$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_quant_part_f4$`Pr(>F)`[2]), " & ",
    sprintf("%.2f", ct_likert_part_f4$`Pr(>F)`[2]), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_mwct.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_part$N), " & ", 
    sprintf("%.0f", mw_likert_part$N), " & ",
    sprintf("%.0f", ct_quant_part$N), " & ", 
    sprintf("%.0f", ct_likert_part$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_parthet_mwct.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\emph{Democrat} and \\emph{Republican} are dummy variables, indicating what party a respondent identifies with. \\emph{Independents} are the reference category. \\\\\\hspace{\\textwidth}
    $^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_parthet_mwct.tex")



################################################
############# LOSS OR GAIN DOMAIN ##############
################################################

name.list <- c("Prediction center: gain", 
               "Prediction center: loss", 
               "Prediction spread",
               "Partisan")

model.list <- c("mw_quant_gl",
                "mw_likert_gl",
                "ct_quant_gl",
                "ct_likert_gl",
                "tpp_quant_gl",
                "tpp_likert_gl")
paste(model.list[1])

cat("", file="../output/tables/tab_gl.tex")
cat( "\\begin{table}[H]
     \\caption{Heterogeneity: Predictions in Loss and Gain Domain}
     \\label{tab:gl}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     &  Outcome beliefs & Support  &  Outcome beliefs &   Support  &  Outcome beliefs &  Support \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_gl.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_gl$coefficients[i + 1]), sig.list.symbol[1], " & ", 
      sprintf("%.2f", mw_likert_gl$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", ct_quant_gl$coefficients[i + 1]), sig.list.symbol[3], " & ", 
      sprintf("%.2f", ct_likert_gl$coefficients[i + 1]), sig.list.symbol[4], " & ", 
      sprintf("%.2f", tpp_quant_gl$coefficients[i + 1]), sig.list.symbol[5], " & ", 
      sprintf("%.2f", tpp_likert_gl$coefficients[i + 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_gl.tex")
  
  cat(" & ", 
      "(", sprintf("%.2f", mw_quant_gl$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", mw_likert_gl$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_gl$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_likert_gl$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_gl$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_likert_gl$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_gl.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_gl$N), " & ", 
    sprintf("%.0f", mw_likert_gl$N), " & ", 
    sprintf("%.0f", ct_quant_gl$N), " & ",
    sprintf("%.0f", ct_likert_gl$N), " & ",
    sprintf("%.0f", tpp_quant_gl$N), " & ", 
    sprintf("%.0f", tpp_likert_gl$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_gl.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. \\emph{Prediction center: gain} is a dummy indicating whether the prediction center is in the gain domain relative to the status quo. \\emph{Prediction center: loss} is a dummy indicating whether the prediction center is in the loss domain relative to the status quo. Support is measured on a seven-point Likert scale, where higher values imply higher support for the policy. Outcome beliefs is a continuous variable refering to the respondent's numerical estimates of the effect of the reform on the respective outcome variable. \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_gl.tex")


################################################
############# PRIOR CERTAINTY ##################
################################################

name.list <- c("Intercept", 
               "Corporate tax", 
               "Trans-Pacific Partnership")

model.list <- c("cert_mod")
paste(model.list[1])

cat("", file="../output/tables/tab_cert2.tex")
cat( "\\begin{table}[H]
     \\caption{Priors for Minimum Wage Reform are Stronger}
     \\label{tab:cert}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{1}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     &  Certainty \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_cert2.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  
  cat(name.list[i], " & ",
      sprintf("%.2f", cert_mod$coefficients[i]), sig.list.symbol[1], " \\\\ \n ",
      append=T, file="../output/tables/tab_cert2.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", cert_mod$std.error[i]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_cert2.tex")
  
}

cat("\\midrule Observations & ",
    sprintf("%.0f", cert_mod$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_cert2.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} The model is estimated using least squares with robust standard errors clustered on the respondent level in the control group. Lower values imply higher certainty. The intercept shows the mean level of certainty for the minimum wage reform. The corporate tax and Trans-Pacific Partnership dummies shows deviations from this mean. \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_cert2.tex")



##################################################################
################# DESCRIPTIVE STATISTICS #########################
##################################################################

## paste the output manually into a .tex file
latex(tabular((Female=dat$female) + 
                (Age = dat$age) +
                (Democrat = na.omit(dat$democrat)) +
                (Republican = na.omit(dat$republican)) +
                (Independent = na.omit(dat$independent)) +
                ("College degree" = dat$educ_college_degree) +
                ("High school graduate, some college" = dat$educ_highschool_voc_degree) +
                ("No high school" = dat$educ_no_highschool) +
                ("Income $<$50K" = dat$income_less50K) +
                ("Income 50K - 100K" = dat$income_50K100K) +
                ("Income 100K - 150K" = dat$income_100K150K) +
                ("Income $>$150K" = dat$income_150Kabove) + 
                ("Risk preferences" = na.omit(dat$riskpref)) ~ 
                (n = 1) + Format(digits=1) * ( mean + sd) + min + max))

#############################################################
##################### ROBUSTNESS UNCERTAINTY ################
#############################################################

##################################################################
################### CORPORATE TAX ################################
##################################################################


## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains zero",
               "Crosses zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains zero",
               "\\hspace{3mm} Crosses zero")


## variable names in regressions (same order)
var.list <- c("ct_forecast_center",
              "ct_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "ct_loss_domain",
              'ct_spread_0',
              'ct_forecast_crossing',
              'ct_bla',
              "ct_forecast_center:ct_forecast_uncertain_magnitude",
              "ct_forecast_uncertain_magnitude:ct_loss_domain",
              'ct_forecast_uncertain_magnitude:ct_spread_0',
              'ct_forecast_uncertain_magnitude:ct_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("ct_robint_mod2",
                "ct_robint_mod3",
                "ct_robint_mod4",
                "ct_robint_mod5",
                "ct_robint_mod6",
                "ct_robint_mod7",
                "ct_robint_mod8",
                "ct_robint_mod9",
                "ct_robint_mod10",
                "ct_robint_mod11",
                "ct_robint_mod12",
                "ct_robint_mod13")

tab.name <- "tab_ct_uncertain_robustness"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Corporate Tax: Alternative Specifications for Uncertainty Treatment}
     \\label{tab:uncert_het_ct}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
  cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is support for the policy. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.   \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)

###################################################################
##################### MINIMUM WAGE ################################
###################################################################

## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains Zero",
               "Crosses Zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains Zero",
               "\\hspace{3mm} Crosses Zero")


## variable names in regressions (same order)
var.list <- c("mw_forecast_center",
              "mw_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "mw_loss_domain",
              'mw_spread_0',
              'mw_forecast_crossing',
              'mw_bla',
              "mw_forecast_center:mw_forecast_uncertain_magnitude",
              "mw_forecast_uncertain_magnitude:mw_loss_domain",
              'mw_forecast_uncertain_magnitude:mw_spread_0',
              'mw_forecast_uncertain_magnitude:mw_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("mw_robint_mod2",
                "mw_robint_mod3",
                "mw_robint_mod4",
                "mw_robint_mod5",
                "mw_robint_mod6",
                "mw_robint_mod7",
                "mw_robint_mod8",
                "mw_robint_mod9",
                "mw_robint_mod10",
                "mw_robint_mod11",
                "mw_robint_mod12",
                "mw_robint_mod13")

tab.name <- "tab_mw_uncertain_robustness"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Minimum Wage: Alternative Specifications for Uncertainty Treatment}
     \\label{tab:uncert_het_mw}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is support for the policy. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.  \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)


###################################################################
##################### TRANS-PACIFIC PARTNERSHIP ###################
###################################################################

## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains Zero",
               "Crosses Zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains Zero",
               "\\hspace{3mm} Crosses Zero")


## variable names in regressions (same order)
var.list <- c("tpp_forecast_center",
              "tpp_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "tpp_loss_domain",
              'tpp_spread_0',
              'tpp_forecast_crossing',
              'tpp_bla',
              "tpp_forecast_center:tpp_forecast_uncertain_magnitude",
              "tpp_forecast_uncertain_magnitude:tpp_loss_domain",
              'tpp_forecast_uncertain_magnitude:tpp_spread_0',
              'tpp_forecast_uncertain_magnitude:tpp_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("tpp_robint_mod2",
                "tpp_robint_mod3",
                "tpp_robint_mod4",
                "tpp_robint_mod5",
                "tpp_robint_mod6",
                "tpp_robint_mod7",
                "tpp_robint_mod8",
                "tpp_robint_mod9",
                "tpp_robint_mod10",
                "tpp_robint_mod11",
                "tpp_robint_mod12",
                "tpp_robint_mod13")

tab.name <- "tab_tpp_uncertain_robustness"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Trans-Pacific Partnership: Alternative Specifications for Uncertainty Treatment}
     \\label{tab:uncert_het_tpp}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is support for the policy. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.  \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)



#############################################################
##################### OUTCOME BELIEFS #######################
#############################################################


##################################################################
################### CORPORATE TAX ################################
##################################################################


## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains zero",
               "Crosses zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains zero",
               "\\hspace{3mm} Crosses zero")


## variable names in regressions (same order)
var.list <- c("ct_forecast_center",
              "ct_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "ct_loss_domain",
              'ct_spread_0',
              'ct_forecast_crossing',
              'ct_bla',
              "ct_forecast_center:ct_forecast_uncertain_magnitude",
              "ct_forecast_uncertain_magnitude:ct_loss_domain",
              'ct_forecast_uncertain_magnitude:ct_spread_0',
              'ct_forecast_uncertain_magnitude:ct_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("ct_robint_q_mod2",
                "ct_robint_q_mod3",
                "ct_robint_q_mod4",
                "ct_robint_q_mod5",
                "ct_robint_q_mod6",
                "ct_robint_q_mod7",
                "ct_robint_q_mod8",
                "ct_robint_q_mod9",
                "ct_robint_q_mod10",
                "ct_robint_q_mod11",
                "ct_robint_q_mod12",
                "ct_robint_q_mod13")

tab.name <- "tab_ct_uncertain_robustness_quant"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Corporate Tax: Alternative Specifications for Uncertainty Treatment on Beliefs}
     \\label{tab:uncert_het_ct_quant}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is outcome beliefs. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.   \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)

###################################################################
##################### MINIMUM WAGE ################################
###################################################################

## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains Zero",
               "Crosses Zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains Zero",
               "\\hspace{3mm} Crosses Zero")


## variable names in regressions (same order)
var.list <- c("mw_forecast_center",
              "mw_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "mw_loss_domain",
              'mw_spread_0',
              'mw_forecast_crossing',
              'mw_bla',
              "mw_forecast_center:mw_forecast_uncertain_magnitude",
              "mw_forecast_uncertain_magnitude:mw_loss_domain",
              'mw_forecast_uncertain_magnitude:mw_spread_0',
              'mw_forecast_uncertain_magnitude:mw_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("mw_robint_q_mod2",
                "mw_robint_q_mod3",
                "mw_robint_q_mod4",
                "mw_robint_q_mod5",
                "mw_robint_q_mod6",
                "mw_robint_q_mod7",
                "mw_robint_q_mod8",
                "mw_robint_q_mod9",
                "mw_robint_q_mod10",
                "mw_robint_q_mod11",
                "mw_robint_q_mod12",
                "mw_robint_q_mod13")

tab.name <- "tab_mw_uncertain_robustness_quant"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Minimum Wage: Alternative Specifications for Uncertainty Treatment on Beliefs}
     \\label{tab:uncert_het_mw_quant}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is outcome beliefs. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.  \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)


###################################################################
##################### TRANS-PACIFIC PARTNERSHIP ###################
###################################################################

## variable labels for table (in order)
## variable labels for table (in order)
name.list <- c("Prediction Center", 
               "Prediction Spread",
               "Partisan",
               "Loss Domain",
               "Contains Zero",
               "Crosses Zero",
               "Spread $\\times$",
               "\\hspace{3mm} Center", 
               "\\hspace{3mm} Loss Domain",
               "\\hspace{3mm} Contains Zero",
               "\\hspace{3mm} Crosses Zero")


## variable names in regressions (same order)
var.list <- c("tpp_forecast_center",
              "tpp_forecast_uncertain_magnitude",
              'Condition == "Partisan"TRUE',
              "tpp_loss_domain",
              'tpp_spread_0',
              'tpp_forecast_crossing',
              'tpp_bla',
              "tpp_forecast_center:tpp_forecast_uncertain_magnitude",
              "tpp_forecast_uncertain_magnitude:tpp_loss_domain",
              'tpp_forecast_uncertain_magnitude:tpp_spread_0',
              'tpp_forecast_uncertain_magnitude:tpp_forecast_crossing')


combined.list <- data.frame(var.list,
                            name.list)

## models to include
model.list <- c("tpp_robint_q_mod2",
                "tpp_robint_q_mod3",
                "tpp_robint_q_mod4",
                "tpp_robint_q_mod5",
                "tpp_robint_q_mod6",
                "tpp_robint_q_mod7",
                "tpp_robint_q_mod8",
                "tpp_robint_q_mod9",
                "tpp_robint_q_mod10",
                "tpp_robint_q_mod11",
                "tpp_robint_q_mod12",
                "tpp_robint_q_mod13")

tab.name <- "tab_tpp_uncertain_robustness_quant"
tab.path <- paste('../output/tables/', tab.name, '.tex', sep = "")

cat("", file = tab.path)
cat( "\\begin{table}[H]
     \\caption{Trans-Pacific Partnership: Alternative Specifications for Uncertainty Treatment on Beliefs}
     \\label{tab:uncert_het_tpp_quant}  
     \\begin{center}
     \\begin{adjustbox}{max width=1\\textwidth}
     \\begin{tabular}{l*{12}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{3}{c}{Interaction} & \\multicolumn{3}{c}{Loss Domain} & \\multicolumn{3}{c}{Spread Contains Zero} & \\multicolumn{3}{c}{Spread Crosses Domains} \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append = F, file = tab.path)

#################################################################
#################################################################
## significance stars

for(i in 1:length(name.list)){
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value['", var.list[i], "']", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
    sig.list.symbol[j] <- ifelse(is.na(sig.list[j]) == TRUE, "", sig.list.symbol[j]) # if NA
  }
  #################################################################
  #################################################################
  
  
  
  
  #################################################################
  #################################################################
  ## variable name
  cat(paste(combined.list[var.list == var.list[i], "name.list"], sep = ""),
      append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## COEFFICIENTS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ", 
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$coefficients['", var.list[i], "']", sep = "")))
            )
          ),
          eval(parse(text = paste("sig.list.symbol[", m, "]", sep = ""))),
          sep = "", append = TRUE, file = tab.path)
    }
    , " \\\\ \n ", 
    append = TRUE, file = tab.path)
  #################################################################
  #################################################################
  
  #################################################################
  #################################################################
  ## STANDARD ERRORS
  cat(
    for(m in 1:length(model.list)){
      cat(" & ",
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 "("),
          sprintf(
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   "%s",
                   "%.2f"), 
            ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                   " ",
                   eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = ""))))
          ),
          ifelse(is.na(eval(parse(text = paste(model.list[m], "$std.error['", var.list[i], "']", sep = "")))) == TRUE,
                 "",
                 ")"), 
          sep = "", append = TRUE, file = tab.path
      )
    }
    , " \\\\ \n \\addlinespace[0.2cm] ",
    append = TRUE, file = tab.path
  )
  
}
#################################################################
#################################################################

#################################################################
#################################################################
## F-TEST
cat("\\midrule Spread + Interaction = 0 $(p)$", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.2f", eval(parse(text = paste(model.list[m], "_f$`Pr(>F)`[2]", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)

## SENDER
cat("Sender", append = TRUE, file = tab.path)
cat(rep(c("& All", "& Experts", "& Partisan"), 4), sep = "", append = TRUE, file = tab.path)
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

#################################################################
#################################################################
## OBSERVATIONS
cat("\\midrule Observations", append = TRUE, file = tab.path)
for(m in 1:length(model.list)){
  cat(" & ", 
      sprintf("%.0f", eval(parse(text = paste(model.list[m], "$N", sep = "")))),
      sep = "", append = TRUE, file = tab.path)
}
cat(" \\\\ \n", sep = "", append = TRUE, file = tab.path)
#################################################################
#################################################################

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
    \\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares with robust standard errors. The dependent variable is outcome beliefs. \\emph{Loss Domain} is a dummy variable indicating whether all predictions are in the loss domain. \\emph{Contains zero} is a dummy variable indicating whether the predictions contain the zero prediction. \\emph{Crosses zero} is a dummy variable indicating whether the predictions include are located in both the loss and gain domain.  \\\\\\hspace{\\textwidth}
    $ ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\end{center}
    \\end{table}", 
    append = TRUE, file= tab.path)



#################################
######### UNCERTAINTY ###########
#################################



name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_mod_cert1",
                "ct_mod_cert1",
                "tpp_mod_cert1")

cat("", file="../output/tables/tab_cert.tex")
cat( "\\begin{table}[H]
     \\caption{Treatment Effects on Certainty of Belief}
     \\label{tab:redform_certainty} 
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{3}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{1}{c}{Minimum Wage}	  & \\multicolumn{1}{c}{Corporate Tax} & \\multicolumn{1}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_cert.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    #sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", "") # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_mod_cert1$coefficients[i + 1]), sig.list.symbol[1], " & ",
      sprintf("%.2f", ct_mod_cert1$coefficients[i + 1]), sig.list.symbol[2], " & ", 
      sprintf("%.2f", tpp_mod_cert1$coefficients[i + 1]), sig.list.symbol[3], " \\\\ \n ",
      append=T, file="../output/tables/tab_cert.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_mod_cert1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", ct_mod_cert1$std.error[i + 1]), ") & ", 
      "(", sprintf("%.2f", tpp_mod_cert1$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_cert.tex")
  
}

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_mod_cert1$N), " & ", 
    sprintf("%.0f", ct_mod_cert1$N), " & ",
    sprintf("%.0f", tpp_mod_cert1$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_cert.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
	\\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares. Robust standard errors in parentheses. Higher values of the outcome variable means more uncertain beliefs. \\\\\\hspace{\\textwidth}
$^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_reducedform}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_cert.tex")



################################################
############# NUMERICAL LITERACY ###############
################################################



name.list <- c("Prediction center", 
               "Partisan sender", 
               "Prediction spread",
               "Prediction center $\\times$ partisan",
               "Prediction spread $\\times$ partisan")

model.list <- c("mw_quant_nl1",
                "mw_quant_nl2",
                "ct_quant_nl1",
                "ct_quant_nl2",
                "tpp_quant_nl1",
                "tpp_quant_nl2")

cat("", file="../output/tables/tab_nl.tex")
cat( "\\begin{table}[H]
     \\caption{Effects within Qualitatively Equivalent Treatments}
     \\label{tab:nl} 
     \\begin{center}
     \\begin{adjustbox}{max width=\\textwidth}
     \\begin{tabular}{l*{6}{c}}
     \\toprule %%%%%%%%%%%%%%%%%%%%%%%%%
     & \\multicolumn{2}{c}{Minimum Wage}	  & \\multicolumn{2}{c}{Corporate Tax} & \\multicolumn{2}{c}{Trans-Pacific Partnership}  \\\\
     \\midrule %%%%%%%%%%%%%%%%%%%%%%%%% \n",
     append=F, file="../output/tables/tab_nl.tex")

for(i in 1:length(name.list)){
  
  sig.list <- vector(length = length(model.list))
  sig.list.symbol <- vector(length = length(model.list))
  for(j in 1:length(model.list)){
    sig.list[j] <- eval(parse(text = paste(paste(model.list[j], "$p.value[", 1 + i, "]", sep = ""))))
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .1, "$ \\dagger $", "") # 10%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .05, "$^{*}$", sig.list.symbol[j]) # 5%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .01, "$^{**}$", sig.list.symbol[j]) # 1%
    sig.list.symbol[j] <- ifelse(sig.list[j] <= .001, "$^{***}$", sig.list.symbol[j]) # 0.1%
  }
  
  cat(name.list[i], " & ", 
      sprintf("%.2f", mw_quant_nl1$coefficients[i + 1]), sig.list.symbol[1], " & ",
      sprintf("%.2f", mw_quant_nl2$coefficients[i + 1]), sig.list.symbol[2], " & ",
      sprintf("%.2f", ct_quant_nl1$coefficients[i + 1]), sig.list.symbol[3], " & ",
      sprintf("%.2f", ct_quant_nl2$coefficients[i + 1]), sig.list.symbol[4], " & ",
      sprintf("%.2f", tpp_quant_nl1$coefficients[i + 1]), sig.list.symbol[5], " & ",
      sprintf("%.2f", tpp_quant_nl2$coefficients[i + 1]), sig.list.symbol[6], " \\\\ \n ",
      append=T, file="../output/tables/tab_nl.tex")
  
  cat(" & ",
      "(", sprintf("%.2f", mw_quant_nl1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", mw_quant_nl2$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_nl1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", ct_quant_nl2$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_nl1$std.error[i + 1]), ") & ",
      "(", sprintf("%.2f", tpp_quant_nl2$std.error[i + 1]), ") \\\\[.25cm] \n ",
      sep = "", append=T, file="../output/tables/tab_nl.tex")
  
}

cat("\\midrule Prediction Center & ", 
    "Positive & ", 
    "Negative & ", 
    "Positive & ", 
    "Negative & ", 
    "Positive & ", 
    "Negative \\\\ \n ",
    append=T, file="../output/tables/tab_nl.tex")

cat("\\midrule Observations & ", 
    sprintf("%.0f", mw_quant_nl1$N), " & ", 
    sprintf("%.0f", mw_quant_nl2$N), " & ", 
    sprintf("%.0f", ct_quant_nl1$N), " & ", 
    sprintf("%.0f", ct_quant_nl2$N), " & ", 
    sprintf("%.0f", tpp_quant_nl1$N), " & ", 
    sprintf("%.0f", tpp_quant_nl2$N), " \\\\ \n ",
    append=T, file="../output/tables/tab_nl.tex")

cat("\\bottomrule %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    \\end{tabular}
    \\end{adjustbox}
	\\caption*{\\footnotesize{\\textbf{Note:} All models are estimated using least squares. Robust standard errors in parentheses. \\\\\\hspace{\\textwidth}
$^\\dagger p < 0.10 ^* p <0.05, ^{**} p<0.01, ^{***} p<0.001$}}
    \\label{tab_reducedform}
    \\end{center}
    \\end{table}"
    , append=T, file="../output/tables/tab_nl.tex")
