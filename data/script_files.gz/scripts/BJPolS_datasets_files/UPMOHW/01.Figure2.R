## This script replicates Figure 2 in Kinne & Bunte, "Guns or Money," BJPS 2018
library(igraph)
library(sna)
library(reshape2)
library(HiveR)
library(SDMTools)
library(RColorBrewer)
library(plyr)
library(ggplot2)
library(GGally)
library(grid)
library(gridExtra)

rm(list=ls(all=TRUE))

## Set this to wherever the BJPS-replication folder is located
dir <- "YourDirectoryHere/BJPS-replication"

setwd(paste(dir, "/Data", sep=""))

## Import network/dyadic data
nets.total <- read.csv("01.networks", header=TRUE, row.names=1)

## List of names against which all data must be sorted. Also use this
## to build an empty matrix, to be used for merging data
id <- sort(unique(nets.total$ccode1))
n <- length(id)
emat <- matrix(NA, length(id), length(id), dimnames=list(id,id))

## Use last five years of the period under analysis
yr <- seq(2005, 2010)

## First sum all DCAs during this period
for (jj in yr) {
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","dca")]
    net <- acast(net, ccode1~ccode2, value.var="dca")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    out[is.na(out)] <- 0
    ## Order rows/columns
    out <- out[order(id),order(id)]
    if ( jj == yr[1] ) {
    	dca.net <- out
    } else {
    	dca.net <- dca.net + out
    }
    rm(net,out)
}; rm(jj)
## Dichotomize to indicate any DCA signed during this period
dca.net[dca.net > 1] <- 1
diag(dca.net) <- 0

## Now do the same for loans
for (jj in yr) {
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","loan")]
    net <- acast(net, ccode1~ccode2, value.var="loan")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    out[is.na(out)] <- 0
    ## Order rows/columns
    out <- out[order(id),order(id)]
    if ( jj == yr[1] ) {
    	loan.net <- out
    } else {
    	loan.net <- loan.net + out
    }
    rm(net,out)
}; rm(jj)
loan.net[loan.net > 1] <- 1
diag(loan.net) <- 0

## Measure (in/out)degree in each network
degree <- sna::degree
dca.deg <- degree(dca.net, gmode="graph")
loan.odeg <- degree(loan.net, gmode="digraph", cmode="outdegree")
loan.ideg <- degree(loan.net, gmode="digraph", cmode="indegree")

## Make an edgelist version of each network
dca.edg <- melt(dca.net); names(dca.edg) <- c("ccode1","ccode2","dca")
dca.edg <- dca.edg[dca.edg$ccode1 < dca.edg$ccode2,] # Make undirected
dca.edg <- dca.edg[dca.edg$dca != 0, ] # Keep only actual ties

loan.edg <- melt(loan.net); names(loan.edg) <- c("ccode1","ccode2","loan")
loan.edg <- loan.edg[loan.edg$ccode1 != loan.edg$ccode2,] # Drop self dyads
loan.edg <- loan.edg[loan.edg$loan != 0, ]

## Code regions based on COW codes, for three axes
reg <- vector(length=length(id))
for (z in 1:length(reg)) {
    if ( as.numeric(colnames(dca.net)[z]) < 400 ) reg[z] <- 1
    if ( as.numeric(colnames(dca.net)[z]) > 399 &
         as.numeric(colnames(dca.net)[z]) < 700 ) reg[z] <- 2
    if ( as.numeric(colnames(dca.net)[z]) > 699 ) reg[z] <- 3
}; rm(z)

## Put all the nodal data in a single data frame
node.list <- data.frame(
    name = rownames(dca.net),
    dca.deg = dca.deg,
    loan.odeg = loan.odeg,
    loan.ideg = loan.ideg,
    loan.deg = loan.odeg + loan.ideg,
    region=reg
)
rm(dca.deg, loan.ideg, loan.odeg, reg)

## Now calculate two-paths in each network
dca.2paths <- dca.net %*% dca.net; isSymmetric(dca.2paths)
loan.2paths <- loan.net %*% loan.net; isSymmetric(loan.2paths)

## Function for mapping DCA 2-path data to edgelist
F1.map <- function(x) {
    data.frame(
        dca.2paths = dca.2paths[which(rownames(dca.2paths) ==
                                      as.character(x$ccode1)),
                                which(colnames(dca.2paths) ==
                                      as.character(x$ccode2))]
    )
} 
dca.edat <- ddply(
    dca.edg, .variables=c("ccode1", "ccode2", "dca"),
    function(x) data.frame(F1.map(x))
)
rm(dca.2paths, dca.edg, F1.map)

## Do the same for loans
F2.map <- function(x) {
    data.frame(
        loan.2paths = loan.2paths[which(rownames(loan.2paths) ==
                                        as.character(x$ccode1)),
                                  which(colnames(loan.2paths) ==
                                        as.character(x$ccode2))]
    )
} 
loan.edat <- ddply(
    loan.edg, .variables=c("ccode1", "ccode2", "loan"),
    function(x) data.frame(F2.map(x))
)
rm(loan.2paths, loan.edg, F2.map)

## Calculate node size as interpolated degree, bound beteen 0.5 and 1.5
approxVals <- approx(c(0.5,1.5), n=length(unique(node.list$dca.deg)))
node.list$dca.size <- sapply(
    node.list$dca.deg, function(x)
        approxVals$y[which(sort(unique(node.list$dca.deg)) == x)]
)
rm(approxVals)

## Do the same for loans, combining in/outdegree
approxVals <- approx(c(0.5,1.5), n=length(unique(node.list$loan.deg)))
node.list$loan.size <- sapply(
    node.list$loan.deg, function(x)
        approxVals$y[which(sort(unique((
            node.list$loan.odeg + node.list$loan.ideg
        ))) == x)]
)
rm(approxVals)

## Generate colors for nodes based on degree
F1.col <- colorRampPalette(
    adjustcolor(brewer.pal(9,"YlOrBr")[2:9], alpha.f=0.5),
    bias = 1.5, space = "rgb", interpolate = "linear"
)
colCodes <- F1.col(length(0:max(node.list$loan.deg)))
names(colCodes) <- 0:max(node.list$loan.deg)
node.list$loan.color <- colCodes[ match(node.list$loan.deg, names(colCodes)) ]
## Save full spectrum of color codes for legend
loan.cols <- colCodes

## Set DCA node color based on degree, but using same scale as for loans, which
## allows for direct comparisions between networks.
node.list$dca.color <- colCodes[ match(node.list$dca.deg, names(colCodes)) ]
## Save full spectrum of color codes for legend
dca.cols <- colCodes; rm(colCodes,F1.col)

## Assign visual attributes to edges, starting with transitivity.
## Use the same scale for both networks, to better
## allow direct comparisons. Set scale on DCA network, since it
## has more triangles.
F1.edg <- colorRampPalette(brewer.pal(9,"YlGnBu")[3:9])
colCodes <- F1.edg(length(0:max(dca.edat$dca.2paths)))
names(colCodes) <- 0:max(dca.edat$dca.2paths)
dca.edat$color <- colCodes[ match(dca.edat$dca.2paths, names(colCodes)) ]
## Save full spectrum of color codes for legend
dca.ecols <- colCodes

## Now the same for loans
loan.edat$color <- colCodes[ match(loan.edat$loan.2paths, names(colCodes)) ]
## Save full spectrum of color codes for legend
loan.ecols <- colCodes

rm(colCodes,F1.edg)


#######################################################
## Use the above data frames to build hive plot objects
#######################################################

## Some helper functions from SDMTools package. Credit to
## Vesna M! https://gist.github.com/Vessy/6562505
source("mod.edge2HPD.R")
source("mod.mineHPD.R")

## Assign nodes to axes by region
node.list$axis <- as.integer(node.list$region)

## Make axis labels
a.labs <- c("Americas &\nEurope", "Africa &\nMiddle East", "Asia &\nOceania")

## Transitivity plot for DCAs
dca.cc <- transitivity(
    graph_from_adjacency_matrix(
        dca.net,
        mode="undirected", diag=FALSE
    ), type="global"
)
## Basic hive plot, we'll adjust this below
hive1.dca <- mod.edge2HPD(
    edge_df = dca.edat[, 1:2],
    edge.weight = rep(0.1,nrow(dca.edat)),
    edge.color = dca.edat$color,
    node.color = node.list[,c("name", "dca.color")],
    node.size = node.list[,c("name", "dca.size")],
    node.radius = node.list[,c("name", "dca.size")],
    node.axis = node.list[,c("name", "axis")],
    axis.cols=rep("gray",3)
)
hive1.dca <- mineHPD(hive1.dca, option = "remove zero edge")


## Transitivity plot for loans
loan.cc <- transitivity(
    graph_from_adjacency_matrix(
        loan.net, mode="directed", diag=FALSE
    ), type="global"
)
hive1.loan <- mod.edge2HPD(
    edge_df = loan.edat[, 1:2],
    edge.weight = rep(0.1,nrow(loan.edat)),
    edge.color = loan.edat$color,
    node.color = node.list[,c("name", "loan.color")],
    node.size = node.list[,c("name", "loan.size")],
    node.radius = node.list[,c("name", "loan.size")],
    node.axis = node.list[,c("name", "axis")],
    axis.cols=rep("gray",3)
)
hive1.loan <- mineHPD(hive1.loan, option = "remove zero edge")






################################################################
## Next plot traditional network graphs and degree distributions
################################################################

## Make the DCA matrix a network object
net.use <- as.network(dca.net, directed=FALSE,
                      hyper=FALSE, matrix.type="adjacency")

## Use GGally package to plot ggplot versions of networks
gg.dca.net <- ggnet2(
    net.use, edge.color="gray85", edge.size=0.1,
    color=node.list$dca.color,
    size=sqrt(node.list$dca.deg)/2,
    size.min=0.001, mode="kamadakawai", alpha=1) +
    guides(color = FALSE, size = FALSE) +
    theme(
        plot.title = element_text(hjust = 0.03, size=12, face="bold")
    )

## DCA degree distribution
gg.dca.deg <- ggplot(as.data.frame(node.list$dca.deg),
                     aes(x=node.list$dca.deg)) +
    geom_histogram(aes(y=..density..), binwidth=0.5,
                   color="gray25", fill="gray35") +
    xlab("Nodal degree") + ylab("Density") +
    theme(
        plot.margin = unit(c(0,0,0,0), "cm"),
        axis.title=element_text(size=10)
    )

## Embed degree plot in the network plot
a1 <- gg.dca.net
b1 <- ggplotGrob(gg.dca.deg)
r1 <- ggplot_build(a1)$layout$panel_ranges[[1]]$y.range
ymin1 <- r1[1]
ymax1 <- r1[1] + (0.25 * (r1[2] - r1[1]))
c1 <- a1 + annotation_custom(grob = b1, xmin=0, xmax=0.4, ymin=ymin1,
                             ymax=ymax1) +
    ggtitle("(b) DCA network and\ndegree distribution")
rm(a1,b1,r1,ymin1,ymax1)


## Do the same for the loan network
rm(net.use)
net.use <- as.network(loan.net, directed=TRUE,
                      hyper=FALSE, matrix.type="adjacency")

gg.loan.net <- ggnet2(
    net.use, edge.color="gray85",
    edge.size=0.1, color=node.list$loan.color,
    size=sqrt(node.list$loan.deg)/2, size.min=0.001, mode="kamadakawai", alpha=1) +
    guides(color = FALSE, size = FALSE) +
    theme(plot.title = element_text(size=12, hjust = 0.03, face="bold"))

gg.loan.odeg <- ggplot(as.data.frame(node.list$loan.odeg),
                       aes(x=(node.list$loan.odeg))) +
    geom_histogram(aes(y=..density..),
                   binwidth=0.5, color="gray25", fill="gray35") +
    xlab("Nodal outdegree") + ylab("Density") +
    theme(
        plot.margin = unit(c(0,0,0,0), "cm"),
        axis.title=element_text(size=10)
    )

a2 <- gg.loan.net
b2 <- ggplotGrob(gg.loan.odeg)
r2 <- ggplot_build(a2)$layout$panel_ranges[[1]]$y.range
ymin2 <- r2[1]
ymax2 <- r2[1] + (0.25 * (r2[2] - r2[1]))
c2 <- a2 + annotation_custom(grob = b2, xmin=0, xmax=0.4, ymin=ymin2,
                             ymax=ymax2) +
    ggtitle("(a) Loan network and\ndegree distribution")
rm(a2,b2,r2,ymin2,ymax2)






###################################################
## Combine all the above figures into a single plot
###################################################

dir.create(paste(dir, "/Figures", sep=""))
setwd(paste(dir, "/Figures", sep=""))

## Use viewports to build the plot
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)

pdf("TestPlot.pdf", width=12, height=10, paper="special")
grid.newpage()
pushViewport(viewport(
    layout = grid.layout(3, 3, widths=unit(c(5.5, 1, 5.5), rep("in",3)),
                         heights=unit(c(4.75, .5, 4.75), rep("in",3)) ))
    )

## Draw ggplot DCA network with custom legend
pushViewport(vplayout(1,1))
print(c2, newpage = FALSE)
popViewport()

## Add shared legend for first row
pushViewport(vplayout(1,2))
grid.raster(
    rev(as.raster(dca.cols)),
    x=0.7,y=0.55,width=0.4,height=0.3, just=c("right","bottom")
)
grid.text(
    as.character(c(15,50,85)),
    x = 0.75, y = seq(.6,.8,.1), just="left", gp=gpar(col="black", fontsize=10)
)
grid.text(
    rep("-",3), x = 0.63, y = seq(.6,.8,.1), just="left",
    gp=gpar(col="white", fontsize=10)
)
grid.text(
    rep("-",3), x = 0.29, y = seq(.6,.8,.1), just="left",
    gp=gpar(col="white", fontsize=10)
)
grid.text(
    "Nodal\ndegree", x = 0.5, y = .9, just="center",
    gp=gpar(col="black", fontsize=10)
)

popViewport()

## Draw loan network
pushViewport(vplayout(1,3))
print(c1, newpage = FALSE)
popViewport()

## Move to second row of viewport (technically third row, since
## we're using a gap row)

lp <- 0.4 # Axis label positions

## Hive plot for loan network
pushViewport(vplayout(3,1))
plotHive(hive1.loan, method = "abs", dr.nodes=TRUE, bkgnd = "white",
         axLab.gpar=gpar(col="black", fontsize=10),  axLab.pos = lp,
         axLabs=a.labs, np=FALSE
         )

## Add the clustering coefficient
grid.text(
    paste("Clustering coefficient = ", round(loan.cc, 3), sep=""),
    x = 0.5, y = .35, just="center", gp=gpar(col="black", fontsize=8)
)
grid.text(
    "(c) Loan ties,\nweighted by transitivity",
    x=0.05, y=0.95, just="left", gp=gpar(col="black", fontsize=12, fontface="bold")
)
popViewport(2)

## Add shared legend for second row
pushViewport(vplayout(3,2))
grid.raster(
    rev(as.raster(dca.ecols)),x=0.7,y=0.55,width=0.4,height=0.3,
    just=c("right","bottom")
)
grid.text(
    as.character(c(2,10,18)), x = 0.75, y = seq(.6,.8,.1), just="left",
    gp=gpar(col="black", fontsize=10)
)
grid.text(
    rep("-",3), x = 0.63, y = seq(.6,.8,.1), just="left",
    gp=gpar(col="white", fontsize=10)
)
grid.text(
    rep("-",3), x = 0.29, y = seq(.6,.8,.1), just="left",
    gp=gpar(col="white", fontsize=10)
)
grid.text(
    "Triangles\nclosed", x = 0.5, y = .9, just="center",
    gp=gpar(col="black", fontsize=10)
)

popViewport()

## DCA hive plot
pushViewport(vplayout(3,3))
plotHive(hive1.dca, method = "abs", dr.nodes=TRUE, bkgnd = "white",
         axLab.gpar=gpar(col="black", fontsize=10), axLab.pos = lp,
         axLabs=a.labs, np=FALSE)

## Add the clustering coefficient
grid.text(
    paste("Clustering coefficient = ", round(dca.cc, 3), sep=""),
    x = 0.5, y = .35, just="center", gp=gpar(col="black", fontsize=8)
)
grid.text(
    "(d) DCA ties,\nweighted by transitivity", x=0.05, y=0.95, just="left",
    gp=gpar(col="black", fontsize=12, fontface="bold")
)
popViewport(2)

dev.off()
