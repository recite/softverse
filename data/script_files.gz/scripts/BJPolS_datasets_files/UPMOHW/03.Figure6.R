## This script replicates Figure 6 in Kinne & Bunte, "Guns or Money," BJPS 2018

library(reshape2)
library(network)
library(sna)
library(RSiena)
library(ggplot2)
library(gdata)
library(countrycode)

rm(list=ls(all=TRUE))

## Set this to wherever the BJPS-replication folder is located
dir <- "YourDirectoryHere/BJPS-replication"

setwd(paste(dir, "/Data", sep=""))

nets.total <- read.csv("01.networks", header=TRUE, row.names=1)
mons.total <- read.csv("02.monadic", header=TRUE, row.names=1)

## Set some parameters.
## We're using data only through 2009
## and saving 2010 for prediction.
yr <- seq(1990, 2009)
yr.lo <- yr[1:(length(yr)-1)]

## List of names against which all data must be sorted. Also use this
## to build an empty matrix, to be used for merging data
id <- sort(unique(mons.total$ccode1))
n <- length(id)
emat <- matrix(NA, length(id), length(id), dimnames=list(id,id))

#########################################################
## Start with the DVs, i.e., DCA and loan data
#########################################################

## Make an empty composition file. We'll fill this in as we
## loop over each year of data.
comp <- rep(list(c(1,length(yr))),length(id))
names(comp) <- id
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","dca")]
    net <- acast(net, ccode1~ccode2, value.var="dca")
    ## Update the composition file as needed
    miss <- setdiff(id,rownames(net))
    for ( z in miss ) { # Move entry up by one if state not present in this year
        comp[[paste(z)]][1] <- sm + 1
    }; rm(z)
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("DCA.NET.", jj, sep=""), out)
    rm(net,out,miss)
    objs[sm] <- paste("DCA.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("DCAs.NET", sep=""), lapply(objs,get))
names(DCAs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^DCA.NET."))

## Now the loan matrices
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","loan")]
    net <- acast(net, ccode1~ccode2, value.var="loan")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("LOAN.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("LOAN.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("LOANs.NET", sep=""), lapply(objs,get))
names(LOANs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^LOAN.NET."))

#########################################################
## Then do all the covariates for both networks
#########################################################

## Names of dyadic and monadic covariates
d.cons <- names(nets.total)[ !names(nets.total) %in% c("ccode1","ccode2","year","dca","loan") ]
m.cons <- names(mons.total)[ !names(mons.total) %in% c("ccode1","year") ]

## Set the monadic covariates as NxK matrices, where K is number of years. Remember to
## subtract the last year for RSiena estimation.
for (k in 1:length(m.cons)) {
    out <- matrix(nrow=length(id),ncol=0)
    rownames(out) <- id
    for (i in yr.lo) {
        tmp <- as.matrix(mons.total[mons.total$year==i,c(m.cons[k])])
        rownames(tmp) <- mons.total[mons.total$year==i,]$ccode1
        ## Bind on row names
        out <- cbind(out, tmp[match(rownames(out),rownames(tmp))])
        rm(tmp)
    }; rm(i)
    colnames(out) <- yr.lo
    out <- out[order(id),]
    assign(paste(m.cons[k],sep=""), out)
    rm(out)
}; rm(k)

for (k in 1:length(d.cons)) { # Save dyadic covariates as lists of matrices
    for (i in yr.lo) {
        cov <- nets.total[nets.total$year==i, c("ccode1","ccode2",d.cons[k])]
        ## Here's the adjacency matrix
        cov <- acast(cov, ccode1~ccode2, value.var=d.cons[k])
        out <- emat
        ## Add cov data to the full matrix with all actors
        out[rownames(out) %in% rownames(cov), colnames(out) %in% colnames(cov)] <- cov
        diag(out) <- 0
        ## Order rows/columns
        out <- out[order(id),order(id)]
        assign(paste(d.cons[k], i, sep=""), out)
        rm(out,cov)
    }; rm(i)
    out.list <- lapply(paste(d.cons[k], yr.lo, sep=""), get)
    names(out.list) <- paste(d.cons[k], yr.lo, sep="")
    assign(paste(d.cons[k], sep=""), out.list)
    rm(out.list, list=paste(d.cons[k], yr.lo, sep=""))
}; rm(k)

####################################
## Convert objects to RSiena objects
####################################

yrhi <- yr
yrlo <- yr.lo
nlo <- length(yrlo)
nhi <- length(yrhi)
N <- n

## Dependent networkS
assign("dcas.net", sienaNet(array(do.call("c", DCAs.NET), dim=c(N,N,nhi))))
assign("loans.net", sienaNet(array(do.call("c", LOANs.NET), dim=c(N,N,nhi))))

## Changing dyadic covariates, omitting the constant ones
dyad.effects <- d.cons[ !d.cons %in% c("colony","lndistance") ]
for (x in dyad.effects) {
    assign(paste(x, ".net", sep=""), varDyadCovar(array(do.call("c", get(x)), dim=c(N,N,nlo))))
}; rm(x)

## Constant dyadic covariates
for (x in d.cons[ d.cons %in% c("colony","lndistance")]) {
    assign(paste(x, ".net", sep=""), coDyadCovar(get(x)[[nlo]]))
}

## Monadic covariates
monad.effects <- m.cons
for (x in monad.effects) {
    assign(paste(x, ".net", sep=""), varCovar(get(x)))
}; rm(x)

## set the composition change object
changes <- sienaCompositionChange(comp)

## Create an RSiena network object
netdata <- sienaDataCreate(
    dcas.net,
    loans.net,

    colony.net,
    lndistance.net,
    alliance.noNATO.net,
    affinity.net,
    NATO.net,
    NATO.PfP.net,
    lntrade.net,
    mutual.enemy.net,
    arms.match.net,

    alliance.net,
    lnimports.net,
    lnexports.net,

    polity.net,
    lnGDPcap.net,
    lnCINC.net,
    terrorism.net,

    credit.net,
    lnOil.net,
    lnExposure.net,
    crisis.debt.net,
    crisis.bank.net,
    crisis.credit.net,
    current.balance.net,
    borrow.multi.net,
    borrow.private.net,
    lend.multi.net,

    changes
    )

eff <- getEffects(netdata)

## Loan network equation first
d.loans <- paste(
    c("affinity","lndistance","colony",
      "alliance","lnimports","lnexports"
      ),
    ".net", sep=""
    )
m.loans_i <- paste(
    c("current.balance","lend.multi","lnGDPcap"),
    ".net", sep=""
    )
m.loans_j <- paste(
    c("credit","corrupt","lnGDPcap","lnOil",
      "lnExposure","crisis.debt","crisis.bank","crisis.credit",
      "current.balance","borrow.multi","borrow.private"),
    ".net", sep=""
    )

for (x in d.loans) { # Dyadic effects
    eff <- includeEffects(eff, X, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_j) { # Monadic effects for debtors
    eff <- includeEffects(eff, altX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_i) { # Monadic effects for creditors
    eff <- includeEffects(eff, egoX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Do a political similarity measure
eff <- includeEffects(eff, simX, name="loans.net", interaction1="polity.net", include=T, type="eval")

## Endogenous loan network effects
eff <- includeEffects(eff, transTrip, name="loans.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, inPopSqrt, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, outActSqrt, name="loans.net", include=T, type="eval")
## Set reciprocity at an arbitrarily low value
eff <- setEffect(eff, recip, name="loans.net", initialValue=-99)
eff <- includeEffects(eff, recip, name="loans.net", include=T, fix=T, test=F, type="eval")

## Now the DCA network equation
d.dcas <- paste(
    c("arms.match","mutual.enemy","affinity","lntrade",
      "NATO","NATO.PfP","alliance.noNATO",
      "lndistance","colony"),
    ".net", sep=""
    )

m.dcas <- paste(
    c("polity","lnCINC","terrorism","lnGDPcap"),
    ".net", sep=""
    )

for (x in d.dcas) { # Dyadic covariates
    eff <- includeEffects(eff, X, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.dcas) { # Monadic covariates
    eff <- includeEffects(eff, altX, egoXaltX, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Endogenous DCA network effects
eff <- includeEffects(eff, transTriads, name="dcas.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, inPop, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, isolateNet, name="dcas.net", include=T, type="eval")

## Now specify the cross-network effects
## Always include the basic cross-products
eff <- includeEffects(eff, crprod, name="loans.net", interaction1="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, crprod, name="dcas.net", interaction1="loans.net", include=T, type="eval")

## Add in higher order cross-network effects
eff <- includeEffects(eff, outPopIntn, JinMix, name="dcas.net", interaction1="loans.net", include=T, type="eval")
eff <- includeEffects(eff, to, inPopIntn, name="loans.net", interaction1="dcas.net", include=T, type="eval")

## Estimate a model and save the results as the training set
dir.create(paste(dir, "/Output", sep=""))
setwd(paste(dir, "/Output", sep=""))

tm <- Sys.time()
model <- sienaAlgorithmCreate(useStdInits=T,
                              projname="Estimates.GOF.train",
                              nsub=5, n3=3000, maxlike=F,
                              modelType=3)
output <- siena07(model,data=netdata,effects=eff,
                  batch=TRUE,verbose=FALSE,useCluster=TRUE,
                  nbrNodes=2,returnDeps=FALSE)
save(output, file="output.GOF.train")
rm(output)

######################################################
## Now specify a model for the 2009 OOS period
######################################################

keep(dir, mons.total, nets.total, sure=TRUE)

## Specify data for out-of-sample prediction
yr <- seq(2009, 2010)
yr.lo <- yr[1:(length(yr)-1)]

## List of names against which all data must be sorted. Also use this
## to build an empty matrix, to be used for merging data
id <- sort(unique(mons.total$ccode1))
n <- length(id)
emat <- matrix(NA, length(id), length(id), dimnames=list(id,id))

#########################################################
## Start with the DVs, i.e., DCA and loan data
#########################################################

## DCAs first
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","dca")]
    net <- acast(net, ccode1~ccode2, value.var="dca")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("DCA.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("DCA.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("DCAs.NET", sep=""), lapply(objs,get))
names(DCAs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^DCA.NET."))

## Now the loan matrices
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","loan")]
    net <- acast(net, ccode1~ccode2, value.var="loan")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("LOAN.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("LOAN.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("LOANs.NET", sep=""), lapply(objs,get))
names(LOANs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^LOAN.NET."))

#########################################################
## Then do all the covariates for both networks
#########################################################

## Names of dyadic and monadic covariates
d.cons <- names(nets.total)[ !names(nets.total) %in% c("ccode1","ccode2","year","dca","loan") ]
m.cons <- names(mons.total)[ !names(mons.total) %in% c("ccode1","year") ]

## Set the monadic covariates as NxK matrices, where K is number of years
for (k in 1:length(m.cons)) {
    out <- matrix(nrow=length(id),ncol=0)
    rownames(out) <- id
    for (i in yr.lo) {
        tmp <- as.matrix(mons.total[mons.total$year==i,c(m.cons[k])])
        rownames(tmp) <- mons.total[mons.total$year==i,]$ccode1
        ## Bind on row names
        out <- cbind(out, tmp[match(rownames(out),rownames(tmp))])
        rm(tmp)
    }; rm(i)
    colnames(out) <- yr.lo
    out <- out[order(id),]
    assign(paste(m.cons[k],sep=""), out)
    rm(out)
}; rm(k)

## Save dyadic covariates as lists of matrices
for (k in 1:length(d.cons)) {
    for (i in yr.lo) {
        cov <- nets.total[nets.total$year==i, c("ccode1","ccode2",d.cons[k])]
        ## Here's the adjacency matrix
        cov <- acast(cov, ccode1~ccode2, value.var=d.cons[k])
        out <- emat
        ## Add cov data to the full matrix with all actors
        out[rownames(out) %in% rownames(cov), colnames(out) %in% colnames(cov)] <- cov
        diag(out) <- 0
        ## Order rows/columns
        out <- out[order(id),order(id)]
        assign(paste(d.cons[k], i, sep=""), out)
        rm(out,cov)
    }; rm(i)
    out.list <- lapply(paste(d.cons[k], yr.lo, sep=""), get)
    names(out.list) <- paste(d.cons[k], yr.lo, sep="")
    assign(paste(d.cons[k], sep=""), out.list)
    rm(out.list, list=paste(d.cons[k], yr.lo, sep=""))
}; rm(k)

####################################
## Convert objects to RSiena objects
####################################

yrhi <- yr
yrlo <- yr.lo
nlo <- length(yrlo)
nhi <- length(yrhi)
N <- n

## Dependent networkS
assign("dcas.net", sienaNet(array(do.call("c", DCAs.NET), dim=c(N,N,nhi))))
assign("loans.net", sienaNet(array(do.call("c", LOANs.NET), dim=c(N,N,nhi))))

## Must specify all covariates as constant (i.e., not changing over time)
dyad.effects <- d.cons
for (x in dyad.effects) {
    assign(paste(x, ".net", sep=""), coDyadCovar(get(x)[[nlo]]))
}; rm(x)

## Monadic covariates
monad.effects <- m.cons
for (x in monad.effects) {
    assign(paste(x, ".net", sep=""), coCovar(get(x)))
}; rm(x)

## Create an RSiena network object. No composition object needed.
netdata <- sienaDataCreate(
    dcas.net,
    loans.net,

    colony.net,
    lndistance.net,
    alliance.noNATO.net,
    affinity.net,
    NATO.net,
    NATO.PfP.net,
    lntrade.net,
    mutual.enemy.net,
    arms.match.net,

    alliance.net,
    lnimports.net,
    lnexports.net,

    polity.net,
    lnGDPcap.net,
    lnCINC.net,
    terrorism.net,

    credit.net,
    lnOil.net,
    lnExposure.net,
    crisis.debt.net,
    crisis.bank.net,
    crisis.credit.net,
    current.balance.net,
    borrow.multi.net,
    borrow.private.net,
    lend.multi.net
    )

eff <- getEffects(netdata)

## Loan network equation first
d.loans <- paste(
    c("affinity","lndistance","colony",
      "alliance","lnimports","lnexports"
      ),
    ".net", sep=""
    )
m.loans_i <- paste(
    c("current.balance","lend.multi","lnGDPcap"),
    ".net", sep=""
    )
m.loans_j <- paste(
    c("credit","corrupt","lnGDPcap","lnOil",
      "lnExposure","crisis.debt","crisis.bank","crisis.credit",
      "current.balance","borrow.multi","borrow.private"),
    ".net", sep=""
    )

for (x in d.loans) { # Dyadic effects
    eff <- includeEffects(eff, X, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_j) { # Monadic effects for debtors
    eff <- includeEffects(eff, altX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_i) { # Monadic effects for creditors
    eff <- includeEffects(eff, egoX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Do a political similarity measure
eff <- includeEffects(eff, simX, name="loans.net", interaction1="polity.net", include=T, type="eval")

## Endogenous loan network effects
eff <- includeEffects(eff, transTrip, name="loans.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, inPopSqrt, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, outActSqrt, name="loans.net", include=T, type="eval")
## Set reciprocity at an arbitrarily low value
eff <- setEffect(eff, recip, name="loans.net", initialValue=-99)
eff <- includeEffects(eff, recip, name="loans.net", include=T, fix=T, test=F, type="eval")

## Now the DCA network equation
d.dcas <- paste(
    c("arms.match","mutual.enemy","affinity","lntrade",
      "NATO","NATO.PfP","alliance.noNATO",
      "lndistance","colony"),
    ".net", sep=""
    )

m.dcas <- paste(
    c("polity","lnCINC","terrorism","lnGDPcap"),
    ".net", sep=""
    )

for (x in d.dcas) { # Dyadic covariates
    eff <- includeEffects(eff, X, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.dcas) { # Monadic covariates
    eff <- includeEffects(eff, altX, egoXaltX, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Endogenous DCA network effects
eff <- includeEffects(eff, transTriads, name="dcas.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, inPop, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, isolateNet, name="dcas.net", include=T, type="eval")

## Now specify the cross-network effects
## Always include the basic cross-products
eff <- includeEffects(eff, crprod, name="loans.net", interaction1="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, crprod, name="dcas.net", interaction1="loans.net", include=T, type="eval")

## Add in higher order cross-network effects
eff <- includeEffects(eff, outPopIntn, JinMix, name="dcas.net",
                      interaction1="loans.net", include=T, type="eval")
eff <- includeEffects(eff, to, inPopIntn, name="loans.net",
                      interaction1="dcas.net", include=T, type="eval")

## Grab estimates from training sample
setwd(paste(dir, "/Output", sep=""))
load("output.GOF.train")

## Save rate and degree start values, since these must differ
## from training period.
rp1 <- eff[eff$effectName=="basic rate parameter dcas.net",]$initialValue
rp2 <- eff[eff$effectName=="dcas.net: degree (density)" & eff$include==TRUE,]$initialValue
rp3 <- eff[eff$effectName=="basic rate parameter loans.net" & eff$include==TRUE,]$initialValue
rp4 <- eff[eff$effectName=="loans.net: outdegree (density)" & eff$include==TRUE,]$initialValue

## Update thetas with estimates from training period
eff <- updateTheta(eff,output)
## Then replace rate and density parameters
eff[eff$effectName=="basic rate parameter dcas.net",]$initialValue <- rp1
eff[eff$effectName=="dcas.net: degree (density)" & eff$include==TRUE,]$initialValue <- rp2
eff[eff$effectName=="basic rate parameter loans.net" & eff$include==TRUE,]$initialValue <- rp3
eff[eff$effectName=="loans.net: outdegree (density)" & eff$include==TRUE,]$initialValue <- rp4

## No subroutines in stage 2, since we're not estimating parameters. Instead,
## just simulate the network a few thousand times.
model.SIM <- sienaModelCreate(useStdInits = F,
                              projname="Simulation-GOF-Predict",
                              nsub=0, n3=3000, maxlike=F, cond=F, modelType=3)

## Call the estimation/simulation function. Be sure to return the dependent
## simulated matrices.
SIM.out.predict <- siena07(model.SIM, data=netdata, effects=eff,
                           batch=TRUE, verbose=FALSE, useCluster=TRUE,
                           nbrNodes=2, initC=TRUE, returnDeps=TRUE)
save(SIM.out.predict,file=paste("output.GOF.predict"))

## Now estimate a logit model, predict out of sample, and compare
## the logit to the SAOM predictions
keep(mons.total, nets.total, dir, id, N, yr, DCAs.NET, LOANs.NET, sure=TRUE)
library(ROCR)
library(PRROC)

## Load SAOM predictions
setwd(paste(dir, "/Output", sep=""))
load("output.GOF.predict")

## Collect SAOM predictions
sims <- SIM.out.predict$sims
for ( z in c("loans.net","dcas.net")) {
    ## Grab predicted SAOM networks for last time period
    base <- matrix(0,N,N,dimnames=list(id,id))
    for ( i in 1:length(sims) ) {
        adj <- matrix(0,N,N)
        ## The final year is the one we're predicting
        edges <- sims[[i]][[1]][[z]][[(length(yr)-1)]]
        adj[edges[, 1:2]] <- edges[,3]
        base <- base + adj
        rm(adj,edges)
    }
    ## Weight total predicted ties by number of simulated networks
    base <- base/length(sims); diag(base) <- NA

    ## Get the * observed* networks for last time period
    if ( z == "dcas.net" ) obs <- DCAs.NET[[length(yr)]]
    if ( z == "loans.net" ) obs <- LOANs.NET[[length(yr)]]
    diag(obs) <- NA
    
    ## Combine predicted and observed vectors, then assess fit
    op <- na.omit(cbind(as.data.frame(as.table(base))[,3],as.data.frame(as.table(obs))[,3]))
    pre.out <- cbind(as.data.frame(as.table(base)),as.data.frame(as.table(obs))[,3])
    names(pre.out) <- c("ccode1","ccode2","predict","observe")    
    assign(paste("saom.pre.", z, sep=""), pre.out); rm(pre.out)

    rm(base,op,roc,pr)
}; rm(z)
rm(sims)

## Reorganize the full dataset for the logit model. Use the full period.
## We're going to grab all the same data as for the SAOMs, then
## restructure it into a data frame.
yr <- seq(1990, 2010)
yr.lo <- yr[1:(length(yr)-1)]

## List of names against which all data must be sorted. Also use this
## to build an empty matrix, to be used for merging data
id <- sort(unique(mons.total$ccode1))
n <- length(id)
emat <- matrix(NA, length(id), length(id), dimnames=list(id,id))

#########################################################
## Start with the DVs, i.e., DCA and loan data
#########################################################

for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","dca")]
    net <- acast(net, ccode1~ccode2, value.var="dca")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("DCA.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("DCA.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("DCAs.NET", sep=""), lapply(objs,get))
names(DCAs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^DCA.NET."))

## Now the loan matrices
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","loan")]
    net <- acast(net, ccode1~ccode2, value.var="loan")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("LOAN.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("LOAN.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("LOANs.NET", sep=""), lapply(objs,get))
names(LOANs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^LOAN.NET."))

#########################################################
## Then do all the covariates for both networks
#########################################################

## Names of dyadic and monadic covariates
d.cons <- names(nets.total)[ !names(nets.total) %in% c("ccode1","ccode2","year","dca","loan") ]
m.cons <- names(mons.total)[ !names(mons.total) %in% c("ccode1","year") ]

## Set the monadic covariates as NxK matrices, where K is number of years. Remember to
## subtract the last year for RSiena estimation.
for (k in 1:length(m.cons)) {
    out <- matrix(nrow=length(id),ncol=0)
    rownames(out) <- id
    for (i in yr.lo) {
        tmp <- as.matrix(mons.total[mons.total$year==i,c(m.cons[k])])
        rownames(tmp) <- mons.total[mons.total$year==i,]$ccode1
        ## Bind on row names
        out <- cbind(out, tmp[match(rownames(out),rownames(tmp))])
        rm(tmp)
    }; rm(i)
    colnames(out) <- yr.lo
    out <- out[order(id),]
    assign(paste(m.cons[k],sep=""), out)
    rm(out)
}; rm(k)

for (k in 1:length(d.cons)) { # Save dyadic covariates as lists of matrices
    for (i in yr.lo) {
        cov <- nets.total[nets.total$year==i, c("ccode1","ccode2",d.cons[k])]
        ## Here's the adjacency matrix
        cov <- acast(cov, ccode1~ccode2, value.var=d.cons[k])
        out <- emat
        ## Add cov data to the full matrix with all actors
        out[rownames(out) %in% rownames(cov), colnames(out) %in% colnames(cov)] <- cov
        diag(out) <- 0
        ## Order rows/columns
        out <- out[order(id),order(id)]
        assign(paste(d.cons[k], i, sep=""), out)
        rm(out,cov)
    }; rm(i)
    out.list <- lapply(paste(d.cons[k], yr.lo, sep=""), get)
    names(out.list) <- paste(d.cons[k], yr.lo, sep="")
    assign(paste(d.cons[k], sep=""), out.list)
    rm(out.list, list=paste(d.cons[k], yr.lo, sep=""))
}; rm(k)

####################################################
## Now convert all the data matrices to a data frame
####################################################

dat <- lapply(DCAs.NET, function(x) as.data.frame(as.table(x)))
for (w in 1:length(yr)) {
    dat[[w]]$year <- yr[w]
}
dat <- do.call("rbind", dat)
names(dat) <- c("ccode1","ccode2","DCAs","year")

tmp <- lapply(LOANs.NET, function(x) as.data.frame(as.table(x)))
for (w in 1:length(yr)) {
    tmp[[w]]$year <- yr[w]
}
tmp <- do.call("rbind", tmp)
names(tmp) <- c("ccode1","ccode2","LOANs","year")

dat <- merge(dat,tmp); rm(tmp)

## Add all the covariates to the data frame,
## dyadic covariates first. Lag these all
## by a year.
for (w in d.cons) {
    tmp <- lapply(get(w), function(x) as.data.frame(as.table(x)))
    for (z in 1:length(tmp)) {
        tmp[[z]]$year <- yr[z] + 1
    }
    tmp <- do.call("rbind", tmp)
    names(tmp) <- c("ccode1","ccode2",w,"year")
    dat <- merge(dat,tmp,all.x=TRUE)
    rm(tmp)
}; rm(w)

## Now merge monadic covariates.
for (w in m.cons) {
    tmp <- as.data.frame(as.table(get(w)))
    names(tmp) <- c("ccode1","year",paste(w,".cc1", sep=""))
    tmp$year <- as.numeric(as.character(tmp$year)) + 1
    dat <- merge(dat,tmp,all.x=TRUE)
    names(tmp) <- c("ccode2","year",paste(w,".cc2", sep=""))
    dat <- merge(dat,tmp,all.x=TRUE)
    dat[[paste(w,".both",sep="")]] <- dat[[paste(w,".cc1", sep="")]] * dat[[paste(w,".cc2", sep="")]]
    if ( w == "polity" ) {
        dat[[paste(w,".diff",sep="")]] <- abs(dat[[paste(w,".cc1", sep="")]] - dat[[paste(w,".cc2", sep="")]])
    }
    rm(tmp)
}

## Drop "self dyads," then create a nondirected version
## of the data frame for DCAs.
dat <- dat[dat$ccode1 != dat$ccode2,]
dat.dca <- dat[as.numeric(as.character(dat$ccode1)) < as.numeric(as.character(dat$ccode2)),]

## Make unique identifiers
dat$dyadid <- (as.numeric(dat$ccode1) * 1000) + as.numeric(dat$ccode2)
dat.dca$dyadid <- (as.numeric(dat.dca$ccode1) * 1000) + as.numeric(dat.dca$ccode2)


## Now collect all the nonmissing observations
dt <- na.omit(dat[,c("LOANs", "lndistance", "affinity", "colony", "alliance", "lnimports", "lnexports", "credit.cc2", "polity.diff", "lnGDPcap.cc1", "lnGDPcap.cc2", "lnOil.cc2", "lnExposure.cc2", "crisis.debt.cc2", "crisis.bank.cc2", "crisis.credit.cc2", "current.balance.cc1", "current.balance.cc2", "borrow.multi.cc2", "borrow.private.cc2", "lend.multi.cc1","year","dyadid","ccode1","ccode2")])
dt <- dt[order(dt$dyadid,dt$year),]
## Specify training set and validation set
idx.in <- which(dt$year < 2010)
idx.out <- which(dt$year == 2010)

## Estimate an AR1 logit model
library(geepack)
gee.loans.train <- geeglm(LOANs ~ lndistance + affinity + colony + alliance + lnimports + lnexports + credit.cc2 + polity.diff + lnGDPcap.cc1 + lnGDPcap.cc2 + lnOil.cc2 + lnExposure.cc2 + crisis.debt.cc2 + crisis.bank.cc2 + crisis.credit.cc2 + current.balance.cc1 + current.balance.cc2 + borrow.multi.cc2 + borrow.private.cc2 + lend.multi.cc1, data=dt, family=binomial(link="logit"), id=dyadid, corstr = "ar1", subset=idx.in)

## Now use the above estimated model to make predictions out of sample
tst <- predict(gee.loans.train, dt[idx.out,], type="response", )
pred.use.loan <- cbind( dt[dt$year==2010, c("LOANs","ccode1","ccode2")], tst)
names(pred.use.loan) <- c("observe","ccode1","ccode2","predict")

## Now do the same for DCAs
dt.dc <- na.omit(dat.dca[,c("DCAs", "lndistance", "colony", "alliance.noNATO", "NATO", "NATO.PfP", "affinity", "mutual.enemy", "arms.match", "lntrade", "polity.both", "lnCINC.both", "lnGDPcap.both", "terrorism.both","year","dyadid","ccode1","ccode2")])
dt.dc <- dt.dc[order(dt.dc$dyadid,dt.dc$year),]
idx.in <- which(dt.dc$year < 2010)
idx.out <- which(dt.dc$year == 2010)

gee.dcas.train <- geeglm(DCAs ~ lndistance + colony + alliance.noNATO + NATO + NATO.PfP + affinity + mutual.enemy + arms.match + lntrade + polity.both + lnCINC.both + lnGDPcap.both + terrorism.both, data=dt.dc, family=binomial(link="logit"), id=dyadid, corstr = "ar1", subset=idx.in)

tst <- predict(gee.dcas.train, dt.dc[idx.out,], type=c("response"))
pred.use.dca <- cbind(dt.dc[dt.dc$year==2010,c("DCAs","ccode1","ccode2")], tst)
names(pred.use.dca) <- c("observe","ccode1","ccode2","predict")

## Finally, recreate Figure 6 from the main paper. Importantly, note
## that since the SAOM is a stochastic model, the results here will not
## *exactly* mirror those from the paper. But they should be very close.
library(ggplot2)
library(grid)
library(gridExtra)

## Who are the most active DCA countries in 2010?
dat.use <- dat[dat$year==2010,c("ccode1","DCAs","LOANs")]
dcas.ct <- aggregate(dat.use$DCAs, by=list(Category=dat.use$ccode1), FUN=sum)
dca.focus <- dcas.ct[order(dcas.ct$x),]$Category[(nrow(dcas.ct)-9):nrow(dcas.ct)]

## Who are the most active lenders in 2010?
loan.ct <- aggregate(dat.use$LOANs, by=list(Category=dat.use$ccode1), FUN=sum)
loan.focus <- loan.ct[order(loan.ct$x),]$Category[(nrow(loan.ct)-9):nrow(loan.ct)]

rm(dat.use, dcas.ct, loan.ct)

## Find PPVs for focus states with loans, first for SAOMs
use.loan.saom <- na.omit(saom.pre.loans.net[saom.pre.loans.net$ccode1 %in% loan.focus,])
use.loan.saom$TP <- 0
use.loan.saom$FP <- 0
## Use a 0.1 prediction threshold to label positive predictions
use.loan.saom[use.loan.saom$observe==1 & use.loan.saom$predict >= 0.1,]$TP <- 1 # True positives
use.loan.saom[use.loan.saom$observe==0 & use.loan.saom$predict >= 0.1,]$FP <- 1 # False positives
loan.ppv.saom <- data.frame(
    ccode1 = aggregate(use.loan.saom$TP, by=list(Category=use.loan.saom$ccode1), FUN=sum)$Category,
    ppv = aggregate(use.loan.saom$TP,
        by=list(Category=use.loan.saom$ccode1)
        , FUN=sum)$x / (
              aggregate(use.loan.saom$TP,
                        by=list(Category=use.loan.saom$ccode1),
                        FUN=sum)$x +
              aggregate(use.loan.saom$FP,
                        by=list(Category=use.loan.saom$ccode1),
                        FUN=sum)$x
              )
    )
rm(use.loan.saom)

## Then for loans logit model
use.loan <- na.omit(pred.use.loan[pred.use.loan$ccode1 %in% loan.focus,])
use.loan$TP <- 0
use.loan$FP <- 0
use.loan[use.loan$observe==1 & use.loan$predict >= 0.1,]$TP <- 1 # True positives
use.loan[use.loan$observe==0 & use.loan$predict >= 0.1,]$FP <- 1 # False positives
loan.ppv.logit <- data.frame(
    ccode1 = aggregate(use.loan$TP, by=list(Category=use.loan$ccode1), FUN=sum)$Category,
    ppv = aggregate(
        use.loan$TP,
        by=list(Category=use.loan$ccode1),
        FUN=sum)$x / (
            aggregate(use.loan$TP,
                      by=list(Category=use.loan$ccode1),
                      FUN=sum)$x +
            aggregate(use.loan$FP,
                      by=list(Category=use.loan$ccode1),
                      FUN=sum)$x
            )
    )
## Any missings indicate PPVs of zero
loan.ppv.logit[is.na(loan.ppv.logit)] <- 0
rm(use.loan)

## Do the same for DCAs
use.dca.saom <- na.omit(saom.pre.dcas.net[saom.pre.dcas.net$ccode1 %in% dca.focus,])
use.dca.saom$TP <- 0
use.dca.saom$FP <- 0
use.dca.saom[use.dca.saom$observe==1 & use.dca.saom$predict >= 0.1,]$TP <- 1 # True positives
use.dca.saom[use.dca.saom$observe==0 & use.dca.saom$predict >= 0.1,]$FP <- 1 # False positives
dca.ppv.saom <- data.frame(
    ccode1 = aggregate(use.dca.saom$TP, by=list(Category=use.dca.saom$ccode1), FUN=sum)$Category,
    ppv = aggregate(use.dca.saom$TP,
        by=list(Category=use.dca.saom$ccode1),
        FUN=sum)$x / (
            aggregate(use.dca.saom$TP,
                      by=list(Category=use.dca.saom$ccode1),
                      FUN=sum)$x +
            aggregate(use.dca.saom$FP,
                      by=list(Category=use.dca.saom$ccode1),
                      FUN=sum)$x
            )
    )
rm(use.dca.saom)

## Need to add reverse dyads, since nondirected data
use.dca <- na.omit(pred.use.dca[pred.use.dca$ccode1 %in% dca.focus,])
dum <- na.omit(pred.use.dca[pred.use.dca$ccode2 %in% dca.focus,]) 
dum2 <- data.frame(
    predict=dum$predict,
    observe=dum$observe,
    ccode1=dum$ccode2,
    ccode2=dum$ccode1
    )
use.dca <- rbind(use.dca,dum2); rm(dum,dum2)
use.dca$TP <- 0
use.dca$FP <- 0
use.dca[use.dca$observe==1 & use.dca$predict >= 0.1,]$TP <- 1 # True positives
use.dca[use.dca$observe==0 & use.dca$predict >= 0.1,]$FP <- 1 # False positives
dca.ppv.logit <- data.frame(
    ccode1 = aggregate(use.dca$TP, by=list(Category=use.dca$ccode1), FUN=sum)$Category,
    ppv = aggregate(use.dca$TP,
        by=list(Category=use.dca$ccode1),
        FUN=sum)$x / (
            aggregate(use.dca$TP,
                      by=list(Category=use.dca$ccode1),
                      FUN=sum)$x +
            aggregate(use.dca$FP,
                      by=list(Category=use.dca$ccode1),
                      FUN=sum)$x
            )
    )
dca.ppv.logit[is.na(dca.ppv.logit)] <- 0
rm(use.dca)

## Plot the predictions in a barplot
df.ppv.loans <- rbind(loan.ppv.logit,loan.ppv.saom)
df.ppv.loans[df.ppv.loans$ppv==0,"ppv"] <- 0.01 # Set zeros to negligibly small value for plotting
df.ppv.loans$model <- c(rep("Logit",10),rep("SAOM",10))
df.ppv.loans$cow <- countrycode(df.ppv.loans$ccode1, "cown", "cowc", warn = FALSE)
ord <- df.ppv.loans[df.ppv.loans$model=="SAOM",][order(df.ppv.loans[df.ppv.loans$model=="SAOM",]$ppv),]$cow
df.ppv.loans$cow <- factor(df.ppv.loans$cow, levels=ord)

gg.ppv.loans <- ggplot(df.ppv.loans, aes(x=cow, y=ppv, group=model, fill=model)) +
    geom_bar(stat="identity", position="dodge", width=.65) +
    scale_fill_manual("", values=c("#2c7bb695","#d7191c95"), labels=c("Logit model     ","SAOM")) +
theme(
    legend.position="bottom",
    legend.margin=margin(0,0,0,0,"mm"),
    axis.text.x=element_text(color="black", angle=45, hjust=1),
    plot.title = element_text(hjust = 0.5)
    ) +
    ylab("Precision of predictions") +
    xlab("") +
    ggtitle("Bilateral loans")

## Now for DCAs
df.ppv.dcas <- rbind(dca.ppv.logit,dca.ppv.saom)
df.ppv.dcas[df.ppv.dcas$ppv==0,"ppv"] <- 0.01 # Set zeros to negligibly small value for plotting
df.ppv.dcas$model <- c(rep("Logit",10),rep("SAOM",10))
df.ppv.dcas$cow <- countrycode(df.ppv.dcas$ccode1, "cown", "cowc", warn = FALSE)
ord <- df.ppv.dcas[df.ppv.dcas$model=="SAOM",][order(df.ppv.dcas[df.ppv.dcas$model=="SAOM",]$ppv),]$cow
df.ppv.dcas$cow <- factor(df.ppv.dcas$cow, levels=ord)

gg.ppv.dcas <- ggplot(df.ppv.dcas, aes(x=cow, y=ppv, group=model, fill=model)) +
    geom_bar(stat="identity", position="dodge", width=.65) +
    scale_fill_manual("", values=c("#2c7bb695","#d7191c95"), labels=c("Logit model     ","SAOM")) +
theme(
    legend.position="bottom",
    legend.margin=margin(0,0,0,0,"mm"),
    axis.text.x=element_text(color="black", angle=45, hjust=1),
    plot.title = element_text(hjust = 0.5)
    ) +
    ylab("Precision of predictions") +
    xlab("") +
    ggtitle("Bilateral DCAs")

dir.create(paste(dir, "/Figures", sep=""))
setwd(paste(dir, "/Figures", sep=""))

pdf("PPV-Loans.pdf", width=5, height=3.5, paper="special")
par(mar=c(0,0,0,0))
gg.ppv.loans
dev.off()

pdf("PPV-DCAs.pdf", width=5, height=3.5, paper="special")
par(mar=c(0,0,0,0))
gg.ppv.dcas
dev.off()








