## This script replicates Figure 5 in Kinne & Bunte, "Guns or Money," BJPS 2018

library(reshape2)
library(network)
library(sna)
library(RSiena)
library(ggplot2)
library(gdata)
library(countrycode)
library(gdata)

rm(list=ls(all=TRUE))

## Set this to wherever the BJPS-replication folder is located
dir <- "YourDirectoryHere/BJPS-replication"

setwd(paste(dir, "/Data", sep=""))

## Import the network and monadic data in two separate objects
nets.total <- read.csv("01.networks", header=TRUE, row.names=1)
mons.total <- read.csv("02.monadic", header=TRUE, row.names=1)

## Set some parameters
yr <- sort(unique(mons.total$year))
yr.lo <- yr[-length(yr)]

## List of names against which all data must be sorted. Also use this
## to build an empty matrix, i.e., for merging data
id <- sort(unique(mons.total$ccode1))
n <- length(id)
emat <- matrix(NA, length(id), length(id), dimnames=list(id,id))

#########################################################
## Start with the DVs, i.e., DCA and loan data
#########################################################

## Make an empty composition file. We'll fill this in as we
## loop over each year of data.
comp <- rep(list(c(1,length(yr))),length(id))
names(comp) <- id

for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","dca")]
    net <- acast(net, ccode1~ccode2, value.var="dca")
    ## Update the composition file as needed
    miss <- setdiff(id,rownames(net))
    for ( z in miss ) { # Move entry up by one if state not present in this year
        comp[[paste(z)]][1] <- sm + 1
    }; rm(z)
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("DCA.NET.", jj, sep=""), out)
    rm(net,out,miss)
    objs[sm] <- paste("DCA.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("DCAs.NET", sep=""), lapply(objs,get))
names(DCAs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^DCA.NET."))

## Now the loan matrices
for (jj in yr) {
    if ( jj == yr[1] ) {
        sm <- 1
        objs <- vector()
    }
    net <- nets.total[nets.total$year==jj,c("ccode1","ccode2","loan")]
    net <- acast(net, ccode1~ccode2, value.var="loan")
    out <- emat
    out[rownames(out) %in% rownames(net), colnames(out) %in% colnames(net)] <- net
    ## Order rows/columns
    out <- out[order(id),order(id)]
    ## Rename
    assign(paste("LOAN.NET.", jj, sep=""), out)
    rm(net,out)
    objs[sm] <- paste("LOAN.NET.", jj, sep="")
    sm <- sm + 1
}; rm(jj)
assign(paste("LOANs.NET", sep=""), lapply(objs,get))
names(LOANs.NET) <- objs
rm(objs,sm)
rm(list = ls(pattern = "^LOAN.NET."))

#########################################################
## Then do all the covariates for both networks
#########################################################

## Names of dyadic and monadic covariates
d.cons <- names(nets.total)[ !names(nets.total) %in% c("ccode1","ccode2","year","dca","loan") ]
m.cons <- names(mons.total)[ !names(mons.total) %in% c("ccode1","year") ]

## Set the monadic covariates as NxK matrices, where K is number of years. Remember to
## subtract the last year for RSiena estimation.
for (k in 1:length(m.cons)) {
    out <- matrix(nrow=length(id),ncol=0)
    rownames(out) <- id
    for (i in yr.lo) {
        tmp <- as.matrix(mons.total[mons.total$year==i,c(m.cons[k])])
        rownames(tmp) <- mons.total[mons.total$year==i,]$ccode1
        ## Bind on row names
        out <- cbind(out, tmp[match(rownames(out),rownames(tmp))])
        rm(tmp)
    }; rm(i)
    colnames(out) <- yr.lo
    out <- out[order(id),]
    assign(paste(m.cons[k],sep=""), out)
    rm(out)
}; rm(k)

## Save dyadic covariates as lists of matrices
for (k in 1:length(d.cons)) {
    for (i in yr.lo) {
        cov <- nets.total[nets.total$year==i, c("ccode1","ccode2",d.cons[k])]
        ## Here's the adjacency matrix
        cov <- acast(cov, ccode1~ccode2, value.var=d.cons[k])
        out <- emat
        ## Add cov data to the full matrix with all actors
        out[rownames(out) %in% rownames(cov), colnames(out) %in% colnames(cov)] <- cov
        diag(out) <- 0
        ## Order rows/columns
        out <- out[order(id),order(id)]
        assign(paste(d.cons[k], i, sep=""), out)
        rm(out,cov)
    }; rm(i)
    out.list <- lapply(paste(d.cons[k], yr.lo, sep=""), get)
    names(out.list) <- paste(d.cons[k], yr.lo, sep="")
    assign(paste(d.cons[k], sep=""), out.list)
    rm(out.list, list=paste(d.cons[k], yr.lo, sep=""))
}; rm(k)

####################################
## Convert objects to RSiena objects
####################################

yrhi <- yr
yrlo <- yr.lo
nlo <- length(yrlo)
nhi <- length(yrhi)
N <- n

## Dependent networkS
assign("dcas.net", sienaNet(array(do.call("c", DCAs.NET), dim=c(N,N,nhi))))
assign("loans.net", sienaNet(array(do.call("c", LOANs.NET), dim=c(N,N,nhi))))

## Changing dyadic covariates, omitting the constant ones
dyad.effects <- d.cons[ !d.cons %in% c("colony","lndistance") ]
for (x in dyad.effects) {
    assign(paste(x, ".net", sep=""), varDyadCovar(array(do.call("c", get(x)), dim=c(N,N,nlo))))
}; rm(x)

## Constant dyadic covariates
for (x in d.cons[ d.cons %in% c("colony","lndistance")]) {
    assign(paste(x, ".net", sep=""), coDyadCovar(get(x)[[nlo]]))
}

## Monadic covariates
monad.effects <- m.cons
for (x in monad.effects) {
    assign(paste(x, ".net", sep=""), varCovar(get(x)))
}; rm(x)

## Set the composition change object
changes <- sienaCompositionChange(comp)

## Create an RSiena network object
netdata <- sienaDataCreate(
    dcas.net,
    loans.net,

    colony.net,
    lndistance.net,
    alliance.noNATO.net,
    affinity.net,
    NATO.net,
    NATO.PfP.net,
    lntrade.net,
    mutual.enemy.net,
    arms.match.net,

    alliance.net,
    lnimports.net,
    lnexports.net,

    polity.net,
    lnGDPcap.net,
    lnCINC.net,
    terrorism.net,

    credit.net,
    lnOil.net,
    lnExposure.net,
    crisis.debt.net,
    crisis.bank.net,
    crisis.credit.net,
    current.balance.net,
    borrow.multi.net,
    borrow.private.net,
    lend.multi.net,

    changes
    )

eff <- getEffects(netdata)

## Loan network equation first
d.loans <- paste(
    c("affinity","lndistance","colony",
      "alliance","lnimports","lnexports"
      ),
    ".net", sep=""
    )
m.loans_i <- paste(
    c("current.balance","lend.multi","lnGDPcap"),
    ".net", sep=""
    )
m.loans_j <- paste(
    c("credit","corrupt","lnGDPcap","lnOil",
      "lnExposure","crisis.debt","crisis.bank","crisis.credit",
      "current.balance","borrow.multi","borrow.private"),
    ".net", sep=""
    )

for (x in d.loans) { # Dyadic effects
    eff <- includeEffects(eff, X, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_j) { # Monadic effects for debtors
    eff <- includeEffects(eff, altX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.loans_i) { # Monadic effects for creditors
    eff <- includeEffects(eff, egoX, name="loans.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Do a political similarity measure
eff <- includeEffects(eff, simX, name="loans.net", interaction1="polity.net", include=T, type="eval")

## Endogenous loan network effects
eff <- includeEffects(eff, transTrip, name="loans.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, inPopSqrt, name="loans.net", include=T, type="eval")
eff <- includeEffects(eff, outActSqrt, name="loans.net", include=T, type="eval")
## Set reciprocity at an arbitrarily low value
eff <- setEffect(eff, recip, name="loans.net", initialValue=-99)
eff <- includeEffects(eff, recip, name="loans.net", include=T, fix=T, test=F, type="eval")

## Now the DCA network equation
d.dcas <- paste(
    c("arms.match","mutual.enemy","affinity","lntrade",
      "NATO","NATO.PfP","alliance.noNATO",
      "lndistance","colony"),
    ".net", sep=""
    )

m.dcas <- paste(
    c("polity","lnCINC","terrorism","lnGDPcap"),
    ".net", sep=""
    )

for (x in d.dcas) { # Dyadic covariates
    eff <- includeEffects(eff, X, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

for (x in m.dcas) { # Monadic covariates
    eff <- includeEffects(eff, altX, egoXaltX, name="dcas.net", interaction1=x, include=T, type="eval")
}; rm(x)

## Endogenous DCA network effects
eff <- includeEffects(eff, transTriads, name="dcas.net", include=F, type="eval")
eff <- includeEffects(eff, transTies, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, inPop, name="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, isolateNet, name="dcas.net", include=T, type="eval")

## Now specify the cross-network effects
## Always include the basic cross-products
eff <- includeEffects(eff, crprod, name="loans.net", interaction1="dcas.net", include=T, type="eval")
eff <- includeEffects(eff, crprod, name="dcas.net", interaction1="loans.net", include=T, type="eval")

## Add in higher order cross-network effects
eff <- includeEffects(eff, outPopIntn, JinMix, name="dcas.net",
                      interaction1="loans.net", include=T, type="eval")
eff <- includeEffects(eff, to, inPopIntn, name="loans.net",
                      interaction1="dcas.net", include=T, type="eval")

## Estimate some models
dir.create(paste(dir, "/Output", sep=""))
setwd(paste(dir, "/Output", sep=""))

tm <- Sys.time()
model <- sienaAlgorithmCreate(useStdInits=T, projname="Estimates.main",
                              nsub=5, n3=3000, maxlike=F, modelType=3)
print01Report(netdata, modelname="Report.main")

output <- siena07(model,data=netdata,effects=eff,batch=TRUE,
                  verbose=FALSE,useCluster=TRUE,nbrNodes=2,returnDeps=FALSE)

## Save RSiena estimation object
save(output, file="output.main")
xtable(output, file="MainEstimates.tex", type="latex", digits=3)

keep(dir, sure=TRUE)








############################################
## Use above estimates to make a forest plot
############################################

library(ggplot2)
library(grid)
library(gridExtra)

setwd(paste(dir, "/Output", sep=""))
load("output.main")

dir.create(paste(dir, "/Figures", sep=""))
setwd(paste(dir, "/Figures", sep=""))

out <- cbind(output$theta,output$se)
rownames(out) <- output$effects$effectName

## First do loans equation
out.loans <- out[grep("loans.net:",rownames(out)),]
for (i in 1:nrow(out.loans)) { # Rescale means and SEs for forest plot
    ad <- 0.5 / out.loans[i,2]
    out.loans[i,1] <- out.loans[i,1] * ad
    out.loans[i,2] <- out.loans[i,2] * ad
    rm(ad)
}; rm(i)
## Don't need to plot density or reciprocity
out.loans <- out.loans[-c(1,2),]

## Label rows and put everything in a data frame for ggplot
loan.names <- c("Transitivity","Indegree (j)","Outdegree (j)","Former colony",
                "Distance","UNGA affinity","Alliance","Bilateral imports",
                "Bilateral exports","Polity similarity","GDP/cap (j)",
                "GDP/cap (i)","Credit rating (j)","Oil reserves (j)","Exposure (j)",
                "Debt crisis (j)","Banking crisis (j)","Currency crisis (j)",
                "Current account (j)","Current account (i)","Multi. propensity (j)",
                "Priv. propensity (j)","Multi. propensity (i)","DCA bilateral",
                "DCA degree (j)","DCA closure")
dloan <- data.frame(
    nms=loan.names,
    x=out.loans[,1],
    xlo=(out.loans[,1] - (1.96 * out.loans[,2])),
    xhi=(out.loans[,1] + (1.96 * out.loans[,2]))
    )
p.cols <- vector()
for (ii in 1:nrow(dloan)) {
    if (dloan[ii,"xlo"] < 0 && dloan[ii,"xhi"] > 0) {
        p.cols[ii] <- "#d7191c" # Color for significant estimates
    } else {
        p.cols[ii] <- "#2c7bb6" # Color for insignificant estimates
    }
}; rm(ii)
dloan$p.cols <- p.cols
dloan <- dloan[ c(2,3,1, 7, 5,4, 6, 10, 15, 14, 8, 9, 17, 16,
                  18, 13, 22, 21, 19, 11, 23, 20, 12,  26,25,24), ]

marg <- c(0.1,0.5,0.1,0)

p1 <- ggplot(dloan) + geom_hline(yintercept=0, lty=2) +
    geom_linerange(mapping=aes(x=seq(1,nrow(dloan)), ymin=xlo, ymax=xhi), color=dloan$p.cols, linetype=1, size=1, alpha=0.5) +
    geom_point(mapping=aes(y=x, x=seq(1,nrow(dloan))), size=3, shape=16, color=dloan$p.cols) +
    scale_x_continuous(breaks=seq(1:nrow(dloan)), labels=as.character(dloan$nms)) +
    xlab("") + ylab("Rescaled estimates + 95% CIs") + ggtitle("Loan Equation") + coord_flip() + 
    theme(
        panel.grid.minor.y=element_blank(),
        axis.text.y=element_text(color="black"),
        plot.margin=unit(marg,"cm"),
        plot.title = element_text(hjust = 0.5)
        )

## Add black rectangle for key estimates
p1 <- p1 + geom_rect(ymin=-Inf,ymax=Inf,xmin=seq(1,nrow(dloan))[26]+0.5,xmax=seq(1,nrow(dloan))[24]-0.5,fill=NA, linetype=1, color="black", size=0.25)

pdf("LoanEstimates.pdf",width=6,height=8,paper="special")
par(mar=c(0,0,0,0))
plot(p1)
dev.off()

rm(dloan,loan.names,marg,out.loans,p1,p.cols)

## Then do DCAs equation
out.dca <- out[grep("dcas.net:",rownames(out)),]
for (i in 1:nrow(out.dca)) { # Rescale
    ad <- 0.5 / out.dca[i,2]
    out.dca[i,1] <- out.dca[i,1] * ad
    out.dca[i,2] <- out.dca[i,2] * ad
    rm(ad)
}
## No need to plot density
out.dca <- out.dca[-1,]

## Label rows and put everything in a data frame for ggplot
dca.names <- c("Transitivity","Degree (j)","Isolate","Former colony","Distance",
               "Alliance (non-NATO)","UNGA affinity","NATO members","NATO-PfP members",
               "Bilateral trade","Common enemy","Arms trade match","Polity (i)",
               "Pol. x pol.","GDP/capita (i)","GDP x GDP","CINC (i)","CINC x CINC",
               "Terrorism (i)","Terr. x Terr.","Loan bilateral","Loan outdegree (j)",
               "Loan similarity")
ddca <- data.frame(
    nms=dca.names,
    x=out.dca[,1],
    xlo=(out.dca[,1] - (1.96 * out.dca[,2])),
    xhi=(out.dca[,1] + (1.96 * out.dca[,2]))
    )
p.cols <- vector()
for (ii in 1:nrow(ddca)) {
    if (ddca[ii,"xlo"] < 0 && ddca[ii,"xhi"] > 0) {
        p.cols[ii] <- "#d7191c" # Color for significant estimates
    } else {
        p.cols[ii] <- "#2c7bb6" # Color for insignificant estimates
    }
}; rm(ii)
ddca$p.cols <- p.cols
ddca <- ddca[c(2,1,3,seq(20,4),23,22,21),]

marg <- c(0.1,0.5,0.1,0)

p2 <- ggplot(ddca) + geom_hline(yintercept=0, lty=2) +
    geom_linerange(mapping=aes(x=seq(1,nrow(ddca)), ymin=xlo, ymax=xhi), color=ddca$p.cols, linetype=1, size=1, alpha=0.5) +
    geom_point(mapping=aes(y=x, x=seq(1,nrow(ddca))), size=3, shape=16, color=ddca$p.cols) +
    scale_x_continuous(breaks=seq(1:nrow(ddca)), labels=as.character(ddca$nms)) +
    xlab("") + ylab("Rescaled estimates + 95% CIs") + ggtitle("DCA Equation") + coord_flip() + 
    theme(
        panel.grid.minor.y=element_blank(),
        axis.text.y=element_text(color="black"),
        plot.margin=unit(marg,"cm"),
        plot.title = element_text(hjust = 0.5)
        )

## Add black rectangle for key estimates
p2 <- p2 + geom_rect(ymin=-Inf,ymax=Inf,xmin=seq(1,nrow(ddca))[23]+0.5,xmax=seq(1,nrow(ddca))[21]-0.5,fill=NA, linetype=1, color="black", size=0.25)

pdf("DCAEstimates.pdf",width=6,height=8,paper="special")
par(mar=c(0,0,0,0))
plot(p2)
dev.off()
