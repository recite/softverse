## These files replicate the results from Kinne & Bunte, “Guns or Money? Defense 
## Cooperation and Bilateral Lending as Coevolving Networks,” British Journal of 
## Political Science, 2018.
##
## Note that the replication materials do not include the data for bilateral loans, as
## the World Bank does not permit these data to be distributed to third parties. In
## order to replicate the results from the paper, the bilateral loan data must be
## obtained from the Debtor Reporting System (DRS) of the World Bank. Instructions
## for obtaining the data can be found at the following link: http://siteresources.
## worldbank.org/DATASTATISTICS/Resources/DRS_dissemination_policy.doc. Refer to 
## DRS Job #48154 when requesting these data. 
##
## Note that, according to DRS policy, “requests from other scholars to access the data 
## for the purposes of validating or critiquing results will be looked on favorably.”
## Once acquired, the DRS loan data must be merged with the 01.networks data file,
## which is a standard R data frame. Once the data have been merged, name the
## resulting column in the data frame “loans,” and the replication files should then
## run without problems.



