rm(list = ls())

#set directory
#path/to/replication/file
setwd('/path/to/this/replication/file/knw_bjps_replication_file')

###########################
#Build directory structure#
###########################

source('./make_directory.R')

#Make folders, if needed
files = c('./output/descriptives', './output/figures', './output/tables')
for (f in files) {
  if (!dir.exists(f)) {dir.create(f, recursive = T)}
}

#Required packages
require(data.table)
require(magrittr)
require(foreign)
require(igraph)
require(stringr)
require(MASS)
require(multiwayvcov)
require(lmtest)
require(stargazer)
require(Exact)
require(Matching)
require(ggplot2)
require(ri)
require(nnet)
require(psych)
require(grid)
require(gridExtra)
require(lfe)
require(sandwich)
require(interflex)
require(dplyr)
require(zoo)
require(parallel)

#Load custom functions
source('./scripts/functions.R')

###############
###############
##Create Data##
###############
###############

#Run scripts to create election, violence, and balance data
###########################################################
source('./scripts/make/make_elections_data.R')
source('./scripts/make/make_violence_data.R')

#The following files produce the analysis data from the raw PODES data (not included)
#source('./scripts/make/make_podes_data.R')
#source('./scripts/make/make_pretreat_podes_data.R')

#This loads the prepared PODES data
podes_dapil = fread('./data/PODES/podes_main_analysis.csv')
podes_dapil_balance = fread('./data/PODES/podes_balance_analysis.csv')

source('./scripts/make/make_ifls_data.R')
source('./scripts/make/make_fractionalization_data.R')

#Prepare for merging election and outcome data
##############################################

#Election data: Create seat proportions
dapil_elections_all[, dapil_number := str_extract(dapil, "\\d$")]
dapil_elections_all[, frac_IC := all_IC_seats / dapil_seats]
dapil_elections_all[, frac_IT := all_IT_seats / dapil_seats]
dapil_elections_all[, frac_ICIT := all_ICIT_seats / dapil_seats]

#Indicators for estimation samples
dapil_elections_all[, sample_ni_it := (bw <= 0.01) & (NI_close) & (IT_close)]
dapil_elections_all[, sample_ni_icit := (bw <= 0.01) & (NI_close) & (ICIT_close)]
dapil_elections_all[, sample_ni_ic := (bw <= 0.01) & (NI_close) & (IC_close)]
dapil_elections_all[, sample_ic_it := (bw <= 0.01) & (IC_close) & (IT_close)]


#NVMS violence data
nvms_dapil[, dapil_number := str_extract(dapil, '\\d$')]
nvms_dapil[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

nvms_dapil_daily[, dapil_number := str_extract(dapil, '\\d$')]
nvms_dapil_daily[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

nvms_dapil_placebo[, dapil_number := str_extract(dapil, '\\d$')]
nvms_dapil_placebo[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

#Podes post-treatment data
podes_dapil[, dapil_number := str_extract(dapil, '\\d$')]
podes_dapil[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

#Podes pre-treatment data
podes_dapil_balance[, dapil_number := str_extract(dapil, '\\d$')]
podes_dapil_balance[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

#Survey data
ifls_dapil[, dapil_number := str_extract(dapil, '\\d$')]
ifls_dapil[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

ifls_l_dapil[, dapil_number := str_extract(dapil, '\\d$')]
ifls_l_dapil[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

#Fractionalziation pre-treatment data
frac_dapil_balance[, dapil_number := str_extract(dapil, '\\d$')]
frac_dapil_balance[is.na(dapil_number), dapil_number := str_extract(dapil, '(?<=-)[A-C]$')]

#Merge analysis data
####################
setkey(podes_dapil, id_kab, dapil_number, election_cycle)
setkey(podes_dapil_balance, id_kab, dapil_number, election_cycle)
setkey(nvms_dapil, id_kab, dapil_number, election_cycle)
setkey(nvms_dapil_daily, id_kab, dapil_number, election_cycle)
setkey(nvms_dapil_placebo, id_kab, dapil_number, election_cycle)
setkey(ifls_dapil, id_kab, dapil_number, election_cycle)
setkey(ifls_l_dapil, id_kab, dapil_number, election_cycle)
setkey(frac_dapil_balance, id_kab, dapil_number, election_cycle)

setkey(dapil_elections_all, kab_code, dapil_number, election_cycle)

#NVMS
mergedTable_nvms = nvms_dapil[dapil_elections_all]
mergedTable_nvms[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_nvms = mergedTable_nvms %>% unique

#NVMS Daily
mergedTable_nvms_daily = nvms_dapil_daily[dapil_elections_all]
mergedTable_nvms_daily[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_nvms_daily = mergedTable_nvms_daily %>% unique


#NVMS Placebo
mergedTable_nvms_placebo = nvms_dapil_placebo[dapil_elections_all]
mergedTable_nvms_placebo[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_nvms_placebo = mergedTable_nvms_placebo %>% unique


#PODES post-treatment
mergedTable_podes = podes_dapil[dapil_elections_all]
mergedTable_podes[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_podes = mergedTable_podes %>% unique

#PODES pre-treatment
mergedTable_podes_balance = podes_dapil_balance[dapil_elections_all]
mergedTable_podes_balance[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_podes_balance = mergedTable_podes_balance %>% unique

#Surveys
mergedTable_ifls = dapil_elections_all[ifls_dapil]
mergedTable_ifls[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]

mergedTable_ifls_l = dapil_elections_all[ifls_l_dapil]
mergedTable_ifls_l[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]

#Fractionalization pre-treatment
mergedTable_frac_balance = frac_dapil_balance[dapil_elections_all]
mergedTable_frac_balance[, c('i.kabupaten', 'i.dapil') := list(NULL) %>% rep(2)]
#Remove repeated dapils
mergedTable_frac_balance = mergedTable_frac_balance %>% unique


#Index for dapils with NVMS data
nvms_j = mergedTable_nvms[!is.na(NVM_Violence_1_count), list(id_kab, dapil_number, election_cycle)]
nvms_prov = mergedTable_nvms[!is.na(NVM_Violence_1_count), id_prov %>% unique]

setkey(mergedTable_podes, id_kab, dapil_number, election_cycle)
mergedTable_podes[, nvms_sample := F]
mergedTable_podes[J(nvms_j), nvms_sample := T]

dapil_elections_all[, id_prov := str_extract(kab_code, "^\\d{2}")]
dapil_elections_all[, nvms := id_prov %in% nvms_prov]

######################
######################
##Figures and Tables##
######################
######################

#########
#Table 1#
#########

source("./scripts/analyses/table_1.R")

#########
#Table 2#
#########

source("./scripts/analyses/table_2.R")

##########
#Figure 1#
##########

source("./scripts/analyses/figure_1.R")


#############################################
#############################################
##Supplementary Appendix Figures and Tables##
#############################################
#############################################

###########
#Figure C1#
###########

source("./scripts/analyses/figure_c1.R")

##################
#Figures D1 to D5#
##################

source("./scripts/analyses/figures_d1_to_d5.R")

##########
#Table D2#
##########

source("./scripts/analyses/table_d2.R")

##########
#Table E1#
##########

source("./scripts/analyses/table_e1.R")

##########
#Table E2#
##########

source("./scripts/analyses/table_e2.R")

##########
#Table E3#
##########

source("./scripts/analyses/table_e3.R")

##########
#Table E4#
##########

source("./scripts/analyses/table_e4.R")

###########
#Figure E1#
###########

source("./scripts/analyses/figure_e1.R")

##########
#Table E5#
##########

source("./scripts/analyses/table_e5.R")

###################
#Figures E2 and E3#
###################

source("./scripts/analyses/figures_e2_e3.R")

##########
#Table E6#
##########

source("./scripts/analyses/table_e6.R")

###########
#Figure E4#
###########

#Produced by "./scripts/make/make_violence_data.R"

##########
#Table E7#
##########

source('./scripts/analyses/table_e7.R')

##################
#Tables E8 and E9#
##################

source('./scripts/analyses/tables_e8_e9.R')


###################
#Figures E5 to E9##
###################

source("./scripts/analyses/figures_e5_to_e9.R")

############
#Figure E10#
############

source("./scripts/analyses/figure_e10.R")

##################
#Tables C2 and D1#
##################

source("./scripts/analyses/tables_c2_d1.R")
