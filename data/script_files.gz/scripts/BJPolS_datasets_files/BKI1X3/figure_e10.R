#Get objects
old_ws = ls()

#Sharia Laws
sharia_laws = fread('./data/sharia_laws/kabs_sharia_laws_011218.csv', header = T) %>% 
  melt.data.table(id.vars= c('kabupaten', 'province', 'kab_code'))
sharia_laws[is.na(value), value := 0]
sharia_laws[variable %in% 2005:2009, election_cycle := 2004]
sharia_laws[variable %in% 2010:2013, election_cycle := 2009]
sharia_law_kab_cycle = sharia_laws[, list(any_sharia = sum(value) > 0,
                                          count_sharia = sum(value)),
                                   by = list(kab_code, election_cycle)] %>% .[!is.na(election_cycle)]

#Religious composition:
census_2010 = fread("./data/census_2010_diversity/religious_diversity_census_2010.csv")
census_2010 = census_2010[, list(kab_code, muslim_pct = islam/total)]

#Kabupaten election data
kabupaten_elections = mergedTable_podes_balance[, list(
  total_seats = sum(dapil_seats, na.rm = T),
  total_it_wins = sum(all_IT_seats, na.rm = T),
  total_close_it_seats = sum(sample_ni_it, na.rm = T),
  total_close_it_wins = sum(sample_ni_it & IT_win, na.rm = T),
  total_ic_wins = sum(all_IC_seats, na.rm = T),
  total_close_ic_seats = sum(sample_ni_ic, na.rm = T),
  total_close_ic_wins = sum(sample_ni_ic & IC_win, na.rm = T),
  total_icit_wins = sum(all_ICIT_seats, na.rm = T),
  total_close_icit_seats = sum(sample_ni_icit, na.rm = T),
  total_close_icit_wins = sum(sample_ni_icit & ICIT_win, na.rm = T)
)
, by = list(id_kab, election_cycle)]

kabupaten_elections[, paste0(c('it', 'ic', 'icit'), "_seat_pct") := lapply(.SD, function(x) x / kabupaten_elections[['total_seats']]), .SDcols = paste0("total_",c('it', 'ic', 'icit'),"_wins")]

#Merge tables
setkey(sharia_law_kab_cycle, kab_code, election_cycle)
setkey(kabupaten_elections, id_kab, election_cycle)
setkey(census_2010, kab_code)

shariaTable = sharia_law_kab_cycle[kabupaten_elections]

setkey(shariaTable, kab_code, election_cycle)

shariaTable = census_2010[shariaTable]


#Create figure groups
shariaTable[, high_islamist := ifelse(it_seat_pct > median(it_seat_pct, na.rm = T), "High Islamist", "Low Islamist")]
shariaTable[, high_mosque_pc := ifelse(muslim_pct > median(muslim_pct, na.rm = T), "High % Muslim", "Low % Muslim")]
shariaTable[, group := paste(high_islamist, high_mosque_pc, sep = "/\n")]
meanNA = function(x) {mean(x, na.rm = T)}
plot_data = dcast.data.table(shariaTable[!is.na(high_islamist) & !is.na(high_mosque_pc)], 
                              high_islamist + high_mosque_pc ~ ., 
                             fun= list(meanNA, meanNA, length), 
                             value.var = list('count_sharia', 'any_sharia', 'kab_code')) %>%
            melt.data.table(measure.vars = c('count_sharia_meanNA', 'any_sharia_meanNA'))

plot_data[, group := paste(high_islamist, high_mosque_pc, sep = "/\n")]

plot_data[, variable := ifelse(variable == 'count_sharia_meanNA', "Count", "Any")]
plot_data[, `Sharia Laws` := variable]
plot_data[, Frequency := value]

pdf("./output/figures/figure_e10.pdf", width = 6, height = 7)
p = ggplot(plot_data[variable %in% 'Any'], aes(x = group, y = Frequency, fill = `Sharia Laws`)) + 
  geom_bar(stat = 'identity', position = position_dodge()) +
  theme_bw() + xlab("District Type") + 
  geom_text(aes(label = kab_code_length), position = position_fill(vjust= -0.05), alpha = rep(1,4)) + 
  theme(legend.position="bottom") + ylab("Fraction with Any Sharia Law")
print(p)
dev.off()