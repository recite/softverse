

# 07-05-2021
# REPLICATION FILES

# Commodity shocks and incumbency effects - Novaes & Schiumerini

#This file replicates the following tables:

# Main text tables: 1, 2, 7

# Appendix tables: S.I.3, 4, 5, 7, 8, 9 

# You should Restart R before anything

# These scripts have been run in the following system and R version:

# platform       x86_64-apple-darwin17.0     
# arch           x86_64                      
# os             darwin17.0                  
# system         x86_64, darwin17.0          
# status                                     
# major          4                           
# minor          0.2                         
# year           2020                        
# month          06                          
# day            22                          
# svn rev        78730                       
# language       R                           
# version.string R version 4.0.2 (2020-06-22)
# nickname       Taking Off Again   


#### MAIN TEXT Tables: T1, T2, T7

#these are the packages
required_packages = c('estimatr','data.table','plm','apsrtable','stargazer','rdrobust','multiwayvcov','lmtest')
lapply(required_packages, require, character.only = TRUE)


rm(list = ls())
library(estimatr)
# library(reshape2)
library(data.table)
library(plm)
library(apsrtable)
library(stargazer)
library(rdd)
library(rdrobust)
library(multiwayvcov)
library(lmtest)


setwd(dir = '.') # Please insert folder where files are stored

load("replication_data.RData")

# Study Group Selection ----

rd <- setDT(subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0)) 
# ineligible2 == 0 removes municipalities with incumbents that would be term-limited at t+1 if they win at t

# Global options for robust RDD ----

ker = 'triangular' # kernel
selection = 'mserd' #bandwidth selection uses mserd for all estimations with mayoral candidates or municipal-level estimations

# Get non-parametric bandwidth ----

bw <- rdbwselect(rd$f_elected,rd$margin, bwselect = selection)
bw = bw$bws[[2]] # conventional bandwidth
rdbw <- subset(rd, abs(margin) < bw) # subsets data to only include candidates within the optimal bandwidth
rd2 <- subset(rd, abs(margin) < 2.5/100) # subsets data to only include candidates within the 2.5% margin  

# Table 1: Placebo test: Future price volatility and past incumbency effects ----

weights <- kernelwts(rd$margin,center = 0,bw = 1, kernel= ker)
placebo.all <- lm(f_elected ~ I(inflation_placebo*elected) + inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year),data=rd, weights = weights)
vcov_both <- cluster.vcov(placebo.all, cbind(rd$muni_code))
placebo.all.coeftest <- coeftest(placebo.all, vcov_both)

weights <- kernelwts(rdbw$margin, center = 0, bw = bw, kernel= ker)
placebo.bw  <- lm(f_elected ~ I(inflation_placebo*elected) + inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(placebo.bw, cbind(rdbw$muni_code))
placebo.bw.coeftest <- coeftest(placebo.bw, vcov_both)

weights <- kernelwts(rd2$margin,center = 0, bw = 0.025, kernel= ker)  
placebo.2.5 <- lm(f_elected ~ I(inflation_placebo*elected) + inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year),data=rd2)
vcov_both <- cluster.vcov(placebo.2.5, cluster = cbind(rd2$muni_code))
placebo.2.5.coeftest = coeftest(placebo.2.5, vcov_both)

stargazer(placebo.all.coeftest, placebo.bw.coeftest, placebo.2.5.coeftest,
          stars='default',
          digits=4,type='text',
          keep.stat = 'n',
          add.lines = list(c("Bandwidth", "All","Optimal","2.5\\%"),
                           c("Year FEs","Yes","Yes","Yes"),
                           c("n",placebo.all$df.residual, placebo.bw$df.residual, placebo.2.5$df.residual)),
          omit = c('year'),
          label = 'main table',
          dep.var.caption = 'Prob. Win Next Election',
          title = 'Placebo test: Future price volatility and past incumbency effects',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))

# Table 2. Incumbency Effects Conditional on Municipal Price Index ---- 

# Includes all municipalities

weights <- kernelwts(rd$margin, center = 0, bw = 1, kernel = ker)
overall.all <- lm(f_elected ~ I(inflation*elected) + inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd, weights = weights)
vcov_both <- cluster.vcov(overall.all, cbind(rd$muni_code))
overall.all.coeftest <- coeftest(overall.all, vcov_both)

weights <- kernelwts(rdbw$margin, center = 0, bw = bw, kernel = ker)
overall.bw  <- lm(f_elected ~ I(inflation*elected) + inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(overall.bw, cbind(rdbw$muni_code))
overall.bw.coeftest <- coeftest(overall.bw, vcov_both)

weights <- kernelwts(rd2$margin, center = 0, bw = 0.025, kernel = ker)
overall.2.5 <- lm(f_elected ~ I(inflation*elected) + inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd2, weights = weights)
vcov_both <- cluster.vcov(overall.2.5, cluster = cbind(rd2$muni_code,rd2$year))
overall.2.5.coeftest = coeftest(overall.2.5, vcov_both)

# rural study group

rd.rural <- rd[ruralPop > median(rd$ruralPop,na.rm=TRUE)] #subsets municipalities above median value of rural population
bw.r <- rdbwselect(rd.rural$f_elected,rd.rural$margin, bwselect = selection, kernel = ker)
bw.r = bw.r$bws[[2]]

rd2.r   <-  subset(rd.rural,abs(margin)<2.5/100)
rdbw.r  <-  subset(rd.rural,abs(margin)<bw.r)

# urban study group
rd.urban <- rd[ruralPop < median(rd$ruralPop,na.rm=TRUE)]
bw.u <- rdbwselect(rd.urban$f_elected,rd.urban$margin, bwselect = selection, kernel = ker)
bw.u = bw.u$bws[[2]]

rd2.u   <-  subset(rd.urban,abs(margin)<2.5/100)
rdbw.u  <-  subset(rd.urban,abs(margin) < bw.u)

# rural estimations
weights <- kernelwts(rd.rural$margin, center = 0, bw = 1, kernel= ker)
rural.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year), data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(rural.all, cbind(rd.rural$muni_code))
rural.all.coeftest <- coeftest(rural.all, vcov_both)

weights <- kernelwts(rdbw.r$margin, center = 0, bw = bw.r, kernel= ker)
rural.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw.r, weights = weights)
vcov_both <- cluster.vcov(rural.bw, cbind(rdbw.r$muni_code))
rural.bw.coeftest <- coeftest(rural.bw, vcov_both)

weights <- kernelwts(rd2.r$margin,center = 0,bw = 0.025, kernel= ker)  
rural2.5    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd2.r)
vcov_both <- cluster.vcov(rural2.5, cbind(rd2.r$muni_code))
rural.2.5.coeftest <- coeftest(rural2.5, vcov_both)

# urban estimations
weights <- kernelwts(rd.urban$margin,center = 0,bw = 1, kernel= ker)
urban.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd.urban, weights = weights)
vcov_both <- cluster.vcov(urban.all, cbind(rd.urban$muni_code))
urban.all.coeftest <- coeftest(urban.all, vcov_both)

weights <- kernelwts(rdbw.u$margin,center = 0,bw = bw.u, kernel= ker)
urban.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year), data=rdbw.u, weights = weights)
vcov_both <- cluster.vcov(urban.bw, cbind(rdbw.u$muni_code))
urban.bw.coeftest <- coeftest(urban.bw, vcov_both)

weights <- kernelwts(rd2.u$margin, center = 0, bw = 0.025, kernel= ker)  
urban.2.5   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year), data=rd2.u)
vcov_both <- cluster.vcov(urban.2.5, cbind(rd2.u$muni_code))
urban.2.5.coeftest <- coeftest(urban.2.5, vcov_both)

# table

stargazer(overall.all.coeftest, overall.bw.coeftest,
          rural.all.coeftest, rural.bw.coeftest,
          urban.all.coeftest, urban.bw.coeftest,
          stars='default',
          digits = 3,type='text',keep.stat = 'n',
          add.lines = list(c("Bandwidth","All", "Optimal","All","Optimal","All","Optimal"),
                           c('Year FEs','Y','Y','Y','Y','Y','Y'),
                           c("n",
                             overall.all$df.residual, overall.bw$df.residual,
                             rural.all$df.residual, rural.bw$df.residual,
                             urban.all$df.residual, urban.bw$df.residual)),
          column.labels   = c("All", "All",'Rural', "Rural", "Urban", 'Urban'),
          omit = c('year'),
          dep.var.caption = 'Probability Win Next Election', dep.var.labels = '',
          label = 'ruralvsurban',
          title = 'Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))


# Table 7. Heterogeneous Incumbency Effects on Probability of Running ----

rd <- subset(retro, (year <2016 & year>2000)  & ineligible2==0)

bw <-rdbwselect(rd$f_try,rd$margin)
bw = bw$bws[[2]]

rd.rural <- subset(rd, ruralPop > median(ruralPop,na.rm=TRUE))
bwr <- rdbwselect(rd.rural$f_try , rd.rural$margin)
bwr = bwr$bws[[2]]

rd.urban <- subset(rd, ruralPop < median(ruralPop,na.rm=TRUE))
bwu <- rdbwselect(rd.urban$f_try , rd.urban$margin)
bwu = bwu$bws[[2]]

rdbw <- subset(rd,abs(margin) < bw)
rd.ruralbw <- subset(rd.rural, abs(margin) < bwr)
rd.urbanbw <- subset(rd.urban, abs(margin) < bwu)

weights <- kernelwts(rd$margin, center = 0 ,bw = 1, kernel="triangular")
f_try.all  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rd, weights = weights)
vcov_both <- cluster.vcov(f_try.all, cbind(rd$muni_code))
f_try.all.coeftest <- coeftest(f_try.all, vcov_both)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
f_try.all_optimal  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rdbw, weights = weights)
vcov_both <- cluster.vcov(f_try.all_optimal, cbind(rdbw$muni_code))
f_try.all.coeftest_optimal <- coeftest(f_try.all_optimal, vcov_both)

weights <- kernelwts(rd.rural$margin,center = 0,bw = 1, kernel="triangular")
f_try.rural  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rd.rural, weights = weights)
vcov_both <- cluster.vcov(f_try.rural, cbind(rd.rural$muni_code))
f_try.rural.coeftest <- coeftest(f_try.rural, vcov_both)

weights <- kernelwts(rd.ruralbw$margin, center = 0, bw = bwr, kernel="triangular")
f_try.rural_optimal  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rd.ruralbw, weights = weights)
vcov_both <- cluster.vcov(f_try.rural_optimal, cbind(rd.ruralbw$muni_code))
f_try.rural.coeftest_optimal <- coeftest(f_try.rural_optimal, vcov_both)

weights <- kernelwts(rd.urban$margin,center = 0, bw = 1, kernel="triangular")  
f_try.urban  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rd.urban)
vcov_both <- cluster.vcov(f_try.urban, cbind(rd.urban$muni_code))
f_try.urban.coeftest <- coeftest(f_try.urban, vcov_both)

weights <- kernelwts(rd.urbanbw$margin,center = 0, bw = bwu, kernel="triangular")  
f_try.urban_optimal  <- lm(f_try ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin)+as.factor(year),data = rd.urbanbw)
vcov_both <- cluster.vcov(f_try.urban_optimal, cbind(rd.urbanbw$muni_code))
f_try.urban.coeftest_optimal <- coeftest(f_try.urban_optimal, vcov_both)

# Table 7

stargazer(f_try.all.coeftest_optimal,
          f_try.rural.coeftest_optimal,
          f_try.urban.coeftest_optimal,
          stars='default',
          digits = 3,
          type='text',
          keep.stat = 'n',
          omit = 'year',
          add.lines = list(c("Group", "All","Rural","Urban"),
                           c("n",f_try.all_optimal$df.residual, f_try.rural_optimal$df.residual, f_try.urban_optimal$df.residual)),
          label = 'self-selection',
          dep.var.caption = 'Probability of Running Next Election', dep.var.labels = '',
          title = 'The Decision to Run for Re-Election Conditional on Municipal Price Index.',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))


# APPENDIX TABLES ----

# Table S.I.2. Placebo test: Future price variation and incumbency effects, rural municipalities

rd <- retro[(year <=2016 & year>2000)  & ineligible2==0 & ruralPop > median(retro$ruralPop,na.rm=TRUE)]
rd.rural <- rd[ruralPop > median(retro$ruralPop,na.rm=TRUE)]
bw.r <- rdbwselect(rd.rural$f_elected,rd.rural$margin)
bw.r = bw.r$bws[[2]]

rd2.r   <-  subset(rd.rural,abs(margin)<2.5/100)
rdbw.r  <-  subset(rd.rural,abs(margin)<bw.r)
ker = 'triangular'

# rural estimations
weights <- kernelwts(rd.rural$margin, center = 0, bw = 1, kernel= ker)
rural.all   <- lm(f_elected~I(inflation_placebo*elected)+inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year), data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(rural.all, cbind(rd.rural$muni_code))
rural.all.coeftest <- coeftest(rural.all, vcov_both)

weights <- kernelwts(rdbw.r$margin, center = 0, bw = bw.r, kernel= ker)
rural.bw    <- lm(f_elected~I(inflation_placebo*elected)+inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year),data=rdbw.r, weights = weights)
vcov_both <- cluster.vcov(rural.bw, cbind(rdbw.r$muni_code))
rural.bw.coeftest <- coeftest(rural.bw, vcov_both)

weights <- kernelwts(rd2.r$margin, center = 0, bw = 2.5/100, kernel= ker)
rural.b2    <- lm(f_elected~I(inflation_placebo*elected)+inflation_placebo+elected*margin+I(inflation_placebo*margin)+as.factor(year),data=rd2.r, weights = weights)
vcov_both <- cluster.vcov(rural.b2, cbind(rd2.r$muni_code))
rural.b2.coeftest <- coeftest(rural.b2, vcov_both)


stargazer(rural.all.coeftest, rural.bw.coeftest, rural.b2.coeftest,
          stars='default',
          digits = 3,type='text',keep.stat = 'n',
          add.lines = list(c("Bandwidth","All", "Optimal","2.5\\%"),
                           c('Year FEs','Y','Y','Y','Y','Y','Y'),
                           c("n",
                             rural.all$df.residual, rural.bw$df.residual, rural.b2$df.residual)),
          #column.labels   = c("All", "All",'Rural', "Rural", "Urban", 'Urban'),
          omit = c('year'),
          dep.var.caption = 'Probability Win Next Election', dep.var.labels = '',
          label = 'ruralplacebo',
          title = 'Placebo test: Future price variation and incumbency effects, rural municipalities',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))

# Table S.I.3. Heterogeneous Incumbency Effects Conditional on Municipal Price Index, All, Rural and Urban Municipalities (2.5%) ----

stargazer(overall.2.5.coeftest, 
          rural.2.5.coeftest,
          urban.2.5.coeftest,
          stars='default',
          digits = 3,type='text',keep.stat = 'n',
          add.lines = list(c("Bandwidth","2.5\\%","2.5\\%","2.5\\%"),
                           c('Year FEs','Y','Y','Y'),
                           c("n",overall.all$df.residual, overall.bw$df.residual,
                             rural.all$df.residual, rural.bw$df.residual,
                             urban.all$df.residual, urban.bw$df.residual)),
          column.labels   = c("All","Rural", 'Urban'),
          omit = c('year'),
          dep.var.caption = 'Probability Win Next Election', dep.var.labels = '',
          label = 'ruralvsurban',
          title = 'Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))




# Table S.I.4. Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities with controls ----

retro[, gdp_pc := gdp / pop]
retro[, pbf_pc := total_pbf_families / pop]
retro[, avg_age := mean(age), by = .(muni_code, year)]
retro[, avg_experience := mean(experience), by = .(muni_code, year)]
retro[, total_left := sum(leftwing), by = .(muni_code, year)]
retro[, total_cands := .N, by = .(muni_code, year)]

rd <- setDT(subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0))

ker = 'triangular' # kernel
selection = 'mserd' #bandwidth selection. cerrd returns rural optimal with more precision
# rural study group
rd.rural <- rd[ruralPop > median(rd$ruralPop,na.rm=TRUE)]
bw.r <- rdbwselect(rd.rural$f_elected,rd.rural$margin, bwselect = selection, kernel = ker)
bw.r = bw.r$bws[[2]]

rd2.r   <-  subset(rd.rural,abs(margin)<2.5/100)
rdbw.r  <-  subset(rd.rural,abs(margin)<bw.r)

# urban study group
rd.urban <- rd[ruralPop < median(rd$ruralPop,na.rm=TRUE)]
bw.u <- rdbwselect(rd.urban$f_elected,rd.urban$margin, bwselect = selection, kernel = ker)
bw.u = bw.u$bws[[2]]

rd2.u   <-  subset(rd.urban,abs(margin)<2.5/100)
rdbw.u  <-  subset(rd.urban,abs(margin) < bw.u)

# rural estimations
weights <- kernelwts(rd.rural$margin, center = 0, bw = 1, kernel= ker)
rural.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year) +
                    nonwhite*elected + gini*elected + avg_age*elected  + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected, 
                  data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(rural.all, cbind(rd.rural$muni_code))
rural.all.coeftest <- coeftest(rural.all, vcov_both)

weights <- kernelwts(rdbw.r$margin, center = 0, bw = bw.r, kernel= ker)
rural.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year) +
                    nonwhite*elected + gini*elected + avg_age*elected + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected,data=rdbw.r, weights = weights)
vcov_both <- cluster.vcov(rural.bw, cbind(rdbw.r$muni_code))
rural.bw.coeftest <- coeftest(rural.bw, vcov_both)

weights <- kernelwts(rd2.r$margin,center = 0,bw = 0.025, kernel= ker)  
rural2.5    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year)+
                    nonwhite*elected + gini*elected + avg_age*elected  + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected,data=rd2.r)
vcov_both <- cluster.vcov(rural2.5, cbind(rd2.r$muni_code))
rural2.5.coeftest <- coeftest(rural2.5, vcov_both)

# urban estimations
weights <- kernelwts(rd.urban$margin,center = 0,bw = 1, kernel= ker)
urban.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year)+
                    nonwhite*elected + gini*elected + avg_age*elected  + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected,data=rd.urban, weights = weights)
vcov_both <- cluster.vcov(urban.all, cbind(rd.urban$muni_code))
urban.all.coeftest <- coeftest(urban.all, vcov_both)

weights <- kernelwts(rdbw.u$margin,center = 0,bw = bw.u, kernel= ker)
urban.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year)+
                    nonwhite*elected + gini*elected + avg_age*elected  + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected, data=rdbw.u, weights = weights)
vcov_both <- cluster.vcov(urban.bw, cbind(rdbw.u$muni_code))
urban.bw.coeftest <- coeftest(urban.bw, vcov_both)

weights <- kernelwts(rd2.u$margin, center = 0, bw = 0.025, kernel= ker)  
urban.2.5   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year)+
                    nonwhite*elected + gini*elected + avg_age*elected  + avg_experience*elected + total_left*elected + total_cands*elected + pbf_pc*elected, data=rd2.u)
vcov_both <- cluster.vcov(urban.2.5, cbind(rd2.u$muni_code))
urban.2.5.coeftest <- coeftest(urban.2.5, vcov_both)

# table
stargazer(rural.all.coeftest,rural.bw.coeftest,rural2.5.coeftest,
          urban.all.coeftest,urban.bw.coeftest,urban.2.5.coeftest,
          stars='default',
          digits = 3,type='text',keep.stat = 'n',
          add.lines = list(c("Bandwidth","All", "Optimal", "2.5\\%","All","Optimal", "2.5\\%"),
                           c('Year FEs','Y','Y','Y','Y','Y','Y'),
                           c("n",rural.all$df.residual, rural.bw$df.residual, rural2.5$df.residual,
                             urban.all$df.residual, urban.bw$df.residual, urban.2.5$df.residual)),
          column.labels   = c("Rural", "Rural",'Rural', "Urban", "Urban", 'Urban'),
          omit = c('year'),
          dep.var.caption = 'Probability Win Next Election', dep.var.labels = '',
          label = 'ruralvsurban covariates',
          title = 'Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))

# Table S.I.5. Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities, alternative IBGE classification ----

rd <- subset(retro, (year < 2016 & year>2000) & ineligible2 == 0)

#rural study group
rd.rural <- rd[rural_ibge == 1]
bw.r <- rdbwselect(rd.rural$f_elected,rd.rural$margin, bwselect = 'mserd')
bw.r = bw.r$bws[[2]]

rdbw.r  <-  subset(rd.rural,abs(margin)<bw.r)

#urban study group
rd.urban <- rd[urban_ibge == 1]
bw.u <- rdbwselect(rd.urban$f_elected,rd.urban$margin, bwselect = 'mserd')
bw.u = bw.u$bws[[2]]

rdbw.u  <-  subset(rd.urban,abs(margin)<bw.u)

rural.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd.rural)
vcov_both <- cluster.vcov(rural.all, cbind(rd.rural$muni_code, rd.rural$year))
rural.all.coeftest <- coeftest(rural.all, vcov_both)

weights <- kernelwts(rdbw.r$margin,center = 0,bw = bw.r, kernel="triangular")
rural.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw.r, weights = weights)
vcov_both <- cluster.vcov(rural.bw, cbind(rdbw.r$muni_code))
rural.bw.coeftest <- coeftest(rural.bw, vcov_both)

urban.all   <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rd.urban)
vcov_both <- cluster.vcov(urban.all, cbind(rd.urban$muni_code, rd.urban$year))
urban.all.coeftest <- coeftest(urban.all, vcov_both)

weights <- kernelwts(rdbw.u$margin,center = 0,bw = bw.u, kernel="triangular")
urban.bw    <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw.u, weights = weights)
vcov_both <- cluster.vcov(urban.bw, cbind(rdbw.u$muni_code))
urban.bw.coeftest <- coeftest(urban.bw, vcov_both)


stargazer(rural.all.coeftest,rural.bw.coeftest,
          urban.all.coeftest,urban.bw.coeftest,
          stars='default',
          digits=3,type='text',keep.stat = 'n',
          add.lines = list(c("Bandwidth","All", "Optimal", "All","Optimal"),
                           c('Year FEs','Y','Y','Y','Y','Y','Y'),
                           c("n",rural.all$df.residual, rural.bw$df.residual, rural2.5$df.residual,
                             urban.all$df.residual, urban.bw$df.residual, urban.2.5$df.residual)),
          column.labels   = c("Rural", "Rural", "Urban", 'Urban'),
          omit = c('year'),
          dep.var.caption = 'Probability Win Next Election', dep.var.labels = '',
          label = 'ruralvsurban',
          title = 'Heterogeneous Incumbency Effects Conditional on Municipal Price Index, Rural vs Urban Municipalities',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))

# Table S.I.7. Commodities and Campaign Resources in Rural Municipalities: Campaign expenditures ----

rd <- subset(retro, ineligible2==0 & (year > 2000 & year < 2016) & ruralPop > median(retro$ruralPop, na.rm =TRUE))
rd[is.na(expenses) ,expenses:=0]
rd[is.na(brokers), brokers:=0]

rd$dv <- log(1 + rd$expenses)
bw <- rdbwselect(rd$dv, rd$margin)
bw = bw$bws[[2]]
rdbw<-subset(rd,abs(margin)<bw)

weights <- kernelwts(rd$margin, center = 0, bw = 1, kernel="triangular")
c.all<-lm(log(1+expenses) ~ I(inflation*elected)+inflation+elected*margin+I(inflation*margin),data=rd, weights = weights)
vcov_both <- cluster.vcov(c.all, cbind(rd$muni_code))
c.all.coeftest <- coeftest(c.all, vcov_both)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
c.optimal<-lm(log(1+expenses) ~ I(inflation*elected)+inflation+elected*margin+I(inflation*margin),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(c.optimal, cbind(rdbw$muni_code))
c.optimal.coeftest <- coeftest(c.optimal, vcov_both)

stargazer(c.all.coeftest, c.optimal.coeftest, stars='default',
          digits=4,type='text',keep.stat = 'n',
          label = 'expenses inflation rural',
          add.lines = list(c("Bandwidth", "All","Optimal","2.5\\%"),
                           c("Year FEs","Yes","Yes","Yes"),
                           c("n",c.all$df.residual, c.optimal$df.residual)),
          omit = c('year'),
          title = 'Commodities and Campaign Resources in Rural Municipalities: Campaign expenditures',
          dep.var.caption = 'log(1+expenses) in the next election',dep.var.labels = '',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))

# Table S.I.8. Commodities and Campaign Resources in Rural Municipalities: Brokers ----

rd$dv <- rd$brokers
bw <- rdbwselect(rd$brokers, rd$margin)
bw = bw$bws[[2]]
rdbw<-subset(rd,abs(margin)<bw)

weights <- kernelwts(rd$margin, center = 0, bw = 1, kernel="triangular")
c.all<-lm(dv ~ I(inflation*elected)+inflation+elected*margin+I(inflation*margin),data=rd, weights = weights)
vcov_both <- cluster.vcov(c.all, cbind(rd$muni_code))
c.all.coeftest <- coeftest(c.all, vcov_both)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
c.optimal<-lm(dv ~ I(inflation*elected)+inflation+elected*margin+I(inflation*margin),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(c.optimal, cbind(rdbw$muni_code))
c.optimal.coeftest <- coeftest(c.optimal, vcov_both)


stargazer(c.all.coeftest, c.optimal.coeftest, stars='default',
          digits=4,type='text',keep.stat = 'n',
          label = 'brokers inflation rural',
          add.lines = list(c("Bandwidth", "All","Optimal","2.5\\%"),
                           c("Year FEs","Yes","Yes","Yes"),
                           c("n",c.all$df.residual, c.optimal$df.residual)),
          omit = c('year'),
          title = 'Commodities and Campaign Resources in Rural Municipalities: Brokers',
          dep.var.caption = 'Number of brokers in next election',dep.var.labels = '',
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'))


# Table S.I.9. Heterogeneous Incumbency Effects by Party ----

rd <- subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0)
rd <-rd[ruralPop > median(rd$ruralPop, na.rm = TRUE)]

bw <- rdbwselect(rd$f_elected, rd$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd,abs(margin)<bw)

bw <- rdbwselect(rd[party=='PT']$f_elected, rd[party=='PT']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party=='PT'],abs(margin)<bw)

weights <- kernelwts(rdbw[party=='PT']$margin,center = 0, bw = bw, kernel="triangular")
pt<-lm(f_elected~I(inflation*elected) + inflation + elected*margin + I(inflation*margin) + as.factor(year),data=rdbw[party=='PT'], weights = weights)
vcov_both <- cluster.vcov(pt, cbind(rdbw[party=='PT']$muni_code))
diagonal <- sqrt(diag(vcov_both))
pt.coeftest <- coeftest(pt, vcov_both)


bw <- rdbwselect(rd[party=='PSDB']$f_elected, rd[party=='PSDB']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party=='PSDB'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin,center = 0, bw = bw, kernel="triangular")    
psdb<-lm(f_elected ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin) + as.factor(year), data=rdbw, weights = weights)
vcov_both <- cluster.vcov(psdb, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
psdb.coeftest <- coeftest(psdb, vcov_both)

bw <- rdbwselect(rd[party=='PMDB']$f_elected, rd[party=='PMDB']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party=='PMDB'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")  
pmdb<-lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(pmdb, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
pmdb.coeftest <- coeftest(pmdb, vcov_both)

bw <- rdbwselect(rd[party=='DEM']$f_elected, rd[party=='DEM']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party=='DEM'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin, center = 0,bw = bw, kernel="triangular")  
dem<-lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data = rdbw, weights = weights)
vcov_both <- cluster.vcov(dem, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
dem.coeftest <- coeftest(dem, vcov_both)

stargazer(dem.coeftest, pmdb.coeftest, psdb.coeftest, pt.coeftest, 
          stars='default',
          digits=3,
          type='text',keep.stat = 'n',
          column.labels = c("DEM", "PMDB", "PSDB", "PT"),
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'),
          label = 'party het effects',
          omit = c('year'),
          add.lines = list(c("n",dem$df.residual, pmdb$df.residual, psdb$df.residual, pt$df.residual)),
          dep.var.caption = 'Prob Win Next Election')


# Table S.I.10. Commodity shocks and incumbency effects, excluding one party ----

bw <- rdbwselect(rd[party!='PT']$f_elected, rd[party!='PT']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party!='PT'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
pt <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(pt, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
pt.coeftest <- coeftest(pt, vcov_both)

bw <- rdbwselect(rd[party!='PSDB']$f_elected, rd[party!='PSDB']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party!='PSDB'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
psdb <- lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(psdb, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
psdb.coeftest <- coeftest(psdb, vcov_both)

bw <- rdbwselect(rd[party!='PMDB']$f_elected, rd[party!='PMDB']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party!='PMDB'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin,center = 0,bw = bw, kernel="triangular")
pmdb<-lm(f_elected~I(inflation*elected)+inflation+elected*margin+I(inflation*margin)+as.factor(year),data=rdbw, weights = weights)
vcov_both <- cluster.vcov(pmdb, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
pmdb.coeftest <- coeftest(pmdb, vcov_both)

bw <- rdbwselect(rd[party!='DEM']$f_elected, rd[party!='DEM']$margin)
bw = bw$bws[[2]]
rdbw  <-  subset(rd[party!='DEM'],abs(margin)<bw)

weights <- kernelwts(rdbw$margin, center = 0,bw = bw, kernel="triangular")
dem <- lm(f_elected ~ I(inflation*elected) + inflation + elected*margin + I(inflation*margin) + as.factor(year), data=rdbw, weights = weights)
vcov_both <- cluster.vcov(dem, cbind(rdbw$muni_code))
diagonal <- sqrt(diag(vcov_both))
dem.coeftest <- coeftest(dem, vcov_both)

stargazer(dem.coeftest, pmdb.coeftest, psdb.coeftest, pt.coeftest, stars='default',
          digits=3,type='text',
          keep.stat = 'n',
          title = 'Commodity shocks and incumbency effects, excluding one party',
          column.labels = c("W/out DEM", "W/out PMDB", "W/out PSDB", "W/out PT"),
          covariate.labels = c('$\\Pi_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Pi_{ki_{t+1}}$','$Incumbency_{ki_{t}}$','$Margin$','$\\Pi_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant'),
          label = 'no party het effects',
          omit = c('year'),
          add.lines = list(c("n",dem$df.residual, pmdb$df.residual, psdb$df.residual, pt$df.residual)),
          df = TRUE,
          dep.var.caption = 'Prob Win Next Election'
)

# Table S.I.13. 2SLS - Commodity shocks as IV for GDP Growth, and Incumbency Effects in Rural Mu- nicipalities ----



rd <- setDT(subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0))

opt <- 'mserd'

bw <- rdbwselect(rd$f_elected,rd$margin,bwselect=opt)
bw = bw$bws[[2]]

rd.rural <- rd[ruralPop > median(rd$ruralPop,na.rm=TRUE)]
bw.r <- rdbwselect(rd.rural$f_elected, rd.rural$margin, bwselect=opt)
bw.r = bw.r$bws[[2]]

#urban study group
rd.urban <- rd[ruralPop < median(rd$ruralPop,na.rm=TRUE)]
bw.u <- rdbwselect(rd.urban$f_elected, rd.urban$margin, bwselect=opt)
bw.u = bw.u$bws[[2]]

rd<-rd[ !is.na(rd$diff.gdp) & !is.na(rd$inflation) & !is.na(rd$diff.agro) ,]

rdbw<-subset(rd,abs(margin)<bw)

urban<-subset(rd,ruralPop<median(ruralPop,na.rm=T))
rdurban<-subset(rd,ruralPop<median(ruralPop,na.rm=T) & abs(margin)<bw.u)

rural <- subset(rd, ruralPop > median(ruralPop,na.rm=T))
rdrural <- subset(rd,ruralPop>median(ruralPop,na.rm=T) & abs(margin)<bw.r)

weightsr <- kernelwts(rural$margin, center = 0, bw = 1)
weightsro <- kernelwts(rdrural$margin, center = 0, bw = bw.r)

weightsu <- kernelwts(urban$margin, center = 0, bw = 1)
weightsuo <- kernelwts(rdurban$margin, center = 0, bw = bw.u)

ker = 'triangular' # kernel
selection = 'mserd' #bandwidth selection

weights <- kernelwts(rural$margin, center = 0, bw = 1, kernel = ker)

rural.all <- ivreg(f_elected ~ I(diff.gdp*elected) + diff.gdp +
                     elected*margin + I(diff.gdp*margin) + as.factor(year)|
                     I(inflation*elected)+inflation+
                     elected*margin+I(inflation*margin)+as.factor(year), data=rural, 
                   weights = weights)
vcov_both <- cluster.vcov(rural.all, cbind(rural$muni_code))
rural.all.coeftest <- coeftest(rural.all, vcov_both)
diagnostics_rural_all <- summary(rural.all,diagnostics=TRUE)

weights <- kernelwts(rdrural$margin, center = 0, bw = bw.r, kernel = ker)

rural.bw <- ivreg(f_elected~I(diff.gdp*elected)+diff.gdp+
                    elected*margin+I(diff.gdp*margin)+as.factor(year)|
                    I(inflation*elected)+inflation+
                    elected*margin+I(inflation*margin)+as.factor(year), data=rdrural, 
                  weights = weights)
vcov_both <- cluster.vcov(rural.bw, cbind(rdrural$muni_code))
rural.bw.coeftest <- coeftest(rural.bw, vcov_both)
diagnostics_rural_bw <- summary(rural.bw,diagnostics=TRUE)


# IV agro GDP as regressor

weights <- kernelwts(rural$margin, center = 0, bw = 1, kernel = ker)

rural.all_agro <- ivreg(f_elected~I(diff.agro*elected)+diff.agro+
                          elected*margin+I(diff.agro*margin)+as.factor(year)|
                          I(inflation*elected)+inflation+
                          elected*margin+I(inflation*margin)+as.factor(year), data=rural, 
                        weights = weights)
vcov_both <- cluster.vcov(rural.all_agro, cbind(rural$muni_code))
rural.all.coeftest_agro <- coeftest(rural.all_agro, vcov_both)
diagnostics_rural_all_agro <- summary(rural.all_agro,diagnostics=TRUE)

weights <- kernelwts(rdrural$margin, center = 0, bw = bw, kernel = ker)

rural.bw_agro <- ivreg(f_elected~I(diff.agro*elected)+diff.agro+
                         elected*margin+I(diff.agro*margin)+as.factor(year)|
                         I(inflation*elected)+inflation+
                         elected*margin+I(inflation*margin)+as.factor(year), data=rdrural, 
                       weights = weights)
vcov_both <- cluster.vcov(rural.bw_agro, cbind(rdrural$muni_code))
rural.bw.coeftest_agro <- coeftest(rural.bw_agro, vcov_both)
diagnostics_rural_bw_agro <- summary(rural.bw_agro,diagnostics=TRUE)



stargazer(rural.all.coeftest, rural.bw.coeftest,
          rural.all.coeftest_agro, rural.bw.coeftest_agro,
          stars='default',
          digits=4,type='text',
          keep.stat = 'n',
          add.lines = list(c("Bandwidth", "All","Optimal","All","Optimal"),
                           c("Year FEs","Yes","Yes","Yes","Yes","Yes"),
                           c("n",
                             rural.all$df.residual,rural.bw$df.residual,
                             rural.all_agro$df.residual,rural.bw_agro$df.residual),
                           c("F-Test, interaction",
                             round(diagnostics_rural_all$diagnostics[1,3],2),
                             round(diagnostics_rural_bw$diagnostics[1,3],2),
                             round(diagnostics_rural_all_agro$diagnostics[1,3],2),
                             round(diagnostics_rural_bw_agro$diagnostics[1,3],2))),
          omit = c('year'),
          label = 'main table',
          dep.var.caption = 'Prob. Win Next Election',
          title = 'Heterogeneous Incumbency Effects Conditional on Municipal Price Index',
          covariate.labels = c('$\\Delta GDP_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\Delta GDP_{ki_{t+1}}$','$\\Delta Agro GDP_{ki_{t+1}} \\times Incumbency_{ki_{t}}$','$\\delta Agro GDP_{ki_{t+1}}$', '$Incumbency_{ki_{t}}$','$Margin$','$\\Delta GDP_{ki_{t+1}} \\times Margin$','$\\Delta Agro_GDP_{ki_{t+1}} \\times Margin$','$Incumbency_{ki_{t}} \\times Margin$','Constant')
)

# MUNICIPAL LEVEL TABLES ----

rd <- subset(retro, (year <2016 & year>2000)  & ineligible2==0)

rd.rural <- subset(rd, ruralPop>median(ruralPop,na.rm=TRUE))

bw <- rdbwselect(rd.rural$f_elected,rd.rural$margin)
bw = bw$bws[[2]]

rd.rural <- rd.rural[elected == 1 & abs(margin) < bw]

# Estimation table, rural municipalities ----

# Table 6. Difference in the pool of candidates and price change, rural municipalitie ----

weights <- kernelwts(rd.rural$margin, center = 0, bw = bw, kernel="triangular")
left.bw <- lm(I(f_left_total - left_total) ~ inflation + as.factor(year),data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(left.bw, cbind(rd.rural$muni_code))
left.bw.coeftest <- coeftest(left.bw, vcov_both)

hill.bw <- lm(I(f_hill - hillContestant) ~ inflation + as.factor(year),data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(hill.bw, cbind(rd.rural$muni_code))
hill.bw.coeftest <- coeftest(hill.bw, vcov_both)

highschool.bw <- lm(I(f_highschool_total - highschool_total)~ inflation + as.factor(year),data=rd.rural, weights = weights)
vcov_both <- cluster.vcov(highschool.bw, cbind(rd.rural$muni_code))
highschool.bw.coeftest <- coeftest(highschool.bw, vcov_both)

ncand.bw <- lm(I(f_ncand - ncand) ~ inflation + as.factor(year),data = rd.rural, weights = weights)
vcov_both <- cluster.vcov(ncand.bw, cbind(rd.rural$muni_code))
ncand.bw.coeftest <- coeftest(ncand.bw, vcov_both)  

#the dv names take a lot of space, and stargazer is clunky. ended up adding second line manually in manuscript.

stargazer(left.bw.coeftest,
          hill.bw.coeftest,
          highschool.bw.coeftest,
          ncand.bw.coeftest,
          stars='default',
          digits = 3,
          type='text',
          keep.stat = 'n',
          omit = 'year',
          add.lines = list(c("n",left.bw$df.residual, hill.bw$df.residual, highschool.bw$df.residual, ncand.bw$df.residual)),
          label = 'pool rural',
          dep.var.caption = 'Change in number of...',
          column.labels = c('Leftist','Rural producer','Highschool Degree','Number of'),
          title = 'Difference in the pool of candidates and inflation, rural municipalities.',
          covariate.labels = c('$\\Pi_{ki_{t+1}}$','Constant'))



# Table 5. Commodity shocks and Fiscal Performance, Rural Municipalities ----

rd <- setDT(subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0))

opt <- 'mserd'

bw <- rdbwselect(rd$f_elected,rd$margin,bwselect=opt)
bw = bw$bws[[2]]

rd.rural <- rd[ruralPop > median(rd$ruralPop,na.rm=TRUE)]
bw.r <- rdbwselect(rd.rural$f_elected, rd.rural$margin, bwselect=opt)
bw.r = bw.r$bws[[2]]

#urban study group
rd.urban <- rd[ruralPop < median(rd$ruralPop,na.rm=TRUE)]
bw.u <- rdbwselect(rd.urban$f_elected, rd.urban$margin, bwselect=opt)
bw.u = bw.u$bws[[2]]

rd<-rd[ !is.na(rd$diff.gdp) & !is.na(rd$inflation) & !is.na(rd$diff.agro) ,]

rdbw<-subset(rd,abs(margin) < bw)

urban<-subset(rd,ruralPop < median(ruralPop,na.rm=T))
rdurban<-subset(rd,ruralPop < median(ruralPop,na.rm=T) & abs(margin) < bw.u)

rural <- subset(rd, ruralPop > median(ruralPop,na.rm=T))
rdrural <- subset(rd,ruralPop > median(ruralPop,na.rm=T) & abs(margin) < bw.r)


rural.mun<-rural[rural$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                    'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                    'ruralPop','margin')]

rdrural.mun<-rdrural[rdrural$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                          'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                          'ruralPop','margin')]

urban.mun<-urban[urban$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                    'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                    'ruralPop','margin')]

rdurban.mun<-rdurban[rdurban$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                          'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                          'ruralPop','margin')]

rural.mun <- rural.mun[is.finite(rowSums(rural.mun)),]
rdrural.mun <- rdrural.mun[is.finite(rowSums(rdrural.mun)),]
urban.mun <- urban.mun[is.finite(rowSums(urban.mun)),]
rdurban.mun <- rdurban.mun[is.finite(rowSums(rdurban.mun)),]

weightsr <- kernelwts(rural.mun$margin, center = 0, bw = 1)
weightsro <- kernelwts(rdrural.mun$margin, center = 0, bw = bw.r)

weightsu <- kernelwts(urban.mun$margin, center = 0, bw = 1)
weightsuo <- kernelwts(rdurban.mun$margin, center = 0, bw = bw.u)

models.r<-list()
models.r$m1  <- felm(change_des_orc ~ inflation|year|0|muni_code,data=rural.mun,weights = weightsr)
models.r$m2  <- felm(change_des_orc ~ inflation|year|0|muni_code,data=rdrural.mun,weights = weightsro)
models.r$m7  <- felm(change_des_goods ~ inflation|year|0|muni_code,data=rural.mun,weights = weightsr)
models.r$m8  <- felm(change_des_goods ~ inflation|year|0|muni_code,data=rdrural.mun,weights = weightsro)
models.r$m9  <- felm(change_des_emp ~ inflation|year|0|muni_code,data=rural.mun,weights = weightsr)
models.r$m10 <- felm(change_des_emp ~ inflation|year|0|muni_code,data=rdrural.mun,weights = weightsro)



stargazer(models.r,no.space=T, type='text',
          keep.stat = c('n'),model.numbers = F,
          title = 'Commodity shocks and Fiscal Performance, Rural Municipalities', label = 'fiscal rural',
          dep.var.labels = c('Total Spending','Public Goods Spending','Personnel Spending'),
          add.lines =  list(c("Bandwidth",rep(c('All','Optimal'),3))))


# Table 3. Commodity Shocks and Total GDP Growth ----

models.g <- list()
models.g$m1 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rural.mun, weights = weightsr)
models.g$m2 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rdrural.mun, weights = weightsro)
models.g$m4 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = urban.mun, weights = weightsu)
models.g$m5 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rdurban.mun, weights = weightsuo)

stargazer(models.g,no.space=T, type='text',
          keep.stat = c('n'),model.numbers = F,
          title = 'Commodity Shocks and GDP Growth',
          label = 'gdp',
          dep.var.caption = 'Change in GDP',
          dep.var.labels.include = FALSE,
          covariate.labels = c('$\\Pi_{ki_{t+1}}$'),
          column.labels = c('Rural','Rural','Urban','Urban'),
          add.lines =  list(c('Bandwidth',rep(c('All','Optimal'),2))))

# Table 4. Commodity Shocks and GDP Growth by Sector ----

models.g <- list()
models.g$m1 <- felm(diff.agro~inflation|year|0|muni_code, data = rural.mun, weights = weightsr)
models.g$m2 <- felm(diff.agro~inflation|year|0|muni_code, data = rdrural.mun, weights = weightsro)
models.g$m3 <- felm(diff.ind~inflation|year|0|muni_code,  data = rural.mun, weights = weightsr)
models.g$m4 <- felm(diff.ind~inflation|year|0|muni_code,  data = rdrural.mun, weights = weightsro)
models.g$m5 <- felm(diff.agro~inflation|year|0|muni_code, data = urban.mun, weights = weightsu)
models.g$m6 <- felm(diff.agro~inflation|year|0|muni_code, data = rdurban.mun, weights = weightsuo)
models.g$m7 <- felm(diff.ind~inflation|year|0|muni_code,  data = urban.mun, weights = weightsu)
models.g$m8 <- felm(diff.ind~inflation|year|0|muni_code,  data = rdurban.mun, weights = weightsuo)


stargazer(models.g,no.space=T, type='text',
          keep.stat = c('n'),model.numbers = F,
          title = 'Commodity Shocks and Agricultural GDP growth',
          label = 'agro gdp',
          covariate.labels = c('$\\Pi_{ki_{t+1}}$'),
          dep.var.labels = c('Agro GDP','Industrial GDP','Agro GDP','Industrial GDP'),
          column.labels = c('Rural','Rural','Rural','Rural','Urban','Urban','Urban','Urban'),
          add.lines =  list(c('Bandwidth',rep(c('All','Optimal'),4))))

# Table S.I.6. Effect of commodity shocks on municipal GDP growth (Alternative Classification) ----


rd <- setDT(subset(retro, (year < 2016 & year > 2000) & ineligible2 == 0))

opt <- 'mserd'

bw <- rdbwselect(rd$f_elected,rd$margin,bwselect=opt)
bw = bw$bws[[2]]

rd.rural <- rd[rural_ibge == 1]
bw.r <- rdbwselect(rd.rural$f_elected, rd.rural$margin, bwselect=opt)
bw.r = bw.r$bws[[2]]

#urban study group
rd.urban <- rd[urban_ibge == 1]
bw.u <- rdbwselect(rd.urban$f_elected, rd.urban$margin, bwselect=opt)
bw.u = bw.u$bws[[2]]

rd<-rd[ !is.na(rd$diff.gdp) & !is.na(rd$inflation) & !is.na(rd$diff.agro) ,]

rdbw<-subset(rd,abs(margin) < bw)

urban <- subset(rd,urban_ibge == 1)
rdurban<-subset(rd,urban_ibge == 1 & abs(margin) < bw.u)

rural <- subset(rd, rural_ibge ==1)
rdrural <- subset(rd,rural_ibge == 1 & abs(margin) < bw.r)

rural.mun<-rural[rural$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                    'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                    'ruralPop','margin')]

rdrural.mun<-rdrural[rdrural$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                          'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                          'ruralPop','margin')]

urban.mun<-urban[urban$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                    'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                    'ruralPop','margin')]

rdurban.mun<-rdurban[rdurban$elected==1,c('inflation','year','muni_code','change_des_emp','change_des_orc',
                                          'diff.gdp','diff.agro','diff.ind','change_des_goods',
                                          'ruralPop','margin')]

rural.mun <- rural.mun[is.finite(rowSums(rural.mun)),]
rdrural.mun <- rdrural.mun[is.finite(rowSums(rdrural.mun)),]
urban.mun <- urban.mun[is.finite(rowSums(urban.mun)),]
rdurban.mun <- rdurban.mun[is.finite(rowSums(rdurban.mun)),]

weightsr <- kernelwts(rural.mun$margin, center = 0, bw = 1)
weightsro <- kernelwts(rdrural.mun$margin, center = 0, bw = bw.r)

weightsu <- kernelwts(urban.mun$margin, center = 0, bw = 1)
weightsuo <- kernelwts(rdurban.mun$margin, center = 0, bw = bw.u)

models.g <- list()
models.g$m1 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rural.mun, weights = weightsr)
models.g$m2 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rdrural.mun, weights = weightsro)
models.g$m4 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = urban.mun, weights = weightsu)
models.g$m5 <- felm(diff.gdp ~ inflation|year|0|muni_code, data = rdurban.mun, weights = weightsuo)

stargazer(models.g,no.space=T, type='text',
          keep.stat = c('n'),model.numbers = F,
          title = 'Commodity Shocks and GDP Growth',
          label = 'gdp',
          dep.var.caption = 'Change in GDP',
          dep.var.labels.include = FALSE,
          column.labels = c('Rural','Rural','Urban','Urban'),
          add.lines =  list(c('Bandwidth',rep(c('All','Optimal'),2))))
