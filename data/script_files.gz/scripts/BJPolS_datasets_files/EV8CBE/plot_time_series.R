rm(list = ls())
library(data.table)
library(ggplot2)
library(ggthemes)


setwd(dir = '.') # Please insert folder where files are stored

annual <- prices[crop!='rice']

annual <-data.table(annual)
annual[crop=='banana',crop:='Bananas']
annual[crop=='soybean',crop:='Soybeans']
annual[crop=='sugar',crop:='Sugar']
annual[crop=='corn',crop:='Maize']
annual[crop=='coffee',crop:='Coffee']
annual[crop=='orange',crop:='Oranges']
annual[crop=='tobacco',crop:='Tobacco']
annual[crop=='wheat',crop:='Wheat']
annual[crop=='cocoa',crop:='Cocoa']


ylim=c(-.5,1)
price.plot <- ggplot(data=annual, aes(x=as.Date(Date))) + 
  geom_rect(aes(xmin=as.Date('1999-10-01'),xmax=as.Date('2000-10-01'),ymin=-Inf,ymax=Inf),alpha=0.1,fill="gray80") +
  geom_rect(aes(xmin=as.Date('2003-10-01'),xmax=as.Date('2004-10-01'),ymin=-Inf,ymax=Inf),alpha=0.1,fill="gray80") +
  geom_rect(aes(xmin=as.Date('2007-10-01'),xmax=as.Date('2008-10-01'),ymin=-Inf,ymax=Inf),alpha=0.1,fill="gray80") +
  geom_rect(aes(xmin=as.Date('2011-10-01'),xmax=as.Date('2012-10-01'),ymin=-Inf,ymax=Inf),alpha=0.1,fill="gray80") +
  geom_rect(aes(xmin=as.Date('2015-10-01'),xmax=as.Date('2016-10-01'),ymin=-Inf,ymax=Inf),alpha=0.1,fill="gray80") +
  geom_line(aes(y = yoy), size = .5) + # Adding a colored line 
  scale_color_grey() +
  theme_minimal() +
  facet_wrap( ~ crop,ncol=3) +
  theme(legend.position = 'bottom') + 
  xlab('') + ylab('Year-over-Year, 12-month Moving Average') + 
  coord_cartesian(ylim=ylim) +
  guides(col = guide_legend(nrow = 2)) +
  geom_hline(yintercept=0,size=.3,linetype="dashed") +
  scale_x_date(limits = as.Date(c('2001-01-01','2016-12-30')), breaks = c(as.Date("2004-07-01"), as.Date("2008-07-01"),as.Date("2012-07-01"),as.Date("2016-07-01")),date_labels = "%Y") 

#ggsave('commodity_prices.pdf', plot = price.plot, device = 'pdf',width = 16, height = 22, units = 'cm')
