# Table_A07.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


# This table reports the numbers of observations for each of the 24 main 
# models that I estimate.  It appears in the appendix.  


library(Bullock, lib.loc = c(.libPaths(), 'packageLibrary'))  # for qw()
source("IV_setup.R")
varNames        <- qw('eqwlth goveqinc guarantee.7pt govt.health.7pt helppoor welfare')
dfNames         <- qw('GSS.df GSS.df   ANES.df       ANES.df         GSS.df   GSS.df') 
modelRownames   <- c(
  'Basic model (Eq. 2)\\lips',
  '\\lips with cohort-year fixed effects',  
  '\\lips with state-when-young $\\times$ year-when-young trends',
  '\\lips with political and demographic controls')
modelColnames <- list(
  c('redistrib.',  'redistrib.',  'guarantee', 'health', 'help',  ''),
  c('to poor (1)', 'to poor (2)', 'SOL',       'care',   'poor',  'welfare'),
  c('(GSS)',       '(GSS)',       '(ANES)',    '(ANES)', '(GSS)', '(GSS)'))



##############################################################################
# CALCULATE THE MAIN IV RESULTS  
##############################################################################
IVModelObjectsEnv <- estimateModels(
  varNames     = varNames, 
  modelEnvir   = IVModelsEnv, 
  dfNames      = dfNames,
  objectSuffix = '.IV') 



##############################################################################
# MAKE THE TABLE OF SAMPLE SIZES
##############################################################################
NTableEduc     <- getNobsForMatrixOfModels(
  varNames, 
  objectEnvir = IVModelObjectsEnv)[1:length(IVModelsEnv),]
NTableCaption <- 'Each cell indicates the number of observations of the corresponding model in \\autoref{FigIVMainResults}. The first row reports the numbers of observations used to estimate the baseline (\\autoref{Eq_IVSecondStage}) models.  The subsequent rows show how sample size declines (or doesn\'t) as I add cohort-year fixed effects, state-when-young $\\times$ year-when-young trend variables, or political and demographic controls.'
NTableRownames  <- paste0('(', 1:nrow(NTableEduc), ')')
NTableOutputFilenameStem <- 'float_output/Table_A07'
NTableEducLaTeX <- latexTable(
  mat            = NTableEduc,  
  rowNames       = NTableRownames, 
  colNames       = modelColnames,  
  footerRows     = NULL,
  headerFooter   = TRUE,
  SETable        = FALSE,
  decimalPlaces  = 0,
  tabcolsep      = '7pt',
  caption        = NTableCaption,
  captionMargins = c('.75in', '.75in'),
  commandName    = 'TabIVMainResultsNobs',
  callCommand    = FALSE)
NTableEducLaTeX.rowsToChange <- grep('N\\{5\\}\\{0\\}', NTableEducLaTeX)
NTableEducLaTeX[NTableEducLaTeX.rowsToChange[1]] <- sub(
  pattern     = 'hspace\\*\\{0em\\}', 
  replacement = 'hspace*{.825em}', 
  x           = NTableEducLaTeX[NTableEducLaTeX.rowsToChange[1]])
NTableEducLaTeX[NTableEducLaTeX.rowsToChange[2]] <- sub(
  pattern     = 'hspace\\*\\{0em\\}', 
  replacement = 'hspace*{.75em}', 
  x           = NTableEducLaTeX[NTableEducLaTeX.rowsToChange[2]])
NTableEducLaTeX[NTableEducLaTeX.rowsToChange[3]] <- sub(
  pattern     = 'hspace\\*\\{0em\\}', 
  replacement = 'hspace*{.67em}', 
  x           = NTableEducLaTeX[NTableEducLaTeX.rowsToChange[3]])
NTableEducLaTeX[NTableEducLaTeX.rowsToChange[4]] <- sub(
  pattern     = 'hspace\\*\\{0em\\}', 
  replacement = 'hspace*{.20em}', 
  x           = NTableEducLaTeX[NTableEducLaTeX.rowsToChange[4]])
latexTablePDF(
  latexCommands      = list(NTableEducLaTeX), 
  firstPageEmpty     = FALSE,
  continuedFloatStar = FALSE,
  wrapper            = FALSE,
  outputFilenameStem = NTableOutputFilenameStem,     
  overwriteExisting  = TRUE,
  keepPDFFile        = FALSE,
  keepTexFile        = TRUE,
  openPDFOnExit      = FALSE)
