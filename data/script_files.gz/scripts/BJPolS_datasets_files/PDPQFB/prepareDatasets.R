# prepareDatasets.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


# Most of the files in the replication archive process the cumulative ANES and
# GSS datasets. This file, prepareDatasets.R, calls files that download those
# cumulative datasets and extract only the variables needed for analysis. 
# Doing so saves time: instead of downloading the cumulative datasets anew for
# each table or figure, we do so only once (by running this file).


# CREATE MAIN PROCESSED FILES
source('ANES_coding.R')  # creates data/ANES_withMergedCSLs.RDS
source('GSS_coding.R')   # creates data/GSS_withMergedCSLs.RDS


# CREATE PROCESSED FILES WITH IMPUTED DATA
# See the "Imputation of Missing Data" section of the appendix.
cat("Making ANES files for appendix section on missing data...\n")
cat("...sourcing ANES_createImputedDatasets.R...\n")
source('ANES_createImputedDatasets.R')      
cat("...sourcing ANES_coding_forImputedDatasets.R...\n")
source('ANES_coding_forImputedDatasets.R')  

cat("Making GSS files for appendix section on missing data...\n")
cat("...sourcing GSS_makeDatasetForImputation.R...\n")
source('GSS_makeDatasetForImputation.R')    
cat("...sourcing GSS_createImputedDatasets.R...\n")
source('GSS_createImputedDatasets.R')       
cat("...sourcing GSS_coding_forImputedDatasets.R...\n")
source('GSS_coding_forImputedDatasets.R')   
