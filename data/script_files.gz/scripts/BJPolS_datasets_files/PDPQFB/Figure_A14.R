# Figure_A14.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


# This file produces Figure A14 in the appendix to the article: "U.S. Income 
# and Unemployment by Level of Education."



library(lattice)
incomeEmployment <- read.csv(
  file       = 'data/educationAndEmployment.csv',
  colClasses = c('character', "NULL", "NULL", 'numeric', "NULL", 'numeric', 'numeric',     "NULL", 'numeric', 'numeric'),
  col.names  = c('schooling',     '', '', 'income',  '', 'pop',     'popEmployed', '', 'popArmedForces', 'popNotInLaborForce'))


# CODE RELEVANT VARIABLES 
# Employment and unemployment rates are based on the civilian labor force.  
# They exclude those in the armed forces as well as others "not in the labor
# force."  In the .csv file loaded above, "in the armed forces" and "not in 
# the labor force" are distinct categories, but they should be treated in the 
# same way when calculating employment and unemployment rates.
incomeEmployment$emp       <- with(incomeEmployment, popEmployed / (pop - popArmedForces - popNotInLaborForce))  # employment rate
incomeEmployment$unemp     <- 1 - incomeEmployment$emp  
incomeEmployment[18:19,]   <- incomeEmployment[19:18,]  # put "GED" before "HS diploma"
incomeEmployment$schoolNum <- c(rep(NA, 5), 1:21)       # level of schooling
incomeEmployment           <- incomeEmployment[!is.na(incomeEmployment$schoolNum), ]
dataToPlot <- with(incomeEmployment[-(1:7),], data.frame(
  y         = c(income, unemp),
  schoolNum = rep(schoolNum - 7, 2),
  panelType = rep(c('income', 'unemp'), each = length(income))))
  


# PRELIMINARIES FOR PRINTING THE FIGURE
dirOutput        <- 'float_output/' 
PDF_title        <- 'Figure A14: Income and Employment by Education (Source: 2010 American Community Survey)'
postscriptBg     <- 'transparent'
plotLineColor    <- 'black'
plotLineWidth    <- 1
panelBorderCol   <- 'black'
panelNumberCol   <- grey(.2)                    # color of number of each panel; lower values are darker
panelBorderWidth <- .3
panelLayout      <- c(2, 1)                     # columns, then rows
xBetween         <- 1.0000                      # space between columns
yBetween         <- 1.3175                      # space between rows
panelYlim        <- list(c(0, 120000), c(0, .3))  
baseCexSize      <- 1.0 
stripTextSize    <- .750 * baseCexSize
xAxisTextSize    <- .696 * baseCexSize
yAxisTextSize    <- .696 * baseCexSize
axisTickSize     <- .4

filenameStem   <- 'Figure_A14'
PS_width       <- 9.5
PS_height      <- 12.0
panelWidth     <- list(2.500, "inches")       
panelHeight    <- list(3.000, "inches")  
fontFamily     <- 'Helvetica'
xAxis <- list(
  draw   = TRUE, 
  labels = c('8th grade', '', '10th grade', '', 
             '12th grade, no diploma', '', '12th grade, diploma', '',  
             '>= 1 year of college, no degree', '', 'Bachelor\'s degree', '',
             'Professional degree', ''), 
  at     = c(1:(nrow(dataToPlot)/2)),
  rot    = 45,
  tck    = c(axisTickSize, 0), 
  col    = panelBorderCol, 
  cex    = xAxisTextSize,
  alternating = 1, 
  relation    = 'same', 
  axs         = 'i')  # axs='i' means that there is no padding around the xlimits

yAxis <- list(
  draw        = TRUE,   
  at          = list(seq(20000, 100000, by = 20000), seq(.05, .25, by = .05)),
  labels      = list(c('$20,000', '$40,000', '$60,000', '$80,000', '$100,000'), 
                     c('5%', '10%', '15%', '20%', '25%')), # sub('^(\\d+)000', '$\\1,000', '20000'),
  rot         = 0,
  tck         = c(axisTickSize, 0),
  col         = panelBorderCol,
  cex         = yAxisTextSize,
  alternating = c(1, 2),
  relation    = 'free',  # but the ylim will constrain all panels to same height
  axs         = 'i')



# PANEL FUNCTION
myPanel <- function(...) {  
  trellis.par.set("clip", list(panel="on", strip="on")) 
  panel.xyplot(...)
  
}



##############################################################################
# PRINT THE PDF FILE
##############################################################################
pdf(
  file   = paste0(dirOutput, filenameStem, '.pdf'), 
  width  = PS_width, 
  height = PS_height, 
  paper  = "special", 
  title  = PDF_title,
  bg     = postscriptBg) 
trellis.par.set(
  axis.components = list(
    left = list(pad1 = .5)),    # distance between axis ticks and tick labels
  axis.line = list(
    alpha = 1, 
    col   = panelBorderCol, 
    lty   = 1, 
    lwd   = panelBorderWidth),  # to eliminate lattice panel border, set col="white"
  superpose.line = list(
    alpha = c(1,1), 
    col   = c('black', plotLineColor), 
    lty   = c("solid", "43"), 
    lwd   = c(1, plotLineWidth)))
incomeEmploymentPlot <- xyplot(
  y ~ schoolNum | panelType, 
  type     = 'l',
  data     = dataToPlot, 
  panel    = myPanel,
  layout   = panelLayout,
  strip    = FALSE,
  ylim     = panelYlim,
  between  = list(x = xBetween, y = yBetween),                   
  scales   = list(x = xAxis,    y = yAxis),
  col      = plotLineColor,
  xlab     = '',
  ylab     = '',
)
print(
  x            = incomeEmploymentPlot, 
  panel.width  = panelWidth, 
  panel.height = panelHeight)
dev.off()


if (!(Sys.which('pdfcrop')=='' | Sys.which('perl')=='')  |  'pdfcrop' %in% installed.packages()[, 'Package']) {  # if "pdfcrop" is installed 
  system(paste(
    if (Sys.info()['sysname']=='Windows') paste(Sys.getenv('Comspec'), '/c ') else '',
    'pdfcrop', 
    paste0(dirOutput, filenameStem, '.pdf'), 
    paste0(dirOutput, filenameStem, '_crop.pdf')))
  if (interactive() & Sys.info()['sysname']=='Windows') shell.exec(normalizePath(paste0(dirOutput, filenameStem, '_crop.pdf')))
  file.remove(paste0(dirOutput, filenameStem, '.pdf'))
}