# mechanismsVarInfo.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


createMechanismsVarInfoDF <- function () {

  data.frame(
    yLabels = c(
      "Married",
      "Income (logged)",
      "Currently employed",
      "Not in poverty",
      "Verbal ability",

      "Standard of living is getting better",
      "Occupational prestige higher than father's",

      "Society should ensure equal opportunity",
      "Equal opportunity already exists",
      "Equal opportunity already exists (1 item)",
      
      "Hard work matters more than luck",
      "Poor people are lazy",  # "Work ethic is important",
      "Welfare causes laziness",
      "Perceived extent of inequality",
      "Ideal extent of inequality"),
  
    varNamesMech = qw(
      "married
       income86l
       employed7cat.NA3       
       noPov
       wordsum

       SOL_gettingBetter
       prestigeMobilityDummy
    
       ensureEqOpp
       eqOppExists
  		 unequalProblem

       workOutweighsLuck
       workEthic
       welfareCausesLaziness
       actualIncomeMatrixRatio
       idealIncomeMatrixRatio"),
  
    dfNamesMech = c(
      "GSS.df", "GSS.df", "ANES.df", "GSS.df", "GSS.df",
      rep("GSS.df",  2),
      rep("ANES.df", 3),
      "GSS.df", "ANES.df", rep("GSS.df", 3)),
    
    OLS_only = c(
      rep(FALSE, 5),
      FALSE, FALSE,
      FALSE, TRUE, FALSE,
      FALSE, rep(TRUE, 4)),
    
    oneYearOnly = c(
      rep(FALSE, 5),
      FALSE, FALSE,
      FALSE, TRUE, FALSE,
      FALSE, TRUE, TRUE, FALSE, FALSE),
    
    stringsAsFactors = FALSE)

}