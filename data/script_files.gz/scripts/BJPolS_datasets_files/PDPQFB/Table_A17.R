# Table_A17.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


# This file produces Table A17 in the appendix to the article: "Professors
# are more liberal than high school teachers."


library(Bullock, lib.loc = c(.libPaths(), 'packageLibrary'))
source('functions/importModels.R')
source('functions/estimateModels.R')
source('functions/latexTable.R')
source('functions/latexTablePDF.R')
source('functions/regTable.R')
GSS          <- readRDS('data/GSS_withMergedCSLs.RDS')
dirOutput    <- 'float_output/'
filenameStem <- 'Table_A17' 


# CODE VARIABLES
secSchoolTeacher  <- GSS$occ == 144     | GSS$occ80 == 'TEACHERS, SECONDARY SCHOOL'
preCollegeTeacher <- GSS$occ%in%142:144 | GSS$occ80%in%c("TEACHERS, ELEMENTARY SCHOOL", "TEACHERS, SECONDARY SCHOOL", "TEACHERS, SPECIAL EDUCATION", "TEACHERS, PREKINDERGARTEN AND KINDERGARTEN")
professor         <- GSS$occ%in%102:140 | unclass(GSS$occ80)%in%71:99


# CREATE DATA FRAMES FOR ESTIMATION
teacherOrProfessor       <- secSchoolTeacher | professor 
GSS.df.eqwlth   <- with(GSS, na.omit(data.frame(year = factor(year), eqwlth   = Bullock::rescale(eqwlth),   professor, secSchoolTeacher, teacherOrProfessor)))
GSS.df.goveqinc <- with(GSS, na.omit(data.frame(year = factor(year), goveqinc = Bullock::rescale(goveqinc), professor, secSchoolTeacher, teacherOrProfessor)))
GSS.df.helppoor <- with(GSS, na.omit(data.frame(year = factor(year), helppoor = Bullock::rescale(helppoor), professor, secSchoolTeacher, teacherOrProfessor)))
GSS.df.welfare  <- with(GSS, na.omit(data.frame(year = factor(year), welfare  = Bullock::rescale(welfare),  professor, secSchoolTeacher, teacherOrProfessor)))


# ESTIMATE MODELS
libProfModEnv            <- list()
libProfModEnv$libProfMod <- formula(eqwlth ~ secSchoolTeacher + factor(year))
libProfModEnv            <- list2env(addModNumAttribute(libProfModEnv))
dfNames    <- c('GSS.df.eqwlth',  'GSS.df.goveqinc', 'GSS.df.helppoor', 'GSS.df.welfare') 
varNames   <- qw('eqwlth          goveqinc           helppoor           welfare')
libProfEnv <- estimateModels(
  varNames     = varNames, 
  modelEnvir   = libProfModEnv,  
  dfNames      = dfNames,
  subset       = 'teacherOrProfessor',
  estFun       = lm,  
  objectSuffix = '.lm')


# CREATE ASCII "REGTABLE"
libProfRegList <- list(
  libProfEnv$eqwlth.lmlibProfMod,
  libProfEnv$goveqinc.lmlibProfMod,
  libProfEnv$helppoor.lmlibProfMod,
  libProfEnv$welfare.lmlibProfMod)
libProfRegTable <- regTable(
  objList    = libProfRegList,
  rowsToKeep = 'secSchoolTeacher'
)


# CREATE LATEX TABLE
R2  <- sapply(libProfRegList, function (x) summary(x)$r.squared )
SER <- sapply(libProfRegList, function (x) summary(x)$sigma )
SER <- gsub('^0\\.', '.', round(SER, 2))
N   <- sapply(libProfRegList, nobs)
libProfRownames            <- c('High school teacher')
libProfColnames <- list(
  c('redistrib.',  'redistrib.',  'help',  ''),
  c('to poor (1)', 'to poor (2)', 'poor',  'welfare'),
  c('(GSS)',       '(GSS)',       '(GSS)', '(GSS)'))
libProfFooterRows <- list(  
  c('$R^2$', round(R2, 2)),
  c('Standard error of regression', SER),
  c('Number of observations', N))
libProfLatexTable <- latexTable(
  mat            = libProfRegTable,
  rowNames       = libProfRownames,  
  colNames       = libProfColnames,
  footerRows     = libProfFooterRows,
  headerFooter   = TRUE,
  decimalPlaces  = 2,
  spacerColumns  = seq(0, ncol(libProfRegTable) - 1, by = 2),  # before rowname and after each SE column
  hspace         = '-.4375in',
  caption        = '\\textit{Professors are more liberal than high school teachers.}  Each column reports OLS estimates and standard errors from a different regression.  In each regression, the outcome ranges from 0 to 1.  It has been regressed on year-of-interview fixed effects and a dummy variable that equals 0 if the respondent is a professor, 1~if she is a high school teacher.  Respondents who are neither professors nor high school teachers are excluded from the data.  Data are from the GSS; the ANES does not permit one to identify which respondents are high school teachers or professors.',  commandName    = 'TabLiberalProfessors',
  callCommand    = FALSE)


# TWEAK TABLE FORMATTING
# With this code block, we indent the first two columns a bit.
columnSpecLines <- grep('hspace\\*\\{0em\\}', libProfLatexTable)
libProfLatexTable[columnSpecLines[1]] <- sub('0em', '.67em', libProfLatexTable[columnSpecLines[1]])  
libProfLatexTable[columnSpecLines[2]] <- sub('0em', '.5em',  libProfLatexTable[columnSpecLines[2]])  


# SAVE THE LATEX TABLE TO DISK
latexTablePDF(
  latexCommands      = list(libProfLatexTable), 
  firstPageEmpty     = FALSE,  
  continuedFloat     = FALSE,  
  wrapper            = FALSE,  # FALSE if inserting LaTeX tables into appendix of my paper
  outputFilenameStem = paste0(dirOutput, filenameStem),
  overwriteExisting  = TRUE,
  keepPDFFile        = FALSE,
  keepTexFile        = TRUE,
  openPDFOnExit      = FALSE)

