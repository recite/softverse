# Figure_A16.R

# Part of the replication archive for 
#
#   Bullock, John G. 2020. "Education and Attitudes toward Redistribution in
#   the United States." British Journal of Political Science 50.


# This file produces Figure A16 in the appendix to the article: "GED 
# Recipients as Proportions of All High School Completers." 


library(dplyr)  # for %>%
library(lattice)
dirOutput    <- 'float_output/' 
filenameStem <- 'Figure_A16'
PDFtitle     <- 'Figure A16: GEDs as a Percentage of All High School Completers'
ANES         <- readRDS('data/ANES_withMergedCSLs.RDS')
GSS          <- readRDS('data/GSS_withMergedCSLs.RDS')


# Load GED data. The data have been digitized from the figure in Heckman, 
# Humphries, and Mader (2011, 425).
dataToPlot <- read.csv(
  file       = 'data/GEDsAsPercentageOfHighSchoolCompleters.csv',
  colClasses = c('integer', 'numeric'),
  col.names  = c('year', 'percentage')) %>%
  filter(year >= 1970)

frequencies.ANES <- sapply(
  dataToPlot$year,
  function (x) { table(ANES$yearYoung[ANES$yearInt>=1970] + 10 >= x) }
)
dataToPlot$reached24ByYear.ANES <- frequencies.ANES[2, ] / apply(frequencies.ANES, 2, sum) * 100  

frequencies.GSS <- sapply(
  dataToPlot$year,
  function (x) { table(GSS$yearYoung[GSS$yearInt>=1970] + 10 >= x) }
)
dataToPlot$reached24ByYear.GSS <- frequencies.GSS[2, ] / apply(frequencies.GSS, 2, sum) * 100



# PRELIMINARIES FOR PRINTING THE FIGURE
postscriptBackground   <- 'transparent'
plotLineColor   <- 'black'
plotLineWidth   <- 1
panelBorderCol  <- 'black'
panelNumberCol  <- grey(.2)                    # color of number of each panel; lower values are darker
panelborderwidth <- .3
panelLayout     <- c(2, 1)                     # columns, then rows
xBetween        <- 1.7000                      # space between columns
yBetween        <- 1.3175                      # space between rows
# panel.xlim      <- NULL                        
panel.ylim      <- c(0, 58)  
stripTextSize   <-  .75                        # cex
xaxtextsize     <-  .8*.87                     # cex
yaxtextsize     <-  .8*.87                     # cex
axisTickSize    <- .4

PS_width         <- 9.5
PS_height        <- 12.0
panelwidth      <- list(6, "inches")       
panelheight     <- list(4.5, "inches")  
fontFamily      <- 'Helvetica'
xaxs <- list(
  draw   = TRUE, 
  labels = seq(1970, 2008, by = 2), 
  at     = seq(1970, 2008, by = 2),
  rot    = 45,
  tck    = c(axisTickSize, 0), 
  col    = panelBorderCol, 
  cex    = xaxtextsize,
  alternating = 1, 
  relation    = 'same', 
axs         = 'i')  # axs='i' means that there is no padding around the xlimits

yaxs <- list(
  draw        = TRUE,   
  labels      = c('5%', '10%', '15%', '20%', '25%', '30%', '35%', '40%', '45%', '50%', '55%', '60%'),
at          = seq(5, 60, by = 5),
rot         = 0,
tck         = c(axisTickSize, 0),
col         = panelBorderCol,
cex         = yaxtextsize,
axs         = 'i')


# PANEL FUNCTION
myPanel <- function(...) {  
  trellis.par.set("clip", list(panel="on", strip="on"))     
  panel.xyplot(...)
}


# PRINT THE PDF FILE
pdf(
  file   = paste0(dirOutput, filenameStem, '.pdf'), 
  width  = PS_width, 
  height = PS_height, 
  paper  = "special", 
  title  = PDFtitle,
  bg     = postscriptBackground) 

trellis.par.set(
  "axis.line", 
  list(
    alpha = 1, 
    col   = panelBorderCol, 
    lty   = 1, 
    lwd   = panelborderwidth))  
trellis.par.set(
  "superpose.line",
  list(
    alpha = c(1,1), 
    col   = rep(plotLineColor, 3), 
    lty   = c("solid", "43", "14"), 
    lwd   = c(1, plotLineWidth)))
tmp <- trellis.par.get('axis.components')
tmp$left$pad1 <- 0.5  # distance between axis ticks and tick labels
trellis.par.set('axis.components', tmp)
GEDPlot <- xyplot(
  percentage + reached24ByYear.ANES + reached24ByYear.GSS ~ year, 
  type     = 'l',
  data     = dataToPlot, 
  panel    = myPanel,
  ylim     = panel.ylim,
  strip    = FALSE,
  scales   = list(x = xaxs, y = yaxs),
  col      = plotLineColor,
  xlab     = '',
  ylab     = '',
)
print(GEDPlot, panel.width = panelwidth, panel.height = panelheight)
dev.off()


if (!(Sys.which('pdfcrop')=='' | Sys.which('perl')=='')  |  'pdfcrop' %in% installed.packages()[, 'Package']) {  # if "pdfcrop" is installed 
  system(paste(
    if (Sys.info()['sysname']=='Windows') paste(Sys.getenv('Comspec'), '/c ') else '',
    'pdfcrop', 
    paste0(dirOutput, filenameStem, '.pdf'), 
    paste0(dirOutput, filenameStem, '_crop.pdf')))
  file.remove(paste0(dirOutput, filenameStem, '.pdf'))
  if (interactive() & Sys.info()['sysname']=='Windows') shell.exec(paste0(normalizePath(dirOutput), filenameStem, '_crop.pdf'))
}


