#setup
library(tidyverse)
library(ggplot2)

#
setwd(path)
df = read.csv("Colombia_tweets/Colombia_tweets_out.csv", sep = " ")
df = mutate(df, date = as.Date(date, "%d-%m-%Y"))
seq.weeks = seq(min(df$date, na.rm = T), max(df$date, na.rm = T), by = 1)
weeks = as.numeric(seq.weeks-min(seq.weeks, na.rm = T)) %/% 7
df.weeks = cbind.data.frame(seq.weeks, weeks)
colnames(df.weeks) <- c("date", "week")
df <- merge(df, df.weeks, by = "date", all = T)
df <- mutate(df, year = as.integer(substr(as.character(date),1,4)))

##############################
###### GROUPING BY WEEK ######
##############################

#PREPARATION

df_week = df %>% 
  group_by(week) %>% 
  summarize(Security_mean = mean(Security, na.rm = T),
            Education_mean = mean(Education, na.rm = T),
            year = max(year)
            )
df_week[is.na(df_week)] <- 0

#PLOTS


#PUBLIC GOODS VS SECURITY

PLOT_eduvsec_pre2015 <- ggplot(data = df_week[df_week$year < 2015,]) +
  geom_smooth(mapping = aes(y = Education_mean, x = week), color = "blue")+
  geom_smooth(mapping = aes(y = Security_mean, x = week), color = "red") +
  ylab("Mean (blue = Education, red = Security)") +
  scale_x_continuous(breaks = c(0, 100, 200), labels = c("2009-12-10","2011-11-10", "2013-10-11"))
ggsave("~/Dropbox/Colombia_tweets/00d_education_v_security_pre2015.png", PLOT_eduvsec_pre2015)




