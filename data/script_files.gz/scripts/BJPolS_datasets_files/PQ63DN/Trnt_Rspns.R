# Author: Werner Krause
# Contact: Humboldt University Berlin, Universitätsstraße 3B, 10117 Berlin 
# Email: werner.krause@hu-berlin.de

# Date: 2021-10-03

# Ezrow, Lawrence and Krause, Werner: Voter Turnout Decline and Party 
# Responsiveness. BJPS.

cat( '\14' )
rm( list = ls( ))

pkgs <- c( 'dplyr', 'magrittr' , 'ggplot2' )
lapply( pkgs , library , character.only = TRUE )

# ─ Session info ───────────────────────────────────────────────────────────────
# setting  value                       
# version  R version 4.1.1 (2021-08-10)
# ui       RStudio                     
# language (EN)                        
# collate  en_US.UTF-8                 
# ctype    en_US.UTF-8                 

# ─ Packages ───────────────────────────────────────────────────────────────────
# package      * version  date       lib source
# dplyr          1.0.7    2021-06-18 [1] CRAN (R 4.1.0)             
# ggplot2        3.3.5    2021-06-25 [1] CRAN (R 4.1.0)   
# haven          2.4.3    2021-08-04 [1] CRAN (R 4.1.0)                     
# interflex      1.2.6    2021-05-18 [1] CRAN (R 4.1.0)                     
# lmtest         0.9-38   2020-09-09 [1] CRAN (R 4.1.0)                     
# magrittr       2.0.1    2020-11-17 [1] CRAN (R 4.1.0)  
# multiwayvcov   1.2.3    2016-05-05 [1] CRAN (R 4.1.0)                     
# RStata       * 1.1.1    2016-10-27 [1] CRAN (R 4.1.0)                     
# scales         1.1.1    2020-05-11 [1] CRAN (R 4.1.0)                     
# stringr        1.4.0    2019-02-10 [1] CRAN (R 4.1.0)                     

# ─ Variables: Trnt_Rspns.Rdata ────────────────────────────────────────────────
# "iso2c": ISO 3166-1 alpha-2 Country Code               
# "cname": Country Name               
# "edate": Election Date 
# "decade": Decade
# "trnt": Turnout (t)
# "trnt_delta": Turnout Change (t-1)
# "trnt_delta_l": Turnout Change (t-2)
# "trnt_l": Turnout (t-1)
# "trnt_l2": Turnout (t-2)
# "mv.0_12mo": Mean Voter Position (t) [12 Months Window]
# "mv.0_12mo_delta": Mean Voter Position Change (t) [12 Months Window]
# "mv.0_12mo_lag": Mean Voter Position (t-1) [12 Months Window]
# "mv.0_9mo_delta": Mean Voter Position Change (t) [9 Months Window]
# "mv.0_6mo_delta": Mean Voter Position Change (t) [6 Months Window]
# "mv.4_12mo_delta": Mean Voter Position Change (t) [4-12 Months Window]
# "party": MARPOR Party Code
# "partyabbrev": MARPOR Party Abbreviation
# "partyname": MARPOR Party Name
# "parfam": MARPOR Party Family
# "rile_logit_delta": Left-Right Position Change (t) [Logit]
# "rile_logit_delta_l": Left-Right Position Change (t-1) [Logit]
# "rile_logit": Left-Right Position (t) [Logit]
# "rile_logit_l": Left-Right Position (t-1) [Logit]
# "rile_delta": Left-Right Change (t) [Bipolar]
# "rile_delta_l"Left-Right Change (t-1) [Bipolar]
# "progtype": MARPOR Program Type       
# "v_delta_l": Vote Share Change (t-1)
# "v": Vote Share (t)
# "v_l": Vote Share (t-1)    
# "v_l2": Vote Share (t-2)    
# "g_lf": Government (t-1)
# "chll_l": Challenger (t-1)              
# "winn_l": Vote Loser (t-1)
# "large_l": Large Party (t-1)
# "niche": Niche Party
# "extr_l": Extreme Party (t-1)  
# "kofgi_delta": Globalization Index Score Change (t)
# "kofgi_l": Globalization Index Score (t-1)
# "log.gdp_delta": GDP (log) Change (t)
# "log.gdp_l": GDP (log) (t-1)
# "comp_elec_delta_l": Competitiveness of Election (t-1)
# "policy_dist_delta_l": Positional Distance Strongest Parties (t-1)
# "extre_v_delta_l": Extreme Party Vote Share Change (t-1)

# ─ Variables: Trnt_Rspns_Survey.dta ───────────────────────────────────────────
# "c": Country Name
# "y": Election/Survey Year
# "cy": Country-Year
# "trnt_delta": Turnout Change
# "v": Voted in Parliamentary Election
# "lr": Left-Right Self-Position
# "lr_ext": Left-Right Extremism [Continuous]
# "lr_bin": Left-Right Extremism [Binary]
# "gender": Gender
# "age": Age
# "age2": Age [Squared]
# "edu": Education
# "union": Union Member
# "inc": Income
# "unem_i": Unemployed
# "sat_dem": Satisfaction with Democracy
# "w": Weight (Combined Sample and Design Weight, Trimmed)

tryCatch( setwd( 'INSERT WORKING DIRECTORY' ))
options( 'RStata.StataPath' = 'INSERT STATA PATH' ) # see Rstata-package
options( 'RStata.StataVersion' = 16L ) # Change Stata Version if needed
load( 'Trnt_Rspns.Rdata' )
source( 'TrntRspns_fncts.R' )

# Tab 1: Citizen Ideology, Turnout, and Changes in Turnout Individual-Level Analyses & ----
# Fig 3: Predicted Probabilities of Voting Based on Individual-Level Analyses ----
# Tab A1: Citizen Ideology, Turnout, and Changes in Turnout Individual-Level Analyses (Full Models) ----
# Tab A2: Replication of Table A1 with Binary Indicator for Centrist Voters ----
# Fig A1: Predicted Probabilities of Voting Based on Individual-Level Analyses (Table A2) ----

cses <- haven::read_dta( 'Trnt_Rspns_Survey.dta' )
library( RStata )

script <- "
melogit v c.lr_ext [pweight=w] || c: || cy:
melogit v c.lr_ext gender age age2 i.edu union inc unem_i sat_dem [pweight=w] || c: || cy: 
melogit v c.lr_ext##c.trnt_delta [pweight=w] || c: || cy: 
margins, at(trnt_delta=(-7(2)7) lr_ext=(0)) predict(mu) 
margins, at(trnt_delta=(-7(2)7) lr_ext=(6)) predict(mu) 
melogit v c.lr_ext##c.trnt_delta gender age age2 i.edu union inc unem_i sat_dem [pweight=w] || c: || cy: 
	
melogit v i.lr_bin [pweight=w] || c: || cy: 
melogit v i.lr_bin gender age age2 i.edu union inc unem_i sat_dem [pweight=w] || c: || cy: 
melogit v i.lr_bin##c.trnt_delta [pweight=w] || c: || cy: 
margins, at(trnt_delta=(-7(2)7) lr_bin=(0)) predict(mu)
margins, at(trnt_delta=(-7(2)7) lr_bin=(1)) predict(mu)
melogit v i.lr_bin##c.trnt_delta gender age age2 i.edu union inc unem_i sat_dem [pweight=w] || c: || cy:
"

# The following command can take some time
# Please create Figures 3, A1, and A2 based on the margins-output
# stata( src = script, data.in = cses )

detach( package:Rstata)
rm( cses , script )

# Tab 2: Analyses of Changes in Party Position ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
c1 <- 'edate'
c2 <- 'party'
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )

ds %>% tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 ) 

# Check without extreme turnout changes
ds %>%
  filter( abs( trnt_delta_l ) < 5 ) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Fig 4: Effect of Mean Voter Shifts on Changes in Party Position, Conditional on Lagged Voter Turnout ----

m <- ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 ) 

tmp <- ia.plot.df( model = m$lm 
                   , effect = 'mv.0_12mo_delta' 
                   , moderator = 'trnt_delta_l'
                   , interaction = 'mv.0_12mo_delta:trnt_delta_l' 
                   , type = 'continuous'
                   , varcov = m$vcv , conf = .95 )

tmp %>% 
  ggplot() + 
  geom_ribbon( aes( x = x_2 , ymin = lower_bound , ymax = upper_bound )
               , fill = "grey70" , alpha = .7 ) +
  geom_line( aes( x = x_2, y = delta_1 ))

rm( tmp , m )

# Fig A2: Marginal Effects Plot (Hainmueller et al. 2019) ----

p <- interflex::interflex( data = ds 
                      , Y = 'rile_logit_delta' 
                      , D = 'mv.0_12mo_delta' 
                      , X = 'trnt_delta_l'
                      , estimator = 'kernel'
                      , FE = 'iso2c'
                      , Z = c( 'v_delta_l' , 'g_lf' , 'kofgi_delta'
                               , 'log.gdp_delta' , 'rile_logit_delta_l' )
                      , cl = c( 'party' , 'edate' )
                      , parallel = FALSE
                      , na.rm = T )

rm( p )

# Tab 3: Empirical Analyses of Different Party Types & ----
# Fig A3: Marginal Effects Plots for Different Party Types (based on Table 3) ----

activ.form2 <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * chll_l' )
m <- ds %>% tw.cl.lm( . , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , chll_l == as.character( 'Dominant' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , chll_l == as.character( 'Challenger' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )

activ.form2 <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * niche' )
m <- tw.cl.lm( ds , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# # warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , niche == as.character( 'Mainstream' ))
#                 , vcov = m$vcv
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , niche == as.character( 'Niche' ))
#                 , vcov = m$vcv
#                 , level = 0.95 )

activ.form2 <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * g_lf' )
m <- tw.cl.lm( ds , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , g_lf == as.character( 'Government' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , g_lf == as.character( 'Opposition' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )

base.form.wo.vdelta <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form2 <- paste0( base.form.wo.vdelta , '+ mv.0_12mo_delta * trnt_delta_l * winn_l' )
m <- tw.cl.lm( ds , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , winn_l == as.character( 'Vote Winner' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , winn_l == as.character( 'Vote Loser' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )

activ.form2 <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * large_l' )
m <- tw.cl.lm( ds , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , large == as.character( 'Large' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , large == as.character( 'Small' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )

activ.form2 <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * extr_l' )
m <- tw.cl.lm( ds , formula = activ.form2 , c1 = c1 , c2 = c2 )
m$tw.se

# warning: the following command can take some time to finish
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , large == as.character( 'Large' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )
# margins::cplot( m$lm
#                 , x = 'trnt_delta_l'
#                 , dx = 'mv.0_12mo_delta'
#                 , what = "effect"
#                 , data = filter( ds , large == as.character( 'Small' ))
#                 , vcov = m$vcv 
#                 , level = 0.95 )

rm( m )

# Tab A4: Alternative Model Specifications ----

ds$party <- as.factor( ds$party )
base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + party' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

base.form <- 'rile_logit_delta ~ mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

base.form <- 'rile_logit_delta ~ rile_logit_l + rile_logit_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
c1 <- NULL
c2 <- 'party'
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

c1 <- 'edate'
c2 <- NULL
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

c1 <- NULL
c2 <- NULL
m <- ds %>% lm( . , formula = activ.form )
m <- list(lm = m, vcv = vcov( m ), tw.se = lmtest::coeftest( m ))
m

rm( m )

base.form <- 'rile_delta ~ rile_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
c1 <- 'edate'
c2 <- 'party'
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Tab A5: Error Correction Model of Changes in Parties’ Left-Right Positions ----

ds %>% tw.cl.lm( . ,formula = 'rile_logit_delta ~ rile_logit_l + mv.0_12mo_delta + mv.0_12mo_lag + trnt_delta_l + trnt_l2 + v_delta_l + v_l2 + g_lf + kofgi_delta + kofgi_l + log.gdp_delta + log.gdp_l + mv.0_12mo_delta * trnt_delta_l + mv.0_12mo_lag * trnt_l2 + factor( iso2c )'
                 , c1 = c1 , c2 = c2 )

# Tab A6: Models Stratified by Turnout Context (Low and High Turnout Elections) ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l * high_trnt' )

ds %>% 
  mutate( high_trnt = ifelse( trnt_l > 76 , 1 , 0 )) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Tab A7: Including Decade Dummy Variables ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c + decade' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )

ds %>% tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Fig A4: Jackknife Analyses ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 

for ( i in unique( ds$iso2c ) ){
  m.tmp <- ds %>% 
    filter( iso2c != i ) %>% 
    tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )
  
  cat( '\n' )
  print( i )
  print( m.tmp$tw.se[ c( 3 , nrow( m.tmp$tw.se )) ,  ])
  rm( m.tmp )
}

# Tab A8: Alternative Public Opinion Windows for the Eurobarometer Surveys  ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ mv * trnt_delta_l' )

ds %>%
  rename( mv = mv.0_9mo_delta ) %>%
  tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )

ds %>%
  rename( mv = mv.0_9mo_delta ) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

ds %>%
  rename( mv = mv.0_6mo_delta ) %>%
  tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )

ds %>%
  rename( mv = mv.0_6mo_delta ) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Tab A9: Omitting Parties with Estimated Manifestos Scores ----

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.0_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ mv.0_12mo_delta * trnt_delta_l' )

ds %>%
  filter( progtype == 1 ) %>%
  tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )

ds %>%
  filter( progtype == 1 ) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Tab A10: Addressing Minor Changes in the Mean Voter Position ----

ds %>%
  mutate( mv.0_12mo_delta = if_else( abs( mv.0_12mo_delta ) < .27 , 0 , mv.0_12mo_delta )) %>%
  tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )

ds %>%
  mutate( mv.0_12mo_delta = if_else( abs( mv.0_12mo_delta ) < .27 , 0 , mv.0_12mo_delta )) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

ds %>%
  mutate( mv.0_12mo_delta = if_else( abs( mv.0_12mo_delta ) < .27 , 0 , mv.0_12mo_delta )) %>%
  filter( mv.0_12mo_delta != 0 ) %>%
  tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )

ds %>%
  mutate( mv.0_12mo_delta = if_else( abs( mv.0_12mo_delta ) < .27 , 0 , mv.0_12mo_delta )) %>%
  filter( mv.0_12mo_delta != 0 ) %>%
  tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

# Tab A11: Controlling for Conditioning Variables  ----

activ.form <- paste0( base.form , '+ mv.0_12mo_delta * kofgi_delta + mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

activ.form <- paste0( base.form , '+ mv.0_12mo_delta * comp_elec_delta_l + mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form, c1 = c1 , c2 = c2 )

activ.form <- paste0( base.form , '+ mv.0_12mo_delta * policy_dist_delta_l + mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

activ.form <- paste0( base.form , '+ mv.0_12mo_delta * extre_v_delta_l + mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

activ.form <- paste0( base.form , '+ mv.0_12mo_delta * kofgi_delta + mv.0_12mo_delta * comp_elec_delta_l+ mv.0_12mo_delta * policy_dist_delta_l + mv.0_12mo_delta * extre_v_delta_l + mv.0_12mo_delta * trnt_delta_l' )
ds %>% tw.cl.lm( . , formula = activ.form  , c1 = c1 , c2 = c2 )

# Tab A12: Harmful and Benign Mean Voter Shifts and Party Responsiveness ----

tmp <- ds %>% mutate( ideo = ifelse( parfam %in% c( 10  , 20 , 30 ) , 'l' , 'c' )
                      , ideo = ifelse( parfam %in% c( 50 , 60 , 70 ) , 'r' , ideo )) %>%
  mutate( harmf = ifelse( mv.0_12mo_delta > .25 & ( ideo == 'l' ) , '1' , '0' )
          , harmf = ifelse( mv.0_12mo_delta < -.25 & ( ideo == 'r' ) , '1' , harmf )
          , benign = ifelse( mv.0_12mo_delta >   .25 & ( ideo == 'r' ) , '1' , '0' )
          , benign = ifelse( mv.0_12mo_delta < -.25 & ( ideo == 'l' ) , '1' , benign )) %>% 
  filter( parfam %in% c( 10 ,  20 , 30 , 50 , 60 , 70 ) )

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c' 
activ.form <- paste0( base.form , '+ harmf*trnt_delta_l + benign*trnt_delta_l' )

tmp %>% tw.cl.lm( . , activ.form , c1 , c2 )

m <- tmp %>% 
  filter( chll_l == 'Dominant' ) %>%
  tw.cl.lm( . , activ.form , c1 , c2 )
m$tw.se 

tmp2 <- ia.plot.df( m$lm
                    , effect = 'harmf1' 
                    , moderator = 'trnt_delta_l'
                    , interaction = 'trnt_delta_l:harmf1' 
                    , type = 'continuous' 
                    , varcov = m$vcv
                    , conf = .9 )
tmp2 %>%
  ggplot() + 
  geom_ribbon( aes( x = x_2 , ymin = lower_bound, ymax = upper_bound), fill = "grey70" , alpha = .7 ) +
  geom_line( aes( x = x_2, y = delta_1 )) + 
  facet_wrap( ~ 'Harmful Mean Voter Shifts' )

tmp2 <- ia.plot.df( m$lm
                    , effect = 'benign1' 
                    , moderator = 'trnt_delta_l'
                    , interaction = 'trnt_delta_l:benign1' 
                    , type = 'continuous' 
                    , varcov = m$vcv
                    , conf = .9 )
tmp2 %>%
  ggplot() + 
  geom_ribbon( aes( x = x_2 , ymin = lower_bound, ymax = upper_bound), fill = "grey70" , alpha = .7 ) +
  geom_line( aes( x = x_2, y = delta_1 )) + 
  facet_wrap( ~ 'Benign Mean Voter Shifts' )

rm( m , tmp , tmp2 )

# Tab A13: Window EB > 4 months ------

base.form <- 'rile_logit_delta ~ rile_logit_delta_l + mv.4_12mo_delta + trnt_delta_l + v_delta_l + g_lf + kofgi_delta + log.gdp_delta + iso2c ' 
activ.form <- paste0( base.form , '+ mv.4_12mo_delta * trnt_delta_l' )

ds %>% tw.cl.lm( . , formula = base.form , c1 = c1 , c2 = c2 )
ds %>% tw.cl.lm( . , formula = activ.form , c1 = c1 , c2 = c2 )

rm( list = ls( ))
cat( '\14' )

