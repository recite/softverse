##9/17/15
##Replication_Code_3
##This script produces Fig 3:  'wedding cake' of term "boundary"
## in 1884

rm(list=ls())
setwd("./../data/") # "C:/Users/as9934/Dropbox/HansardProject/burstiness/bjps_replication/data/")

#grab the data for 1884
load("tdm_1884.rdata")
require(tm)

#get bursts of this term
require(bursts)

#main burstiness function
burstiness <- function(x="boundary"){

z <- which(matrix(tdm[x,])==1)
kout <- kleinberg(z)
kout$level <- kout$level - 1 
print(kout)
#plot.bursts(kout)
kout
}



par(bg="cornsilk2")

bout <- burstiness()

plot(bout$start, bout$level, xlim=c(min(bout$start), max(bout$end)), type="p",
xlab="speech", ylab="level")
points(bout$end, bout$level, type="p")

segments(bout$start,bout$level, bout$end, bout$level)
segments(bout$start, bout$level, bout$start, bout$level)
segments(bout$end, bout$level, bout$end, bout$level)

bout.int <- subset(bout, bout$level!=0)

segments(bout.int$start, bout.int$level, bout.int$start, bout.int$level-1, lwd=2)
segments(bout.int$end, bout.int$level, bout.int$end, bout.int$level-1, lwd=2)

points(bout$start, bout$level, bg=bout$level+1, pch=21, col='black', cex=2)
points(bout$end, bout$level, bg=bout$level+1, pch=21, col='black', cex=2)

text(14000, 3,"boundary" , font=2)
#lev 1 - speech
#But they had something more definite than even a general instruction given to 
#the Boundary Commissioners

#lev 2 - speech
# What the hon. Member for Ennis (Mr. Kenny) asked was that the boundary should 
# be extended so as to include Castleconnell

#lev 3 -speech 
#had dealt very tenderly with the claims of the City of Westminster, the 
# proposed representation of which he had agreed to increase from three Members
#to four, although the City of Westminster had a population of nearly 40,000 
#less than the City of Dublin, which had only four Members allotted to it, 
#even with an extended boundary.

