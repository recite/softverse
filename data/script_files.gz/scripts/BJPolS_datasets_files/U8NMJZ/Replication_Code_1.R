##9/17/2015
##Replication_Code_1
##This script reproduces Fig 1, number of speeches by Gov and Oppn MPs 
##over time


rm(list=ls())


setwd("./../data/") # "C:/Users/as9934/Dropbox/HansardProject/burstiness/bjps_replication/data/")
load("paneldata.rdata")


sup <-   sort(unique(panel.data$session))

#function to find governing party in that session
gov.party <- function(x=subs){
  govp <- names(which.max(table(subs$party[subs$cabinet==1])))
  oppp <- names(table(subs$party))[names(table(subs$party))!=govp] 
  c(govp,oppp)
}

#number of govp mps
gov.mps <- c()
#number of govp speeches
gov.speeches <- c()

#number of opp mps
opp.mps <- c()

#number of opp speeeches
opp.speeches <- c()

#plot cols and characters
gov.cols <- c()
opp.cols <- c()
gov.pch <- c()
opp.pch <- c()


for(i in 1:length(sup)){
  subs <- subset(panel.data, panel.data$session==sup[i])
  
  #define gov party
  governing.party <-  gov.party(subs)[1]
  ifelse(governing.party=="L",gov.cols <- c(gov.cols,"gold"),gov.cols <- c(gov.cols, "lightblue"))
  ifelse(governing.party=="L",gov.pch<- c(gov.pch, 22), gov.pch <- c(gov.pch, 21))
  ifelse(governing.party=="L",opp.cols <- c(opp.cols,"lightblue"), opp.cols <- c(opp.cols, "gold"))
  ifelse(governing.party=="L",opp.pch<- c(opp.pch, 21), opp.pch <- c(opp.pch, 22))
  
  oppn.party <- gov.party(subs)[2]
  ifelse(governing.party!="L",gov.cols <- c(gov.cols,"lightblue"),gov.cols <- c(gov.cols, "gold"))
  ifelse(governing.party!="L",gov.pch<- c(gov.pch, 21), gov.pch <- c(gov.pch, 22))
  ifelse(governing.party!="L",opp.cols <- c(opp.cols,"gold"), opp.cols <- c(opp.cols, "lightblue"))
  ifelse(governing.party!="L",opp.pch<- c(opp.pch, 22), opp.pch <- c(opp.pch, 21))
  
  
  
  oppn.party <- gov.party(subs)[-c(1)]

  
    gov.mps <- c(gov.mps, sum(subs$party==governing.party) )
    gov.speeches <-c(gov.speeches, sum(subs[subs$party==governing.party,"speeches"]) )
  
    opp.mps <- c(opp.mps, sum(subs$party%in%oppn.party) )      
    opp.speeches <- c(opp.speeches, sum(subs[subs$party%in%oppn.party,"speeches"]) )
    
}

#do a summary plot - MPs and numbers of speeches
#gov
par(bg='cornsilk')
par(mar=c(4,4,2,4))
par(mfrow=c(2,1))

plot(1:length(sup), gov.mps, bg=gov.cols, col='black' ,  pch = gov.pch, cex=1.5, axes=F, xlab="", ylab="Govt MPs",
     ylim = c(min(opp.mps), max(gov.mps)))
axis(1, at=1:length(sup), labels= sup , las=2, cex.axis=.7)
axis(2)
box()
par(new=TRUE) 
plot(1:length(sup), gov.speeches, type ="l", axes=F, xlab="", ylab="", lwd=2, , ylim=c(0,max(gov.speeches))  ) 
axis(4)
mtext("Gov Speeches", side=4, line=3)


plot(1:length(sup), opp.mps, bg=opp.cols, col='black' ,  pch = gov.pch, cex=1.5, axes=F, xlab="", ylab="Oppn MPs",
     ylim = c(min(opp.mps), max(gov.mps)))
axis(1, at=1:length(sup), labels= sup , las=2, cex.axis=.7)
axis(2)
box()
par(new=TRUE) 
plot(1:length(sup), opp.speeches, type ="l", axes=F, xlab="", ylab="", lwd=2, ylim=c(0,max(gov.speeches)))
axis(4)
mtext("Oppn Speeches", side=4, line=3)



