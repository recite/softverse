##9/19/2015
##Replication_Code_7
## This script reproduces Fig 7 
##-- burstiness of Cabinet vs Oppn, and Cabinet vs Backbenchers
rm(list=ls())
setwd("./../data") # C:/Users/as9934/Dropbox/HansardProject/burstiness/bjps_replication/data")

#load the panel data (only the Cs and Ls for this script)
load("paneldata.rdata")

#go by session, draw plots
#note that we have party id as one column
# in each session, check what majority party is in terms of holding gov office
#--> have everyone else as oppn

#make dframe to take results
sup <-   sort(unique(panel.data$session))
df <- data.frame(session= sup,  cab.med=NA, 
                 oppn.med=NA,  
                 bb.med=NA)



#set all initial values to 1 so ratios are well defined.

#function to find governing party in that session
gov.party <- function(x=subs){
  govp <- names(which.max(table(subs$party[subs$cabinet==1])))
  oppp <- names(table(subs$party))[names(table(subs$party))!=govp] 
  c(govp,oppp)
}

#par(mar=c(1,4,2,2))

#gather boxplot info
min.boxes <- list()
opp.boxes <- list()
bac.boxes <- list()

#get colors of gov for later
cols <- c()

#get colors of oppn
ocols<- c()

#look at median cabinet vs median oppn as a ratio
for(i in 1:length(sup)){
  subs <- subset(panel.data, panel.data$session==sup[i])
  
  #define gov party
  governing.party <-  gov.party(subs)[1]
  if(governing.party=="L"){cols<-c(cols,"gold");ocols <- c(ocols, "lightblue")}
  if(governing.party!="L"){cols<-c(cols, "lightblue"); ocols <- c(ocols, "gold")}
  
  oppn.party <- gov.party(subs)[-c(1)]
  
  #define bbers as anyone without cabinet  or other office
  backbenchers <- subset(subs, subs$party==governing.party&subs$cabinet!=1&subs$non_cabinet!=1)
  opposition <- subset(subs, subs$party%in%oppn.party)
  

  ministers <- subset(subs, subs$cabinet==1)
  

  
  df[i,2]<- mean(ministers$burstiness.actual)
  df[i,3]<- mean(opposition$burstiness.actual)
  df[i,4]<- mean(backbenchers$burstiness.actual)
  
  
}


#plot mean ratio of cab:non cab
par(mfrow=c(2,1))
par(bg='cornsilk')

slist <- as.character( sup )
slist[length(slist)] <- "1910"
labs <-  gsub("_.*","",slist)

uni.sess <-  unique(gsub("_.*","",slist))
m <- match(uni.sess, labs)
labs2 <- rep(NA, length(labs) )
labs2[m] <- uni.sess

#do strucchange tests
require(strucchange)
bp.opp <- breakpoints((df[,2]/df[,3])~1)
bp.bb <- breakpoints((df[,2]/df[,4])~1)


plot(1:nrow(df), df[,2]/df[,3], col="black", type="l", axes=F, xlab="",
     ylab="mean burst ratio", main="Cabinet vs Opposition", xaxs="i")
axis(1, at=1:nrow(df), labels= labs2 , las=2, cex.axis=.7)
axis(2)
box()
ratio <- df[,2]/(df[,3])
lows <-lowess(ratio~1:nrow(df), f=.3)
lines(lows$x, lows$y, lwd=2, col="red")
#put breaks on
abline(v=bp.opp$breakpoints, lty=2, lwd=2)
text(34,30, labels=paste("mean=",round(mean(ratio[1:bp.opp$breakpoints]),d=2) ))
text(68, 30, labels=paste("mean=",round(mean(ratio[(bp.opp$breakpoints+1):length(ratio)]),d=2))) 



bb.ratio <- df[,2]/df[,4]
plot(1:nrow(df), df[,2]/df[,4], col="black", type="l", axes=F, xlab="",
     ylab="mean burst ratio", main="Cabinet vs Backbenchers", xaxs="i")
axis(1, at=1:nrow(df), labels=labs2, las=2, cex.axis=.7)
axis(2)
box()
lows.bb <- lowess(bb.ratio~ 1:nrow(df) , f=.3)
lines(lows.bb$x, lows.bb$y, lwd=2, col="red")


