##9/17/2015
##Replication_Code_5
## This script reproduces Fig 5-- bursty profile of some MPs over time

rm(list=ls())
setwd("./../data/members_over_time") # "C:/Users/as9934/Dropbox/HansardProject/burstiness/bjps_replication/data/members_over_time")

#do a rescale below
require(scales)

session.list<-c("1832_1", "1832_2", "1835_1", "1835_2", "1835_3", "1837_1", 
                "1837_2", "1837_3", "1837_4", "1841_1", "1841_2", "1841_3", "1841_4", 
                "1841_5", "1841_6", "1841_7", "1847_1", "1847_2", "1847_3", "1847_4", 
                "1847_5", "1852_1", "1852_2", "1852_3", "1852_4", "1852_5", "1857_1", 
                "1857_2", "1857_3", "1859_1", "1859_2", "1859_3", "1859_4", "1859_5", 
                "1859_6", "1859_7", "1865_1", "1865_2", "1865_3", "1868_1", "1868_2", 
                "1868_3", "1868_4", "1868_5", "1874_1", "1874_2", "1874_3", "1874_4", 
                "1874_5", "1874_6", "1874_7", "1880_1", "1880_2", "1880_3", "1880_4", 
                "1880_5", "1880_6", "1885_1", "1886_1", "1886_2", "1886_3", "1886_4", 
                "1886_5", "1886_6", "1886_7", "1892_1", "1892_2", "1892_3", "1892_4", 
                "1895_1", "1895_2", "1895_3", "1895_4", "1895_5", "1895_6", "1895_7", 
                "1900_1", "1900_2", "1900_3", "1900_4", "1900_5", "1900_6", "1906_1", 
                "1906_2", "1906_3", "1906_4", "1910A_1")


#get the members bursts file
session.list.csv <- paste("members_bursts_", session.list,".csv", sep="")

#member info
members <- read.csv("member_profile.csv")
 

get.bursts <- function(MP=3523){
  
  
  
  #get MP's actual name
  MP.name <- members$name[ match(MP, members[,1])  ]
  
  
  
  std.burst <- c()
  
  for ( i in 1:length(session.list)){
    rc <- read.csv(session.list.csv[i])
    
    #have to _aggregate_ bursts by MP first
    agged <-aggregate(rc$burst, list(MP=rc$MP), sum)
    out.rescale <- rescale(agged$x)
    #remember to match MP to his position in aggregated data      
    out.std <- out.rescale[match(MP, agged$MP)]
    if(is.na(out.std)==T){out.std<-0} #give MP a burstiness of 0, if NA
    std.burst <- c(std.burst, out.std)
  }                                 
  list(MP.name, std.burst)                                   
}

#par changes
par(bg="cornsilk1")
par(las=2)
par(mfrow=c(4,1))
par(mar=c(4,3,1,1))

slist <- session.list
slist[length(slist)] <- "1910"
labs <-  gsub("_.*","",slist)

uni.sess <-  unique(gsub("_.*","",slist))
m <- match(uni.sess, labs)
labs2 <- rep(NA, length(labs) )
labs2[m] <- uni.sess



#do Disraeli
disraeli <- get.bursts(MP=3523)

labs <-  gsub("_.*","",session.list)                   
plot(1:length(session.list),disraeli[[2]], axes=F, type="l", xlab="", xaxs="i",
     yaxs="i", ylab="Standardized Burst", ylim=c(0.001,1), col="black", lwd=2)
polygon(1:length(session.list), disraeli[[2]], col="blue")
axis(1, at=1:length(session.list), labels=labs2, cex.axis=1.2)
axis(2)
box()
text(1,.8,  labels=sub("Mr ","",disraeli[[1]]), pos=4, col="black", font=2, cex=1.6)

#do Gladstone
gladstone <- get.bursts(MP=3104)
plot(1:length(session.list),gladstone[[2]], axes=F, type="l", xlab="", xaxs="i",
     yaxs="i", ylab="Standardized Burst", ylim=c(0.001,1), col="black", lwd=2)
polygon(1:length(session.list), gladstone[[2]], col="gold")
axis(1, at=1:length(session.list), labels=labs2, cex.axis=1.2)
axis(2)
box()
text(1,.8, labels=sub("Mr ","",gladstone[[1]]), pos=4, col="black", font=2, cex=1.6)





#do Parnell
parnell <- get.bursts(MP=5542)
plot(1:length(session.list),parnell[[2]], axes=F, type="l", xlab="", xaxs="i",
     yaxs="i", ylab="Standardized Burst", ylim=c(0.001,1), col="black", lwd=2)
polygon(1:length(session.list), parnell[[2]], col="darkgreen")
axis(1, at=1:length(session.list), labels=labs2, cex.axis=1.2)
axis(2)
box()
text(1,.8, labels=sub("Mr ","",parnell[[1]]), pos=4, col="black", font=2, cex=1.6)

#do plimsoll 
plimsoll <- get.bursts(MP=5086)
plot(1:length(session.list), plimsoll[[2]], axes=F, type="l", xlab="", xaxs="i",
     yaxs="i", ylab="Standardized Burst", ylim=c(0.001,1), col="black", lwd=2)
polygon(1:length(session.list), plimsoll[[2]], col="red")
axis(1, at=1:length(session.list), labels=labs2, cex.axis=1.2)
axis(2)
box()
text(1,.8, labels=sub("Mr ","",plimsoll[[1]]), pos=4, col="black", font=2, cex=1.6)


