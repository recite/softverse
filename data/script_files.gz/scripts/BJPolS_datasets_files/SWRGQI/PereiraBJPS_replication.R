library(interplot); library(lmtest); library(xtable); library(stargazer)

setwd('INSERT PATH HERE')
lo<-read.csv('Learning_data.csv', stringsAsFactors = F)

#Subsetting to officials who opened the email
lot<-lo[lo$open==1,]

#Function to produce coefficient plots
cplots<-function(model,xrange,xlabel="Label"){
  est_info<-coef(model)[2]
  se_inf<-sqrt(vcov(model)[2,2])
  est_infodeb<-coef(model)[3]
  se_infdeb<-sqrt(vcov(model)[3,3])
  #Creating the coefficient plot
  par(mar=c(5,6,2,2))
  plot(seq(xrange[1],xrange[2], length.out = 2), 
       c(-2.25,-1.25), type='n',yaxt='n', ylab='',
       xlab=xlabel)
  abline(v=0,lty=2)
  pos<-c(-1.5,-2)
  cfs<-c(est_info,est_infodeb)
  ses<-c(se_inf,se_infdeb)
  axis(side=2,at=pos,labels=c('Other party', 'Bipartisan'),las=2,tick=F, cex.axis=.9)
  points(cfs,pos,pch=20)
  for (i in 1:2){
    segments(cfs[i]-1.96*ses[i],pos[i],
             cfs[i]+1.96*ses[i])
    segments(cfs[i]-1.65*ses[i],pos[i],
             cfs[i]+1.65*ses[i], lwd=2)
  }
}

#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure 1 (panel A)
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
m1<-lm(policy_interest~outpartisan+bipartisan_v0,lot)
cplots(model=m1,xrange=c(-.1,.02),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')


#%# Figure 1 (panel B)
m2<-lm(engagement_level~outpartisan+bipartisan_v0,lot)
cplots(model=m2,xrange=c(-.25,.05),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')


# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # APPENDIX B - SAMPLE
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table B2 - Differences between subjects who opened the email and subjects who did not open the email 
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#

#Dem vote share
t.test(lo$demshare_12[lo$open==0],lo$demshare_12[lo$open==1])
#Logged population
lo$log_pop<-log(lo$pop)
t.test(lo$log_pop[lo$open==0],lo$log_pop[lo$open==1])
#Source
lo$amos<-ifelse(lo$source=='amos',1,0)
t.test(lo$amos[lo$open==0],lo$amos[lo$open==1])
#Number of elected officials
t.test(lo$n_town[lo$open==0],lo$n_town[lo$open==1])
#Republican
lo$republican<-ifelse(lo$party=='Republican',1,0)
t.test(lo$republican[lo$open==0],lo$republican[lo$open==1])
#Democrat
lo$democrat<-ifelse(lo$party=='Democratic',1,0)
t.test(lo$democrat[lo$open==0],lo$democrat[lo$open==1])

# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # APPENDIX D - Descriptives and main results
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table D1 - Study participants by state
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#N
table(lot$st)
# Percentage
round(prop.table(table(lot$st)),5)

#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure D1
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
barplot(height = table(factor(lot$engagement_level, levels=0:6))/length(lot$engagement_level),
        ylab = "Proportion",
        xlab = "Number of clicks",
        main = "", ylim=c(0,.7))

#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table D2 - Balance tests
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
lot$treat4<-ifelse(lot$copartisan==1,1,ifelse(lot$outpartisan==1,2, ifelse(lot$bip==1,3,NA)))
lot$treat4<-as.factor(lot$treat4)
lot$treat4[lot$B_v1==1]<-NA # Dropping those cases with coding error
lot$amos<-ifelse(lot$source=='amos',1,0)
lot$republican<-ifelse(lot$party=='Republican',1,0)
lot$democrat<-ifelse(lot$party=='Democratic',1,0)

demshare_12<-c(summary(lot$demshare_12[lot$copartisan==1])[4],
               summary(lot$demshare_12[lot$outpartisan==1])[4],
               summary(lot$demshare_12[lot$bipartisan_v0==1])[4],
               summary(aov(demshare_12~treat4,lot))[[1]][["Pr(>F)"]][1])
population<-c(log(summary(lot$pop[lot$copartisan==1])[4]),
              log(summary(lot$pop[lot$outpartisan==1])[4]),
              log(summary(lot$pop[lot$B_v1==1])[4]),
              summary(aov(log(pop)~treat4,lot))[[1]][["Pr(>F)"]][1])
n_town<-c(summary(lot$n_town[lot$copartisan==1])[4],
          summary(lot$n_town[lot$outpartisan==1])[4],
          summary(lot$n_town[lot$bipartisan_v0==1])[4],
          summary(aov(n_town~treat4,lot))[[1]][["Pr(>F)"]][1])
amos<-c(summary(lot$amos[lot$copartisan==1])[4],
       summary(lot$amos[lot$outpartisan==1])[4],
       summary(lot$amos[lot$bipartisan_v0==1])[4],
       summary(aov(amos~treat4,lot))[[1]][["Pr(>F)"]][1])
republican<-c(summary(lot$republican[lot$copartisan==1])[4],
              summary(lot$republican[lot$outpartisan==1])[4],
              summary(lot$republican[lot$bip==1])[4],
              summary(aov(republican~treat4,lot))[[1]][["Pr(>F)"]][1])
democrat<-c(summary(lot$democrat[lot$copartisan==1])[4],
            summary(lot$democrat[lot$outpartisan==1])[4],
            summary(lot$democrat[lot$bip==1])[4],
            summary(aov(democrat~treat4,lot))[[1]][["Pr(>F)"]][1])

balance<-rbind(demshare_12, population,amos,n_town,republican, democrat)
xtable(balance)


#Likelihood ratio tests
# # # OWN v. OTHER
cases<-lot[,c('demshare_12','pop','amos','n_town','republican', 
              'democrat')]
m1<-glm(copartisan~demshare_12+ pop+amos+n_town+republican+ democrat,
        family="binomial",lot[lot$bip==0,])
m1n<-glm(copartisan~1,family="binomial",lot[lot$bip==0 & complete.cases(cases),])
lrtest(m1n,m1)

# # # OWN v. BIPARTISAN
m2<-glm(copartisan~demshare_12+ pop+amos+n_town+republican+ democrat,
        family=binomial,lot[lot$outpartisan==0,])
m2n<-glm(copartisan~1,family=binomial,lot[lot$outpartisan==0& complete.cases(cases),])
lrtest(m2n,m2)

# # # OTHER v. BIPARTISAN
m3<-glm(outpartisan~demshare_12+ pop+amos+n_town+republican+ democrat,
        family="binomial",lot[lot$copartisan==0,])
m3n<-glm(outpartisan~1,family="binomial",lot[lot$copartisan==0& complete.cases(cases),])
lrtest(m3n,m3)


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table D3 (Complement to Figure 1)
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
m1<-lm(policy_interest~outpartisan+bipartisan_v0,lot)
m2<-lm(engagement_level~outpartisan+bipartisan_v0,lot)
stargazer(m1,m2, no.space = T)


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table D4 - T-tests for differences in policy interest
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
t.test(lot$policy_interest[lot$copartisan==1], lot$policy_interest[lot$outpartisan==1])
t.test(lot$policy_interest[lot$bipartisan_v0==1], lot$policy_interest[lot$copartisan==1])
t.test(lot$policy_interest[lot$bipartisan_v0==1], lot$policy_interest[lot$outpartisan==1])


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Table D5 - T-tests for differences in policy engagement
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
t.test(lot$engagement_level[lot$copartisan==1], lot$engagement_level[lot$outpartisan==1]) #Significant
t.test(lot$engagement_level[lot$bipartisan_v0==1], lot$engagement_level[lot$copartisan==1])
t.test(lot$engagement_level[lot$bipartisan_v0==1], lot$engagement_level[lot$outpartisan==1])



# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # APPENDIX E - SENSITIVITY ANALYSES
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #

#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#$%# Figure E1 - Treatment effects excluding officials from competitive districts
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
lot$comp<-abs(.5-lot$demshare_12)
lot$comp_test<-ifelse(lot$comp>summary(lot$comp)[4],1,0)

# # # # Policy interest
m1<-lm(policy_interest~outpartisan+bipartisan_v0,lot[lot$comp_test==1,])
cplots(model=m1,xrange=c(-.15,.02),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')

# # # # Policy engagement
m2<-lm(engagement_level~outpartisan+bipartisan_v0,lot[lot$comp_test==1,])
cplots(model=m2,xrange=c(-.35,.05),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#$%# Table E1 - The effects of partisan endorsements for different measures of policy interest
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#Website
t.test(lot$web[lot$copartisan==1], lot$web[lot$outpartisan==1])
t.test(lot$web[lot$bipartisan_v0==1], lot$web[lot$copartisan==1])
t.test(lot$web[lot$bipartisan_v0==1], lot$web[lot$outpartisan==1])

#Newsletter
t.test(lot$news[lot$copartisan==1], lot$news[lot$outpartisan==1])
t.test(lot$news[lot$bipartisan_v0==1], lot$news[lot$copartisan==1])
t.test(lot$news[lot$bipartisan_v0==1], lot$news[lot$outpartisan==1])

#Social Media
t.test(lot$sm[lot$copartisan==1], lot$sm[lot$outpartisan==1])
t.test(lot$sm[lot$bipartisan_v0==1], lot$sm[lot$copartisan==1])
t.test(lot$sm[lot$bipartisan_v0==1], lot$sm[lot$outpartisan==1])


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#$%# Figure E2 - Effects of partisan endorsements by partisanship
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#

# # # # Policy interest (dems)
m1d<-lm(policy_interest~outpartisan+bipartisan_v0,lot[lot$dem_imputed==1,])
cplots(model=m1d,xrange=c(-.2,.07),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')
# # # # Policy engagement (dems)
m2d<-lm(engagement_level~outpartisan+bipartisan_v0,lot[lot$dem_imputed==1,])
cplots(model=m2d,xrange=c(-.4,.1),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')
# # # # Policy interest (reps)
m1r<-lm(policy_interest~outpartisan+bipartisan_v0,lot[lot$dem_imputed==0,])
cplots(model=m1r,xrange=c(-.2,.07),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')
# # # # Policy engagement (reps)
m2r<-lm(engagement_level~outpartisan+bipartisan_v0,lot[lot$dem_imputed==0,])
cplots(model=m2r,xrange=c(-.4,.1),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure E3 - Treatment effects with both versions of bipartisan endorsement
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#

# # # # Policy interest
m1<-lm(policy_interest~outpartisan+bip,lot)
cplots(model=m1,xrange=c(-.1,.02),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')
# # # # Policy engagement
m2<-lm(engagement_level~outpartisan+bip,lot)
cplots(model=m2,xrange=c(-.25,.05),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure E4 - Treatment effects with alternative measure of partisanship (based on 2016 election)
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
# # # # Policy interest
m1<-lm(policy_interest~outpartisan_2016+bipartisan_v0,lot)
cplots(model=m1,xrange=c(-.1,.02),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')
# # # # Policy engagement
m2<-lm(engagement_level~outpartisan_2016+bipartisan_v0,lot)
cplots(model=m2,xrange=c(-.25,.05),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')

#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure E5 - Treatment effects among same-party county majority in 2012 and 2016
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
# # # # Policy interest
lot$change<-ifelse(lot$outpartisan_2016==1 & lot$outpartisan_2012==0, 1,
                   ifelse(lot$outpartisan_2016==0 & lot$outpartisan_2012==1,1,0))

m1<-lm(policy_interest~outpartisan+bipartisan_v0,lot[lot$change==0,])
cplots(model=m1,xrange=c(-.1,.02),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')
# # # # Policy engagement
m2<-lm(engagement_level~outpartisan+bipartisan_v0,lot[lot$change==0,])
cplots(model=m2,xrange=c(-.25,.05),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')


#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
#%# Figure E6 - ITT
#%##%##%##%##%##%##%##%##%##%##%##%##%##%##%##%#
m1<-lm(policy_interest~outpartisan+bip,lo)
cplots(model=m1,xrange=c(-.05,.005),
       xlabel = 'Effect on Policy Interest\n(baseline = same party endorsement)')

m2<-lm(engagement_level~outpartisan+bip,lo)
cplots(model=m2,xrange=c(-.1,.02),
       xlabel = 'Effect on Policy Engagement\n(baseline = same party endorsement)')

# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # APPENDIX F - RESULTS BY DISTRICT COMPETITIVENESS
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #
# % # % # % # % # % # % # % # % # % # % # % # % # % # % # % # % #

lot$comp<-abs(.5-lot$demshare_12)

#%# FIGURE F1 (panel a)
zbip1<-lm(policy_interest~bipartisan_v0*comp+outpartisan*comp, lot)
interplot(zbip1,'bipartisan_v0','comp', rfill='mediumseagreen', xmin=0, xmax=0.4, hist=T, ci=.9)+
  xlim(0,0.4)+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),plot.title = element_text(hjust = 0.5),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of bipartisan policy\n(baseline = same party)")+
  # ggtitle('Marginal effect of Same Party by Electoral Competitiveness')+
  xlab("Presidential Vote Margin")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='aquamarine4')

#%# FIGURE F1 (panel b)
zbip2<-lm(policy_interest~bipartisan_v0*comp+copartisan*comp, lot)
interplot(zbip2,'bipartisan_v0','comp', rfill='mediumseagreen', xmin=0, xmax=0.4, hist=T, ci=.9)+
  xlim(0,0.4)+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),plot.title = element_text(hjust = 0.5),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of bipartisan policy\n(baseline = other party)")+
  # ggtitle('Marginal effect of Same Party by Electoral Competitiveness')+
  xlab("Presidential Vote Margin")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='aquamarine4')

#%# FIGURE F1 (panel c)
zbip1<-lm(engagement_level~bipartisan_v0*comp+outpartisan*comp, lot)
interplot(zbip1,'bipartisan_v0','comp', rfill='mediumseagreen', xmin=0, xmax=0.4, hist=T, ci=.9)+
  xlim(0,0.4)+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),plot.title = element_text(hjust = 0.5),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of bipartisan policy\n(baseline = same party)")+
  # ggtitle('Marginal effect of Same Party by Electoral Competitiveness')+
  xlab("Presidential Vote Margin")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='aquamarine4')

#%# FIGURE F1 (panel d)
zbip2<-lm(engagement_level~bipartisan_v0*comp+copartisan*comp, lot)
interplot(zbip2,'bipartisan_v0','comp', rfill='mediumseagreen', xmin=0, xmax=0.4, hist=T, ci=.9)+
  xlim(0,0.4)+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),plot.title = element_text(hjust = 0.5),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of bipartisan policy\n(baseline = other party)")+
  # ggtitle('Marginal effect of Same Party by Electoral Competitiveness')+
  xlab("Presidential Vote Margin")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='aquamarine4')

