################################################################################
################################################################################
######## Are All "Birthers" Conspiracy Theorists?: On the Relationship #########
########## Between Conspiratorial Thinking and Political Orientations ##########
################################################################################
################################################################################
############ Adam M. Enders, Steven M. Smallpage, Robert N. Lupton #############
################################################################################
################################################################################
  
require(lattice)
require(MASS)
require(foreign)

#######################################################################################

### Study 1 ###

# Read in "cononly-anes.dta" using "read.dta" function in "Forgeign" package
# Call new dataset "con.data"
head(con.data)


# Distributions of conspiracy questions (Figure 1)
histogram(~as.factor(born) | as.factor(rep), data = con.data,
          xlab = "",
          ylim = c(-2, 69),
          aspect = 1,
          main = "A. Birther",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)


histogram(~as.factor(endlife) | as.factor(rep), data = con.data,
          xlab = "",
          ylim = c(-2, 69),
          aspect = 1,
          main = "B. Death Panel",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)


histogram(~as.factor(gov911) | as.factor(rep), data = con.data,
          xlab = "",
          ylim = c(-2, 69),
          aspect = 1,
          main = "C. Truther",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)


histogram(~as.factor(levees) | as.factor(rep), data = con.data,
          xlab = "",
          ylim = c(-2, 69),
          aspect = 1,
          main = "D. Levee Breach",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)


#######################################################################################

### Study 2 ###

# Read in "cononly-mturk.dta" using "read.dta" function in "Forgeign" package
# Call new dataset "mturkdata"
head(mturkdata)


# Distributions of conspiracy questions (Figure 3)
histogram(~as.factor(birtherbelief) | as.factor(rep), data = mturkdata,
          xlab = "",
          ylim = c(-1, 26),
          aspect = 1,
          main = "A. Birther",
          groups = as.factor(rep2),
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25)),
)

histogram(~as.factor(jfkbelief) | as.factor(rep), data = mturkdata,
          xlab = "",
          ylim = c(-1, 26),
          aspect = 1,
          main = "B. JFK",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)

histogram(~as.factor(trutherbelief) | as.factor(rep), data = mturkdata,
          xlab = "",
          ylim = c(-1, 26),
          aspect = 1,
          main = "C. Truther",
          strip = strip.custom(factor.levels=c("Democrat", "Republican")),          
          scales=list(
            x=list(labels=c("Def. Not True","Prob. Not True",
                            "Prob. True","Def. True"), rot=25))
)


#######################################################################################

### Supplemental Appendix ###

# Distribution of general conspiracy orientation questions (Figure A1)
stacked <- stack(as.data.frame(cbind(mturkdata$lies, mturkdata$outsideint,
                                     mturkdata$accident, mturkdata$secrets)))
stacked2 <- subset(stacked, values != "NA")

histogram(~as.factor(values) | ind, data = stacked2,
          main = "",
          xlab = "",          
          ylim = c(-2, 80),
          index.cond=list(c(3,4,1,2)),
          strip = strip.custom(factor.levels=c("Politicians Lie", "Outside Interests",  
                                               "No Accidents", "Secret Designs")),
          scales=list(
            x=list(labels=c("Strongly Disagree","Somewhat Disagree","Neither/Nor", 
                            "Somewhat Agree","Strongly Agree"), rot=25)),
          aspect = 1
)





