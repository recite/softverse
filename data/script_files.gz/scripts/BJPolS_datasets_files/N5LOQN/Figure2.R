######################################################
##Replication file for "Hafner-Burton, Hyde and Jablonski. 
##Surviving Elections: Election Violence, Incumbent Victory, and Post-Election Repercussions" 
##British Journal of Political Science. Accepted November 2015
##
##Plots Figure 2 (data estimated in Table 2-5.do)
##Run on R 2.14.2
######################################################

rm(list = ls())


coef.vec <-  c(.18257948, .18470549, .4894075, .05351984, .32227539,  -.15301059, -.10081487, .1145104, -0.343919, -.38137909, -.10924415)
upper.vec<- c(.32022139, .33562406, .67636592, .3477947, .66026397, .31457719,    .27541854, .62891226, -.23321222, -.16705916, .60865868)
lower.vec<- c(.04493757, .03378692, .30244907, -.24075502, -.01571318, -.62059837,-.47704827, -.39989146, -.46249182, -.59569901, -.82714698)

var.names <- c("Pre-Election Violence", "Fraud", "Physical Integrity", "Leader Age", "Leader Tenure", "Civil War", "GDP (log)", "Population (log)", "Victory Uncertain", "Polity2", "Demonstrations")


ylimits=c(.25,13.25)
maintitle="The Effect of Pre-Election Violence\n on Election Outcomes"

tiff("h:\\plot.tif",width=3900,height=3000)
    
y.axis <- c(length(coef.vec):1)#create indicator for y.axis, descending so that R orders vars from top to bottom on y-axis

font.type=7
par(mar=c(7, 15, 3, 3), 
	font.main=font.type,
	font.axis=font.type,
	font.lab=font.type,
	font.sum=font.type,
	font=font.type,
	cex=6)


plot(coef.vec, y.axis, axes = F, type = "p", ylab = "", xlab = "",pch = 19, cex = 1.5, xlim = c(-.75,.75), ylim=ylimits,xaxs = "r") 

mtext(text="Change in Victory Probability", side=1, padj=2.5, cex=9, font=(font.type+1))
mtext(text="Pr(Y=1|X=max(X)) - Pr(Y=1|X=min(X))", side=1, padj=4.9, cex=9, font=font.type)


segments(lower.vec, y.axis, upper.vec, y.axis, lwd =  12, col=c("black", "black", "black", "black", "black", "black", "black", "black", "black", "black", "black"))

points(coef.vec, y.axis, type = "p", pch = 19, cex = 2)


axis(1, at = seq(-.75,.75,by=.25), tick = T,#draw x-axis and labels with tick marks
   cex.axis = 2, mgp = c(2,.6,0))#reduce label size, moves labels closer to tick marks    

axis(2, at = y.axis, label = var.names, las = 1, tick = T, ,mgp = c(2,.6,0),
    cex.axis = 1.8, lwd=5) #draw y-axis with tick marks, make labels perpendicular to axis and closer to axis

segments(0,0,0,17,lty=2, lwd=5) # draw dotted line through 0
box(bty = "l", lwd=5) #place box around plot



dev.off()


    
