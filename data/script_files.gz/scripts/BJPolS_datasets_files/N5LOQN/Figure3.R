######################################################
##Replication file for "Hafner-Burton, Hyde and Jablonski. 
##Surviving Elections: Election Violence, Incumbent Victory, and Post-Election Repercussions" 
##British Journal of Political Science. Accepted November 2015
##
##Plots Figure 3 (data estimated in Table 2-5.do)
##Run on R 2.14.2
######################################################

rm(list = ls())

coef.vec <- c(.3272372441545383,.8446870314644079,.51690228182108,.7886571139911437)
lower.vec<- c(.2359726319166749,.6639997874004634,.4077004267635752,.6342726359997259)
upper.vec<- c(.4185018563924018,1.025374275528352,.6261041368785848,.9430415919825614)

var.names <- c("No Boycott", "Boycott", "No Boycott","Boycott")
xlimits=c(.25,2.75)
ylimits=c(0,1)
maintitle="The Effect of Pre-Election Violence\n on Voting"

tiff("h:\\turnout.tif",width=3900,height=3000)
    
x.axis <- c(.5,1,2,2.5)#create indicator for x.axis, descending so that R orders vars from top to bottom on y-axis
x.axis.labels <- c(.5,1,2,2.5)

font.type=7
par(mar=c(15, 7, 3, 3), 
	font.main=font.type,
	font.axis=font.type,
	font.lab=font.type,
	font=font.type,
	cex=6)


plot(x.axis, coef.vec, axes = F, type = "p", ylab = "", xlab = "",pch = 19, cex = 1.5, xlim = xlimits, ylim=ylimits,xaxs = "r") 

mtext(text="Pr(Incumbent Wins)", side=2, padj=-2, cex=11, font=(font.type))

mtext(text="Pre-Election Violence=0", at=mean(c(x.axis[1], x.axis[2])), side=3, cex=9, font=font.type)
mtext(text="Pre-Election Violence=1", at=mean(c(x.axis[3], x.axis[4])), side=3, cex=9, font=font.type)


segments( x.axis, lower.vec, x.axis, upper.vec,  lwd =  12, col=c("grey50","grey50","black","black"))
points(x.axis,coef.vec, type = "p", pch = 19, cex = 2, col=c("grey50","grey50","black","black"))


axis(2, at = seq(0,1,by=.25), tick = T,#draw x-axis and labels with tick marks
   cex.axis = 1.5, mgp = c(2,.6,0))#reduce label size, moves labels closer to tick marks    

axis(1, at = x.axis.labels, label = var.names, las = 2, tick = T, ,mgp = c(2,.6,0),
    cex.axis = 1.8, lwd=5) #draw y-axis with tick marks, make labels perpendicular to axis and closer to axis

segments(median(xlimits),-1,median(xlimits),17,lty=1, lwd=5) # draw dotted line through 0

box(bty = "l", lwd=5) #place box around plot
dev.off()


    
