
covariates <- select(data_black, stopped, searched_arrested, contacted, 
                     employed, unemployed, parttime,student, not_working, retired, distance_garner,
                     `16-21`, `22-24`, `25-34`, `35-44`, `45-54`, `55-64`,
                     `65-74`, `75+`, borough)
control_table <- t(apply(X = select(covariates, -distance_garner, -borough), MARGIN = 2, FUN = cov_tab, 
                         forcing = covariates$distance_garner, cluster=covariates$borough))
control_table
