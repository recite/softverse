#Set working directory
setwd()

## empty memory (!)
rm(list=ls())

library(tidyverse)

df <- readstata13::read.dta13("./data.dta")

# Table 1

m_coh <- lm(votechoiceR1 %in% c("AfD", "GRUENE") ~ openlist2 * info, df, subset = openlist2 != "")
m_CDU <- lm(votechoiceR1 == "Union" ~ openlist2 * info, df, subset = openlist2 != "")
m_SPD <- lm(votechoiceR1 == "SPD" ~ openlist2 * info, df, subset = openlist2 != "")
m_AfD <- lm(votechoiceR1 == "AfD" ~ openlist2 * info, df, subset = openlist2 != "")
m_GRU <- lm(votechoiceR1 == "GRUENE" ~ openlist2 * info, df, subset = openlist2 != "")
m_FDP <- lm(votechoiceR1 == "FDP" ~ openlist2 * info, df, subset = openlist2 != "")
m_LIN <- lm(votechoiceR1 == "DIE LINKE" ~ openlist2 * info, df, subset = openlist2 != "")

texreg::texreg(list(m_coh, m_GRU, m_LIN, m_SPD, m_FDP, m_CDU, m_AfD),
               file = "./tables/tab1.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("Cohesive Parties", "Greens", "Left", "SPD", "FDP", "CDU/CSU", "AfD"),
               custom.coef.names = c(NA, "Open List", "Information", "Open List x Info."),
               leading.zero = T,
               custom.note = "",
               label = "t:replication",
               caption_above = F,
               caption = "Effects of ballot type and information. Coefficients estimated from a linear regression of ballot type (open vs. closed list), provision of information (yes vs. no), and its interaction on party choice (binary indicator whether party in model header is voted for). Entries are unstandardized regression coefficients from linear regression models. Standard errors in parentheses. $^{*} p < 0.05$, $^{**} p < 0.01$, $^{***} p < 0.001$.")

#Table A7

m_h1multnom <- nnet::multinom(votechoiceR1 ~ openlist2 * info, df, subset = openlist2 != "")

texreg::texreg(list(m_h1multnom),
               beside = T,
               file = "./tables/tabA7.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("CDU/CSU", "Left",  "FDP", "Greens", "SPD"),
               custom.coef.names = c(NA, "Open List", "Information", "Open List x Information"),
               leading.zero = T,
               label = "t:replicationMultinom",
               caption = "Effects of ballot type and information. Coefficients estimated from a multinomial logistic regression of ballot type (open vs. closed list), provision of information (yes vs. no) and its interaction on party choice (binary indicator whether party in model header is voted for). Entries stem from multinomial logistic regression. Standard errors in parentheses. $^{*} p < 0.05$, $^{**} p < 0.01$, $^{***} p < 0.001$.")

# Table A1

psych::describe(df$age)

table(df$edu3)
psych::describe(df$edu3 == "Lo")
psych::describe(df$edu3 == "Me")
psych::describe(df$edu3 == "Hi")

table(df$employ2)
psych::describe(df$employ2 == "Employed")

df$inc2 <- ifelse(df$inc %in% c("Dont know", "Keine Angabe"), NA, df$inc)
table(df$inc2)
psych::describe(df$inc2)

table(df$gender)
psych::describe(df$gender == "Female")

table(df$polInt)
psych::describe(as.numeric(df$polInt))

table(df$region)
psych::describe(df$region == "West")
psych::describe(df$region == "East")
psych::describe(df$region == "Bavaria")

df$immigration_rev <- abs(df$immigration - 10)
psych::describe(df$immigration_rev)

# Figure A1

ggplot(df, aes(x=immigration_rev)) + 
  geom_bar() +
  theme_bw() +
  labs(x="Immigration", y = "Count") +
  scale_x_continuous(breaks = c(0:10))

ggsave("./figures/FigA1.png", dpi = 100)


# Tables A4 - A6

bal_age <- lm(age ~ openlist2 * info, df, subset = openlist2 != "")
bal_gender <- lm(gender=="Female" ~ openlist2 * info, df, subset = openlist2 != "")
bal_inc <- lm(incNum ~ openlist2 * info, df, subset = openlist2 != "")
bal_employ <- lm(employ2=="Employed" ~ openlist2 * info, df, subset = openlist2 != "")
bal_edu3  <- lm(edu3=="Lo" ~ openlist2 * info, df, subset = openlist2 != "")
bal_regE <-  lm(region=="East" ~ openlist2 * info, df, subset = openlist2 != "")

bal_AfD <- lm(SM_AfD ~ openlist2 * info, df, subset = openlist2 != "")
bal_CDU <- lm(SM_CDU ~ openlist2 * info, df, subset = openlist2 != "")
bal_SPD <- lm(SM_SPD ~ openlist2 * info, df, subset = openlist2 != "")
bal_Gru <- lm(SM_Gru ~ openlist2 * info, df, subset = openlist2 != "")
bal_FDP <- lm(SM_FDP ~ openlist2 * info, df, subset = openlist2 != "")
bal_LIN <- lm(SM_LIN ~ openlist2 * info, df, subset = openlist2 != "")

bal_polInt <- lm(as.numeric(polInt) ~ openlist2 * info, df, subset = openlist2 != "")
bal_imm <- lm(immigration_rev ~ openlist2 * info, df, subset = openlist2 != "")
bal_lr <- lm(left_right ~ openlist2 * info, df, subset = openlist2 != "")

texreg::texreg(list(bal_age, bal_gender, bal_edu3, bal_employ, bal_inc, bal_regE),
               file = "./tables/tabA4.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("Age", "Gender", "Education", "Employment", "Income", "Region = East"),
               custom.coef.names = c(NA, "Open List", "Information", "Open List x Information"),
               leading.zero = T,
               label = "t:balance_demo",
               float.pos = "htb",
               caption = "Balance test: Demographics")


texreg::texreg(list(bal_CDU, bal_SPD, bal_AfD, bal_Gru, bal_FDP, bal_LIN),
               file = "./tables/tabA5.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("CDU/CSU", "SPD", "AfD", "Greens", "FDP", "Left"),
               custom.coef.names = c(NA, "Open List", "Information", "Open List x Information"),
               leading.zero = T,
               label = "t:balance_scalometer",
               float.pos = "htb",
               caption = "Balance test: Scalometer")

texreg::texreg(list(bal_imm, bal_lr, bal_polInt),
               file = "./tables/tabA6.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("Immigration", "Left-Right Self-Placement", "Political Interest"),
               custom.coef.names = c(NA, "Open List", "Information", "Open List x Information"),
               leading.zero = T,
               label = "t:balance_politics",
               float.pos = "htb",
               caption = "Balance test: Political Variables")

#Figure A3

list_models <- ls(pattern = "bal_")

dv <- NA
pValue <- NA

for (i in 1:length(list_models)){
  m <- get(list_models[i])
  pValue[i] <- pf(summary(m)$fstatistic[1],summary(m)$fstatistic[2],summary(m)$fstatistic[3],lower.tail=FALSE)
  dv[i] <- substr(list_models[i], 5, nchar(list_models[i]))
}

df_balance <- data.frame(pValue, dv)
df_balance <- df_balance[order(df_balance$pValue),]
df_balance$x <- seq(0,1, length.out = length(list_models))
df_balance$dv <- factor(df_balance$dv,
                        levels = sort(unique(df_balance$dv)),
                        labels = c("AfD", "Age", "CDU", "Education",
                                   "Employment", "FDP", "Gender", "Greens",
                                   "Immigration", "Income", "LEFT",
                                   "Left-Right", "Pol. Interest", "East",
                                   "SPD"))

ggplot(df_balance, aes(x=x, y=pValue)) +
  geom_point() +
  geom_abline(slope = 1, intercept = 0, lty = "dashed") +
  geom_text(aes(label=dv),hjust=0, vjust=1) +
  theme_bw() +
  labs(x="Uniform distribution", y= "p-Values") +
  ylim(c(0,1))  +
  theme(text = element_text(size = 16))

ggsave("./figures/figA3.png", dpi = 100)

#Table A9

m_cohPLUS <- lm(votechoiceR1 %in% c("AfD", "GRUENE") ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_CDUPLUS <- lm(votechoiceR1 == "Union" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_SPDPLUS <- lm(votechoiceR1 == "SPD" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_AfDPLUS <- lm(votechoiceR1 == "AfD" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_GRUPLUS <- lm(votechoiceR1 == "GRUENE" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_FDPPLUS <- lm(votechoiceR1 == "FDP" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))
m_LINPLUS <- lm(votechoiceR1 == "DIE LINKE" ~ treatmentR1, df, subset = treatmentR1 %in% c("OpenInfo", "OpenInfo+"))

texreg::texreg(list(m_cohPLUS, m_GRUPLUS, m_LINPLUS, m_SPDPLUS, m_FDPPLUS, m_CDUPLUS, m_AfDPLUS),
               file = "./tables/tabA9.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("Cohesive Parties", "Greens", "Left", "SPD", "FDP", "CDU/CSU", "AfD"),
               custom.coef.names = c(NA, "Open Info +"),
               custom.note = "",
               leading.zero = T,
               label = "t:Emphasisframe",
               caption = "Effects of emphasis frame. Estimates draw on subsample of respondents receiving both the open list and information  treatment, while 50\\% also received an emphasis frame. Coefficients estimated from a linear regression of the emphasis frame indicator (yes vs. no) on party choice (binary indicator whether party in model header is voted for). Entries are unstandardized regression coefficients from linear regression models. Standard errors in parentheses. $^{*} p < 0.05$, $^{**} p < 0.01$, $^{***} p < 0.001$.")


#Table A10

df_plusT <- subset(df, treatmentR1 %in% c("OpenInfo", "OpenInfo+"))

df_plusT$treatmentR1 <- factor(df_plusT$treatmentR1,
                               levels = c("OpenInfo", "OpenInfo+"))

df_plusT$time_infoR1 <- ifelse(df_plusT$time_infoR1 > 200, 60, df_plusT$time_infoR1)
#some respondents stopped and waited for quite some time; we restrict this.


m_homoPLUST <- lm(votechoiceR1 %in% c("AfD", "GRUENE") ~ treatmentR1 * time_infoR1, df_plusT)
m_CDUPLUST <- lm(votechoiceR1 == "Union" ~ treatmentR1 * time_infoR1, df_plusT)
m_SPDPLUST <- lm(votechoiceR1 == "SPD" ~ treatmentR1 * time_infoR1, df_plusT)
m_AfDPLUST <- lm(votechoiceR1 == "AfD" ~ treatmentR1 * time_infoR1, df_plusT)
m_GRUPLUST <- lm(votechoiceR1 == "GRUENE" ~ treatmentR1 * time_infoR1, df_plusT)
m_FDPPLUST <- lm(votechoiceR1 == "FDP" ~ treatmentR1 * time_infoR1, df_plusT)
m_LINPLUST <- lm(votechoiceR1 == "DIE LINKE" ~ treatmentR1 * time_infoR1, df_plusT)


texreg::texreg(list(m_homoPLUST, m_GRUPLUST, m_LINPLUST, m_SPDPLUST, m_FDPPLUST, m_CDUPLUST, m_AfDPLUST),
               file = "./tables/tabA10.tex",
               stars = c(0.05,0.01,0.001),
               digits = 2,
               custom.model.names = c("Cohesive Parties", "Greens", "Left", "SPD", "FDP", "CDU/CSU", "AfD"),
               custom.coef.names = c(NA, "Open Info +", "Time on information page", "Open Info + x Time"),
               custom.note = "",
               leading.zero = T,
               label = "t:EmphasisframexTime",
               caption = "Effects of emphasis frame interacted with time. Estimates draw on subsample of respondents receiving both the open list and information  treatment, while 50\\% also received an emphasis frame. Coefficients estimated from a linear regression of the emphasis frame indicator (yes vs. no) on party choice (binary indicator whether party in model header is voted for). Entries are unstandardized regression coefficients from linear regression models. Standard errors in parentheses. $^{*} p < 0.05$, $^{**} p < 0.01$, $^{***} p < 0.001$.")

rm(df_plusT)

