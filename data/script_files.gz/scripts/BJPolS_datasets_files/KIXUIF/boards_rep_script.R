## set path to replication folder
curcomp <- c("~/Dropbox/boards_rep_v2")
setwd(curcomp)

# do not print warnings [(particularly NAs introduced by coercion in as.numeric()...)]
options(warn=-1) # set to options(warn=0) to restore warnings

## scripts replicating data cleaning and assembly
source("clean_data_script.R")

## scripts replicating results in main text and supplementary materials
source("analysis_script.R")

