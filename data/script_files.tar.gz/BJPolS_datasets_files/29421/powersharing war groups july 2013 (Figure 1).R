
#This file creates Figure 1 for:
#Strøm, Kaare, Scott Gates, Benjamin A.T. Graham and Håvard Strand. “Inclusion, Dispersion, and Constraint: Powersharing in the World’s States, 1975-2010.” 

rm(list=ls(all=TRUE))
setwd("/Users/bengraham1/Dropbox/Collaborative Research/Powersharing/Dataset Introduction Paper/Country Year Data/")
#setwd("/Users/lynnta/Desktop/1--Alldata")
library(foreign)
library(Hmisc)
d <- read.dta("for conflict pic June2013.dta")

attach(d)

#group1 = civilwar
#group2 = postconflict(10yr)
#group3 = non-conflict


#war groups
incwar_mean<- mean(na.omit(d$inclusive[d$wargroup==1]))
incpost_mean<- mean(na.omit(d$inclusive[d$wargroup==2]))
incnowar_mean<- mean(na.omit(d$inclusive[d$wargroup==3]))
incmeans<-c(incwar_mean, incpost_mean, incnowar_mean)

funcwar_mean<- mean(na.omit(d$funcdisp[d$wargroup==1]))
funcpost_mean<- mean(na.omit(d$funcdisp[d$wargroup==2]))
funcnowar_mean<- mean(na.omit(d$funcdisp[d$wargroup==3]))
funcmeans<-c(funcwar_mean, funcpost_mean, funcnowar_mean)

terrwar_mean<- mean(na.omit(d$terrdisp[d$wargroup==1]))
terrpost_mean<- mean(na.omit(d$terrdisp[d$wargroup==2]))
terrnowar_mean<- mean(na.omit(d$terrdisp[d$wargroup==3]))
terrmeans<-c(terrwar_mean, terrpost_mean, terrnowar_mean)

incwar_sd<- sd(na.omit(d$inclusive[d$wargroup==1]))
incpost_sd<- sd(na.omit(d$inclusive[d$wargroup==2]))
incnowar_sd<- sd(na.omit(d$inclusive[d$wargroup==3]))
incsds<-c(incwar_sd, incpost_sd, incnowar_sd)

funcwar_sd<- sd(na.omit(d$funcdisp[d$wargroup==1]))
funcpost_sd<- sd(na.omit(d$funcdisp[d$wargroup==2]))
funcnowar_sd<- sd(na.omit(d$funcdisp[d$wargroup==3]))
funcsds<-c(funcwar_sd, funcpost_sd, funcnowar_sd)

terrwar_sd<- sd(na.omit(d$terrdisp[d$wargroup==1]))
terrpost_sd<- sd(na.omit(d$terrdisp[d$wargroup==2]))
terrnowar_sd<- sd(na.omit(d$terrdisp[d$wargroup==3]))
terrsds<-c(terrwar_sd, terrpost_sd, terrnowar_sd)

stderr <- function(x) sqrt(var(x,na.rm=TRUE)/length(na.omit(x)))


incwar_se<- stderr(inclusive[wargroup==1])
incpost_se<- stderr(inclusive[wargroup==2])
incnowar_se<- stderr(inclusive[wargroup==3])
incses<-c(incwar_se, incpost_se, incnowar_se)

funcwar_se<- stderr(funcdisp[wargroup==1])
funcpost_se<-stderr(funcdisp[wargroup==2])
funcnowar_se<- stderr(funcdisp[wargroup==3])
funcses<-c(funcwar_se, funcpost_se, funcnowar_se)

terrwar_se<- stderr(terrdisp[wargroup==1])
terrpost_se<- stderr(terrdisp[wargroup==2])
terrnowar_se<- stderr(terrdisp[wargroup==3])
terrses<-c(terrwar_se, terrpost_se, terrnowar_se)






#conflict groups
incconflict_mean<- mean(na.omit(d$inclusive[d$conflictgroup==1]))
incpostcon_mean<- mean(na.omit(d$inclusive[d$conflictgroup==2]))
incnoconflict_mean<- mean(na.omit(d$inclusive[d$conflictgroup==3]))
incconmeans<-c(incconflict_mean, incpostcon_mean, incnoconflict_mean)

funcconflict_mean<- mean(na.omit(d$funcdisp[d$conflictgroup==1]))
funcpostcon_mean<- mean(na.omit(d$funcdisp[d$conflictgroup==2]))
funcnoconflict_mean<- mean(na.omit(d$funcdisp[d$conflictgroup==3]))
funcconmeans<-c(funcconflict_mean, funcpostcon_mean, funcnoconflict_mean)

terrconflict_mean<- mean(na.omit(d$terrdisp[d$conflictgroup==1]))
terrpostcon_mean<- mean(na.omit(d$terrdisp[d$conflictgroup==2]))
terrnoconflict_mean<- mean(na.omit(d$terrdisp[d$conflictgroup==3]))
terrconmeans<-c(terrconflict_mean, terrpostcon_mean, terrnoconflict_mean)

incconflict_sd<- sd(na.omit(d$inclusive[d$conflictgroup==1]))
incpostcon_sd<- sd(na.omit(d$inclusive[d$conflictgroup==2]))
incnoconflict_sd<- sd(na.omit(d$inclusive[d$conflictgroup==3]))
incconsds<-c(incconflict_sd, incpostcon_sd, incnoconflict_sd)

funcconflict_sd<- sd(na.omit(d$funcdisp[d$conflictgroup==1]))
funcpostcon_sd<- sd(na.omit(d$funcdisp[d$conflictgroup==2]))
funcnoconflict_sd<- sd(na.omit(d$funcdisp[d$conflictgroup==3]))
funcconsds<-c(funcconflict_sd, funcpostcon_sd, funcnoconflict_sd)

terrconflict_sd<- sd(na.omit(d$terrdisp[d$conflictgroup==1]))
terrpostcon_sd<- sd(na.omit(d$terrdisp[d$conflictgroup==2]))
terrnoconflict_sd<- sd(na.omit(d$terrdisp[d$conflictgroup==3]))
terrconsds<-c(terrconflict_sd, terrpostcon_sd, terrnoconflict_sd)

incconflict_se<- stderr(inclusive[conflictgroup==1])
incpostcon_se<- stderr(inclusive[conflictgroup==2])
incnoconflict_se<- stderr(inclusive[conflictgroup==3])
incses<-c(incwar_se, incpost_se, incnowar_se)

funcconflict_se<- stderr(funcdisp[conflictgroup==1])
funcpostcon_se<-stderr(funcdisp[conflictgroup==2])
funcnoconflict_se<- stderr(funcdisp[conflictgroup==3])
funcses<-c(funcconflict_se, funcpostcon_se, funcnoconflict_se)

terrconflict_se<- stderr(terrdisp[conflictgroup==1])
terrpostcon_se<- stderr(terrdisp[conflictgroup==2])
terrnoconflict_se<- stderr(terrdisp[conflictgroup==3])
terrses<-c(terrconflict_se, terrpostcon_se, terrnoconflict_se)


warmeans <- rbind(incmeans, funcmeans, terrmeans)

conflictmeans <- rbind(incconmeans, funcconmeans, terrconmeans)




groupmeans <- c(incnowar_mean, funcnowar_mean, terrnowar_mean, incpost_mean, funcpost_mean, terrpost_mean, incwar_mean, funcwar_mean, terrwar_mean)

congroupmeans <- c(incnoconflict_mean, funcnoconflict_mean, terrnoconflict_mean, incpostcon_mean, funcpostcon_mean, terrpostcon_mean, incconflict_mean, funcconflict_mean, terrconflict_mean)

groupsds <- c(incnowar_sd, funcnowar_sd, terrnowar_sd, incpost_sd, funcpost_sd, terrpost_sd, incwar_sd, funcwar_sd, terrwar_sd)

congroupsds <- c(incnoconflict_sd, funcnoconflict_sd, terrnoconflict_sd, incpostcon_sd, funcpostcon_sd, terrpostcon_sd, incconflict_sd, funcconflict_sd, terrconflict_sd)


groupses <- c(incnowar_se, funcnowar_se, terrnowar_se, incpost_se, funcpost_se, terrpost_se, incwar_se, funcwar_se, terrwar_se)

congroupses <- c(incnoconflict_se, funcnoconflict_se, terrnoconflict_se, incpostcon_se, funcpostcon_se, terrpostcon_se, incconflict_se, funcconflict_se, terrconflict_se)




cihighs <-(groupmeans+(1.96*groupses))
cihighs

concihighs <-(congroupmeans+(1.96*congroupses))
concihighs

cilows <-(groupmeans-(1.96*groupses))
cilows

concilows <-(congroupmeans-(1.96*congroupses))
concilows


rawnames<-c('States Currently at War','Post-Conflict States', 'Other States')
fnames<-factor(rawnames)

colnames(warmeans)<-rawnames

colnames(conflictmeans)<-rawnames

par(mar=c(4,10,5,1))

dotchart(warmeans, labels=c('Inclusive Powersharing', 'Constraining Powersharing', 'Dispersive Powersharing'), 
xlim=c(-0.45,0.25), pch=19) 
abline (v=0, lty=5)

mtext("Figure 1: Mean Values of Powersharing" , side = 3, cex = 1.5, line = 2.2, at=-.33)
mtext("by War Sub-Groups", side = 3, cex = 1.5, line = .8, at=-.33)
mtext("Each index has a standard deviation of one and an overall mean of zero.", side = 1, cex = .8, line = 2.2, at = -.33)

#stop here to keep it simple





SEQ<- seq(13)


 for(i in 1:3){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i], SEQ[i]), lwd=2)
 }

 for(i in 4:6){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i+2], SEQ[i+2]), lwd=2)
 }

 for(i in 7:9){
 lines(c(cihighs[i], cilows[i]), c(SEQ[i+4], SEQ[i+4]), lwd=2)
 }
