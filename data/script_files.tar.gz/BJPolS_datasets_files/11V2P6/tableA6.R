## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication 
## APPENDIX TABLE A6

rm(list=ls(all=T))
library(haven)
library(survival)
library(texreg)

# Your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")

## Data -----------------------------------------
d <- read_dta("duration_data.dta")


## Create Survival Objects ---------------------------------

# survival from dispute start
sur.Y.s <- Surv(d$counter_s, d$comply_event)

# survival from panel ruling
d.y.p <- d[d$counter_p>0 & is.na(d$counter_p)==FALSE,]
sur.Y.p <- Surv(d.y.p$counter_p, d.y.p$comply_event)

## TABLE A6 Results -------------------------------------------


# Survival from Request for Consultations

# Model A21a
modA21.a <- as.formula(sur.Y.s ~ lnprec_all_max + 
                       lnthird + leg_meas+ ln_trade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ cluster(respondent))
cphA21.a <- coxph(modA21.a, data=d, na.action=na.exclude, method="breslow")

# Model A21b
modA21.b <- as.formula(sur.Y.s ~ lnext_all_max + 
                       lnthird + leg_meas+ ln_trade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ cluster(respondent))
cphA21.b <- coxph(modA21.b, data=d, na.action=na.exclude, method="breslow")


# Survival from Panel Ruling

# Model A22a
modA22.a <- as.formula(sur.Y.p ~ lnprec_all_max + 
                        lnthird + leg_meas+ ln_trade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ cluster(respondent))
cphA22.a <- coxph(modA22.a, data=d.y.p, na.action=na.exclude, method="breslow")

# Model A22b
modA22.b <- as.formula(sur.Y.p ~ lnext_all_max + 
                         lnthird + leg_meas+ ln_trade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ cluster(respondent))
cphA22.b <- coxph(modA22.b, data=d.y.p, na.action=na.exclude, method="breslow")

# View results in table
screenreg(list(cphA21.b,cphA21.a,cphA22.b,cphA22.a), digits = 2, single.row = FALSE, stars = c(0.05, 0.01), 
          include.aic=F, include.adjrs=F, include.maxrs=F, include.events=F, include.zph=F)


length(unique(d$ds))
length(unique(d$ds[d$comply_event==1]))

length(unique(d.y.p$ds))
length(unique(d.y.p$ds[d.y.p$comply_event==1]))

## END

