## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication of Precedent Analysis
## MAIN RESULTS -- TABLES 4, 5, and 7


rm(list=ls(all=T))
library(haven)
library(lmtest)
library(sandwich)
library(sampleSelection)
library(stargazer)

## set your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication/")

## Data -----------------------------------------
d <- read_dta("comply_data.dta")


###############################################################
#### TABLE 4 --------------------------------------------- ####


## 4. Single-stage models -----------------------------------

# Select variables 
d.sub <- subset(d, select = c("ds", "ds_combined", "complainant", "respondent", "syear",
                              "comply_ontime", "ln_ex", "ln_narrow", "ln_follow",
                              "lnthird", "lntrade_rc", "gdp_share",
                              "r_US", "lnpwon", "leg_meas", "comfirm_nr", "deffirm_nr",
                              "art_ad","art_gatt", "art_subs", "art_agric"))


# Select cases for which compliance is evaluated
d.sub <- d.sub[!is.na(d.sub$comply_ontime),] 	

# Country-year variable
d.sub$ctyr <- paste(d.sub$respondent, d.sub$syear, sep="_")



# Binary - on-time compliance, extensions, linear model
lm4.1 <- lm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas, data = d.sub)
lm4.1c <- coeftest(lm4.1, vcov=vcovCL(lm4.1, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, extensions, logit model
lg4.2 <- glm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas, data = d.sub, family = binomial)
lg4.2c <- coeftest(lg4.2, vcov=vcovCL(lg4.2, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, extensions, linear model, country-year FE
lm4.3 <- lm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + gdp_share + art_ad + lnpwon + leg_meas + as.factor(ctyr), data = d.sub)
lm4.3c <- coeftest(lm4.3, vcov=vcovCL(lm4.3, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, follows, linear model
lm4.4 <- lm(comply_ontime ~ ln_follow + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas, data = d.sub)
lm4.4c <- coeftest(lm4.4, vcov=vcovCL(lm4.4, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, narrows, linear model
lm4.5 <- lm(comply_ontime ~ ln_narrow + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas, data = d.sub)
lm4.5c <- coeftest(lm4.5, vcov=vcovCL(lm4.5, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, extensions, linear model, issue area
lm4.6 <- lm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas +
              art_gatt + art_subs + art_agric, data = d.sub)
lm4.6c <- coeftest(lm4.6, vcov=vcovCL(lm4.6, factor(d.sub$ds_combined) ))

# Binary - on-time compliance, extensions, linear model, firms
lm4.7 <- lm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas + comfirm_nr + deffirm_nr, data = d.sub)
lm4.7c <- coeftest(lm4.7, vcov=vcovCL(lm4.7, factor(d.sub$ds_combined) ))

## 4. Two-stage model -----------------------------------

# Binary on-time compliance, extensions, Heckman two step, firm involvement in selection stage
sel4.8 <- appeal ~ lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + appeal_share + systemic  + article_xxii 
out4.8 <- comply_ontime ~ ln_ex + leg_meas + lnthird + lntrade_rc + gdp_share + art_ad + lnpwon + r_US
hek4.8 <- heckit(selection = sel4.8, outcome = out4.8, data = d, method = "2step")
summary(hek4.8)

keep.vars <- c("ln_ex", "ln_follow", "ln_narrow", 
               "lnthird", "lntrade_rc", "gdp_share", 
               "r_US", "art_ad", "lnpwon", "leg_meas", 
               "appeal_share", "systemic", "article_xxii",
               "comfirm_nr", "deffirm_nr", 
               "art_gatt", "art_subs", "art_agric")

stargazer(lm4.1c, lg4.2c, lm4.3c, lm4.4c, lm4.5c, lm4.6c, lm4.7c, hek4.8, type = "text", out = "table4.htm", 
          no.space = T, star.cutoffs = c(0.05, 0.01), digits = 2,
          selection.equation=T,
          keep = keep.vars,
          dep.var.labels = c("On-Time Compliance", "Selection: Appeal"),
          covariate.labels = c("Extensions", "Follows", "Narrows", "Third Parties", "Trade Share",
                               "GDP Share", "US Respondent", "AD Dispute", "Case Law", "Leg. Measure", 
                               "Appeal Share","Systemic Issues", "Article XXII", 
                               "Complainant Firms", "Respondent Firms"))

stargazer(hek4.8, type = "text", out = "table4_sel.htm", selection.equation=F,
          no.space = T, star.cutoffs = c(0.05, 0.01), digits = 2,
          dep.var.labels = "On-time Compliance",
          covariate.labels = c("Extensions","Leg. Measure",
                               "Third Parties", "Trade Share", "GDP Share", 
                               "AD Dispute", "Case Law", "US Respondent"))



###############################################################
#### TABLE 5 --------------------------------------------- ####


## 5. Single-stage models -----------------------------------

# Select variables 
d.sub <- subset(d, select = c("ds", "ds_combined", 
                              "complainant", "respondent",
                              "lntime_comply" ,"ln_ex","lnthird", 
                              "lntrade_rc", "gdp_share",
                              "r_US", "art_ad", "lnpwon", "leg_meas", 
                              "comfirm_nr", "deffirm_nr"))

# Complete observations
nrow(na.omit(d.sub))

# model 9 - Compliance delay
lm5.9 <- lm(lntime_comply ~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, data = d.sub)
lm5.9.c <- coeftest(lm5.9, vcov=vcovCL(lm5.9, factor(d.sub$ds_combined) ))

# model 10 - Compliance delay, control for firms
lm5.10 <- lm(lntime_comply ~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas+ comfirm_nr+ deffirm_nr, data = d.sub)
lm5.10.c <- coeftest(lm5.10, vcov=vcovCL(lm5.10, factor(d.sub$ds_combined) ))

## 5. Two-stage model --------------------------------------

# model 11 - Compliance delay
sel5.11 <- appeal ~ lnthird + lntrade_rc + gdp_share + r_US + art_ad + lnpwon + appeal_share + systemic  + article_xxii 
out5.11 <- lntime_comply ~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas 
hek5.11 <- heckit(selection = sel5.11, outcome = out5.11, data = d, method = "2step")
summary(hek5.11)

keep.vars <- c("ln_ex", "lnthird", "lntrade_rc", "gdp_share", "r_US", "art_ad", 
               "lnpwon", "leg_meas", "comfirm_nr", "deffirm_nr", "appeal_share", "systemic", 
               "article_xxii","Constant")

stargazer(lm5.9.c, lm5.10.c, hek5.11, type = "text", out = "table5.htm", 
          no.space = T, star.cutoffs = c(0.05, 0.01), digits = 2,
          selection.equation=T,
          keep = keep.vars,
          dep.var.labels = c("Compliance Delay", "Selection: Appeal"),
          covariate.labels = c("Extensions", "Third Parties", "Trade Share",
                               "GDP Share", "US Respondent", "AD Dispute", 
                               "Case Law", "Leg. Measure", 
                               "Complainant Firms", "Respondent Firms", 
                               "Appeal Share","Systemic Issues", 
                               "Article XXII", "Constant" ))


stargazer(hek5.11, type = "text", out = "table5_sel.htm", selection.equation=F,
          no.space = T, star.cutoffs = c(0.05, 0.01), digits = 2,
          dep.var.labels = "Compliance Delay",
          covariate.labels = c("Extensions","Third Parties","Trade Share", "GDP Share",
                                 "US Respondent", "AD Dispute", "Case Law",  "Leg. Measure"))

# R-squared
round(summary(lm5.9)$r.squared,2)
round(summary(lm5.10)$r.squared,2)


###############################################################
#### TABLE 7 --------------------------------------------- ####


## 5. Single-stage models -----------------------------------

# Select variables 
d.sub <- subset(d, select = c("ds", "ds_combined", "complainant", "respondent",
                              "comply_ontime","lntime_comply" ,"ln_ex","lnthird", 
                              "lntrade_rc", "gdp_share",
                              "r_US", "art_ad", "lnpwon", "leg_meas"))

# Complete observations
nrow(na.omit(d.sub[,-c(5)]))


# Binary - on-time compliance, extensions, linear model, US interaction
lm7.15 <- lm(comply_ontime ~ ln_ex*r_US + lnthird + lntrade_rc + gdp_share + art_ad + lnpwon + leg_meas, data = d.sub)
lm7.15c <- coeftest(lm7.15, vcov=vcovCL(lm7.15, factor(d.sub$ds_combined) ))

# Continuous - compliance delay, extensions, linear model, US interaction
lm7.16 <- lm(lntime_comply ~ ln_ex*r_US + lnthird + lntrade_rc + gdp_share + art_ad + lnpwon + leg_meas, data = d.sub)
lm7.16c <- coeftest(lm7.16, vcov=vcovCL(lm7.16, factor(d.sub$ds_combined) ))


keep.vars <- c("ln_ex", "r_US","lnthird", "lntrade_rc", "gdp_share", "art_ad", 
               "lnpwon", "leg_meas","Constant")
ord.vars <-  c("^ln_ex:r_US$","^ln_ex$", "^r_US$", "^lnthird$", "^lntrade_rc$", "^gdp_share$", "^art_ad$", "^lnpwon$", "^leg_meas$", "^Constant$")

stargazer(lm7.15c, lm7.16c, type = "text", out = "table7.htm", 
          no.space = T, star.cutoffs = c(0.05, 0.01), digits = 2,				
          keep = keep.vars,
          order = ord.vars,
          covariate.labels = c("Extensions * US Respondent", 
                               "Extensions", "US Respondent", 
                               "Third Parties", "Trade Share",
                               "GDP Share", "AD Dispute", 
                               "Case Law", "Legislative Measure", 
                               "Constant"))

# R-squared
round(summary(lm7.15)$r.squared,2)
round(summary(lm7.16)$r.squared,2)


## END 
