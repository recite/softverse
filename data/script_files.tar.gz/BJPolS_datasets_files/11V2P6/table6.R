## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication of Duration Analysis
## MAIN RESULTS -- TABLE 6

rm(list=ls(all=T))
library(haven)
library(survival)
library(texreg)

# Your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")

## Data -----------------------------------------
d <- read_dta("duration_data.dta")


## Create Survival Objects ---------------------------------

# survival from AB ruling
d.ab <- d[d$counter_a>0&is.na(d$year_a_report)==FALSE & is.na(d$counter_a)==FALSE,]
sur.Y.ab <- Surv(d.ab$counter_a, d.ab$comply_event)

# survival from AB ruling for cases where US is a Litigant 
d.abUS <- d[d$counter_a>0&is.na(d$year_a_report)==FALSE & is.na(d$counter_a)==FALSE & (d$c_US==1|d$r_US==1),]
sur.Y.abUS <- Surv(d.abUS$counter_a, d.abUS$comply_event)


## TABLE 6 Results -------------------------------------------

# model 12 - time from AB report; precedent extensions in prior disputes; all disputes with data
mod.12 <- as.formula(sur.Y.ab ~ lnext_all_max + 
                         lnthird + ln_trade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas + cluster(respondent))
cph.12 <- coxph(mod.12, data=d.ab, na.action=na.exclude, method="breslow")
summary(cph.12)  

# model 13 - time from AB report; precedent extensions in prior disputes; US litigant
mod.13 <- as.formula(sur.Y.abUS ~ lnext_all_max + 
                           lnthird + ln_trade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas + clobby + rlobby + cluster(respondent))
cph.13 <- coxph(mod.13, data=d.abUS, na.action=na.exclude, method="breslow")
summary(cph.13)  


# model 14 - time from AB report; precedent extensions in prior disputes; all disputes with data
mod.14 <- as.formula(sur.Y.ab ~ lnprec_all_max + 
                         lnthird + ln_trade_rc + gdp_share + r_US + art_ad + lnpwon + leg_meas + cluster(respondent))
cph.14 <- coxph(mod.14, data=d.ab, na.action=na.exclude, method="breslow")
summary(cph.14)  


# View results in table
screenreg(list(cph.12,cph.13,cph.14), digits = 2, single.row = FALSE, stars = c(0.05, 0.01), 
          include.aic=F, include.adjrs=F, include.maxrs=F, include.events=F, include.zph=F)


length(unique(d.ab$ds))
length(unique(d.ab$ds[d.ab$comply_event==1]))

length(unique(d.abUS$ds))
length(unique(d.abUS$ds[d.abUS$comply_event==1]))


## END



















