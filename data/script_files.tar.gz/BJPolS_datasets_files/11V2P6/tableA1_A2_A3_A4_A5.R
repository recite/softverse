## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication 
## APPENDIX TABLES A1, A2, A3, A4, A5

## Initial steps
rm(list=ls(all=T))
library(haven)
library(stargazer)
library(clusterSEs)
library(MASS)


# Set your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")

## Data -----------------------------------------

# read in data and subset
d<- read_dta("comply_data.dta")

# start and AB years, adjusted so that 1995 is year 1
d$syear_adj <- d$syear-1994
d$ayear_adj <- d$ayear-1994

# Select variables 
d.sub <- subset(d, select = c("ds", "ds_combined", "complainant", "respondent", "litigant_id", 
                              "syear", "ayear", "syear_adj", "ayear_adj",
                              "comply_ontime", "comply_ontime_tri", "lntime_comply",
                              "ln_ex", "ln_narrow", "ln_follow", "demean_ex",
                              "lnthird", "lntrade_rc", "ln_trade_total", "gdp_share",
                              "r_US", "lnpwon", "leg_meas", "comfirm_nr", "deffirm_nr",
                              "art_ad","art_gatt", "art_subs", "art_agric", "merch",
                              "greatpower", "remedy", "zeroing", "comply_ratio", "civil_law"))


# Select cases for which compliance is evaluated
d.sub <- d.sub[!is.na(d.sub$comply_ontime),] 	



# Country-year FE
d.sub$respondent <- ifelse(d.sub$respondent=="Dominican Republic", "Dominican R.", d.sub$respondent)
d.sub$resp_yr <- paste(d.sub$respondent,d.sub$syear,sep="_")

# Select cases with appeals
d.AB <- d.sub[is.na(d.sub$ayear)==F,]


#############################################################################
## Table A1 - Descriptive statistics --------------------------------------  

summary(d.sub$comply_ontime); round(sd(d.sub$comply_ontime),2)
summary(d.sub$lntime_comply); round(sd(d.sub$lntime_comply, na.rm=T),2)

summary(d.sub$ln_ex); round(sd(d.sub$ln_ex, na.rm=T),2)
summary(d.sub$ln_follow); round(sd(d.sub$ln_follow, na.rm=T),2)
summary(d.sub$ln_narrow); round(sd(d.sub$ln_narrow, na.rm=T),2)

summary(d.sub$lnthird); round(sd(d.sub$lnthird, na.rm=T),2)
summary(d.sub$lntrade_rc); round(sd(d.sub$lntrade_rc, na.rm=T),2)
summary(d.sub$gdp_share); round(sd(d.sub$gdp_share, na.rm=T),2)
summary(d.sub$lnpwon); round(sd(d.sub$lnpwon, na.rm=T),2)
summary(d.sub$r_US); round(sd(d.sub$r_US, na.rm=T),2)
summary(d.sub$leg_meas); round(sd(d.sub$leg_meas, na.rm=T),2)
summary(d.sub$comfirm_nr); round(sd(d.sub$comfirm_nr, na.rm=T),2)
summary(d.sub$deffirm_nr); round(sd(d.sub$deffirm_nr, na.rm=T),2)

summary(d.sub$art_ad); round(sd(d.sub$art_ad, na.rm=T),2)
summary(d.sub$art_gatt); round(sd(d.sub$art_gatt, na.rm=T),2)
summary(d.sub$art_subs); round(sd(d.sub$art_subs, na.rm=T),2)
summary(d.sub$art_agric); round(sd(d.sub$art_agric, na.rm=T),2)

summary(d$appeal_share); round(sd(d$appeal_share, na.rm=T),2)
summary(d$article_xxii); round(sd(d$article_xxii, na.rm=T),2)
summary(d$systemic); round(sd(d$systemic, na.rm=T),2)



#############################################################################
## Table A2 - Alt baseline estimations --------------------------------------  

# Model A1 - linear
regA1 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
            data = d.sub)
regA1.c <- coeftest(regA1, vcov=vcovCL(regA1, factor(d.sub$ds_combined) )); regA1.c

# substantive effect size - increase of 1 unit in ln_ex
exp(regA1$coef[2]) / (1 + exp(regA1$coef[2]))  # probability


# Model A2 - logistic
regA2 <- glm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
            data = d.sub, family = "binomial")
regA2.c <- coeftest(regA2, vcov=vcovCL(regA2, factor(d.sub$ds_combined) )); regA2.c


# Model A3 - ordered logistic
regA3 <- polr(as.factor(comply_ontime_tri)~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
             data = d.sub)
regA3.c <- coeftest(regA3, vcov=vcovCL(regA3, factor(d.sub$ds_combined) )); regA3.c

# Model A4 - cluster by litigant pair
regA4.c <- coeftest(regA1, vcov=vcovCL(regA1, factor(d.sub$litigant_id) )); regA4.c


# Model A5 - AB rulings
regA5 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
            data = d.AB)
regA5.c <- coeftest(regA5, vcov=vcovCL(regA5, factor(d.AB$ds_combined) )); regA5.c

# Table A2 results
stargazer(regA1.c, regA2.c, regA3.c, regA4.c, regA5.c, 
          no.space = T, type = "text", star.cutoffs = c(0.05, 0.01), digits = 2)


#############################################################################
## Table A3 - Logistic models of on-time compliance ------------------------- 

# Model A6 - logistic, FE
regA6 <- glm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ art_ad+ lnpwon+ leg_meas + resp_yr, 
             data = d.sub, family = "binomial")
regA6.c <- coeftest(regA6, vcov=vcovCL(regA6, factor(d.sub$resp_yr) ))

# Model A7 - logistic, follows
regA7 <- glm(comply_ontime~ ln_follow+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
             data = d.sub, family = "binomial")
regA7.c <- coeftest(regA7, vcov=vcovCL(regA7, factor(d.sub$ds_combined) ))

# Model A8 - logistic, narrows
regA8 <- glm(comply_ontime~ ln_narrow+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas, 
             data = d.sub, family = "binomial")
regA8.c <- coeftest(regA8, vcov=vcovCL(regA8, factor(d.sub$ds_combined) ))

# Model A9 - logistic, topic
regA9 <- glm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas+
               art_gatt+ art_subs+ art_agric, 
             data = d.sub, family = "binomial")
regA9.c <- coeftest(regA9, vcov=vcovCL(regA9, factor(d.sub$ds_combined) ))

# Model A10 - logistic, firms
regA10 <- glm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+ gdp_share+ r_US+ art_ad+ lnpwon+ leg_meas+
               comfirm_nr+ deffirm_nr, 
             data = d.sub, family = "binomial")
regA10.c <- coeftest(regA10, vcov=vcovCL(regA10, factor(d.sub$ds_combined) ))


# Table A3 results
stargazer(regA6.c, regA7.c, regA8.c, regA9.c, regA10.c, 
          no.space = T, type = "text", star.cutoffs = c(0.05, 0.01), digits = 2)

logLik(regA6)
logLik(regA7)
logLik(regA8)
logLik(regA9)
logLik(regA10)

#############################################################################
## Table A4 - Additional controls: economic stakes, time trend --------------

# Model A11, total trade
regA11 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc + gdp_share+ r_US + art_ad+ lnpwon+ leg_meas+ ln_trade_total, 
             data = d.sub)
regA11.c <- coeftest(regA11, vcov=vcovCL(regA11, factor(d.sub$ds_combined) ))

# Model A12, merchandise
regA12 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share + r_US + art_ad+ lnpwon+ leg_meas+ merch, 
             data = d.sub)
regA12.c <- coeftest(regA12, vcov=vcovCL(regA12, factor(d.sub$ds_combined) ))

# Model A13, year consult req.
regA13 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share + r_US + art_ad+ lnpwon+ leg_meas+ syear_adj, 
             data = d.sub)
regA13.c <- coeftest(regA13, vcov=vcovCL(regA13, factor(d.sub$ds_combined) ))

# Model A14, year AB
regA14 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US + art_ad+ lnpwon+ leg_meas+ ayear_adj, 
             data = d.AB)
regA14.c <- coeftest(regA14, vcov=vcovCL(regA14, factor(d.AB$ds_combined) ))



# Table A4 results
stargazer(regA11.c, regA12.c, regA13.c, regA14.c, 
          no.space = T, type = "text", star.cutoffs = c(0.05, 0.01), digits = 2)

summary(regA11)[8]
summary(regA12)[8]
summary(regA13)[8]
summary(regA14)[8]


#############################################################################
## Table A5 - Analysis with compliance delay --------------------------------

# Model A15
regA15 <- lm(lntime_comply~ ln_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US + art_ad+ lnpwon+ leg_meas + syear_adj, 
             data = d)
regA15.c <- coeftest(regA15, vcov=vcovCL(regA15, factor(d$ds_combined) ))

# Model A16 extensions demean
regA16 <- lm(lntime_comply~ demean_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US + art_ad+ lnpwon+ leg_meas, 
             data = d)
regA16.c <- coeftest(regA16, vcov=vcovCL(regA16, factor(d$ds_combined) ))


# Model A17
regA17 <- lm(lntime_comply~ ln_follow+ lnthird+ lntrade_rc+  gdp_share+ r_US +art_ad+ lnpwon+ leg_meas, 
             data = d)
regA17.c <- coeftest(regA17, vcov=vcovCL(regA17, factor(d$ds_combined) ))

# Model A18
regA18 <- lm(lntime_comply~ ln_narrow+ lnthird+ lntrade_rc+  gdp_share+ r_US +art_ad+ lnpwon+ leg_meas, 
             data = d)
regA18.c <- coeftest(regA18, vcov=vcovCL(regA18, factor(d$ds_combined) ))

# Model A19
regA19 <- lm(lntime_comply~ ln_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US +art_ad+ lnpwon+ leg_meas+ 
               art_gatt+ art_subs+ art_agric, 
             data = d)
regA19.c <- coeftest(regA19, vcov=vcovCL(regA19, factor(d$ds_combined) ))

# Model A20
regA20 <- lm(lntime_comply~ ln_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US +art_ad+ lnpwon+ leg_meas+
              comfirm_nr+ deffirm_nr, 
             data = d)
regA20.c <- coeftest(regA20, vcov=vcovCL(regA20, factor(d$ds_combined) ))





# Table A5 results
stargazer(regA15.c, regA16.c, regA17.c, regA18.c, regA19.c, regA20.c,
          no.space = T, type = "text", star.cutoffs = c(0.05, 0.01), digits = 2)

summary(regA15)[8]
summary(regA16)[8]
summary(regA17)[8]
summary(regA18)[8]
summary(regA19)[8]
summary(regA20)[8]





#############################################################################
## Table A6 - Additional Controls -------------------------------------------

# Model A23, great powers
regA23 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc + gdp_share+ r_US + art_ad+ lnpwon+ leg_meas+ greatpower, 
             data = d.sub)
regA23.c <- coeftest(regA23, vcov=vcovCL(regA23, factor(d.sub$ds_combined) ))

# Model A24, remedy
regA24 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share + r_US + art_ad+ lnpwon+ leg_meas+ remedy, 
             data = d.sub)
regA24.c <- coeftest(regA24, vcov=vcovCL(regA24, factor(d.sub$ds_combined) ))

# Model A25, zeroing cases omitted
regA25 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share + r_US + art_ad+ lnpwon+ leg_meas, 
             data = d.sub[d.sub$zeroing==0,])
regA25.c <- coeftest(regA25, vcov=vcovCL(regA25, factor(d.sub$ds_combined[d.sub$zeroing==0]) ))

# Model A26, ratio of past compliance.
regA26 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share + r_US + art_ad+ lnpwon+ leg_meas+ comply_ratio, 
             data = d.sub)
regA26.c <- coeftest(regA26, vcov=vcovCL(regA26, factor(d.sub$ds_combined) ))

# Model A27, civil law
regA27 <- lm(comply_ontime~ ln_ex+ lnthird+ lntrade_rc+  gdp_share+ r_US + art_ad+ lnpwon+ leg_meas+ civil_law, 
             data = d.sub)
regA27.c <- coeftest(regA27, vcov=vcovCL(regA27, factor(d.sub$ds_combined) ))

# Table A6 results
stargazer(regA23.c, regA24.c, regA25.c, regA26.c, regA27.c, 
          no.space = T, type = "text", star.cutoffs = c(0.05, 0.01), digits = 2)

summary(regA23)[8]
summary(regA24)[8]
summary(regA25)[8]
summary(regA26)[8]
summary(regA27)[8]

## END
