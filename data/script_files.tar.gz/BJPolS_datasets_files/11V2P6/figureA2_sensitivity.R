## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication 
## APPENDIX FIGURE A2 & sensitivity analysis

## Initial Steps  -----------------------------------
rm(list=ls(all=T))

library(haven)
library(sensemakr) #Cinelli and Hazlett (2019) package

# Set your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")

## Data -----------------------------------------

# read in data and subset
d<- read_dta("comply_data.dta")

# select variables
d.sub <- ( subset(d, select = c("ds","ds_combined","respondent",
                                "comply_ontime","ln_ex", 
                                "lnthird", "lntrade_rc", "gdp_share", 
                                "r_US",  "lnpwon", "leg_meas","art_ad")))

# Only cases for which compliance is evaluated
d.sub <- d.sub[is.na(d.sub$comply_ontime)==F,] 

## Sensitivity Analysis -------------------------------

# regression model
mod<- lm(comply_ontime ~ ln_ex + lnthird + lntrade_rc + 
                    gdp_share + r_US + art_ad + lnpwon + leg_meas, 
                    data = d.sub)  
summary(mod)

# run sensemakr
sens <- sensemakr(mod, treatment = "ln_ex", benchmark_covariates = "r_US", kd = 1:3)
sens

# summary of results
summary(sens)

## Save plots to pdf
pdf("figureA2_sens.pdf")
  plot(sens)
dev.off()

## END






