## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication of Precedent Descriptive Statistics
## APPENDIX FIGURE A1

## Initial steps
rm(list=ls(all=T))
library(haven)
library(clusterSEs)
require(plotrix)
require(scales)

# Set your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")

## Data -----------------------------------------

# read in data and subset
d<- read_dta("comply_data.dta")


# Select variables 
d.sub <- subset(d, select = c("ds", "ds_combined","respondent",
                              "comply_ontime", "ln_ex",
                              "lnthird", "lntrade_rc", "gdp_share",
                              "r_US", "lnpwon", "leg_meas", "art_ad"))


# Select cases for which compliance is evaluated
d.sub <- d.sub[!is.na(d.sub$comply_ontime),] 	

d.sub$respondent <- ifelse(d.sub$respondent=="Dominican Republic", "Dominican R.", d.sub$respondent)


## COUNTRY EFFECTS --------------------

# Are some countries more sensitive to precedent than others?
# Evaluate by dropping each country and recovering the coefficient (se) on ln_ex

r.list <- unique(d.sub$respondent)
bob <- data.frame(r.list) 
bob$coef_ext <- NA
bob$se_ext <- NA


for(i in 1:length(r.list)){
	
	if(i=="USA"){
			d.c <- subset(d.sub, respondent != r.list[i])
			lm <- lm(comply_ontime ~ ln_ex + lnthird + 
								lntrade_rc + gdp_share + 
								art_ad + lnpwon + leg_meas, d.c)
			lm.c <- coeftest(lm, vcov=vcovCL(lm, factor(d.c$ds_combined) ))
			bob[i,2:3] <- lm.c[2,1:2]
	} else {

	d.c <- subset(d.sub, respondent != r.list[i])
	lm <- lm(comply_ontime ~ ln_ex + lnthird + 
								lntrade_rc + gdp_share + 
								r_US + art_ad + lnpwon + leg_meas, d.c)
	lm.c <- coeftest(lm, vcov=vcovCL(lm, factor(d.c$ds_combined) ))
	bob[i,2:3] <- lm.c[2,1:2]
	}
}

bob$ci_low <- bob$coef_ext - 1.96*bob$se_ext
bob$ci_hi <- bob$coef_ext + 1.96*bob$se_ext
bob <- bob[order(bob[,2],decreasing=FALSE),]
bob$index <- seq(1:length(r.list))


# US is influential outlier, as discussed in main analysis.
# Plot to focus on how the other countries sway the estimates.

bob <- bob[-19,]

pdf("figureA1_beta_country_LOO.pdf")
par(mar = c(9,5,1,1))
plotCI(x = bob$index, bob$coef_ext, ui = bob$ci_hi , li = bob$ci_low, pch = 19, xlab="", xaxt = "n", 
		ylab = expression(paste(beta, " on Precedent Extension")), ylim = c(-0.35, 0.15))
axis(side=1, at=bob$index, labels = FALSE)
text(x=bob$index+.4, y = -.39, par("usr")[3], 
     labels = bob$r.list, srt = 90, pos = 2, xpd = TRUE)
mtext("Omitting Respondent Country...", side = 1, line = 7)
abline(h = 0, col = alpha("darkgrey", 0.5), lwd = 2, lty=2)
dev.off()

## END
