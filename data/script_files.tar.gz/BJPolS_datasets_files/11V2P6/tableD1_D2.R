## Kucik, Peritz, Puig (2022) "Legalization and Compliance"
## Replication 
## APPENDIX TABLES D1 and D2

## Initial steps
rm(list=ls(all=T))
library(haven)

# Set your working directory here
setwd("/Users/lperitz/Dropbox/JK_LP/RulingExpansion/BJPS/bjps22_replication")


###############################################################################
## TABLE D1: Share of all WTO disputes and AB reports by issue area -----------

# read in data and subset
d1<- read_dta("comply_data.dta")
d1.AB <- d1[d1$appeal==1&is.na(d1$comply_ontime)==F,] # our sample
  

tableD1 <- function(d1_X, d1AB_X){
  print(round(mean(d1_X),2)*100)
  print(round(mean(d1AB_X),2)*100)
  }

tableD1(d1$art_agric, d1.AB$art_agric)
tableD1(d1$art_ad, d1.AB$art_ad)
tableD1(d1$art_gatt, d1.AB$art_gatt)
tableD1(d1$art_sg, d1.AB$art_sg)
tableD1(d1$art_sps, d1.AB$art_sps)
tableD1(d1$art_subs, d1.AB$art_subs)
tableD1(d1$art_tbt, d1.AB$art_tbt)
tableD1(d1$art_textile, d1.AB$art_textile)
tableD1(d1$art_trips, d1.AB$art_trips)


###############################################################################
## TABLE D2: Share of precedent applications that extend the law by issue -----

d2<- read_dta("precedent_data.dta")

table(d2$agreementscited)

table(d2$agreementscited[d2$referencecategorygrouped=="Extends"])

## END
