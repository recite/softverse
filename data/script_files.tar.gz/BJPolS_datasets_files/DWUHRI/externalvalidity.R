library(devtools)
install_github("naoki-egami/exr", dependencies = TRUE)
library(exr)
library(haven)
externalvalidity <- read_dta("C:/Users/au544415/Desktop/BJPS/externalvalidity.dta")
covariates <- c("")

externalvalidity_old <- subset(externalvalidity, age >= 44)
externalvalidity_young <- subset(externalvalidity, age < 44)

for_sate <- as.formula(paste0("vote ~ undemocratic"))
lm_sate <- lm(for_sate, data = externalvalidity_old)
summary(lm_sate)
sate_est_old <- summary(lm_sate)$coef["undemocratic", c(1,2)]
sate_est_old

for_sate <- as.formula(paste0("vote ~ undemocratic"))
lm_sate <- lm(for_sate, data = externalvalidity_young)
summary(lm_sate)
sate_est_young <- summary(lm_sate)$coef["undemocratic", c(1,2)]
sate_est_young

exr_out_old <- exr(outcome = "vote", 
                   treatment = "undemocratic", 
                   covariates = c("attentive", "attitude", "partisan", "metro", "highedu", "female"), 
                   data = externalvalidity_old,
                   sate_estimate = sate_est_old) ##excluding Study 2, 3, 5

exr_out2_old <- exr(outcome = "vote", 
                    treatment = "undemocratic", 
                    covariates = c("attentive", "highedu", "female"), 
                    data = externalvalidity_old,
                    sate_estimate = sate_est_old) ##all studies

exr_out3_old <- exr(outcome = "vote", 
                    treatment = "undemocratic", 
                    covariates = c("attentive", "metro", "highedu", "female"), 
                    data = externalvalidity_old,
                    sate_estimate = sate_est_old) ##excluding Study 2

exr_out4_old <- exr(outcome = "vote", 
                    treatment = "undemocratic", 
                    covariates = c("attentive", "attitude", "highedu", "female"), 
                    data = externalvalidity_old,
                    sate_estimate = sate_est_old) ##excluding Study 3

exr_out5_old <- exr(outcome = "vote", 
                    treatment = "undemocratic", 
                    covariates = c("attentive", "partisan", "highedu", "female"), 
                    data = externalvalidity_old,
                    sate_estimate = sate_est_old) ##excluding Study 5

exr_out_young <- exr(outcome = "vote", 
                     treatment = "undemocratic", 
                     covariates = c("attentive", "attitude", "partisan", "metro", "highedu", "female"), 
                     data = externalvalidity_young,
                     sate_estimate = sate_est_young) ##excluding Study 2, 3, 5

exr_out2_young <- exr(outcome = "vote", 
                      treatment = "undemocratic", 
                      covariates = c("attentive", "highedu", "female"), 
                      data = externalvalidity_young,
                      sate_estimate = sate_est_young) ##all studies

exr_out3_young <- exr(outcome = "vote", 
                      treatment = "undemocratic", 
                      covariates = c("attentive", "metro", "highedu", "female"), 
                      data = externalvalidity_young,
                      sate_estimate = sate_est_young) ##excluding Study 2

exr_out4_young <- exr(outcome = "vote", 
                      treatment = "undemocratic", 
                      covariates = c("attentive", "attitude", "highedu", "female"), 
                      data = externalvalidity_young,
                      sate_estimate = sate_est_young) ##excluding Study 3

exr_out5_young <- exr(outcome = "vote", 
                      treatment = "undemocratic", 
                      covariates = c("attentive", "partisan", "highedu", "female"), 
                      data = externalvalidity_young,
                      sate_estimate = sate_est_young) ##excluding Study 5




##Figure E1 (save manually)
par(mfrow=c(1,2))
plot(exr_out_young, main="Young: All")
plot(exr_out_old, main="Older: All")


##Figure E2 (save manually)
par(mfcol=c(4,2))
plot(exr_out2_young, main="Young: Attention, Education, Gender")
plot(exr_out3_young, main="Young: Attention, Education, Gender, Residence")
plot(exr_out4_young, main="Young: Attention, Education, Gender, Attitudes")
plot(exr_out5_young, main="Young: Attention, Education, Gender, Partisanship")
plot(exr_out2_old, main="Older: Attention, Education, Gender")
plot(exr_out3_old, main="Older: Attention, Education, Gender, Residence")
plot(exr_out4_old, main="Older: Attention, Education, Gender, Attitudes")
plot(exr_out5_old, main="Older: Attention, Education, Gender, Partisanship")