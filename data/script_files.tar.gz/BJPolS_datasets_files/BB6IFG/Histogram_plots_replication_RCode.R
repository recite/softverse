#REPLICATION CODE FOR DESCRIPTIVE STATISTICS

library(stargazer)
#Loading Primary Data Set
bjps_rep<-read.csv("BJPS_replication_data.csv")

#Descriptive Statistics
stargazer(bjps_rep)

#Figure 5: Histogram of Member State Observations
hist(bjps_rep$sumcaseobs1,xlab="Percentage of Member-State Governments Filing an Observation",main="",ylab="Number of Legal Issues")
box()

#Figure 6: Histogram of Net Support for Pro-EU Ruling
hist(bjps_rep$netint,xlab="Net Support for Pro-EU Integration Ruling",main="",ylab="Number of Legal Issues")
box()

#Figure 7: Histogram of Net Support for Pro-EU Ruling (Excluding Cases with No Member State Observations)
bjps_rep1 <- subset(bjps_rep, netint!=0)
hist(bjps_rep1$netint,xlab="Net Support for Pro-EU Integration Ruling",main="",ylab="Number of Legal Issues")
box()
