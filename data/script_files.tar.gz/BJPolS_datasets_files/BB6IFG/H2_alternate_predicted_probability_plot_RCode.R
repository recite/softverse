bjps_rep<-read.csv("BJPS_replication_data.csv")

h2_alt_preds <- read.csv("H2_Alternate_predicted_probability_replication_data.csv")
h2a <-subset(h2_alt_preds, at2==0.078)

plot(h2a$margin~ h2a$at1,type="l",ylim=c(0,.5),lwd=5,xlab="Percentage of Member-State Governments Filing Observations",ylab="Probability of Pro-EU Integration Ruling",col="black",main="",axes=F)
lines(h2a $ci_lb ~ h2a $at1,type="l",lty=2,lwd=2,col="black")
lines(h2a $ci_ub ~ h2a $at1,type="l",lty=2,lwd=2,col="black")
axis(1, c(0,.2,.4,.6,.8,1 ), col = NA, col.ticks = 1)
box(bty="L")
axis(2,c(0.1,0.2,0.3,0.4,0.5),, col = NA, col.ticks = 1)
rug(bjps_rep$netint)

h2b <-subset(h2_alt_preds, at2==-0.1537)
lines(h2b $margin ~ h2b $at1, type="l",lwd=5,col="gray")
lines(h2b $ci_lb ~ h2b $at1,type="l",lty=2,lwd=2,col="gray")
lines(h2b $ci_ub ~ h2b $at1,type="l",lty=2,lwd=2,col="gray")

