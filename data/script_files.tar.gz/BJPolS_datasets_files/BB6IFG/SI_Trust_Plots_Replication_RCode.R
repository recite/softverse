library(ggplot2)
trust <- read.csv("Eurobarometer_Trust_replication_data.csv")
trust$Date <- as.Date(trust$Date,"%m/%d/%y")

#Figure 1: Net Trust in National Legal Systems (30 Country Plot)
ggplot(trust, aes(x=Date,y= Legal_Trust_diff, group=Country))+geom_line()+facet_wrap(~Country)+ggtitle("")+labs(y="Net Trust in National Legal Systems",x="Year")

#Figure 2: Net Trust in National Legal Systems (Six Country Plot)
trust1 <- subset(trust, level==1)
ggplot(trust1, aes(x=Date,y= Legal_Trust_diff, group=Country))+geom_line()+facet_wrap(~Country)+ggtitle("")+labs(y="Net Trust in National Legal Systems",x="Year")


#Figure 3: Net Trust in National Legal Systems vs Net Trust in National Government (30 Country Plot)
ggplot(trust, aes(x=Date,y=court_gov_diff, group=Country))+geom_line()+facet_wrap(~Country)+ggtitle("")+labs(y="Relative Trust in National Legal Systems",x="Year")

#Figure 4: Net Trust in National Legal Systems vs Net Trust in National Government (4 Country Plot)
trust2 <- subset(trust, group==1)
ggplot(trust2, aes(x=Date,y=court_gov_diff, group=Country))+geom_line()+facet_wrap(~Country)+ggtitle("")+labs(y="Relative Trust in National Legal Systems",x="Year")