bjps_rep<-read.csv("BJPS_replication_data.csv")
h1_preds <- read.csv("H1_preds.csv")
par(mar=c(4.1,4.1,2.7,2.1))
plot(h1_preds $margin~ h1_preds $at1,type="l",ylim=c(0.2,.45),lwd=5,xlab="Percentage of Member-State Governments Filing Observations",ylab="Probability of Pro-EU Integration Ruling",col="black",main="",axes=F)
lines(h1_preds $ci_lb ~ h1_preds $at1,type="l",lty=2,lwd=2,col="black")
lines(h1_preds $ci_ub ~ h1_preds $at1,type="l",lty=2,lwd=2,col="black")
axis(1, c(0,0.2,0.4,0.6 ), col = NA, col.ticks = 1)
box(bty="L")
axis(2,c(0.2,0.3,0.4),, col = NA, col.ticks = 1)
rug(bjps_rep$sumcaseobs1)

h2_predsa <- read.csv("~/Dropbox/Unpopular Courts Paper/Unpopular Courts AJPS/BJPS R&R/H2_preds.csv")

h2a <-subset(h2_predsa, at1==0.06)

plot(h2a$margin~ h2a$at2,type="l",ylim=c(0.25,.5),lwd=5,xlab="Net Support for Pro-EU Integration Ruling",ylab="Probability of Pro-EU Integration Ruling",col="black",main="",axes=F)
lines(h2a $ci_lb ~ h2a $at2,type="l",lty=2,lwd=2,col="black")
lines(h2a $ci_ub ~ h2a $at2,type="l",lty=2,lwd=2,col="black")
axis(1, c(-0.1,-0.5,0,0.5,0.1 ), col = NA, col.ticks = 1)
box(bty="L")
axis(2,c(0.2,0.3,0.4,0.5),, col = NA, col.ticks = 1)
rug(bjps_rep$netint)

h2b <-subset(h2_predsa, at1==0.3333)
lines(h2b $margin ~ h2b $at2, type="l",lwd=5,col="gray")
lines(h2b $ci_lb ~ h2b $at2,type="l",lty=2,lwd=2,col="gray")
lines(h2b $ci_ub ~ h2b $at2,type="l",lty=2,lwd=2,col="gray")

