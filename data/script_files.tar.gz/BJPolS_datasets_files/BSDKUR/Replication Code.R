##Models for AJPS submission, GAH Dyads
library(tidyverse) ##data cleaning
library(estimatr) ##robust SEs
library(stargazer) ##tex output
library(fixest)

load("final_data.rds")



##Figure 1
forplot <-group_by(updated_data, to_parfam, from_parfam) %>%
  summarize(Out_Party_Dislike = mean(party_dislike))


##Remove regional and idiosyncratic parties from plot

forplot <-filter(forplot, to_parfam <=70, from_parfam <=70)

forplot <-mutate(forplot, to_parfam = ifelse(to_parfam == 10, "Green",
                                             ifelse(to_parfam == 20, "Radical Left",
                                                    ifelse(to_parfam == 30, "Social Democratic",
                                                           ifelse(to_parfam == 40, "Liberal",
                                                                  ifelse(to_parfam == 50, "Christian Democratic",
                                                                         ifelse(to_parfam == 60, "Conservative",
                                                                                ifelse(to_parfam == 70, "Radical Right", NA))))))),
                 from_parfam = ifelse(from_parfam == 10, "Green",
                                      ifelse(from_parfam == 20, "Radical Left",
                                             ifelse(from_parfam == 30, "Social Democratic",
                                                    ifelse(from_parfam == 40, "Liberal",
                                                           ifelse(from_parfam == 50, "Christian Democratic",
                                                                  ifelse(from_parfam == 60, "Conservative",
                                                                         ifelse(from_parfam == 70, "Radical Right", NA))))))),
)


##Reoreder the factor from left to right

forplot$to_parfam <- factor(forplot$to_parfam, levels=c("Radical Left", "Green", "Social Democratic", "Liberal", "Christian Democratic",
                                                        "Conservative", "Radical Right"))

forplot$from_parfam <- factor(forplot$from_parfam, levels=c("Radical Left", "Green", "Social Democratic", "Liberal", "Christian Democratic",
                                                            "Conservative", "Radical Right"))

ggplot(forplot, aes(x = to_parfam, y= Out_Party_Dislike)) + geom_bar(stat='identity') + facet_wrap(~from_parfam) + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))






##RILE Esimation First. Note that to get the clustered SEs to print
## in tex, First run lm, then adjust SEs using estimatr in the stargazer command


## Table 2

LR_only <-feols(party_dislike ~ rile_distance_s + govern_together + opposition_together +from_rrparty + 
                  to_rrparty | country + year, data = updated_data,
                cluster =~ countryyear)

summary(LR_only)


two_dim <-feols(party_dislike ~ society_distance_s + econ_distance_s + govern_together + opposition_together
                 + from_rrparty + to_rrparty | country + year, data = updated_data, cluster =~ countryyear)



##table a A 10- SE clustered by country

LR_only_CC <-feols(party_dislike ~ rile_distance_s + govern_together + opposition_together +from_rrparty + 
                  to_rrparty | country + year, data = updated_data,
                cluster =~ countryyear)


two_dim_CC <-feols(party_dislike ~ society_distance_s + econ_distance_s + govern_together + opposition_together
                + from_rrparty + to_rrparty | country + year, data = updated_data, cluster =~ countryyear)





##Robustness checks  and reduced models for table 2 (Table A3)

Bivariate_LR <-feols(party_dislike ~ rile_distance_s | country + year, data = updated_data,
                 cluster =~ countryyear)


##Using both CMP variables

##3.2 - Just 2 dimensional ideology
Just_two_dim<-feols(party_dislike ~ society_distance_s + econ_distance_s | country + year, data = updated_data,
                cluster =~ countryyear)

##3.3 Just Coalition
Just_Coalitions <-feols(party_dislike ~ govern_together + opposition_together | country+ year, data = updated_data,
                 cluster =~ countryyear)

Just_RR_Party <-feols(party_dislike ~ from_rrparty + to_rrparty | country + year, data = updated_data,
                 cluster =~ countryyear)





## create a "not in" function
`%notin%` <- Negate(`%in%`)

##Split data by earlier and later periods for Table 3
later_rounds <-filter(updated_data, year > 2006) 
former <-filter(updated_data, year < 2007)




##Analyses in Table 3


Table3_reduced_later <-feols(party_dislike ~ society_distance_s+ econ_distance_s| country + year,
                          data = later_rounds, cluster = ~ countryyear )
 
Table3_twoD_later <-feols(party_dislike ~ society_distance_s+ econ_distance_s + govern_together + opposition_together 
                 + to_rrparty   + from_rrparty  | country + year,
                 data = later_rounds, cluster = ~ countryyear )

Table3_reduced_Earlier <-feols(party_dislike ~econ_distance_s + society_distance_s  | country + year,
                            data = later_rounds_t, cluster = ~ countryyear )


Table3_twoD_Earlier <-feols(party_dislike ~econ_distance_s + society_distance_s + govern_together + opposition_together 
                            +   to_rrparty   + from_rrparty  | country + year,
                            data = later_rounds_t, cluster = ~ countryyear )


## Robustness check RILE scores 
Table3_RILE_Later <-feols(party_dislike ~rile_distance_s  + govern_together + opposition_together 
             +   to_rrparty   + from_rrparty  | country + year,
             data = later_rounds, cluster = ~ countryyear )



Table3_Rile_Earlier <-feols(party_dislike ~ rile_distance_s + govern_together + opposition_together 
             +  to_rrparty   + from_rrparty  | country + year,
             data = former, cluster = ~ countryyear)





##run individual level models (Table 4)



load("multilevel_3_17.Rdata")



updated <-filter(updated, party_from != party_to)

updated <-filter(updated, to_mp_number != from_mp_number)

updated <-mutate(updated, cntryyr = paste(country, year, sep = " "))

##remove non evaluated dyads


updated <-filter(updated, is.na(thermometer_score) == F)


updated$dislike <-10 - updated$thermometer_score


updated <-mutate(updated, govern_together = ifelse(country == "United States of America", 0, govern_together),
                      opposition_together = ifelse(country == "United States of America", 0, opposition_together))



##models
library(fixest)

table3.1 <-feols(dislike ~ rile_distance_s | ID, cluster = ~ cntryyr, data = updated)
table3.1a <-lm(dislike ~ rile_distance_s + as.factor(country) + as.factor(year), data = updated)


##Using both CMP variables

##3.2 - Just 2 dimensional ideology
table3.2 <-feols(dislike ~ society_distance_s + econ_distance_s | ID, cluster = ~ cntryyr, data = updated)


##3.3 Just Coalition


table3.3 <-feols(dislike ~ govern_together + opposition_together | ID, cluster = ~ cntryyr, data = updated)

##Just RR Party
table3.4 <-feols(dislike ~  to_rrparty | ID, cluster = ~ cntryyr, data = updated)



##3.4

table3.5a <-feols(dislike ~ society_distance_s + econ_distance_s + govern_together + opposition_together
              + from_rrparty + to_rrparty | ID, cluster = ~ cntryyr, data = updated)

table3.6a <-feols(dislike ~ rile_distance_s + govern_together + opposition_together + 
                to_rrparty| ID, cluster = ~ cntryyr, data = updated)


later_rounds <-filter(updated, year > 2006) 
former <-filter(updated, year < 2007)







##Predicted Probabilities Plots

##Code for Figure 2


new_gov<-data.frame(rile_distance_s = seq(from = -1, to = 1, by = .05),
                    govern_together = 1, opposition_together = 0, 
                    from_rrparty = 0, to_rrparty = 0, country = "Netherlands", year = 1996)
new_ng <-data.frame(rile_distance_s = seq(from = -1, to = 1, by = .05),
                    govern_together = 0, opposition_together = 0, 
                    from_rrparty = 0, to_rrparty = 0, country = "Netherlands", year = 1996)


##get predicted probabilites
preds <-predict(table3.6p, newdata = new_gov, se.fit = T)
preds2 <-predict(table3.6p, newdata = new_ng, se.fit = T)

##Bind the predictions and the just craeted data frame
prd <-cbind(new_gov, preds)
prd2 <-cbind(new_ng, preds2)



p1 <- ggplot(NULL,  aes(x = rile_distance_s, y = fit)) + geom_line(data = prd, color = "blue")  + geom_errorbar(data = prd, aes(ymax = fit +2*se.fit, ymin = fit - 2*se.fit), alpha = 1, color = "blue", linetype = "dashed") +
  geom_line(data = prd2, color = "red") + geom_errorbar(data = prd2, aes(ymax = fit +2*se.fit, ymin = fit - 2*se.fit), alpha = 1, color = "red", linetype = "dashed") +
  xlab("Elite Left Right Distance") +
  ylab ("Predicted Level of Partisan Dislike ")  + theme(plot.title = element_text(hjust = 0.5))  + coord_cartesian(ylim = c(2.5, 8.5)) + theme(axis.title=element_text(size=20),  axis.text = element_text(size = 20))


##Radical Right Version
new_rr<-data.frame(rile_distance_s = seq(from = -1, to = 1, by = .05),
                   govern_together = 0, opposition_together = 0, 
                   from_rrparty = 0, to_rrparty = 0, country = "Netherlands", year = 1996)
new_rr2 <-data.frame(rile_distance_s = seq(from = -1, to = 1, by = .05),
                    govern_together = 0, opposition_together = 0, 
                    from_rrparty = 0, to_rrparty = 1, country = "Netherlands", year = 1996)


##get predicted probabilites
preds3 <-predict(table3.6p, newdata = new_rr, se.fit = T)
preds4 <-predict(table3.6p, newdata = new_rr2, se.fit = T)

##Bind the predictions and the just craeted data frame
prd3 <-cbind(new_rr, preds3)
prd4 <-cbind(new_rr2, preds4)



##
p2 <-ggplot(NULL,  aes(x = rile_distance_s, y = fit)) + geom_line(data = prd3, color = "blue")  + geom_errorbar(data = prd3, aes(ymax = fit +2*se.fit, ymin = fit - 2*se.fit), alpha = 1, color = "blue", linetype = "dashed") +
  geom_line(data = prd4, color = "red") + geom_errorbar(data = prd4, aes(ymax = fit +2*se.fit, ymin = fit - 2*se.fit), alpha = 1, color = "red", linetype = "dashed") +
  xlab("Elite Left Right Distance") +
  ylab ("Predicted level of Partisan Dislike")  + theme(plot.title = element_text(hjust = 0.5))  + coord_cartesian(ylim = c(2.5, 8.5)) + theme(axis.title=element_text(size=20),  axis.text = element_text(size = 20))




## Robustness Checks with CHES data

## Table A5 CHES robustness check
CHES_Mod <-feols(party_dislike ~ lrgen_distance_s |country + year, data = updated_data, cluster =~ countryyear)
CHES_Mod2 <-feols(party_dislike ~ lrgen_distance_s +govern_together + opposition_together +from_rrparty + 
                    to_rrparty  |country + year, data = updated_data, cluster =~ countryyear)

CHES_Mod
CHES_Mod2
CHES_Mod3 <-feols(party_dislike ~ lrecon_distance_s + galtan_distance_s |country + year, data = updated_data, cluster =~ countryyear)
CHES_Mod4 <-feols(party_dislike ~ lrecon_distance_s +galtan_distance_s + govern_together + opposition_together +from_rrparty + 
                    to_rrparty  |country + year, data = updated_data, cluster =~ countryyear)
CHES_Mod3
CHES_Mod4

## Individual Level models split by time period (table A8)



m5_l <-feols(dislike ~ society_distance_s+ econ_distance_s + govern_together + opposition_together 
             +   to_rrparty |country + year, cluster = ~ cntryyr,
             data = later_rounds)

m5_o <-feols(dislike ~ society_distance_s+ econ_distance_s + govern_together + opposition_together 
             +   to_rrparty   |country + year, cluster = ~ cntryyr,
             data = former)



##Non-Linear Models

LR_only_NL <-feols(party_dislike ~ (rile_distance_s^2) + govern_together + opposition_together +from_rrparty + 
                  to_rrparty | country + year, data = updated_data,
                cluster =~ countryyear)


two_dim_NL <-feols(party_dislike ~ (society_distance_s^2) + (econ_distance_s^2) + govern_together + opposition_together
                + from_rrparty + to_rrparty | country + year, data = updated_data, cluster =~ countryyear)


## Partial Residuals Plot for Supplementary Appendix

install.packages("visreg")
library(visreg)

## Note - ran using base R lm for simplicity of plotting - same results as FEOLS. 
table2.2 <-lm(party_dislike ~ society_distance_s + econ_distance_s + govern_together + opposition_together
              + from_rrparty + to_rrparty + as.factor(country) + as.factor(year), data = updated_data)


png(file="culture_partial_residual.png",
    width=800, height=600)

visreg(table2.2, "society_distance_s", partial = T, by = "country", layout=c(5,4), xlab = "Elite Cultural Polarization", ylab = "Out Party Dislike")
dev.off()

png(file="economic_partial_residual.png",
    width=800, height=600)
visreg(table2.2, "econ_distance_s", partial = T, by = "country", layout=c(5,4),xlab = "Elite Economic Polarization", ylab = "Out Party Dislike")
dev.off()


table2.1 <-lm(party_dislike ~ rile_distance_s + govern_together + opposition_together +from_rrparty + 
                to_rrparty +as.factor(country) + as.factor(year), data = updated_data)

png(file="left-right partial residual.png",
    width=800, height=600)
visreg(table2.1, "rile_distance_s", partial = T, by = "country", layout=c(5,4), xlab = "Elite Left-Right Polarization", ylab = "Out Party Dislike" )
dev.off()
