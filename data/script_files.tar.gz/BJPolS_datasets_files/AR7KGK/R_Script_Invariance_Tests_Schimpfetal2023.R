#############################################/
## R-Script - Analyses                      ##
## by: Schimpf, Wuttke, Schoen              ##
## Version: March 19, 2022                 ##
## R-Version: 4.1.0.                        ##
## Part - Measurement Invariance Test       ##
#############################################/

#####################################################/
#### /// MI Test - Anti-Elitism                  ####
#####################################################/

#### <<<>>> Configural Model ####
long_minvariance_syntax(var_list = list(t1 = c("Anti_Elite_W5_1", "Anti_Elite_W5_2", "Anti_Elite_W5_3"), 
                                        t2 = c("Anti_Elite_W8_1", "Anti_Elite_W8_2", "Anti_Elite_W8_3"),
                                        t3 = c("Anti_Elite_W9_1", "Anti_Elite_W9_2", "Anti_Elite_W9_3"),
                                        t3 = c("Anti_Elite_W13_1", "Anti_Elite_W13_2", "Anti_Elite_W13_3"),
                                        t3 = c("Anti_Elite_W14_1", "Anti_Elite_W14_2", "Anti_Elite_W14_3"),
                                        t3 = c("Anti_Elite_W15_1", "Anti_Elite_W15_2", "Anti_Elite_W15_3")), 
                        model = "configural") %>% 
  cat()

configural.v1 <-'

#### CONFIGURAL INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Anti_Elite_W5_1 + lambda1 * Anti_Elite_W5_1 + Anti_Elite_W5_2 + Anti_Elite_W5_3
eta2 =~ NA * Anti_Elite_W8_1 + lambda1 * Anti_Elite_W8_1 + Anti_Elite_W8_2 + Anti_Elite_W8_3
eta3 =~ NA * Anti_Elite_W9_1 + lambda1 * Anti_Elite_W9_1 + Anti_Elite_W9_2 + Anti_Elite_W9_3
eta4 =~ NA * Anti_Elite_W13_1 + lambda1 * Anti_Elite_W13_1 + Anti_Elite_W13_2 + Anti_Elite_W13_3
eta5 =~ NA * Anti_Elite_W14_1 + lambda1 * Anti_Elite_W14_1 + Anti_Elite_W14_2 + Anti_Elite_W14_3
eta6 =~ NA * Anti_Elite_W15_1 + lambda1 * Anti_Elite_W15_1 + Anti_Elite_W15_2 + Anti_Elite_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Anti_Elite_W5_1 ~ tau1 * 1 
Anti_Elite_W5_2 ~ 1 
Anti_Elite_W5_3 ~ 1 
Anti_Elite_W8_1 ~ tau1 * 1 
Anti_Elite_W8_2 ~ 1 
Anti_Elite_W8_3 ~ 1 
Anti_Elite_W9_1 ~ tau1 * 1 
Anti_Elite_W9_2 ~ 1 
Anti_Elite_W9_3 ~ 1 
Anti_Elite_W13_1 ~ tau1 * 1 
Anti_Elite_W13_2 ~ 1 
Anti_Elite_W13_3 ~ 1 
Anti_Elite_W14_1 ~ tau1 * 1 
Anti_Elite_W14_2 ~ 1 
Anti_Elite_W14_3 ~ 1 
Anti_Elite_W15_1 ~ tau1 * 1 
Anti_Elite_W15_2 ~ 1 
Anti_Elite_W15_3 ~ 1 
# Specify Unique Variances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W5_1 
Anti_Elite_W5_2 ~~ Anti_Elite_W5_2 
Anti_Elite_W5_3 ~~ Anti_Elite_W5_3 
Anti_Elite_W8_1 ~~ Anti_Elite_W8_1 
Anti_Elite_W8_2 ~~ Anti_Elite_W8_2 
Anti_Elite_W8_3 ~~ Anti_Elite_W8_3 
Anti_Elite_W9_1 ~~ Anti_Elite_W9_1 
Anti_Elite_W9_2 ~~ Anti_Elite_W9_2 
Anti_Elite_W9_3 ~~ Anti_Elite_W9_3 
Anti_Elite_W13_1 ~~ Anti_Elite_W13_1 
Anti_Elite_W13_2 ~~ Anti_Elite_W13_2 
Anti_Elite_W13_3 ~~ Anti_Elite_W13_3 
Anti_Elite_W14_1 ~~ Anti_Elite_W14_1 
Anti_Elite_W14_2 ~~ Anti_Elite_W14_2 
Anti_Elite_W14_3 ~~ Anti_Elite_W14_3 
Anti_Elite_W15_1 ~~ Anti_Elite_W15_1 
Anti_Elite_W15_2 ~~ Anti_Elite_W15_2 
Anti_Elite_W15_3 ~~ Anti_Elite_W15_3 
# Specify Unique Covariances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W8_1
Anti_Elite_W5_1 ~~ Anti_Elite_W9_1
Anti_Elite_W5_1 ~~ Anti_Elite_W13_1
Anti_Elite_W5_1 ~~ Anti_Elite_W14_1
Anti_Elite_W5_1 ~~ Anti_Elite_W15_1
Anti_Elite_W8_1 ~~ Anti_Elite_W9_1
Anti_Elite_W8_1 ~~ Anti_Elite_W13_1
Anti_Elite_W8_1 ~~ Anti_Elite_W14_1
Anti_Elite_W8_1 ~~ Anti_Elite_W15_1
Anti_Elite_W9_1 ~~ Anti_Elite_W13_1
Anti_Elite_W9_1 ~~ Anti_Elite_W14_1
Anti_Elite_W9_1 ~~ Anti_Elite_W15_1
Anti_Elite_W13_1 ~~ Anti_Elite_W14_1
Anti_Elite_W13_1 ~~ Anti_Elite_W15_1
Anti_Elite_W14_1 ~~ Anti_Elite_W15_1
Anti_Elite_W5_2 ~~ Anti_Elite_W8_2
Anti_Elite_W5_2 ~~ Anti_Elite_W9_2
Anti_Elite_W5_2 ~~ Anti_Elite_W13_2
Anti_Elite_W5_2 ~~ Anti_Elite_W14_2
Anti_Elite_W5_2 ~~ Anti_Elite_W15_2
Anti_Elite_W8_2 ~~ Anti_Elite_W9_2
Anti_Elite_W8_2 ~~ Anti_Elite_W13_2
Anti_Elite_W8_2 ~~ Anti_Elite_W14_2
Anti_Elite_W8_2 ~~ Anti_Elite_W15_2
Anti_Elite_W9_2 ~~ Anti_Elite_W13_2
Anti_Elite_W9_2 ~~ Anti_Elite_W14_2
Anti_Elite_W9_2 ~~ Anti_Elite_W15_2
Anti_Elite_W13_2 ~~ Anti_Elite_W14_2
Anti_Elite_W13_2 ~~ Anti_Elite_W15_2
Anti_Elite_W14_2 ~~ Anti_Elite_W15_2
Anti_Elite_W5_3 ~~ Anti_Elite_W8_3
Anti_Elite_W5_3 ~~ Anti_Elite_W9_3
Anti_Elite_W5_3 ~~ Anti_Elite_W13_3
Anti_Elite_W5_3 ~~ Anti_Elite_W14_3
Anti_Elite_W5_3 ~~ Anti_Elite_W15_3
Anti_Elite_W8_3 ~~ Anti_Elite_W9_3
Anti_Elite_W8_3 ~~ Anti_Elite_W13_3
Anti_Elite_W8_3 ~~ Anti_Elite_W14_3
Anti_Elite_W8_3 ~~ Anti_Elite_W15_3
Anti_Elite_W9_3 ~~ Anti_Elite_W13_3
Anti_Elite_W9_3 ~~ Anti_Elite_W14_3
Anti_Elite_W9_3 ~~ Anti_Elite_W15_3
Anti_Elite_W13_3 ~~ Anti_Elite_W14_3
Anti_Elite_W13_3 ~~ Anti_Elite_W15_3
Anti_Elite_W14_3 ~~ Anti_Elite_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
configural.fit_AE <-cfa(configural.v1,
                     data = df_GLES17,
                     estimator = "MLR",
                     se = "robust",
                     std.lv = TRUE)


#### <<<>>> Weak Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Anti_Elite_W5_1", "Anti_Elite_W5_2", "Anti_Elite_W5_3"), 
                                        t2 = c("Anti_Elite_W8_1", "Anti_Elite_W8_2", "Anti_Elite_W8_3"),
                                        t3 = c("Anti_Elite_W9_1", "Anti_Elite_W9_2", "Anti_Elite_W9_3"),
                                        t3 = c("Anti_Elite_W13_1", "Anti_Elite_W13_2", "Anti_Elite_W13_3"),
                                        t3 = c("Anti_Elite_W14_1", "Anti_Elite_W14_2", "Anti_Elite_W14_3"),
                                        t3 = c("Anti_Elite_W15_1", "Anti_Elite_W15_2", "Anti_Elite_W15_3")), 
                        model = "weak") %>% 
  cat()

weak.v1 <-'
#### WEAK INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Anti_Elite_W5_1 + lambda1 * Anti_Elite_W5_1 + lambda2 * Anti_Elite_W5_2 + lambda3 * Anti_Elite_W5_3
eta2 =~ NA * Anti_Elite_W8_1 + lambda1 * Anti_Elite_W8_1 + lambda2 * Anti_Elite_W8_2 + lambda3 * Anti_Elite_W8_3
eta3 =~ NA * Anti_Elite_W9_1 + lambda1 * Anti_Elite_W9_1 + lambda2 * Anti_Elite_W9_2 + lambda3 * Anti_Elite_W9_3
eta4 =~ NA * Anti_Elite_W13_1 + lambda1 * Anti_Elite_W13_1 + lambda2 * Anti_Elite_W13_2 + lambda3 * Anti_Elite_W13_3
eta5 =~ NA * Anti_Elite_W14_1 + lambda1 * Anti_Elite_W14_1 + lambda2 * Anti_Elite_W14_2 + lambda3 * Anti_Elite_W14_3
eta6 =~ NA * Anti_Elite_W15_1 + lambda1 * Anti_Elite_W15_1 + lambda2 * Anti_Elite_W15_2 + lambda3 * Anti_Elite_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Anti_Elite_W5_1 ~ tau1 * 1 
Anti_Elite_W5_2 ~ 1 
Anti_Elite_W5_3 ~ 1 
Anti_Elite_W8_1 ~ tau1 * 1 
Anti_Elite_W8_2 ~ 1 
Anti_Elite_W8_3 ~ 1 
Anti_Elite_W9_1 ~ tau1 * 1 
Anti_Elite_W9_2 ~ 1 
Anti_Elite_W9_3 ~ 1 
Anti_Elite_W13_1 ~ tau1 * 1 
Anti_Elite_W13_2 ~ 1 
Anti_Elite_W13_3 ~ 1 
Anti_Elite_W14_1 ~ tau1 * 1 
Anti_Elite_W14_2 ~ 1 
Anti_Elite_W14_3 ~ 1 
Anti_Elite_W15_1 ~ tau1 * 1 
Anti_Elite_W15_2 ~ 1 
Anti_Elite_W15_3 ~ 1 
# Specify Unique Variances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W5_1 
Anti_Elite_W5_2 ~~ Anti_Elite_W5_2 
Anti_Elite_W5_3 ~~ Anti_Elite_W5_3 
Anti_Elite_W8_1 ~~ Anti_Elite_W8_1 
Anti_Elite_W8_2 ~~ Anti_Elite_W8_2 
Anti_Elite_W8_3 ~~ Anti_Elite_W8_3 
Anti_Elite_W9_1 ~~ Anti_Elite_W9_1 
Anti_Elite_W9_2 ~~ Anti_Elite_W9_2 
Anti_Elite_W9_3 ~~ Anti_Elite_W9_3 
Anti_Elite_W13_1 ~~ Anti_Elite_W13_1 
Anti_Elite_W13_2 ~~ Anti_Elite_W13_2 
Anti_Elite_W13_3 ~~ Anti_Elite_W13_3 
Anti_Elite_W14_1 ~~ Anti_Elite_W14_1 
Anti_Elite_W14_2 ~~ Anti_Elite_W14_2 
Anti_Elite_W14_3 ~~ Anti_Elite_W14_3 
Anti_Elite_W15_1 ~~ Anti_Elite_W15_1 
Anti_Elite_W15_2 ~~ Anti_Elite_W15_2 
Anti_Elite_W15_3 ~~ Anti_Elite_W15_3 
# Specify Unique Covariances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W8_1
Anti_Elite_W5_1 ~~ Anti_Elite_W9_1
Anti_Elite_W5_1 ~~ Anti_Elite_W13_1
Anti_Elite_W5_1 ~~ Anti_Elite_W14_1
Anti_Elite_W5_1 ~~ Anti_Elite_W15_1
Anti_Elite_W8_1 ~~ Anti_Elite_W9_1
Anti_Elite_W8_1 ~~ Anti_Elite_W13_1
Anti_Elite_W8_1 ~~ Anti_Elite_W14_1
Anti_Elite_W8_1 ~~ Anti_Elite_W15_1
Anti_Elite_W9_1 ~~ Anti_Elite_W13_1
Anti_Elite_W9_1 ~~ Anti_Elite_W14_1
Anti_Elite_W9_1 ~~ Anti_Elite_W15_1
Anti_Elite_W13_1 ~~ Anti_Elite_W14_1
Anti_Elite_W13_1 ~~ Anti_Elite_W15_1
Anti_Elite_W14_1 ~~ Anti_Elite_W15_1
Anti_Elite_W5_2 ~~ Anti_Elite_W8_2
Anti_Elite_W5_2 ~~ Anti_Elite_W9_2
Anti_Elite_W5_2 ~~ Anti_Elite_W13_2
Anti_Elite_W5_2 ~~ Anti_Elite_W14_2
Anti_Elite_W5_2 ~~ Anti_Elite_W15_2
Anti_Elite_W8_2 ~~ Anti_Elite_W9_2
Anti_Elite_W8_2 ~~ Anti_Elite_W13_2
Anti_Elite_W8_2 ~~ Anti_Elite_W14_2
Anti_Elite_W8_2 ~~ Anti_Elite_W15_2
Anti_Elite_W9_2 ~~ Anti_Elite_W13_2
Anti_Elite_W9_2 ~~ Anti_Elite_W14_2
Anti_Elite_W9_2 ~~ Anti_Elite_W15_2
Anti_Elite_W13_2 ~~ Anti_Elite_W14_2
Anti_Elite_W13_2 ~~ Anti_Elite_W15_2
Anti_Elite_W14_2 ~~ Anti_Elite_W15_2
Anti_Elite_W5_3 ~~ Anti_Elite_W8_3
Anti_Elite_W5_3 ~~ Anti_Elite_W9_3
Anti_Elite_W5_3 ~~ Anti_Elite_W13_3
Anti_Elite_W5_3 ~~ Anti_Elite_W14_3
Anti_Elite_W5_3 ~~ Anti_Elite_W15_3
Anti_Elite_W8_3 ~~ Anti_Elite_W9_3
Anti_Elite_W8_3 ~~ Anti_Elite_W13_3
Anti_Elite_W8_3 ~~ Anti_Elite_W14_3
Anti_Elite_W8_3 ~~ Anti_Elite_W15_3
Anti_Elite_W9_3 ~~ Anti_Elite_W13_3
Anti_Elite_W9_3 ~~ Anti_Elite_W14_3
Anti_Elite_W9_3 ~~ Anti_Elite_W15_3
Anti_Elite_W13_3 ~~ Anti_Elite_W14_3
Anti_Elite_W13_3 ~~ Anti_Elite_W15_3
Anti_Elite_W14_3 ~~ Anti_Elite_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
weak.fit_AE <-cfa(weak.v1,data = df_GLES17,estimator = "MLR",se = "robust",
                  std.lv = TRUE)

#### <<<>>> Strong Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Anti_Elite_W5_1", "Anti_Elite_W5_2", "Anti_Elite_W5_3"), 
                                        t2 = c("Anti_Elite_W8_1", "Anti_Elite_W8_2", "Anti_Elite_W8_3"),
                                        t3 = c("Anti_Elite_W9_1", "Anti_Elite_W9_2", "Anti_Elite_W9_3"),
                                        t3 = c("Anti_Elite_W13_1", "Anti_Elite_W13_2", "Anti_Elite_W13_3"),
                                        t3 = c("Anti_Elite_W14_1", "Anti_Elite_W14_2", "Anti_Elite_W14_3"),
                                        t3 = c("Anti_Elite_W15_1", "Anti_Elite_W15_2", "Anti_Elite_W15_3")), 
                        model = "strong") %>% 
  cat()

strong.v1 <-'
#### STRONG INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Anti_Elite_W5_1 + lambda1 * Anti_Elite_W5_1 + lambda2 * Anti_Elite_W5_2 + lambda3 * Anti_Elite_W5_3
eta2 =~ NA * Anti_Elite_W8_1 + lambda1 * Anti_Elite_W8_1 + lambda2 * Anti_Elite_W8_2 + lambda3 * Anti_Elite_W8_3
eta3 =~ NA * Anti_Elite_W9_1 + lambda1 * Anti_Elite_W9_1 + lambda2 * Anti_Elite_W9_2 + lambda3 * Anti_Elite_W9_3
eta4 =~ NA * Anti_Elite_W13_1 + lambda1 * Anti_Elite_W13_1 + lambda2 * Anti_Elite_W13_2 + lambda3 * Anti_Elite_W13_3
eta5 =~ NA * Anti_Elite_W14_1 + lambda1 * Anti_Elite_W14_1 + lambda2 * Anti_Elite_W14_2 + lambda3 * Anti_Elite_W14_3
eta6 =~ NA * Anti_Elite_W15_1 + lambda1 * Anti_Elite_W15_1 + lambda2 * Anti_Elite_W15_2 + lambda3 * Anti_Elite_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Anti_Elite_W5_1 ~ tau1 * 1 
Anti_Elite_W5_2 ~ tau2 * 1 
Anti_Elite_W5_3 ~ tau3 * 1 
Anti_Elite_W8_1 ~ tau1 * 1 
Anti_Elite_W8_2 ~ tau2 * 1 
Anti_Elite_W8_3 ~ tau3 * 1 
Anti_Elite_W9_1 ~ tau1 * 1 
Anti_Elite_W9_2 ~ tau2 * 1 
Anti_Elite_W9_3 ~ tau3 * 1 
Anti_Elite_W13_1 ~ tau1 * 1 
Anti_Elite_W13_2 ~ tau2 * 1 
Anti_Elite_W13_3 ~ tau3 * 1 
Anti_Elite_W14_1 ~ tau1 * 1 
Anti_Elite_W14_2 ~ tau2 * 1 
Anti_Elite_W14_3 ~ tau3 * 1 
Anti_Elite_W15_1 ~ tau1 * 1 
Anti_Elite_W15_2 ~ tau2 * 1 
Anti_Elite_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W5_1 
Anti_Elite_W5_2 ~~ Anti_Elite_W5_2 
Anti_Elite_W5_3 ~~ Anti_Elite_W5_3 
Anti_Elite_W8_1 ~~ Anti_Elite_W8_1 
Anti_Elite_W8_2 ~~ Anti_Elite_W8_2 
Anti_Elite_W8_3 ~~ Anti_Elite_W8_3 
Anti_Elite_W9_1 ~~ Anti_Elite_W9_1 
Anti_Elite_W9_2 ~~ Anti_Elite_W9_2 
Anti_Elite_W9_3 ~~ Anti_Elite_W9_3 
Anti_Elite_W13_1 ~~ Anti_Elite_W13_1 
Anti_Elite_W13_2 ~~ Anti_Elite_W13_2 
Anti_Elite_W13_3 ~~ Anti_Elite_W13_3 
Anti_Elite_W14_1 ~~ Anti_Elite_W14_1 
Anti_Elite_W14_2 ~~ Anti_Elite_W14_2 
Anti_Elite_W14_3 ~~ Anti_Elite_W14_3 
Anti_Elite_W15_1 ~~ Anti_Elite_W15_1 
Anti_Elite_W15_2 ~~ Anti_Elite_W15_2 
Anti_Elite_W15_3 ~~ Anti_Elite_W15_3 
# Specify Unique Covariances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W8_1
Anti_Elite_W5_1 ~~ Anti_Elite_W9_1
Anti_Elite_W5_1 ~~ Anti_Elite_W13_1
Anti_Elite_W5_1 ~~ Anti_Elite_W14_1
Anti_Elite_W5_1 ~~ Anti_Elite_W15_1
Anti_Elite_W8_1 ~~ Anti_Elite_W9_1
Anti_Elite_W8_1 ~~ Anti_Elite_W13_1
Anti_Elite_W8_1 ~~ Anti_Elite_W14_1
Anti_Elite_W8_1 ~~ Anti_Elite_W15_1
Anti_Elite_W9_1 ~~ Anti_Elite_W13_1
Anti_Elite_W9_1 ~~ Anti_Elite_W14_1
Anti_Elite_W9_1 ~~ Anti_Elite_W15_1
Anti_Elite_W13_1 ~~ Anti_Elite_W14_1
Anti_Elite_W13_1 ~~ Anti_Elite_W15_1
Anti_Elite_W14_1 ~~ Anti_Elite_W15_1
Anti_Elite_W5_2 ~~ Anti_Elite_W8_2
Anti_Elite_W5_2 ~~ Anti_Elite_W9_2
Anti_Elite_W5_2 ~~ Anti_Elite_W13_2
Anti_Elite_W5_2 ~~ Anti_Elite_W14_2
Anti_Elite_W5_2 ~~ Anti_Elite_W15_2
Anti_Elite_W8_2 ~~ Anti_Elite_W9_2
Anti_Elite_W8_2 ~~ Anti_Elite_W13_2
Anti_Elite_W8_2 ~~ Anti_Elite_W14_2
Anti_Elite_W8_2 ~~ Anti_Elite_W15_2
Anti_Elite_W9_2 ~~ Anti_Elite_W13_2
Anti_Elite_W9_2 ~~ Anti_Elite_W14_2
Anti_Elite_W9_2 ~~ Anti_Elite_W15_2
Anti_Elite_W13_2 ~~ Anti_Elite_W14_2
Anti_Elite_W13_2 ~~ Anti_Elite_W15_2
Anti_Elite_W14_2 ~~ Anti_Elite_W15_2
Anti_Elite_W5_3 ~~ Anti_Elite_W8_3
Anti_Elite_W5_3 ~~ Anti_Elite_W9_3
Anti_Elite_W5_3 ~~ Anti_Elite_W13_3
Anti_Elite_W5_3 ~~ Anti_Elite_W14_3
Anti_Elite_W5_3 ~~ Anti_Elite_W15_3
Anti_Elite_W8_3 ~~ Anti_Elite_W9_3
Anti_Elite_W8_3 ~~ Anti_Elite_W13_3
Anti_Elite_W8_3 ~~ Anti_Elite_W14_3
Anti_Elite_W8_3 ~~ Anti_Elite_W15_3
Anti_Elite_W9_3 ~~ Anti_Elite_W13_3
Anti_Elite_W9_3 ~~ Anti_Elite_W14_3
Anti_Elite_W9_3 ~~ Anti_Elite_W15_3
Anti_Elite_W13_3 ~~ Anti_Elite_W14_3
Anti_Elite_W13_3 ~~ Anti_Elite_W15_3
Anti_Elite_W14_3 ~~ Anti_Elite_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strong.fit_AE <-cfa(strong.v1,data = df_GLES17,estimator = "MLR",
                    se = "robust",
                    std.lv = TRUE)

#### <<<>>> Strict Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Anti_Elite_W5_1", "Anti_Elite_W5_2", "Anti_Elite_W5_3"), 
                                        t2 = c("Anti_Elite_W8_1", "Anti_Elite_W8_2", "Anti_Elite_W8_3"),
                                        t3 = c("Anti_Elite_W9_1", "Anti_Elite_W9_2", "Anti_Elite_W9_3"),
                                        t3 = c("Anti_Elite_W13_1", "Anti_Elite_W13_2", "Anti_Elite_W13_3"),
                                        t3 = c("Anti_Elite_W14_1", "Anti_Elite_W14_2", "Anti_Elite_W14_3"),
                                        t3 = c("Anti_Elite_W15_1", "Anti_Elite_W15_2", "Anti_Elite_W15_3")), 
                        model = "strict") %>% 
  cat()

strict.v1 <-'
#### STRICT INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Anti_Elite_W5_1 + lambda1 * Anti_Elite_W5_1 + lambda2 * Anti_Elite_W5_2 + lambda3 * Anti_Elite_W5_3
eta2 =~ NA * Anti_Elite_W8_1 + lambda1 * Anti_Elite_W8_1 + lambda2 * Anti_Elite_W8_2 + lambda3 * Anti_Elite_W8_3
eta3 =~ NA * Anti_Elite_W9_1 + lambda1 * Anti_Elite_W9_1 + lambda2 * Anti_Elite_W9_2 + lambda3 * Anti_Elite_W9_3
eta4 =~ NA * Anti_Elite_W13_1 + lambda1 * Anti_Elite_W13_1 + lambda2 * Anti_Elite_W13_2 + lambda3 * Anti_Elite_W13_3
eta5 =~ NA * Anti_Elite_W14_1 + lambda1 * Anti_Elite_W14_1 + lambda2 * Anti_Elite_W14_2 + lambda3 * Anti_Elite_W14_3
eta6 =~ NA * Anti_Elite_W15_1 + lambda1 * Anti_Elite_W15_1 + lambda2 * Anti_Elite_W15_2 + lambda3 * Anti_Elite_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Anti_Elite_W5_1 ~ tau1 * 1 
Anti_Elite_W5_2 ~ tau2 * 1 
Anti_Elite_W5_3 ~ tau3 * 1 
Anti_Elite_W8_1 ~ tau1 * 1 
Anti_Elite_W8_2 ~ tau2 * 1 
Anti_Elite_W8_3 ~ tau3 * 1 
Anti_Elite_W9_1 ~ tau1 * 1 
Anti_Elite_W9_2 ~ tau2 * 1 
Anti_Elite_W9_3 ~ tau3 * 1 
Anti_Elite_W13_1 ~ tau1 * 1 
Anti_Elite_W13_2 ~ tau2 * 1 
Anti_Elite_W13_3 ~ tau3 * 1 
Anti_Elite_W14_1 ~ tau1 * 1 
Anti_Elite_W14_2 ~ tau2 * 1 
Anti_Elite_W14_3 ~ tau3 * 1 
Anti_Elite_W15_1 ~ tau1 * 1 
Anti_Elite_W15_2 ~ tau2 * 1 
Anti_Elite_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Anti_Elite_W5_1 ~~ theta1 * Anti_Elite_W5_1 
Anti_Elite_W5_2 ~~ theta2 * Anti_Elite_W5_2 
Anti_Elite_W5_3 ~~ theta3 * Anti_Elite_W5_3 
Anti_Elite_W8_1 ~~ theta1 * Anti_Elite_W8_1 
Anti_Elite_W8_2 ~~ theta2 * Anti_Elite_W8_2 
Anti_Elite_W8_3 ~~ theta3 * Anti_Elite_W8_3 
Anti_Elite_W9_1 ~~ theta1 * Anti_Elite_W9_1 
Anti_Elite_W9_2 ~~ theta2 * Anti_Elite_W9_2 
Anti_Elite_W9_3 ~~ theta3 * Anti_Elite_W9_3 
Anti_Elite_W13_1 ~~ theta1 * Anti_Elite_W13_1 
Anti_Elite_W13_2 ~~ theta2 * Anti_Elite_W13_2 
Anti_Elite_W13_3 ~~ theta3 * Anti_Elite_W13_3 
Anti_Elite_W14_1 ~~ theta1 * Anti_Elite_W14_1 
Anti_Elite_W14_2 ~~ theta2 * Anti_Elite_W14_2 
Anti_Elite_W14_3 ~~ theta3 * Anti_Elite_W14_3 
Anti_Elite_W15_1 ~~ theta1 * Anti_Elite_W15_1 
Anti_Elite_W15_2 ~~ theta2 * Anti_Elite_W15_2 
Anti_Elite_W15_3 ~~ theta3 * Anti_Elite_W15_3 
# Specify Unique Covariances ----
Anti_Elite_W5_1 ~~ Anti_Elite_W8_1
Anti_Elite_W5_1 ~~ Anti_Elite_W9_1
Anti_Elite_W5_1 ~~ Anti_Elite_W13_1
Anti_Elite_W5_1 ~~ Anti_Elite_W14_1
Anti_Elite_W5_1 ~~ Anti_Elite_W15_1
Anti_Elite_W8_1 ~~ Anti_Elite_W9_1
Anti_Elite_W8_1 ~~ Anti_Elite_W13_1
Anti_Elite_W8_1 ~~ Anti_Elite_W14_1
Anti_Elite_W8_1 ~~ Anti_Elite_W15_1
Anti_Elite_W9_1 ~~ Anti_Elite_W13_1
Anti_Elite_W9_1 ~~ Anti_Elite_W14_1
Anti_Elite_W9_1 ~~ Anti_Elite_W15_1
Anti_Elite_W13_1 ~~ Anti_Elite_W14_1
Anti_Elite_W13_1 ~~ Anti_Elite_W15_1
Anti_Elite_W14_1 ~~ Anti_Elite_W15_1
Anti_Elite_W5_2 ~~ Anti_Elite_W8_2
Anti_Elite_W5_2 ~~ Anti_Elite_W9_2
Anti_Elite_W5_2 ~~ Anti_Elite_W13_2
Anti_Elite_W5_2 ~~ Anti_Elite_W14_2
Anti_Elite_W5_2 ~~ Anti_Elite_W15_2
Anti_Elite_W8_2 ~~ Anti_Elite_W9_2
Anti_Elite_W8_2 ~~ Anti_Elite_W13_2
Anti_Elite_W8_2 ~~ Anti_Elite_W14_2
Anti_Elite_W8_2 ~~ Anti_Elite_W15_2
Anti_Elite_W9_2 ~~ Anti_Elite_W13_2
Anti_Elite_W9_2 ~~ Anti_Elite_W14_2
Anti_Elite_W9_2 ~~ Anti_Elite_W15_2
Anti_Elite_W13_2 ~~ Anti_Elite_W14_2
Anti_Elite_W13_2 ~~ Anti_Elite_W15_2
Anti_Elite_W14_2 ~~ Anti_Elite_W15_2
Anti_Elite_W5_3 ~~ Anti_Elite_W8_3
Anti_Elite_W5_3 ~~ Anti_Elite_W9_3
Anti_Elite_W5_3 ~~ Anti_Elite_W13_3
Anti_Elite_W5_3 ~~ Anti_Elite_W14_3
Anti_Elite_W5_3 ~~ Anti_Elite_W15_3
Anti_Elite_W8_3 ~~ Anti_Elite_W9_3
Anti_Elite_W8_3 ~~ Anti_Elite_W13_3
Anti_Elite_W8_3 ~~ Anti_Elite_W14_3
Anti_Elite_W8_3 ~~ Anti_Elite_W15_3
Anti_Elite_W9_3 ~~ Anti_Elite_W13_3
Anti_Elite_W9_3 ~~ Anti_Elite_W14_3
Anti_Elite_W9_3 ~~ Anti_Elite_W15_3
Anti_Elite_W13_3 ~~ Anti_Elite_W14_3
Anti_Elite_W13_3 ~~ Anti_Elite_W15_3
Anti_Elite_W14_3 ~~ Anti_Elite_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strict.fit_AE <-cfa(strict.v1,data = df_GLES17,estimator = "MLR",se = "robust",
                    std.lv = TRUE)

#### <<<>>> Comparinson - Fit Indeces (Anti-Elitism) ####

fitM_AntiElite_Config <- as.data.frame(fitMeasures(configural.fit_AE))
fitM_AntiElite_Weak <- as.data.frame(fitMeasures(weak.fit_AE))
fitM_AntiElite_Strong <- as.data.frame(fitMeasures(strong.fit_AE))
fitM_AntiElite_Strict <- as.data.frame(fitMeasures(strict.fit_AE))

## Extract Relevant Fit Measures (Following Mckinnon et al 2021) and create df
## columns for table

Indices_Anti_Elitism <- c("No. of estimated parameters",
                          "Raw Loglikelihood",
                          "Robust CFI",
                          "Robust RMSEA")
Configural_Anti_Elitism <- slice(fitM_AntiElite_Config,c(1,36,27,52))
Metric_Anti_Elitism <- slice(fitM_AntiElite_Weak,c(1,36,27,52))
Scalar_Anti_Elitism <- slice(fitM_AntiElite_Strong,c(1,36,27,52))
Residual_Anti_Elitism <- slice(fitM_AntiElite_Strict,c(1,36,27,52))

#Bind relevant fit measures
tab_invariance_ae <- cbind(Indices_Anti_Elitism, round(cbind(Configural_Anti_Elitism, 
      Metric_Anti_Elitism, Scalar_Anti_Elitism,
      Residual_Anti_Elitism), 3))

#####################################################/
#### /// MI Test - Homogeneity                   ####
#####################################################/


#### <<<>>> Configural Model ####
long_minvariance_syntax(var_list = list(t1 = c("Homogeneity_W5_1", "Homogeneity_W5_2", "Homogeneity_W5_3"), 
                                        t2 = c("Homogeneity_W8_1", "Homogeneity_W8_2", "Homogeneity_W8_3"),
                                        t3 = c("Homogeneity_W9_1", "Homogeneity_W9_2", "Homogeneity_W9_3"),
                                        t3 = c("Homogeneity_W13_1", "Homogeneity_W13_2", "Homogeneity_W13_3"),
                                        t3 = c("Homogeneity_W14_1", "Homogeneity_W14_2", "Homogeneity_W14_3"),
                                        t3 = c("Homogeneity_W15_1", "Homogeneity_W15_2", "Homogeneity_W15_3")), 
                        model = "configural") %>% 
  cat()
# Model
configural.v2 <-'

#### CONFIGURAL INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Homogeneity_W5_1 + lambda1 * Homogeneity_W5_1 + Homogeneity_W5_2 + Homogeneity_W5_3
eta2 =~ NA * Homogeneity_W8_1 + lambda1 * Homogeneity_W8_1 + Homogeneity_W8_2 + Homogeneity_W8_3
eta3 =~ NA * Homogeneity_W9_1 + lambda1 * Homogeneity_W9_1 + Homogeneity_W9_2 + Homogeneity_W9_3
eta4 =~ NA * Homogeneity_W13_1 + lambda1 * Homogeneity_W13_1 + Homogeneity_W13_2 + Homogeneity_W13_3
eta5 =~ NA * Homogeneity_W14_1 + lambda1 * Homogeneity_W14_1 + Homogeneity_W14_2 + Homogeneity_W14_3
eta6 =~ NA * Homogeneity_W15_1 + lambda1 * Homogeneity_W15_1 + Homogeneity_W15_2 + Homogeneity_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Homogeneity_W5_1 ~ tau1 * 1 
Homogeneity_W5_2 ~ 1 
Homogeneity_W5_3 ~ 1 
Homogeneity_W8_1 ~ tau1 * 1 
Homogeneity_W8_2 ~ 1 
Homogeneity_W8_3 ~ 1 
Homogeneity_W9_1 ~ tau1 * 1 
Homogeneity_W9_2 ~ 1 
Homogeneity_W9_3 ~ 1 
Homogeneity_W13_1 ~ tau1 * 1 
Homogeneity_W13_2 ~ 1 
Homogeneity_W13_3 ~ 1 
Homogeneity_W14_1 ~ tau1 * 1 
Homogeneity_W14_2 ~ 1 
Homogeneity_W14_3 ~ 1 
Homogeneity_W15_1 ~ tau1 * 1 
Homogeneity_W15_2 ~ 1 
Homogeneity_W15_3 ~ 1 
# Specify Unique Variances ----
Homogeneity_W5_1 ~~ Homogeneity_W5_1 
Homogeneity_W5_2 ~~ Homogeneity_W5_2 
Homogeneity_W5_3 ~~ Homogeneity_W5_3 
Homogeneity_W8_1 ~~ Homogeneity_W8_1 
Homogeneity_W8_2 ~~ Homogeneity_W8_2 
Homogeneity_W8_3 ~~ Homogeneity_W8_3 
Homogeneity_W9_1 ~~ Homogeneity_W9_1 
Homogeneity_W9_2 ~~ Homogeneity_W9_2 
Homogeneity_W9_3 ~~ Homogeneity_W9_3 
Homogeneity_W13_1 ~~ Homogeneity_W13_1 
Homogeneity_W13_2 ~~ Homogeneity_W13_2 
Homogeneity_W13_3 ~~ Homogeneity_W13_3 
Homogeneity_W14_1 ~~ Homogeneity_W14_1 
Homogeneity_W14_2 ~~ Homogeneity_W14_2 
Homogeneity_W14_3 ~~ Homogeneity_W14_3 
Homogeneity_W15_1 ~~ Homogeneity_W15_1 
Homogeneity_W15_2 ~~ Homogeneity_W15_2 
Homogeneity_W15_3 ~~ Homogeneity_W15_3 
# Specify Unique Covariances ----
Homogeneity_W5_1 ~~ Homogeneity_W8_1
Homogeneity_W5_1 ~~ Homogeneity_W9_1
Homogeneity_W5_1 ~~ Homogeneity_W13_1
Homogeneity_W5_1 ~~ Homogeneity_W14_1
Homogeneity_W5_1 ~~ Homogeneity_W15_1
Homogeneity_W8_1 ~~ Homogeneity_W9_1
Homogeneity_W8_1 ~~ Homogeneity_W13_1
Homogeneity_W8_1 ~~ Homogeneity_W14_1
Homogeneity_W8_1 ~~ Homogeneity_W15_1
Homogeneity_W9_1 ~~ Homogeneity_W13_1
Homogeneity_W9_1 ~~ Homogeneity_W14_1
Homogeneity_W9_1 ~~ Homogeneity_W15_1
Homogeneity_W13_1 ~~ Homogeneity_W14_1
Homogeneity_W13_1 ~~ Homogeneity_W15_1
Homogeneity_W14_1 ~~ Homogeneity_W15_1
Homogeneity_W5_2 ~~ Homogeneity_W8_2
Homogeneity_W5_2 ~~ Homogeneity_W9_2
Homogeneity_W5_2 ~~ Homogeneity_W13_2
Homogeneity_W5_2 ~~ Homogeneity_W14_2
Homogeneity_W5_2 ~~ Homogeneity_W15_2
Homogeneity_W8_2 ~~ Homogeneity_W9_2
Homogeneity_W8_2 ~~ Homogeneity_W13_2
Homogeneity_W8_2 ~~ Homogeneity_W14_2
Homogeneity_W8_2 ~~ Homogeneity_W15_2
Homogeneity_W9_2 ~~ Homogeneity_W13_2
Homogeneity_W9_2 ~~ Homogeneity_W14_2
Homogeneity_W9_2 ~~ Homogeneity_W15_2
Homogeneity_W13_2 ~~ Homogeneity_W14_2
Homogeneity_W13_2 ~~ Homogeneity_W15_2
Homogeneity_W14_2 ~~ Homogeneity_W15_2
Homogeneity_W5_3 ~~ Homogeneity_W8_3
Homogeneity_W5_3 ~~ Homogeneity_W9_3
Homogeneity_W5_3 ~~ Homogeneity_W13_3
Homogeneity_W5_3 ~~ Homogeneity_W14_3
Homogeneity_W5_3 ~~ Homogeneity_W15_3
Homogeneity_W8_3 ~~ Homogeneity_W9_3
Homogeneity_W8_3 ~~ Homogeneity_W13_3
Homogeneity_W8_3 ~~ Homogeneity_W14_3
Homogeneity_W8_3 ~~ Homogeneity_W15_3
Homogeneity_W9_3 ~~ Homogeneity_W13_3
Homogeneity_W9_3 ~~ Homogeneity_W14_3
Homogeneity_W9_3 ~~ Homogeneity_W15_3
Homogeneity_W13_3 ~~ Homogeneity_W14_3
Homogeneity_W13_3 ~~ Homogeneity_W15_3
Homogeneity_W14_3 ~~ Homogeneity_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
configural.fit_HO <-cfa(configural.v2,
                        data = df_GLES17,
                        estimator = "MLR",
                        se = "robust",
                        std.lv = TRUE)


#### <<<>>> Weak Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Homogeneity_W5_1", "Homogeneity_W5_2", "Homogeneity_W5_3"), 
                                        t2 = c("Homogeneity_W8_1", "Homogeneity_W8_2", "Homogeneity_W8_3"),
                                        t3 = c("Homogeneity_W9_1", "Homogeneity_W9_2", "Homogeneity_W9_3"),
                                        t3 = c("Homogeneity_W13_1", "Homogeneity_W13_2", "Homogeneity_W13_3"),
                                        t3 = c("Homogeneity_W14_1", "Homogeneity_W14_2", "Homogeneity_W14_3"),
                                        t3 = c("Homogeneity_W15_1", "Homogeneity_W15_2", "Homogeneity_W15_3")), 
                        model = "weak") %>% 
  cat()

weak.v2 <-'
#### WEAK INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Homogeneity_W5_1 + lambda1 * Homogeneity_W5_1 + lambda2 * Homogeneity_W5_2 + lambda3 * Homogeneity_W5_3
eta2 =~ NA * Homogeneity_W8_1 + lambda1 * Homogeneity_W8_1 + lambda2 * Homogeneity_W8_2 + lambda3 * Homogeneity_W8_3
eta3 =~ NA * Homogeneity_W9_1 + lambda1 * Homogeneity_W9_1 + lambda2 * Homogeneity_W9_2 + lambda3 * Homogeneity_W9_3
eta4 =~ NA * Homogeneity_W13_1 + lambda1 * Homogeneity_W13_1 + lambda2 * Homogeneity_W13_2 + lambda3 * Homogeneity_W13_3
eta5 =~ NA * Homogeneity_W14_1 + lambda1 * Homogeneity_W14_1 + lambda2 * Homogeneity_W14_2 + lambda3 * Homogeneity_W14_3
eta6 =~ NA * Homogeneity_W15_1 + lambda1 * Homogeneity_W15_1 + lambda2 * Homogeneity_W15_2 + lambda3 * Homogeneity_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Homogeneity_W5_1 ~ tau1 * 1 
Homogeneity_W5_2 ~ 1 
Homogeneity_W5_3 ~ 1 
Homogeneity_W8_1 ~ tau1 * 1 
Homogeneity_W8_2 ~ 1 
Homogeneity_W8_3 ~ 1 
Homogeneity_W9_1 ~ tau1 * 1 
Homogeneity_W9_2 ~ 1 
Homogeneity_W9_3 ~ 1 
Homogeneity_W13_1 ~ tau1 * 1 
Homogeneity_W13_2 ~ 1 
Homogeneity_W13_3 ~ 1 
Homogeneity_W14_1 ~ tau1 * 1 
Homogeneity_W14_2 ~ 1 
Homogeneity_W14_3 ~ 1 
Homogeneity_W15_1 ~ tau1 * 1 
Homogeneity_W15_2 ~ 1 
Homogeneity_W15_3 ~ 1 
# Specify Unique Variances ----
Homogeneity_W5_1 ~~ Homogeneity_W5_1 
Homogeneity_W5_2 ~~ Homogeneity_W5_2 
Homogeneity_W5_3 ~~ Homogeneity_W5_3 
Homogeneity_W8_1 ~~ Homogeneity_W8_1 
Homogeneity_W8_2 ~~ Homogeneity_W8_2 
Homogeneity_W8_3 ~~ Homogeneity_W8_3 
Homogeneity_W9_1 ~~ Homogeneity_W9_1 
Homogeneity_W9_2 ~~ Homogeneity_W9_2 
Homogeneity_W9_3 ~~ Homogeneity_W9_3 
Homogeneity_W13_1 ~~ Homogeneity_W13_1 
Homogeneity_W13_2 ~~ Homogeneity_W13_2 
Homogeneity_W13_3 ~~ Homogeneity_W13_3 
Homogeneity_W14_1 ~~ Homogeneity_W14_1 
Homogeneity_W14_2 ~~ Homogeneity_W14_2 
Homogeneity_W14_3 ~~ Homogeneity_W14_3 
Homogeneity_W15_1 ~~ Homogeneity_W15_1 
Homogeneity_W15_2 ~~ Homogeneity_W15_2 
Homogeneity_W15_3 ~~ Homogeneity_W15_3 
# Specify Unique Covariances ----
Homogeneity_W5_1 ~~ Homogeneity_W8_1
Homogeneity_W5_1 ~~ Homogeneity_W9_1
Homogeneity_W5_1 ~~ Homogeneity_W13_1
Homogeneity_W5_1 ~~ Homogeneity_W14_1
Homogeneity_W5_1 ~~ Homogeneity_W15_1
Homogeneity_W8_1 ~~ Homogeneity_W9_1
Homogeneity_W8_1 ~~ Homogeneity_W13_1
Homogeneity_W8_1 ~~ Homogeneity_W14_1
Homogeneity_W8_1 ~~ Homogeneity_W15_1
Homogeneity_W9_1 ~~ Homogeneity_W13_1
Homogeneity_W9_1 ~~ Homogeneity_W14_1
Homogeneity_W9_1 ~~ Homogeneity_W15_1
Homogeneity_W13_1 ~~ Homogeneity_W14_1
Homogeneity_W13_1 ~~ Homogeneity_W15_1
Homogeneity_W14_1 ~~ Homogeneity_W15_1
Homogeneity_W5_2 ~~ Homogeneity_W8_2
Homogeneity_W5_2 ~~ Homogeneity_W9_2
Homogeneity_W5_2 ~~ Homogeneity_W13_2
Homogeneity_W5_2 ~~ Homogeneity_W14_2
Homogeneity_W5_2 ~~ Homogeneity_W15_2
Homogeneity_W8_2 ~~ Homogeneity_W9_2
Homogeneity_W8_2 ~~ Homogeneity_W13_2
Homogeneity_W8_2 ~~ Homogeneity_W14_2
Homogeneity_W8_2 ~~ Homogeneity_W15_2
Homogeneity_W9_2 ~~ Homogeneity_W13_2
Homogeneity_W9_2 ~~ Homogeneity_W14_2
Homogeneity_W9_2 ~~ Homogeneity_W15_2
Homogeneity_W13_2 ~~ Homogeneity_W14_2
Homogeneity_W13_2 ~~ Homogeneity_W15_2
Homogeneity_W14_2 ~~ Homogeneity_W15_2
Homogeneity_W5_3 ~~ Homogeneity_W8_3
Homogeneity_W5_3 ~~ Homogeneity_W9_3
Homogeneity_W5_3 ~~ Homogeneity_W13_3
Homogeneity_W5_3 ~~ Homogeneity_W14_3
Homogeneity_W5_3 ~~ Homogeneity_W15_3
Homogeneity_W8_3 ~~ Homogeneity_W9_3
Homogeneity_W8_3 ~~ Homogeneity_W13_3
Homogeneity_W8_3 ~~ Homogeneity_W14_3
Homogeneity_W8_3 ~~ Homogeneity_W15_3
Homogeneity_W9_3 ~~ Homogeneity_W13_3
Homogeneity_W9_3 ~~ Homogeneity_W14_3
Homogeneity_W9_3 ~~ Homogeneity_W15_3
Homogeneity_W13_3 ~~ Homogeneity_W14_3
Homogeneity_W13_3 ~~ Homogeneity_W15_3
Homogeneity_W14_3 ~~ Homogeneity_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
weak.fit_HO <-cfa(weak.v2,data = df_GLES17,estimator = "MLR",se = "robust",
                  std.lv = TRUE)

#### <<<>>> Strong Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Homogeneity_W5_1", "Homogeneity_W5_2", "Homogeneity_W5_3"), 
                                        t2 = c("Homogeneity_W8_1", "Homogeneity_W8_2", "Homogeneity_W8_3"),
                                        t3 = c("Homogeneity_W9_1", "Homogeneity_W9_2", "Homogeneity_W9_3"),
                                        t3 = c("Homogeneity_W13_1", "Homogeneity_W13_2", "Homogeneity_W13_3"),
                                        t3 = c("Homogeneity_W14_1", "Homogeneity_W14_2", "Homogeneity_W14_3"),
                                        t3 = c("Homogeneity_W15_1", "Homogeneity_W15_2", "Homogeneity_W15_3")), 
                        model = "strong") %>% 
  cat()

strong.v2 <-'
#### STRONG INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Homogeneity_W5_1 + lambda1 * Homogeneity_W5_1 + lambda2 * Homogeneity_W5_2 + lambda3 * Homogeneity_W5_3
eta2 =~ NA * Homogeneity_W8_1 + lambda1 * Homogeneity_W8_1 + lambda2 * Homogeneity_W8_2 + lambda3 * Homogeneity_W8_3
eta3 =~ NA * Homogeneity_W9_1 + lambda1 * Homogeneity_W9_1 + lambda2 * Homogeneity_W9_2 + lambda3 * Homogeneity_W9_3
eta4 =~ NA * Homogeneity_W13_1 + lambda1 * Homogeneity_W13_1 + lambda2 * Homogeneity_W13_2 + lambda3 * Homogeneity_W13_3
eta5 =~ NA * Homogeneity_W14_1 + lambda1 * Homogeneity_W14_1 + lambda2 * Homogeneity_W14_2 + lambda3 * Homogeneity_W14_3
eta6 =~ NA * Homogeneity_W15_1 + lambda1 * Homogeneity_W15_1 + lambda2 * Homogeneity_W15_2 + lambda3 * Homogeneity_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Homogeneity_W5_1 ~ tau1 * 1 
Homogeneity_W5_2 ~ tau2 * 1 
Homogeneity_W5_3 ~ tau3 * 1 
Homogeneity_W8_1 ~ tau1 * 1 
Homogeneity_W8_2 ~ tau2 * 1 
Homogeneity_W8_3 ~ tau3 * 1 
Homogeneity_W9_1 ~ tau1 * 1 
Homogeneity_W9_2 ~ tau2 * 1 
Homogeneity_W9_3 ~ tau3 * 1 
Homogeneity_W13_1 ~ tau1 * 1 
Homogeneity_W13_2 ~ tau2 * 1 
Homogeneity_W13_3 ~ tau3 * 1 
Homogeneity_W14_1 ~ tau1 * 1 
Homogeneity_W14_2 ~ tau2 * 1 
Homogeneity_W14_3 ~ tau3 * 1 
Homogeneity_W15_1 ~ tau1 * 1 
Homogeneity_W15_2 ~ tau2 * 1 
Homogeneity_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Homogeneity_W5_1 ~~ Homogeneity_W5_1 
Homogeneity_W5_2 ~~ Homogeneity_W5_2 
Homogeneity_W5_3 ~~ Homogeneity_W5_3 
Homogeneity_W8_1 ~~ Homogeneity_W8_1 
Homogeneity_W8_2 ~~ Homogeneity_W8_2 
Homogeneity_W8_3 ~~ Homogeneity_W8_3 
Homogeneity_W9_1 ~~ Homogeneity_W9_1 
Homogeneity_W9_2 ~~ Homogeneity_W9_2 
Homogeneity_W9_3 ~~ Homogeneity_W9_3 
Homogeneity_W13_1 ~~ Homogeneity_W13_1 
Homogeneity_W13_2 ~~ Homogeneity_W13_2 
Homogeneity_W13_3 ~~ Homogeneity_W13_3 
Homogeneity_W14_1 ~~ Homogeneity_W14_1 
Homogeneity_W14_2 ~~ Homogeneity_W14_2 
Homogeneity_W14_3 ~~ Homogeneity_W14_3 
Homogeneity_W15_1 ~~ Homogeneity_W15_1 
Homogeneity_W15_2 ~~ Homogeneity_W15_2 
Homogeneity_W15_3 ~~ Homogeneity_W15_3 
# Specify Unique Covariances ----
Homogeneity_W5_1 ~~ Homogeneity_W8_1
Homogeneity_W5_1 ~~ Homogeneity_W9_1
Homogeneity_W5_1 ~~ Homogeneity_W13_1
Homogeneity_W5_1 ~~ Homogeneity_W14_1
Homogeneity_W5_1 ~~ Homogeneity_W15_1
Homogeneity_W8_1 ~~ Homogeneity_W9_1
Homogeneity_W8_1 ~~ Homogeneity_W13_1
Homogeneity_W8_1 ~~ Homogeneity_W14_1
Homogeneity_W8_1 ~~ Homogeneity_W15_1
Homogeneity_W9_1 ~~ Homogeneity_W13_1
Homogeneity_W9_1 ~~ Homogeneity_W14_1
Homogeneity_W9_1 ~~ Homogeneity_W15_1
Homogeneity_W13_1 ~~ Homogeneity_W14_1
Homogeneity_W13_1 ~~ Homogeneity_W15_1
Homogeneity_W14_1 ~~ Homogeneity_W15_1
Homogeneity_W5_2 ~~ Homogeneity_W8_2
Homogeneity_W5_2 ~~ Homogeneity_W9_2
Homogeneity_W5_2 ~~ Homogeneity_W13_2
Homogeneity_W5_2 ~~ Homogeneity_W14_2
Homogeneity_W5_2 ~~ Homogeneity_W15_2
Homogeneity_W8_2 ~~ Homogeneity_W9_2
Homogeneity_W8_2 ~~ Homogeneity_W13_2
Homogeneity_W8_2 ~~ Homogeneity_W14_2
Homogeneity_W8_2 ~~ Homogeneity_W15_2
Homogeneity_W9_2 ~~ Homogeneity_W13_2
Homogeneity_W9_2 ~~ Homogeneity_W14_2
Homogeneity_W9_2 ~~ Homogeneity_W15_2
Homogeneity_W13_2 ~~ Homogeneity_W14_2
Homogeneity_W13_2 ~~ Homogeneity_W15_2
Homogeneity_W14_2 ~~ Homogeneity_W15_2
Homogeneity_W5_3 ~~ Homogeneity_W8_3
Homogeneity_W5_3 ~~ Homogeneity_W9_3
Homogeneity_W5_3 ~~ Homogeneity_W13_3
Homogeneity_W5_3 ~~ Homogeneity_W14_3
Homogeneity_W5_3 ~~ Homogeneity_W15_3
Homogeneity_W8_3 ~~ Homogeneity_W9_3
Homogeneity_W8_3 ~~ Homogeneity_W13_3
Homogeneity_W8_3 ~~ Homogeneity_W14_3
Homogeneity_W8_3 ~~ Homogeneity_W15_3
Homogeneity_W9_3 ~~ Homogeneity_W13_3
Homogeneity_W9_3 ~~ Homogeneity_W14_3
Homogeneity_W9_3 ~~ Homogeneity_W15_3
Homogeneity_W13_3 ~~ Homogeneity_W14_3
Homogeneity_W13_3 ~~ Homogeneity_W15_3
Homogeneity_W14_3 ~~ Homogeneity_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strong.fit_HO <-cfa(strong.v2,data = df_GLES17,estimator = "MLR",se = "robust",
                    std.lv = TRUE)

#### <<<>>> Strict Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Homogeneity_W5_1", "Homogeneity_W5_2", "Homogeneity_W5_3"), 
                                        t2 = c("Homogeneity_W8_1", "Homogeneity_W8_2", "Homogeneity_W8_3"),
                                        t3 = c("Homogeneity_W9_1", "Homogeneity_W9_2", "Homogeneity_W9_3"),
                                        t3 = c("Homogeneity_W13_1", "Homogeneity_W13_2", "Homogeneity_W13_3"),
                                        t3 = c("Homogeneity_W14_1", "Homogeneity_W14_2", "Homogeneity_W14_3"),
                                        t3 = c("Homogeneity_W15_1", "Homogeneity_W15_2", "Homogeneity_W15_3")), 
                        model = "strict") %>% 
  cat()

strict.v2 <-'
#### STRICT INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Homogeneity_W5_1 + lambda1 * Homogeneity_W5_1 + lambda2 * Homogeneity_W5_2 + lambda3 * Homogeneity_W5_3
eta2 =~ NA * Homogeneity_W8_1 + lambda1 * Homogeneity_W8_1 + lambda2 * Homogeneity_W8_2 + lambda3 * Homogeneity_W8_3
eta3 =~ NA * Homogeneity_W9_1 + lambda1 * Homogeneity_W9_1 + lambda2 * Homogeneity_W9_2 + lambda3 * Homogeneity_W9_3
eta4 =~ NA * Homogeneity_W13_1 + lambda1 * Homogeneity_W13_1 + lambda2 * Homogeneity_W13_2 + lambda3 * Homogeneity_W13_3
eta5 =~ NA * Homogeneity_W14_1 + lambda1 * Homogeneity_W14_1 + lambda2 * Homogeneity_W14_2 + lambda3 * Homogeneity_W14_3
eta6 =~ NA * Homogeneity_W15_1 + lambda1 * Homogeneity_W15_1 + lambda2 * Homogeneity_W15_2 + lambda3 * Homogeneity_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Homogeneity_W5_1 ~ tau1 * 1 
Homogeneity_W5_2 ~ tau2 * 1 
Homogeneity_W5_3 ~ tau3 * 1 
Homogeneity_W8_1 ~ tau1 * 1 
Homogeneity_W8_2 ~ tau2 * 1 
Homogeneity_W8_3 ~ tau3 * 1 
Homogeneity_W9_1 ~ tau1 * 1 
Homogeneity_W9_2 ~ tau2 * 1 
Homogeneity_W9_3 ~ tau3 * 1 
Homogeneity_W13_1 ~ tau1 * 1 
Homogeneity_W13_2 ~ tau2 * 1 
Homogeneity_W13_3 ~ tau3 * 1 
Homogeneity_W14_1 ~ tau1 * 1 
Homogeneity_W14_2 ~ tau2 * 1 
Homogeneity_W14_3 ~ tau3 * 1 
Homogeneity_W15_1 ~ tau1 * 1 
Homogeneity_W15_2 ~ tau2 * 1 
Homogeneity_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Homogeneity_W5_1 ~~ theta1 * Homogeneity_W5_1 
Homogeneity_W5_2 ~~ theta2 * Homogeneity_W5_2 
Homogeneity_W5_3 ~~ theta3 * Homogeneity_W5_3 
Homogeneity_W8_1 ~~ theta1 * Homogeneity_W8_1 
Homogeneity_W8_2 ~~ theta2 * Homogeneity_W8_2 
Homogeneity_W8_3 ~~ theta3 * Homogeneity_W8_3 
Homogeneity_W9_1 ~~ theta1 * Homogeneity_W9_1 
Homogeneity_W9_2 ~~ theta2 * Homogeneity_W9_2 
Homogeneity_W9_3 ~~ theta3 * Homogeneity_W9_3 
Homogeneity_W13_1 ~~ theta1 * Homogeneity_W13_1 
Homogeneity_W13_2 ~~ theta2 * Homogeneity_W13_2 
Homogeneity_W13_3 ~~ theta3 * Homogeneity_W13_3 
Homogeneity_W14_1 ~~ theta1 * Homogeneity_W14_1 
Homogeneity_W14_2 ~~ theta2 * Homogeneity_W14_2 
Homogeneity_W14_3 ~~ theta3 * Homogeneity_W14_3 
Homogeneity_W15_1 ~~ theta1 * Homogeneity_W15_1 
Homogeneity_W15_2 ~~ theta2 * Homogeneity_W15_2 
Homogeneity_W15_3 ~~ theta3 * Homogeneity_W15_3 
# Specify Unique Covariances ----
Homogeneity_W5_1 ~~ Homogeneity_W8_1
Homogeneity_W5_1 ~~ Homogeneity_W9_1
Homogeneity_W5_1 ~~ Homogeneity_W13_1
Homogeneity_W5_1 ~~ Homogeneity_W14_1
Homogeneity_W5_1 ~~ Homogeneity_W15_1
Homogeneity_W8_1 ~~ Homogeneity_W9_1
Homogeneity_W8_1 ~~ Homogeneity_W13_1
Homogeneity_W8_1 ~~ Homogeneity_W14_1
Homogeneity_W8_1 ~~ Homogeneity_W15_1
Homogeneity_W9_1 ~~ Homogeneity_W13_1
Homogeneity_W9_1 ~~ Homogeneity_W14_1
Homogeneity_W9_1 ~~ Homogeneity_W15_1
Homogeneity_W13_1 ~~ Homogeneity_W14_1
Homogeneity_W13_1 ~~ Homogeneity_W15_1
Homogeneity_W14_1 ~~ Homogeneity_W15_1
Homogeneity_W5_2 ~~ Homogeneity_W8_2
Homogeneity_W5_2 ~~ Homogeneity_W9_2
Homogeneity_W5_2 ~~ Homogeneity_W13_2
Homogeneity_W5_2 ~~ Homogeneity_W14_2
Homogeneity_W5_2 ~~ Homogeneity_W15_2
Homogeneity_W8_2 ~~ Homogeneity_W9_2
Homogeneity_W8_2 ~~ Homogeneity_W13_2
Homogeneity_W8_2 ~~ Homogeneity_W14_2
Homogeneity_W8_2 ~~ Homogeneity_W15_2
Homogeneity_W9_2 ~~ Homogeneity_W13_2
Homogeneity_W9_2 ~~ Homogeneity_W14_2
Homogeneity_W9_2 ~~ Homogeneity_W15_2
Homogeneity_W13_2 ~~ Homogeneity_W14_2
Homogeneity_W13_2 ~~ Homogeneity_W15_2
Homogeneity_W14_2 ~~ Homogeneity_W15_2
Homogeneity_W5_3 ~~ Homogeneity_W8_3
Homogeneity_W5_3 ~~ Homogeneity_W9_3
Homogeneity_W5_3 ~~ Homogeneity_W13_3
Homogeneity_W5_3 ~~ Homogeneity_W14_3
Homogeneity_W5_3 ~~ Homogeneity_W15_3
Homogeneity_W8_3 ~~ Homogeneity_W9_3
Homogeneity_W8_3 ~~ Homogeneity_W13_3
Homogeneity_W8_3 ~~ Homogeneity_W14_3
Homogeneity_W8_3 ~~ Homogeneity_W15_3
Homogeneity_W9_3 ~~ Homogeneity_W13_3
Homogeneity_W9_3 ~~ Homogeneity_W14_3
Homogeneity_W9_3 ~~ Homogeneity_W15_3
Homogeneity_W13_3 ~~ Homogeneity_W14_3
Homogeneity_W13_3 ~~ Homogeneity_W15_3
Homogeneity_W14_3 ~~ Homogeneity_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strict.fit_HO <-cfa(strict.v2,data = df_GLES17,estimator = "MLR",se = "robust",
                    std.lv = TRUE)

#### <<<>>> Comparinson - Fit Indeces (Homogeneity) ####

fitM_Homogeneity_Config <- as.data.frame(fitMeasures(configural.fit_HO))
fitM_Homogeneity_Weak <- as.data.frame(fitMeasures(weak.fit_HO))
fitM_Homogeneity_Strong <- as.data.frame(fitMeasures(strong.fit_HO))
fitM_Homogeneity_Strict <- as.data.frame(fitMeasures(strict.fit_HO))

## Extract Relevant Fit Measures (Following Mckinnon et al 2021) and create df
## columns for table

Indices_Homogeneity <- c("No. of estimated parameters",
                          "Raw Loglikelihood",
                          "Robust CFI",
                          "Robust RMSEA")
Configural_Homogeneity <- slice(fitM_Homogeneity_Config,c(1,36,27,52))
Metric_Homogeneity <- slice(fitM_Homogeneity_Weak,c(1,36,27,52))
Scalar_Homogeneity <- slice(fitM_Homogeneity_Strong,c(1,36,27,52))
Residual_Homogeneity <- slice(fitM_Homogeneity_Strict,c(1,36,27,52))

tab_invariance_ho <- cbind(Indices_Homogeneity, round(cbind(Configural_Homogeneity, 
                                       Metric_Homogeneity, Scalar_Homogeneity,
                                       Residual_Homogeneity), 3))

#####################################################/
#### /// MI Test - Sovereignty                   ####
#####################################################/


#### <<<>>> Configural Model ####
long_minvariance_syntax(var_list = list(t1 = c("Sovereignty_W5_1", "Sovereignty_W5_2", "Sovereignty_W5_3"), 
                                        t2 = c("Sovereignty_W8_1", "Sovereignty_W8_2", "Sovereignty_W8_3"),
                                        t3 = c("Sovereignty_W9_1", "Sovereignty_W9_2", "Sovereignty_W9_3"),
                                        t3 = c("Sovereignty_W13_1", "Sovereignty_W13_2", "Sovereignty_W13_3"),
                                        t3 = c("Sovereignty_W14_1", "Sovereignty_W14_2", "Sovereignty_W14_3"),
                                        t3 = c("Sovereignty_W15_1", "Sovereignty_W15_2", "Sovereignty_W15_3")), 
                        model = "configural") %>% 
  cat()
# Model
configural.v3 <-'

#### CONFIGURAL INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Sovereignty_W5_1 + lambda1 * Sovereignty_W5_1 + Sovereignty_W5_2 + Sovereignty_W5_3
eta2 =~ NA * Sovereignty_W8_1 + lambda1 * Sovereignty_W8_1 + Sovereignty_W8_2 + Sovereignty_W8_3
eta3 =~ NA * Sovereignty_W9_1 + lambda1 * Sovereignty_W9_1 + Sovereignty_W9_2 + Sovereignty_W9_3
eta4 =~ NA * Sovereignty_W13_1 + lambda1 * Sovereignty_W13_1 + Sovereignty_W13_2 + Sovereignty_W13_3
eta5 =~ NA * Sovereignty_W14_1 + lambda1 * Sovereignty_W14_1 + Sovereignty_W14_2 + Sovereignty_W14_3
eta6 =~ NA * Sovereignty_W15_1 + lambda1 * Sovereignty_W15_1 + Sovereignty_W15_2 + Sovereignty_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Sovereignty_W5_1 ~ tau1 * 1 
Sovereignty_W5_2 ~ 1 
Sovereignty_W5_3 ~ 1 
Sovereignty_W8_1 ~ tau1 * 1 
Sovereignty_W8_2 ~ 1 
Sovereignty_W8_3 ~ 1 
Sovereignty_W9_1 ~ tau1 * 1 
Sovereignty_W9_2 ~ 1 
Sovereignty_W9_3 ~ 1 
Sovereignty_W13_1 ~ tau1 * 1 
Sovereignty_W13_2 ~ 1 
Sovereignty_W13_3 ~ 1 
Sovereignty_W14_1 ~ tau1 * 1 
Sovereignty_W14_2 ~ 1 
Sovereignty_W14_3 ~ 1 
Sovereignty_W15_1 ~ tau1 * 1 
Sovereignty_W15_2 ~ 1 
Sovereignty_W15_3 ~ 1 
# Specify Unique Variances ----
Sovereignty_W5_1 ~~ Sovereignty_W5_1 
Sovereignty_W5_2 ~~ Sovereignty_W5_2 
Sovereignty_W5_3 ~~ Sovereignty_W5_3 
Sovereignty_W8_1 ~~ Sovereignty_W8_1 
Sovereignty_W8_2 ~~ Sovereignty_W8_2 
Sovereignty_W8_3 ~~ Sovereignty_W8_3 
Sovereignty_W9_1 ~~ Sovereignty_W9_1 
Sovereignty_W9_2 ~~ Sovereignty_W9_2 
Sovereignty_W9_3 ~~ Sovereignty_W9_3 
Sovereignty_W13_1 ~~ Sovereignty_W13_1 
Sovereignty_W13_2 ~~ Sovereignty_W13_2 
Sovereignty_W13_3 ~~ Sovereignty_W13_3 
Sovereignty_W14_1 ~~ Sovereignty_W14_1 
Sovereignty_W14_2 ~~ Sovereignty_W14_2 
Sovereignty_W14_3 ~~ Sovereignty_W14_3 
Sovereignty_W15_1 ~~ Sovereignty_W15_1 
Sovereignty_W15_2 ~~ Sovereignty_W15_2 
Sovereignty_W15_3 ~~ Sovereignty_W15_3 
# Specify Unique Covariances ----
Sovereignty_W5_1 ~~ Sovereignty_W8_1
Sovereignty_W5_1 ~~ Sovereignty_W9_1
Sovereignty_W5_1 ~~ Sovereignty_W13_1
Sovereignty_W5_1 ~~ Sovereignty_W14_1
Sovereignty_W5_1 ~~ Sovereignty_W15_1
Sovereignty_W8_1 ~~ Sovereignty_W9_1
Sovereignty_W8_1 ~~ Sovereignty_W13_1
Sovereignty_W8_1 ~~ Sovereignty_W14_1
Sovereignty_W8_1 ~~ Sovereignty_W15_1
Sovereignty_W9_1 ~~ Sovereignty_W13_1
Sovereignty_W9_1 ~~ Sovereignty_W14_1
Sovereignty_W9_1 ~~ Sovereignty_W15_1
Sovereignty_W13_1 ~~ Sovereignty_W14_1
Sovereignty_W13_1 ~~ Sovereignty_W15_1
Sovereignty_W14_1 ~~ Sovereignty_W15_1
Sovereignty_W5_2 ~~ Sovereignty_W8_2
Sovereignty_W5_2 ~~ Sovereignty_W9_2
Sovereignty_W5_2 ~~ Sovereignty_W13_2
Sovereignty_W5_2 ~~ Sovereignty_W14_2
Sovereignty_W5_2 ~~ Sovereignty_W15_2
Sovereignty_W8_2 ~~ Sovereignty_W9_2
Sovereignty_W8_2 ~~ Sovereignty_W13_2
Sovereignty_W8_2 ~~ Sovereignty_W14_2
Sovereignty_W8_2 ~~ Sovereignty_W15_2
Sovereignty_W9_2 ~~ Sovereignty_W13_2
Sovereignty_W9_2 ~~ Sovereignty_W14_2
Sovereignty_W9_2 ~~ Sovereignty_W15_2
Sovereignty_W13_2 ~~ Sovereignty_W14_2
Sovereignty_W13_2 ~~ Sovereignty_W15_2
Sovereignty_W14_2 ~~ Sovereignty_W15_2
Sovereignty_W5_3 ~~ Sovereignty_W8_3
Sovereignty_W5_3 ~~ Sovereignty_W9_3
Sovereignty_W5_3 ~~ Sovereignty_W13_3
Sovereignty_W5_3 ~~ Sovereignty_W14_3
Sovereignty_W5_3 ~~ Sovereignty_W15_3
Sovereignty_W8_3 ~~ Sovereignty_W9_3
Sovereignty_W8_3 ~~ Sovereignty_W13_3
Sovereignty_W8_3 ~~ Sovereignty_W14_3
Sovereignty_W8_3 ~~ Sovereignty_W15_3
Sovereignty_W9_3 ~~ Sovereignty_W13_3
Sovereignty_W9_3 ~~ Sovereignty_W14_3
Sovereignty_W9_3 ~~ Sovereignty_W15_3
Sovereignty_W13_3 ~~ Sovereignty_W14_3
Sovereignty_W13_3 ~~ Sovereignty_W15_3
Sovereignty_W14_3 ~~ Sovereignty_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
configural.fit_SOV <-cfa(configural.v3,
                        data = df_GLES17,
                        estimator = "MLR",
                        se = "robust",
                        std.lv = TRUE)


#### <<<>>> Weak Invariance Test ####
long_minvariance_syntax(var_list = list(t1 = c("Sovereignty_W5_1", "Sovereignty_W5_2", "Sovereignty_W5_3"), 
                                        t2 = c("Sovereignty_W8_1", "Sovereignty_W8_2", "Sovereignty_W8_3"),
                                        t3 = c("Sovereignty_W9_1", "Sovereignty_W9_2", "Sovereignty_W9_3"),
                                        t3 = c("Sovereignty_W13_1", "Sovereignty_W13_2", "Sovereignty_W13_3"),
                                        t3 = c("Sovereignty_W14_1", "Sovereignty_W14_2", "Sovereignty_W14_3"),
                                        t3 = c("Sovereignty_W15_1", "Sovereignty_W15_2", "Sovereignty_W15_3")), 
                        model = "weak") %>% 
  cat()

weak.v3 <-'
#### WEAK INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Sovereignty_W5_1 + lambda1 * Sovereignty_W5_1 + lambda2 * Sovereignty_W5_2 + lambda3 * Sovereignty_W5_3
eta2 =~ NA * Sovereignty_W8_1 + lambda1 * Sovereignty_W8_1 + lambda2 * Sovereignty_W8_2 + lambda3 * Sovereignty_W8_3
eta3 =~ NA * Sovereignty_W9_1 + lambda1 * Sovereignty_W9_1 + lambda2 * Sovereignty_W9_2 + lambda3 * Sovereignty_W9_3
eta4 =~ NA * Sovereignty_W13_1 + lambda1 * Sovereignty_W13_1 + lambda2 * Sovereignty_W13_2 + lambda3 * Sovereignty_W13_3
eta5 =~ NA * Sovereignty_W14_1 + lambda1 * Sovereignty_W14_1 + lambda2 * Sovereignty_W14_2 + lambda3 * Sovereignty_W14_3
eta6 =~ NA * Sovereignty_W15_1 + lambda1 * Sovereignty_W15_1 + lambda2 * Sovereignty_W15_2 + lambda3 * Sovereignty_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Sovereignty_W5_1 ~ tau1 * 1 
Sovereignty_W5_2 ~ 1 
Sovereignty_W5_3 ~ 1 
Sovereignty_W8_1 ~ tau1 * 1 
Sovereignty_W8_2 ~ 1 
Sovereignty_W8_3 ~ 1 
Sovereignty_W9_1 ~ tau1 * 1 
Sovereignty_W9_2 ~ 1 
Sovereignty_W9_3 ~ 1 
Sovereignty_W13_1 ~ tau1 * 1 
Sovereignty_W13_2 ~ 1 
Sovereignty_W13_3 ~ 1 
Sovereignty_W14_1 ~ tau1 * 1 
Sovereignty_W14_2 ~ 1 
Sovereignty_W14_3 ~ 1 
Sovereignty_W15_1 ~ tau1 * 1 
Sovereignty_W15_2 ~ 1 
Sovereignty_W15_3 ~ 1 
# Specify Unique Variances ----
Sovereignty_W5_1 ~~ Sovereignty_W5_1 
Sovereignty_W5_2 ~~ Sovereignty_W5_2 
Sovereignty_W5_3 ~~ Sovereignty_W5_3 
Sovereignty_W8_1 ~~ Sovereignty_W8_1 
Sovereignty_W8_2 ~~ Sovereignty_W8_2 
Sovereignty_W8_3 ~~ Sovereignty_W8_3 
Sovereignty_W9_1 ~~ Sovereignty_W9_1 
Sovereignty_W9_2 ~~ Sovereignty_W9_2 
Sovereignty_W9_3 ~~ Sovereignty_W9_3 
Sovereignty_W13_1 ~~ Sovereignty_W13_1 
Sovereignty_W13_2 ~~ Sovereignty_W13_2 
Sovereignty_W13_3 ~~ Sovereignty_W13_3 
Sovereignty_W14_1 ~~ Sovereignty_W14_1 
Sovereignty_W14_2 ~~ Sovereignty_W14_2 
Sovereignty_W14_3 ~~ Sovereignty_W14_3 
Sovereignty_W15_1 ~~ Sovereignty_W15_1 
Sovereignty_W15_2 ~~ Sovereignty_W15_2 
Sovereignty_W15_3 ~~ Sovereignty_W15_3 
# Specify Unique Covariances ----
Sovereignty_W5_1 ~~ Sovereignty_W8_1
Sovereignty_W5_1 ~~ Sovereignty_W9_1
Sovereignty_W5_1 ~~ Sovereignty_W13_1
Sovereignty_W5_1 ~~ Sovereignty_W14_1
Sovereignty_W5_1 ~~ Sovereignty_W15_1
Sovereignty_W8_1 ~~ Sovereignty_W9_1
Sovereignty_W8_1 ~~ Sovereignty_W13_1
Sovereignty_W8_1 ~~ Sovereignty_W14_1
Sovereignty_W8_1 ~~ Sovereignty_W15_1
Sovereignty_W9_1 ~~ Sovereignty_W13_1
Sovereignty_W9_1 ~~ Sovereignty_W14_1
Sovereignty_W9_1 ~~ Sovereignty_W15_1
Sovereignty_W13_1 ~~ Sovereignty_W14_1
Sovereignty_W13_1 ~~ Sovereignty_W15_1
Sovereignty_W14_1 ~~ Sovereignty_W15_1
Sovereignty_W5_2 ~~ Sovereignty_W8_2
Sovereignty_W5_2 ~~ Sovereignty_W9_2
Sovereignty_W5_2 ~~ Sovereignty_W13_2
Sovereignty_W5_2 ~~ Sovereignty_W14_2
Sovereignty_W5_2 ~~ Sovereignty_W15_2
Sovereignty_W8_2 ~~ Sovereignty_W9_2
Sovereignty_W8_2 ~~ Sovereignty_W13_2
Sovereignty_W8_2 ~~ Sovereignty_W14_2
Sovereignty_W8_2 ~~ Sovereignty_W15_2
Sovereignty_W9_2 ~~ Sovereignty_W13_2
Sovereignty_W9_2 ~~ Sovereignty_W14_2
Sovereignty_W9_2 ~~ Sovereignty_W15_2
Sovereignty_W13_2 ~~ Sovereignty_W14_2
Sovereignty_W13_2 ~~ Sovereignty_W15_2
Sovereignty_W14_2 ~~ Sovereignty_W15_2
Sovereignty_W5_3 ~~ Sovereignty_W8_3
Sovereignty_W5_3 ~~ Sovereignty_W9_3
Sovereignty_W5_3 ~~ Sovereignty_W13_3
Sovereignty_W5_3 ~~ Sovereignty_W14_3
Sovereignty_W5_3 ~~ Sovereignty_W15_3
Sovereignty_W8_3 ~~ Sovereignty_W9_3
Sovereignty_W8_3 ~~ Sovereignty_W13_3
Sovereignty_W8_3 ~~ Sovereignty_W14_3
Sovereignty_W8_3 ~~ Sovereignty_W15_3
Sovereignty_W9_3 ~~ Sovereignty_W13_3
Sovereignty_W9_3 ~~ Sovereignty_W14_3
Sovereignty_W9_3 ~~ Sovereignty_W15_3
Sovereignty_W13_3 ~~ Sovereignty_W14_3
Sovereignty_W13_3 ~~ Sovereignty_W15_3
Sovereignty_W14_3 ~~ Sovereignty_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
weak.fit_SOV <-cfa(weak.v3,data = df_GLES17,estimator = "MLR",se = "robust",
                   std.lv = TRUE)

#### <<<>>> Strong Invariance Test ####

strong.v3 <-'
#### STRONG INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Sovereignty_W5_1 + lambda1 * Sovereignty_W5_1 + lambda2 * Sovereignty_W5_2 + lambda3 * Sovereignty_W5_3
eta2 =~ NA * Sovereignty_W8_1 + lambda1 * Sovereignty_W8_1 + lambda2 * Sovereignty_W8_2 + lambda3 * Sovereignty_W8_3
eta3 =~ NA * Sovereignty_W9_1 + lambda1 * Sovereignty_W9_1 + lambda2 * Sovereignty_W9_2 + lambda3 * Sovereignty_W9_3
eta4 =~ NA * Sovereignty_W13_1 + lambda1 * Sovereignty_W13_1 + lambda2 * Sovereignty_W13_2 + lambda3 * Sovereignty_W13_3
eta5 =~ NA * Sovereignty_W14_1 + lambda1 * Sovereignty_W14_1 + lambda2 * Sovereignty_W14_2 + lambda3 * Sovereignty_W14_3
eta6 =~ NA * Sovereignty_W15_1 + lambda1 * Sovereignty_W15_1 + lambda2 * Sovereignty_W15_2 + lambda3 * Sovereignty_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Sovereignty_W5_1 ~ tau1 * 1 
Sovereignty_W5_2 ~ tau2 * 1 
Sovereignty_W5_3 ~ tau3 * 1 
Sovereignty_W8_1 ~ tau1 * 1 
Sovereignty_W8_2 ~ tau2 * 1 
Sovereignty_W8_3 ~ tau3 * 1 
Sovereignty_W9_1 ~ tau1 * 1 
Sovereignty_W9_2 ~ tau2 * 1 
Sovereignty_W9_3 ~ tau3 * 1 
Sovereignty_W13_1 ~ tau1 * 1 
Sovereignty_W13_2 ~ tau2 * 1 
Sovereignty_W13_3 ~ tau3 * 1 
Sovereignty_W14_1 ~ tau1 * 1 
Sovereignty_W14_2 ~ tau2 * 1 
Sovereignty_W14_3 ~ tau3 * 1 
Sovereignty_W15_1 ~ tau1 * 1 
Sovereignty_W15_2 ~ tau2 * 1 
Sovereignty_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Sovereignty_W5_1 ~~ Sovereignty_W5_1 
Sovereignty_W5_2 ~~ Sovereignty_W5_2 
Sovereignty_W5_3 ~~ Sovereignty_W5_3 
Sovereignty_W8_1 ~~ Sovereignty_W8_1 
Sovereignty_W8_2 ~~ Sovereignty_W8_2 
Sovereignty_W8_3 ~~ Sovereignty_W8_3 
Sovereignty_W9_1 ~~ Sovereignty_W9_1 
Sovereignty_W9_2 ~~ Sovereignty_W9_2 
Sovereignty_W9_3 ~~ Sovereignty_W9_3 
Sovereignty_W13_1 ~~ Sovereignty_W13_1 
Sovereignty_W13_2 ~~ Sovereignty_W13_2 
Sovereignty_W13_3 ~~ Sovereignty_W13_3 
Sovereignty_W14_1 ~~ Sovereignty_W14_1 
Sovereignty_W14_2 ~~ Sovereignty_W14_2 
Sovereignty_W14_3 ~~ Sovereignty_W14_3 
Sovereignty_W15_1 ~~ Sovereignty_W15_1 
Sovereignty_W15_2 ~~ Sovereignty_W15_2 
Sovereignty_W15_3 ~~ Sovereignty_W15_3 
# Specify Unique Covariances ----
Sovereignty_W5_1 ~~ Sovereignty_W8_1
Sovereignty_W5_1 ~~ Sovereignty_W9_1
Sovereignty_W5_1 ~~ Sovereignty_W13_1
Sovereignty_W5_1 ~~ Sovereignty_W14_1
Sovereignty_W5_1 ~~ Sovereignty_W15_1
Sovereignty_W8_1 ~~ Sovereignty_W9_1
Sovereignty_W8_1 ~~ Sovereignty_W13_1
Sovereignty_W8_1 ~~ Sovereignty_W14_1
Sovereignty_W8_1 ~~ Sovereignty_W15_1
Sovereignty_W9_1 ~~ Sovereignty_W13_1
Sovereignty_W9_1 ~~ Sovereignty_W14_1
Sovereignty_W9_1 ~~ Sovereignty_W15_1
Sovereignty_W13_1 ~~ Sovereignty_W14_1
Sovereignty_W13_1 ~~ Sovereignty_W15_1
Sovereignty_W14_1 ~~ Sovereignty_W15_1
Sovereignty_W5_2 ~~ Sovereignty_W8_2
Sovereignty_W5_2 ~~ Sovereignty_W9_2
Sovereignty_W5_2 ~~ Sovereignty_W13_2
Sovereignty_W5_2 ~~ Sovereignty_W14_2
Sovereignty_W5_2 ~~ Sovereignty_W15_2
Sovereignty_W8_2 ~~ Sovereignty_W9_2
Sovereignty_W8_2 ~~ Sovereignty_W13_2
Sovereignty_W8_2 ~~ Sovereignty_W14_2
Sovereignty_W8_2 ~~ Sovereignty_W15_2
Sovereignty_W9_2 ~~ Sovereignty_W13_2
Sovereignty_W9_2 ~~ Sovereignty_W14_2
Sovereignty_W9_2 ~~ Sovereignty_W15_2
Sovereignty_W13_2 ~~ Sovereignty_W14_2
Sovereignty_W13_2 ~~ Sovereignty_W15_2
Sovereignty_W14_2 ~~ Sovereignty_W15_2
Sovereignty_W5_3 ~~ Sovereignty_W8_3
Sovereignty_W5_3 ~~ Sovereignty_W9_3
Sovereignty_W5_3 ~~ Sovereignty_W13_3
Sovereignty_W5_3 ~~ Sovereignty_W14_3
Sovereignty_W5_3 ~~ Sovereignty_W15_3
Sovereignty_W8_3 ~~ Sovereignty_W9_3
Sovereignty_W8_3 ~~ Sovereignty_W13_3
Sovereignty_W8_3 ~~ Sovereignty_W14_3
Sovereignty_W8_3 ~~ Sovereignty_W15_3
Sovereignty_W9_3 ~~ Sovereignty_W13_3
Sovereignty_W9_3 ~~ Sovereignty_W14_3
Sovereignty_W9_3 ~~ Sovereignty_W15_3
Sovereignty_W13_3 ~~ Sovereignty_W14_3
Sovereignty_W13_3 ~~ Sovereignty_W15_3
Sovereignty_W14_3 ~~ Sovereignty_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strong.fit_SOV <-cfa(strong.v3,data = df_GLES17,estimator = "MLR",se = "robust",
                     std.lv = TRUE)

#### <<<>>> Strict Invariance Test ####

strict.v3 <-'
#### STRICT INVARIANCE MODEL ####
# Specify Latent Factors ----
eta1 =~ NA * Sovereignty_W5_1 + lambda1 * Sovereignty_W5_1 + lambda2 * Sovereignty_W5_2 + lambda3 * Sovereignty_W5_3
eta2 =~ NA * Sovereignty_W8_1 + lambda1 * Sovereignty_W8_1 + lambda2 * Sovereignty_W8_2 + lambda3 * Sovereignty_W8_3
eta3 =~ NA * Sovereignty_W9_1 + lambda1 * Sovereignty_W9_1 + lambda2 * Sovereignty_W9_2 + lambda3 * Sovereignty_W9_3
eta4 =~ NA * Sovereignty_W13_1 + lambda1 * Sovereignty_W13_1 + lambda2 * Sovereignty_W13_2 + lambda3 * Sovereignty_W13_3
eta5 =~ NA * Sovereignty_W14_1 + lambda1 * Sovereignty_W14_1 + lambda2 * Sovereignty_W14_2 + lambda3 * Sovereignty_W14_3
eta6 =~ NA * Sovereignty_W15_1 + lambda1 * Sovereignty_W15_1 + lambda2 * Sovereignty_W15_2 + lambda3 * Sovereignty_W15_3
# Specify Latent Variable Means ----
eta1 ~ 0 * 1 
eta2 ~ 1 
eta3 ~ 1 
eta4 ~ 1 
eta5 ~ 1 
eta6 ~ 1 
# Specify Latent Variable Variances ----
eta1 ~~ 1 * eta1
eta2 ~~ eta2
eta3 ~~ eta3
eta4 ~~ eta4
eta5 ~~ eta5
eta6 ~~ eta6
# Specify Latent Variable Covariances ----
eta1 ~~ eta2
eta1 ~~ eta3
eta1 ~~ eta4
eta1 ~~ eta5
eta1 ~~ eta6
eta2 ~~ eta3
eta2 ~~ eta4
eta2 ~~ eta5
eta2 ~~ eta6
eta3 ~~ eta4
eta3 ~~ eta5
eta3 ~~ eta6
eta4 ~~ eta5
eta4 ~~ eta6
eta5 ~~ eta6
# Specify Observed Variable Intercepts ----
Sovereignty_W5_1 ~ tau1 * 1 
Sovereignty_W5_2 ~ tau2 * 1 
Sovereignty_W5_3 ~ tau3 * 1 
Sovereignty_W8_1 ~ tau1 * 1 
Sovereignty_W8_2 ~ tau2 * 1 
Sovereignty_W8_3 ~ tau3 * 1 
Sovereignty_W9_1 ~ tau1 * 1 
Sovereignty_W9_2 ~ tau2 * 1 
Sovereignty_W9_3 ~ tau3 * 1 
Sovereignty_W13_1 ~ tau1 * 1 
Sovereignty_W13_2 ~ tau2 * 1 
Sovereignty_W13_3 ~ tau3 * 1 
Sovereignty_W14_1 ~ tau1 * 1 
Sovereignty_W14_2 ~ tau2 * 1 
Sovereignty_W14_3 ~ tau3 * 1 
Sovereignty_W15_1 ~ tau1 * 1 
Sovereignty_W15_2 ~ tau2 * 1 
Sovereignty_W15_3 ~ tau3 * 1 
# Specify Unique Variances ----
Sovereignty_W5_1 ~~ theta1 * Sovereignty_W5_1 
Sovereignty_W5_2 ~~ theta2 * Sovereignty_W5_2 
Sovereignty_W5_3 ~~ theta3 * Sovereignty_W5_3 
Sovereignty_W8_1 ~~ theta1 * Sovereignty_W8_1 
Sovereignty_W8_2 ~~ theta2 * Sovereignty_W8_2 
Sovereignty_W8_3 ~~ theta3 * Sovereignty_W8_3 
Sovereignty_W9_1 ~~ theta1 * Sovereignty_W9_1 
Sovereignty_W9_2 ~~ theta2 * Sovereignty_W9_2 
Sovereignty_W9_3 ~~ theta3 * Sovereignty_W9_3 
Sovereignty_W13_1 ~~ theta1 * Sovereignty_W13_1 
Sovereignty_W13_2 ~~ theta2 * Sovereignty_W13_2 
Sovereignty_W13_3 ~~ theta3 * Sovereignty_W13_3 
Sovereignty_W14_1 ~~ theta1 * Sovereignty_W14_1 
Sovereignty_W14_2 ~~ theta2 * Sovereignty_W14_2 
Sovereignty_W14_3 ~~ theta3 * Sovereignty_W14_3 
Sovereignty_W15_1 ~~ theta1 * Sovereignty_W15_1 
Sovereignty_W15_2 ~~ theta2 * Sovereignty_W15_2 
Sovereignty_W15_3 ~~ theta3 * Sovereignty_W15_3 
# Specify Unique Covariances ----
Sovereignty_W5_1 ~~ Sovereignty_W8_1
Sovereignty_W5_1 ~~ Sovereignty_W9_1
Sovereignty_W5_1 ~~ Sovereignty_W13_1
Sovereignty_W5_1 ~~ Sovereignty_W14_1
Sovereignty_W5_1 ~~ Sovereignty_W15_1
Sovereignty_W8_1 ~~ Sovereignty_W9_1
Sovereignty_W8_1 ~~ Sovereignty_W13_1
Sovereignty_W8_1 ~~ Sovereignty_W14_1
Sovereignty_W8_1 ~~ Sovereignty_W15_1
Sovereignty_W9_1 ~~ Sovereignty_W13_1
Sovereignty_W9_1 ~~ Sovereignty_W14_1
Sovereignty_W9_1 ~~ Sovereignty_W15_1
Sovereignty_W13_1 ~~ Sovereignty_W14_1
Sovereignty_W13_1 ~~ Sovereignty_W15_1
Sovereignty_W14_1 ~~ Sovereignty_W15_1
Sovereignty_W5_2 ~~ Sovereignty_W8_2
Sovereignty_W5_2 ~~ Sovereignty_W9_2
Sovereignty_W5_2 ~~ Sovereignty_W13_2
Sovereignty_W5_2 ~~ Sovereignty_W14_2
Sovereignty_W5_2 ~~ Sovereignty_W15_2
Sovereignty_W8_2 ~~ Sovereignty_W9_2
Sovereignty_W8_2 ~~ Sovereignty_W13_2
Sovereignty_W8_2 ~~ Sovereignty_W14_2
Sovereignty_W8_2 ~~ Sovereignty_W15_2
Sovereignty_W9_2 ~~ Sovereignty_W13_2
Sovereignty_W9_2 ~~ Sovereignty_W14_2
Sovereignty_W9_2 ~~ Sovereignty_W15_2
Sovereignty_W13_2 ~~ Sovereignty_W14_2
Sovereignty_W13_2 ~~ Sovereignty_W15_2
Sovereignty_W14_2 ~~ Sovereignty_W15_2
Sovereignty_W5_3 ~~ Sovereignty_W8_3
Sovereignty_W5_3 ~~ Sovereignty_W9_3
Sovereignty_W5_3 ~~ Sovereignty_W13_3
Sovereignty_W5_3 ~~ Sovereignty_W14_3
Sovereignty_W5_3 ~~ Sovereignty_W15_3
Sovereignty_W8_3 ~~ Sovereignty_W9_3
Sovereignty_W8_3 ~~ Sovereignty_W13_3
Sovereignty_W8_3 ~~ Sovereignty_W14_3
Sovereignty_W8_3 ~~ Sovereignty_W15_3
Sovereignty_W9_3 ~~ Sovereignty_W13_3
Sovereignty_W9_3 ~~ Sovereignty_W14_3
Sovereignty_W9_3 ~~ Sovereignty_W15_3
Sovereignty_W13_3 ~~ Sovereignty_W14_3
Sovereignty_W13_3 ~~ Sovereignty_W15_3
Sovereignty_W14_3 ~~ Sovereignty_W15_3
'
# -> uses all valid cases, not just complete data! run on subset
strict.fit_SOV <-cfa(strict.v3,data = df_GLES17,estimator = "MLR",
                     se = "robust",std.lv = TRUE)

#### <<<>>> Comparinson - Fit Indeces (Sovereignty) ####

fitM_Sovereignty_Config <- as.data.frame(fitMeasures(configural.fit_SOV))
fitM_Sovereignty_Weak <- as.data.frame(fitMeasures(weak.fit_SOV))
fitM_Sovereignty_Strong <- as.data.frame(fitMeasures(strong.fit_SOV))
fitM_Sovereignty_Strict <- as.data.frame(fitMeasures(strict.fit_SOV))

## Extract Relevant Fit Measures (Following Mckinnon et al 2021) and create df
## columns for table

Indices_Sovereignty <- c("No. of estimated parameters",
                         "Raw Loglikelihood",
                         "Robust CFI",
                         "Robust RMSEA")
Configural_Sovereignty <- slice(fitM_Sovereignty_Config,c(1,36,27,52))
Metric_Sovereignty <- slice(fitM_Sovereignty_Weak,c(1,36,27,52))
Scalar_Sovereignty <- slice(fitM_Sovereignty_Strong,c(1,36,27,52))
Residual_Sovereignty <- slice(fitM_Sovereignty_Strict,c(1,36,27,52))

#bind results for text
tab_invariance_sov <- cbind(Indices_Sovereignty, round(cbind(Configural_Sovereignty, 
                                       Metric_Sovereignty, Scalar_Sovereignty,
                                       Residual_Sovereignty), 3))

