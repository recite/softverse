#############################################/
## R-Script - Recode                        ##
## by: Schimpf, Wuttke, Schoen              ##
## Version: June 2023                       ##
## R-Version: 4.1.0.                        ##
#############################################/

###################################################################/
#### /// Section 0: Load Dataset                              #####
##################################################################/

#read in dataset (Waves 1-9)
df_GLES17 <- read.csv("GLESP_17_21_SelectedVars.csv",
                      stringsAsFactors=FALSE)

###################################################################/
#### /// Section 1: Data preparation                           #####
##################################################################/

#### >>> Recode populism items ####

#### <<<>>> Anti Elitism Items ####

#Politicians talk too much (Anti_elitism1)
df_GLES17$Anti_Elite_W5_1 <- as.numeric(as.factor(df_GLES17$kp5_3103a))
df_GLES17$Anti_Elite_W8_1 <- as.numeric(as.factor(df_GLES17$kp8_3103a))
df_GLES17$Anti_Elite_W9_1 <- as.numeric(as.factor(df_GLES17$kp9_3103a))
df_GLES17$Anti_Elite_W13_1 <- as.numeric(as.factor(df_GLES17$kp13_3103a))
df_GLES17$Anti_Elite_W14_1 <- as.numeric(as.factor(df_GLES17$kp14_3103a))
df_GLES17$Anti_Elite_W15_1 <- as.numeric(as.factor(df_GLES17$kp15_3103a))

# Recode values and missings (1="Fully disagree" to 5="Fully agree")
df_GLES17$Anti_Elite_W5_1 <- car::recode(df_GLES17$Anti_Elite_W5_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Note: the recoding is correct; because variables are read in as character, transforming them
#       into factor and then numeric switches up the code order of the original variable.
df_GLES17$Anti_Elite_W8_1 <- car::recode(df_GLES17$Anti_Elite_W8_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W9_1 <- car::recode(df_GLES17$Anti_Elite_W9_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W13_1 <- car::recode(df_GLES17$Anti_Elite_W13_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W14_1 <- car::recode(df_GLES17$Anti_Elite_W14_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W15_1 <- car::recode(df_GLES17$Anti_Elite_W15_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")

# Check recoding:
table(df_GLES17$Anti_Elite_W5_1, df_GLES17$kp5_3103a, useNA = "always")
table(df_GLES17$Anti_Elite_W8_1, df_GLES17$kp8_3103a, useNA = "always")
table(df_GLES17$Anti_Elite_W9_1, df_GLES17$kp9_3103a, useNA = "always")
table(df_GLES17$Anti_Elite_W13_1, df_GLES17$kp13_3103a, useNA = "always")
table(df_GLES17$Anti_Elite_W14_1, df_GLES17$kp14_3103a, useNA = "always")
table(df_GLES17$Anti_Elite_W15_1, df_GLES17$kp15_3103a, useNA = "always")


#Differences between people and elite greater than between people (Anti-Elitism2)
df_GLES17$Anti_Elite_W5_2 <- as.numeric(as.factor(df_GLES17$kp5_3103e))
df_GLES17$Anti_Elite_W8_2 <- as.numeric(as.factor(df_GLES17$kp8_3103e))
df_GLES17$Anti_Elite_W9_2 <- as.numeric(as.factor(df_GLES17$kp9_3103e))
df_GLES17$Anti_Elite_W13_2 <- as.numeric(as.factor(df_GLES17$kp13_3103e))
df_GLES17$Anti_Elite_W14_2 <- as.numeric(as.factor(df_GLES17$kp14_3103e))
df_GLES17$Anti_Elite_W15_2 <- as.numeric(as.factor(df_GLES17$kp15_3103e))

# Recode values and missings
df_GLES17$Anti_Elite_W5_2 <- car::recode(df_GLES17$Anti_Elite_W5_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W8_2 <- car::recode(df_GLES17$Anti_Elite_W8_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W9_2 <- car::recode(df_GLES17$Anti_Elite_W9_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W13_2 <- car::recode(df_GLES17$Anti_Elite_W13_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W14_2 <- car::recode(df_GLES17$Anti_Elite_W14_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Anti_Elite_W15_2 <- car::recode(df_GLES17$Anti_Elite_W15_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Coding Check:
table(df_GLES17$Anti_Elite_W5_2, df_GLES17$kp5_3103e, useNA = "always")
table(df_GLES17$Anti_Elite_W8_2, df_GLES17$kp8_3103e, useNA = "always")
table(df_GLES17$Anti_Elite_W9_2, df_GLES17$kp9_3103e, useNA = "always")
table(df_GLES17$Anti_Elite_W13_2, df_GLES17$kp13_3103e, useNA = "always")
table(df_GLES17$Anti_Elite_W14_2, df_GLES17$kp14_3103e, useNA = "always")
table(df_GLES17$Anti_Elite_W15_2, df_GLES17$kp15_3103e, useNA = "always")

# Politicians care about what the people think (Anti-Elitism 3 - note: this item is reversed in its wording
# so that higher values equal higher levels of anti-elitism)
df_GLES17$Anti_Elite_W5_3 <- as.numeric(as.factor(df_GLES17$kp5_050a))
df_GLES17$Anti_Elite_W8_3 <- as.numeric(as.factor(df_GLES17$kp8_050a))
df_GLES17$Anti_Elite_W9_3 <- as.numeric(as.factor(df_GLES17$kp9_050a))
df_GLES17$Anti_Elite_W13_3 <- as.numeric(as.factor(df_GLES17$kp13_050a))
df_GLES17$Anti_Elite_W14_3 <- as.numeric(as.factor(df_GLES17$kp14_050a))
df_GLES17$Anti_Elite_W15_3 <- as.numeric(as.factor(df_GLES17$kp15_050a))

# Recode values and missings
df_GLES17$Anti_Elite_W5_3 <- car::recode(df_GLES17$Anti_Elite_W5_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")
df_GLES17$Anti_Elite_W8_3 <- car::recode(df_GLES17$Anti_Elite_W8_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")
df_GLES17$Anti_Elite_W9_3 <- car::recode(df_GLES17$Anti_Elite_W9_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")
df_GLES17$Anti_Elite_W13_3 <- car::recode(df_GLES17$Anti_Elite_W13_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")
df_GLES17$Anti_Elite_W14_3 <- car::recode(df_GLES17$Anti_Elite_W14_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")
df_GLES17$Anti_Elite_W15_3 <- car::recode(df_GLES17$Anti_Elite_W15_3, "1=NA; 2=NA; 3=NA;
                                         6=5; 4=4; 8=3; 5=2; 7=1")

# Coding Check:
table(df_GLES17$Anti_Elite_W5_3, df_GLES17$kp5_050a, useNA = "always")
table(df_GLES17$Anti_Elite_W8_3, df_GLES17$kp8_050a, useNA = "always")
table(df_GLES17$Anti_Elite_W9_3, df_GLES17$kp9_050a, useNA = "always")
table(df_GLES17$Anti_Elite_W13_3, df_GLES17$kp13_050a, useNA = "always")
table(df_GLES17$Anti_Elite_W14_3, df_GLES17$kp14_050a, useNA = "always")
table(df_GLES17$Anti_Elite_W15_3, df_GLES17$kp15_050a, useNA = "always")

#### <<<>>> Homogenous People Items ####

#People are of good and honest character (Homogeneity1)
df_GLES17$Homogeneity_W5_1 <- as.numeric(as.factor(df_GLES17$kp5_3103b))
df_GLES17$Homogeneity_W8_1 <- as.numeric(as.factor(df_GLES17$kp8_3103b))
df_GLES17$Homogeneity_W9_1 <- as.numeric(as.factor(df_GLES17$kp9_3103b))
df_GLES17$Homogeneity_W13_1 <- as.numeric(as.factor(df_GLES17$kp13_3103b))
df_GLES17$Homogeneity_W14_1 <- as.numeric(as.factor(df_GLES17$kp14_3103b))
df_GLES17$Homogeneity_W15_1 <- as.numeric(as.factor(df_GLES17$kp15_3103b))

# Recode values and missings
df_GLES17$Homogeneity_W5_1 <- car::recode(df_GLES17$Homogeneity_W5_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W8_1 <- car::recode(df_GLES17$Homogeneity_W8_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W9_1 <- car::recode(df_GLES17$Homogeneity_W9_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W13_1 <- car::recode(df_GLES17$Homogeneity_W13_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W14_1 <- car::recode(df_GLES17$Homogeneity_W14_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W15_1 <- car::recode(df_GLES17$Homogeneity_W15_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Coding check:
table(df_GLES17$Homogeneity_W5_1, df_GLES17$kp5_3103b, useNA = "always")
table(df_GLES17$Homogeneity_W8_1, df_GLES17$kp8_3103b, useNA = "always")
table(df_GLES17$Homogeneity_W9_1, df_GLES17$kp9_3103b, useNA = "always")
table(df_GLES17$Homogeneity_W13_1, df_GLES17$kp13_3103b, useNA = "always")
table(df_GLES17$Homogeneity_W14_1, df_GLES17$kp14_3103b, useNA = "always")
table(df_GLES17$Homogeneity_W15_1, df_GLES17$kp15_3103b, useNA = "always")

#Ordinary people pull together (Homogeneity2)
df_GLES17$Homogeneity_W5_2 <- as.numeric(as.factor(df_GLES17$kp5_3103d))
df_GLES17$Homogeneity_W8_2 <- as.numeric(as.factor(df_GLES17$kp8_3103d))
df_GLES17$Homogeneity_W9_2 <- as.numeric(as.factor(df_GLES17$kp9_3103d))
df_GLES17$Homogeneity_W13_2 <- as.numeric(as.factor(df_GLES17$kp13_3103d))
df_GLES17$Homogeneity_W14_2 <- as.numeric(as.factor(df_GLES17$kp14_3103d))
df_GLES17$Homogeneity_W15_2 <- as.numeric(as.factor(df_GLES17$kp15_3103d))

# Recode values and missings
df_GLES17$Homogeneity_W5_2 <- car::recode(df_GLES17$Homogeneity_W5_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W8_2 <- car::recode(df_GLES17$Homogeneity_W8_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W9_2 <- car::recode(df_GLES17$Homogeneity_W9_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W13_2 <- car::recode(df_GLES17$Homogeneity_W13_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W14_2 <- car::recode(df_GLES17$Homogeneity_W14_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W15_2 <- car::recode(df_GLES17$Homogeneity_W15_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Coding check:
table(df_GLES17$Homogeneity_W5_2, df_GLES17$kp5_3103d, useNA = "always")
table(df_GLES17$Homogeneity_W8_2, df_GLES17$kp8_3103d, useNA = "always")
table(df_GLES17$Homogeneity_W9_2, df_GLES17$kp9_3103d, useNA = "always")
table(df_GLES17$Homogeneity_W13_2, df_GLES17$kp13_3103d, useNA = "always")
table(df_GLES17$Homogeneity_W14_2, df_GLES17$kp14_3103d, useNA = "always")
table(df_GLES17$Homogeneity_W15_2, df_GLES17$kp15_3103d, useNA = "always")


#Ordinary people sahre same values (Homogeneity3)
df_GLES17$Homogeneity_W5_3 <- as.numeric(as.factor(df_GLES17$kp5_3103h))
df_GLES17$Homogeneity_W8_3 <- as.numeric(as.factor(df_GLES17$kp8_3103h))
df_GLES17$Homogeneity_W9_3 <- as.numeric(as.factor(df_GLES17$kp9_3103h))
df_GLES17$Homogeneity_W13_3 <- as.numeric(as.factor(df_GLES17$kp13_3103h))
df_GLES17$Homogeneity_W14_3 <- as.numeric(as.factor(df_GLES17$kp14_3103h))
df_GLES17$Homogeneity_W15_3 <- as.numeric(as.factor(df_GLES17$kp15_3103h))

# Recode values and missings
df_GLES17$Homogeneity_W5_3 <- car::recode(df_GLES17$Homogeneity_W5_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W8_3 <- car::recode(df_GLES17$Homogeneity_W8_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W9_3 <- car::recode(df_GLES17$Homogeneity_W9_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W13_3 <- car::recode(df_GLES17$Homogeneity_W13_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W14_3 <- car::recode(df_GLES17$Homogeneity_W14_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Homogeneity_W15_3 <- car::recode(df_GLES17$Homogeneity_W15_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")

# Coding check:
table(df_GLES17$Homogeneity_W5_3, df_GLES17$kp5_3103h, useNA = "always")
table(df_GLES17$Homogeneity_W8_3, df_GLES17$kp8_3103h, useNA = "always")
table(df_GLES17$Homogeneity_W9_3, df_GLES17$kp9_3103h, useNA = "always")
table(df_GLES17$Homogeneity_W13_3, df_GLES17$kp13_3103h, useNA = "always")
table(df_GLES17$Homogeneity_W14_3, df_GLES17$kp14_3103h, useNA = "always")
table(df_GLES17$Homogeneity_W15_3, df_GLES17$kp15_3103h, useNA = "always")


#### <<<>>> People's Sovereignty ####

#People should have final say (Sovereignty 1)
df_GLES17$Sovereignty_W5_1 <- as.numeric(as.factor(df_GLES17$kp5_3103c))
df_GLES17$Sovereignty_W8_1 <- as.numeric(as.factor(df_GLES17$kp8_3103c))
df_GLES17$Sovereignty_W9_1 <- as.numeric(as.factor(df_GLES17$kp9_3103c))
df_GLES17$Sovereignty_W13_1 <- as.numeric(as.factor(df_GLES17$kp13_3103c))
df_GLES17$Sovereignty_W14_1 <- as.numeric(as.factor(df_GLES17$kp14_3103c))
df_GLES17$Sovereignty_W15_1 <- as.numeric(as.factor(df_GLES17$kp15_3103c))

# Recode values and missings
df_GLES17$Sovereignty_W5_1 <- car::recode(df_GLES17$Sovereignty_W5_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W8_1 <- car::recode(df_GLES17$Sovereignty_W8_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W9_1 <- car::recode(df_GLES17$Sovereignty_W9_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W13_1 <- car::recode(df_GLES17$Sovereignty_W13_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W14_1 <- car::recode(df_GLES17$Sovereignty_W14_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W15_1 <- car::recode(df_GLES17$Sovereignty_W15_1, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Coding check:
table(df_GLES17$Sovereignty_W5_1, df_GLES17$kp5_3103c, useNA = "always")
table(df_GLES17$Sovereignty_W8_1, df_GLES17$kp8_3103c, useNA = "always")
table(df_GLES17$Sovereignty_W9_1, df_GLES17$kp9_3103c, useNA = "always")
table(df_GLES17$Sovereignty_W13_1, df_GLES17$kp13_3103c, useNA = "always")
table(df_GLES17$Sovereignty_W14_1, df_GLES17$kp14_3103c, useNA = "always")
table(df_GLES17$Sovereignty_W15_1, df_GLES17$kp15_3103c, useNA = "always")


##People should make most important policy decisions (Sovereignty 2)
df_GLES17$Sovereignty_W5_2 <- as.numeric(as.factor(df_GLES17$kp5_3103f))
df_GLES17$Sovereignty_W8_2 <- as.numeric(as.factor(df_GLES17$kp8_3103f))
df_GLES17$Sovereignty_W9_2 <- as.numeric(as.factor(df_GLES17$kp9_3103f))
df_GLES17$Sovereignty_W13_2 <- as.numeric(as.factor(df_GLES17$kp13_3103f))
df_GLES17$Sovereignty_W14_2 <- as.numeric(as.factor(df_GLES17$kp14_3103f))
df_GLES17$Sovereignty_W15_2 <- as.numeric(as.factor(df_GLES17$kp15_3103f))

# Recode values and missings
df_GLES17$Sovereignty_W5_2 <- car::recode(df_GLES17$Sovereignty_W5_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W8_2 <- car::recode(df_GLES17$Sovereignty_W8_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W9_2 <- car::recode(df_GLES17$Sovereignty_W9_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W13_2 <- car::recode(df_GLES17$Sovereignty_W13_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W14_2 <- car::recode(df_GLES17$Sovereignty_W14_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W15_2 <- car::recode(df_GLES17$Sovereignty_W15_2, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")

# Coding check:
table(df_GLES17$Sovereignty_W5_2, df_GLES17$kp5_3103f, useNA = "always")
table(df_GLES17$Sovereignty_W8_2, df_GLES17$kp8_3103f, useNA = "always")
table(df_GLES17$Sovereignty_W9_2, df_GLES17$kp9_3103f, useNA = "always")
table(df_GLES17$Sovereignty_W13_2, df_GLES17$kp13_3103f, useNA = "always")
table(df_GLES17$Sovereignty_W14_2, df_GLES17$kp14_3103f, useNA = "always")
table(df_GLES17$Sovereignty_W15_2, df_GLES17$kp15_3103f, useNA = "always")


##Politicians need to follow the will of the people (Sovereignty 3)
df_GLES17$Sovereignty_W5_3 <- as.numeric(as.factor(df_GLES17$kp5_3103g))
df_GLES17$Sovereignty_W8_3 <- as.numeric(as.factor(df_GLES17$kp8_3103g))
df_GLES17$Sovereignty_W9_3 <- as.numeric(as.factor(df_GLES17$kp9_3103g))
df_GLES17$Sovereignty_W13_3 <- as.numeric(as.factor(df_GLES17$kp13_3103g))
df_GLES17$Sovereignty_W14_3 <- as.numeric(as.factor(df_GLES17$kp14_3103g))
df_GLES17$Sovereignty_W15_3 <- as.numeric(as.factor(df_GLES17$kp15_3103g))


# Recode values and missings
df_GLES17$Sovereignty_W5_3 <- car::recode(df_GLES17$Sovereignty_W5_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W8_3 <- car::recode(df_GLES17$Sovereignty_W8_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W9_3 <- car::recode(df_GLES17$Sovereignty_W9_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W13_3 <- car::recode(df_GLES17$Sovereignty_W13_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W14_3 <- car::recode(df_GLES17$Sovereignty_W14_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
df_GLES17$Sovereignty_W15_3 <- car::recode(df_GLES17$Sovereignty_W15_3, "1=NA; 2=NA; 3=NA;
                                         6=1; 4=2; 8=3; 5=4; 7=5")
# Coding check
table(df_GLES17$Sovereignty_W5_3, df_GLES17$kp5_3103g, useNA = "always")
table(df_GLES17$Sovereignty_W8_3, df_GLES17$kp8_3103g, useNA = "always")
table(df_GLES17$Sovereignty_W9_3, df_GLES17$kp9_3103g, useNA = "always")
table(df_GLES17$Sovereignty_W13_3, df_GLES17$kp13_3103g, useNA = "always")
table(df_GLES17$Sovereignty_W14_3, df_GLES17$kp14_3103g, useNA = "always")
table(df_GLES17$Sovereignty_W15_3, df_GLES17$kp15_3103g, useNA = "always")

#### >>> Prep Populism Dimension Scores ####

#General note: higher values indicate higher levels of agreement.

#### <<<>>> Generate Mean Score: Anti-Elitism ####

## Note: If respondents have valid answers for less than three items, we still calculate a mean.

#Wave 5
df_GLES17$Anti_Elitism_Mean_W5 <- rowMeans(df_GLES17[,c("Anti_Elite_W5_1", 
                                                        "Anti_Elite_W5_2",
                                                        "Anti_Elite_W5_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W5[is.nan(df_GLES17$Anti_Elitism_Mean_W5)] <- NA

# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W5_na_count <- apply(df_GLES17[,c("Anti_Elite_W5_1", 
                                                         "Anti_Elite_W5_2",
                                                         "Anti_Elite_W5_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W5_na_count))
df_GLES17$Anti_Elitism_Mean_W5[df_GLES17$Anti_Elitism_W5_na_count>0] <- NA

#Wave 8
df_GLES17$Anti_Elitism_Mean_W8 <- rowMeans(df_GLES17[,c("Anti_Elite_W8_1", 
                                                        "Anti_Elite_W8_2",
                                                        "Anti_Elite_W8_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W8[is.nan(df_GLES17$Anti_Elitism_Mean_W8)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W8_na_count <- apply(df_GLES17[,c("Anti_Elite_W8_1", 
                                                         "Anti_Elite_W8_2",
                                                         "Anti_Elite_W8_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W8_na_count))
df_GLES17$Anti_Elitism_Mean_W8[df_GLES17$Anti_Elitism_W8_na_count>0] <- NA

#Wave 9
df_GLES17$Anti_Elitism_Mean_W9 <- rowMeans(df_GLES17[,c("Anti_Elite_W9_1", 
                                                        "Anti_Elite_W9_2",
                                                        "Anti_Elite_W9_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W9[is.nan(df_GLES17$Anti_Elitism_Mean_W9)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W9_na_count <- apply(df_GLES17[,c("Anti_Elite_W9_1", 
                                                         "Anti_Elite_W9_2",
                                                         "Anti_Elite_W9_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W9_na_count))
df_GLES17$Anti_Elitism_Mean_W9[df_GLES17$Anti_Elitism_W9_na_count>0] <- NA

#Wave 13
df_GLES17$Anti_Elitism_Mean_W13 <- rowMeans(df_GLES17[,c("Anti_Elite_W13_1", 
                                                         "Anti_Elite_W13_2",
                                                         "Anti_Elite_W13_3")], 
                                            na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W13[is.nan(df_GLES17$Anti_Elitism_Mean_W13)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W13_na_count <- apply(df_GLES17[,c("Anti_Elite_W13_1", 
                                                          "Anti_Elite_W13_2",
                                                          "Anti_Elite_W13_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W13_na_count))
df_GLES17$Anti_Elitism_Mean_W13[df_GLES17$Anti_Elitism_W13_na_count>0] <- NA


#Wave 14
df_GLES17$Anti_Elitism_Mean_W14 <- rowMeans(df_GLES17[,c("Anti_Elite_W14_1", 
                                                         "Anti_Elite_W14_2",
                                                         "Anti_Elite_W14_3")], 
                                            na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W14[is.nan(df_GLES17$Anti_Elitism_Mean_W14)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W14_na_count <- apply(df_GLES17[,c("Anti_Elite_W14_1", 
                                                          "Anti_Elite_W14_2",
                                                          "Anti_Elite_W14_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W14_na_count))
df_GLES17$Anti_Elitism_Mean_W14[df_GLES17$Anti_Elitism_W14_na_count>0] <- NA


#Wave 15
df_GLES17$Anti_Elitism_Mean_W15 <- rowMeans(df_GLES17[,c("Anti_Elite_W15_1", 
                                                         "Anti_Elite_W15_2",
                                                         "Anti_Elite_W15_3")], 
                                            na.rm = T, dims = 1)
df_GLES17$Anti_Elitism_Mean_W15[is.nan(df_GLES17$Anti_Elitism_Mean_W15)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Anti_Elitism_W15_na_count <- apply(df_GLES17[,c("Anti_Elite_W15_1", 
                                                          "Anti_Elite_W15_2",
                                                          "Anti_Elite_W15_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Anti_Elitism_W15_na_count))
df_GLES17$Anti_Elitism_Mean_W15[df_GLES17$Anti_Elitism_W15_na_count>0] <- NA

#### <<<>>> Compare Anti-Elitism Mean Score to predicted CFA score for robustness reported in Appendix ####

# We fit a cfa for each of the dimensions at each point in time and calculate correlation
# between mean score and predicted factor scores

#### Anti-Elitism - Wave 5

#fit CFA
mla_AE_W5  <- ' fs_AE_W5  =~ Anti_Elite_W5_1 + Anti_Elite_W5_2 + Anti_Elite_W5_3'
onefac3items_AE_W5 <- cfa(mla_AE_W5, data=df_GLES17) 
summary(onefac3items_AE_W5)

#merge cfa scores with original dataframe
idx_AE_W5 <- lavInspect(onefac3items_AE_W5, "case.idx")

vec_AE_W5_fs <- (lavPredict(onefac3items_AE_W5, newdata = df_GLES17[,c("Anti_Elite_W5_1", 
                                                                       "Anti_Elite_W5_2",
                                                                       "Anti_Elite_W5_3")]))
for (fs_AE_W5 in colnames(vec_AE_W5_fs)) {
  df_GLES17[idx_AE_W5, fs_AE_W5] <- vec_AE_W5_fs[ , fs_AE_W5]
}

#correlation
cor_AE_meanfs_W5 <- cor(df_GLES17$Anti_Elitism_Mean_W5, df_GLES17$fs_AE_W5, use="complete")

#### Anti-Elitism - Wave 8

#fit CFA
mla_AE_W8  <- ' fs_AE_W8  =~ Anti_Elite_W8_1 + Anti_Elite_W8_2 + Anti_Elite_W8_3'
onefac3items_AE_W8 <- cfa(mla_AE_W8, data=df_GLES17) 
summary(onefac3items_AE_W8)

#merge cfa scores with original dataframe
idx_AE_W8 <- lavInspect(onefac3items_AE_W8, "case.idx")
vec_AE_W8_fs <- (lavPredict(onefac3items_AE_W8, newdata = df_GLES17[,c("Anti_Elite_W8_1", 
                                                                       "Anti_Elite_W8_2",
                                                                       "Anti_Elite_W8_3")]))
for (fs_AE_W8 in colnames(vec_AE_W8_fs)) {
  df_GLES17[idx_AE_W8, fs_AE_W8] <- vec_AE_W8_fs[ , fs_AE_W8]
}
#correlation
cor_AE_meanfs_W8 <- cor(df_GLES17$Anti_Elitism_Mean_W8, df_GLES17$fs_AE_W8, use="complete")

#### Anti-Elitism - Wave 9

#fit CFA
mla_AE_W9  <- ' fs_AE_W9  =~ Anti_Elite_W9_1 + Anti_Elite_W9_2 + Anti_Elite_W9_3'
onefac3items_AE_W9 <- cfa(mla_AE_W9, data=df_GLES17) 
summary(onefac3items_AE_W9)

#merge cfa scores with original dataframe
idx_AE_W9 <- lavInspect(onefac3items_AE_W9, "case.idx")
vec_AE_W9_fs <- (lavPredict(onefac3items_AE_W9, newdata = df_GLES17[,c("Anti_Elite_W9_1", 
                                                                       "Anti_Elite_W9_2",
                                                                       "Anti_Elite_W9_3")]))
for (fs_AE_W9 in colnames(vec_AE_W9_fs)) {
  df_GLES17[idx_AE_W9, fs_AE_W9] <- vec_AE_W9_fs[ , fs_AE_W9]
}
#correlation
cor_AE_meanfs_W9 <- cor(df_GLES17$Anti_Elitism_Mean_W9, df_GLES17$fs_AE_W9, use="complete")

#### Anti-Elitism - Wave 13

#fit CFA
mla_AE_W13  <- ' fs_AE_W13  =~ Anti_Elite_W13_1 + Anti_Elite_W13_2 + Anti_Elite_W13_3'
onefac3items_AE_W13 <- cfa(mla_AE_W13, data=df_GLES17) 
summary(onefac3items_AE_W13)

#merge cfa scores with original dataframe
idx_AE_W13 <- lavInspect(onefac3items_AE_W13, "case.idx")
vec_AE_W13_fs <- (lavPredict(onefac3items_AE_W13, newdata = df_GLES17[,c("Anti_Elite_W13_1", 
                                                                         "Anti_Elite_W13_2",
                                                                         "Anti_Elite_W13_3")]))
for (fs_AE_W13 in colnames(vec_AE_W13_fs)) {
  df_GLES17[idx_AE_W13, fs_AE_W13] <- vec_AE_W13_fs[ , fs_AE_W13]
}
#correlation
cor_AE_meanfs_W13 <- cor(df_GLES17$Anti_Elitism_Mean_W13, df_GLES17$fs_AE_W13, use="complete")

#### Anti-Elitism - Wave 14

#fit CFA
mla_AE_W14  <- ' fs_AE_W14  =~ Anti_Elite_W14_1 + Anti_Elite_W14_2 + Anti_Elite_W14_3'
onefac3items_AE_W14 <- cfa(mla_AE_W14, data=df_GLES17) 
summary(onefac3items_AE_W14)

#merge cfa scores with original dataframe
idx_AE_W14 <- lavInspect(onefac3items_AE_W14, "case.idx")
vec_AE_W14_fs <- (lavPredict(onefac3items_AE_W14, newdata = df_GLES17[,c("Anti_Elite_W14_1", 
                                                                         "Anti_Elite_W14_2",
                                                                         "Anti_Elite_W14_3")]))
for (fs_AE_W14 in colnames(vec_AE_W14_fs)) {
  df_GLES17[idx_AE_W14, fs_AE_W14] <- vec_AE_W14_fs[ , fs_AE_W14]
}
#correlation
cor_AE_meanfs_W14 <- cor(df_GLES17$Anti_Elitism_Mean_W14, df_GLES17$fs_AE_W14, use="complete")

#### Anti-Elitism - Wave 15

#fit CFA
mla_AE_W15  <- ' fs_AE_W15  =~ Anti_Elite_W15_1 + Anti_Elite_W15_2 + Anti_Elite_W15_3'
onefac3items_AE_W15 <- cfa(mla_AE_W15, data=df_GLES17) 
summary(onefac3items_AE_W15)

#merge cfa scores with original dataframe
idx_AE_W15 <- lavInspect(onefac3items_AE_W15, "case.idx")
vec_AE_W15_fs <- (lavPredict(onefac3items_AE_W15, newdata = df_GLES17[,c("Anti_Elite_W15_1", 
                                                                         "Anti_Elite_W15_2",
                                                                         "Anti_Elite_W15_3")]))
for (fs_AE_W15 in colnames(vec_AE_W15_fs)) {
  df_GLES17[idx_AE_W15, fs_AE_W15] <- vec_AE_W15_fs[ , fs_AE_W15]
}
#correlation
cor_AE_meanfs_W15 <- cor(df_GLES17$Anti_Elitism_Mean_W15, df_GLES17$fs_AE_W15, use="complete")

#### Combine correlations and check range:
mean_cfa_cor_AE <- cbind(round(rbind(cor_AE_meanfs_W5, cor_AE_meanfs_W8,
                                     cor_AE_meanfs_W9, cor_AE_meanfs_W13,
                                     cor_AE_meanfs_W14, cor_AE_meanfs_W15),3),
                         c("Wave 5", "Wave 8", "Wave 9", "Wave 13",
                           "Wave 14", "Wave 15"))

#### <<<>>> Generate Mean Score: Homogeneity ####

## Note: If respondents have valid answers for less than three items, we still calculate a mean.

#Wave 5
df_GLES17$Homogeneity_Mean_W5 <- rowMeans(df_GLES17[,c("Homogeneity_W5_1", 
                                                       "Homogeneity_W5_2",
                                                       "Homogeneity_W5_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W5[is.nan(df_GLES17$Homogeneity_Mean_W5)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W5_na_count <- apply(df_GLES17[,c("Homogeneity_W5_1", 
                                                        "Homogeneity_W5_2",
                                                        "Homogeneity_W5_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W5_na_count))
df_GLES17$Homogeneity_Mean_W5[df_GLES17$Homogeneity_W5_na_count>0] <- NA

#Wave 8
df_GLES17$Homogeneity_Mean_W8 <- rowMeans(df_GLES17[,c("Homogeneity_W8_1", 
                                                       "Homogeneity_W8_2",
                                                       "Homogeneity_W8_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W8[is.nan(df_GLES17$Homogeneity_Mean_W8)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W8_na_count <- apply(df_GLES17[,c("Homogeneity_W8_1", 
                                                        "Homogeneity_W8_2",
                                                        "Homogeneity_W8_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W8_na_count))
df_GLES17$Homogeneity_Mean_W8[df_GLES17$Homogeneity_W8_na_count>0] <- NA

#Wave 9
df_GLES17$Homogeneity_Mean_W9 <- rowMeans(df_GLES17[,c("Homogeneity_W9_1", 
                                                       "Homogeneity_W9_2",
                                                       "Homogeneity_W9_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W9[is.nan(df_GLES17$Homogeneity_Mean_W9)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W9_na_count <- apply(df_GLES17[,c("Homogeneity_W9_1", 
                                                        "Homogeneity_W9_2",
                                                        "Homogeneity_W9_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W9_na_count))
df_GLES17$Homogeneity_Mean_W9[df_GLES17$Homogeneity_W9_na_count>0] <- NA

#Wave 13
df_GLES17$Homogeneity_Mean_W13 <- rowMeans(df_GLES17[,c("Homogeneity_W13_1", 
                                                        "Homogeneity_W13_2",
                                                        "Homogeneity_W13_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W13[is.nan(df_GLES17$Homogeneity_Mean_W13)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W13_na_count <- apply(df_GLES17[,c("Homogeneity_W13_1", 
                                                         "Homogeneity_W13_2",
                                                         "Homogeneity_W13_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W13_na_count))
df_GLES17$Homogeneity_Mean_W13[df_GLES17$Homogeneity_W13_na_count>0] <- NA

#Wave 14
df_GLES17$Homogeneity_Mean_W14 <- rowMeans(df_GLES17[,c("Homogeneity_W14_1", 
                                                        "Homogeneity_W14_2",
                                                        "Homogeneity_W14_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W14[is.nan(df_GLES17$Homogeneity_Mean_W14)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W14_na_count <- apply(df_GLES17[,c("Homogeneity_W14_1", 
                                                         "Homogeneity_W14_2",
                                                         "Homogeneity_W14_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W14_na_count))
df_GLES17$Homogeneity_Mean_W14[df_GLES17$Homogeneity_W14_na_count>0] <- NA

#Wave 15
df_GLES17$Homogeneity_Mean_W15 <- rowMeans(df_GLES17[,c("Homogeneity_W15_1", 
                                                        "Homogeneity_W15_2",
                                                        "Homogeneity_W15_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Homogeneity_Mean_W15[is.nan(df_GLES17$Homogeneity_Mean_W15)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Homogeneity_W15_na_count <- apply(df_GLES17[,c("Homogeneity_W15_1", 
                                                         "Homogeneity_W15_2",
                                                         "Homogeneity_W15_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Homogeneity_W15_na_count))
df_GLES17$Homogeneity_Mean_W15[df_GLES17$Homogeneity_W15_na_count>0] <- NA

#### <<<>>> Compare Homogeneity Mean Score to predicted CFA score for robustness reported in Appendix ####

# We fit a cfa for each of the dimensions at each point in time and calculate correlation
# between mean score and predicted factor scores

#### Homogeneity - Wave 5

#fit CFA
mla_HO_W5  <- ' fs_HO_W5  =~ Homogeneity_W5_1 + Homogeneity_W5_2 + Homogeneity_W5_3'
onefac3items_HO_W5 <- cfa(mla_HO_W5, data=df_GLES17) 
summary(onefac3items_HO_W5)

#merge cfa scores with original dataframe
idx_HO_W5 <- lavInspect(onefac3items_HO_W5, "case.idx")

vec_HO_W5_fs <- (lavPredict(onefac3items_HO_W5, newdata = df_GLES17[,c("Homogeneity_W5_1", 
                                                                       "Homogeneity_W5_2",
                                                                       "Homogeneity_W5_3")]))
for (fs_HO_W5 in colnames(vec_HO_W5_fs)) {
  df_GLES17[idx_HO_W5, fs_HO_W5] <- vec_HO_W5_fs[ , fs_HO_W5]
}

#correlation
cor_HO_meanfs_W5 <- cor(df_GLES17$Homogeneity_Mean_W5, df_GLES17$fs_HO_W5, use="complete")

#### Homogeneity - Wave 8

#fit CFA
mla_HO_W8  <- ' fs_HO_W8  =~ Homogeneity_W8_1 + Homogeneity_W8_2 + Homogeneity_W8_3'
onefac3items_HO_W8 <- cfa(mla_HO_W8, data=df_GLES17) 
summary(onefac3items_HO_W8)

#merge cfa scores with original dataframe
idx_HO_W8 <- lavInspect(onefac3items_HO_W8, "case.idx")
vec_HO_W8_fs <- (lavPredict(onefac3items_HO_W8, newdata = df_GLES17[,c("Homogeneity_W8_1", 
                                                                       "Homogeneity_W8_2",
                                                                       "Homogeneity_W8_3")]))
for (fs_HO_W8 in colnames(vec_HO_W8_fs)) {
  df_GLES17[idx_HO_W8, fs_HO_W8] <- vec_HO_W8_fs[ , fs_HO_W8]
}
#correlation
cor_HO_meanfs_W8 <- cor(df_GLES17$Homogeneity_Mean_W8, df_GLES17$fs_HO_W8, use="complete")

#### Homogeneity - Wave 9

#fit CFA
mla_HO_W9  <- ' fs_HO_W9  =~ Homogeneity_W9_1 + Homogeneity_W9_2 + Homogeneity_W9_3'
onefac3items_HO_W9 <- cfa(mla_HO_W9, data=df_GLES17) 
summary(onefac3items_HO_W9)

#merge cfa scores with original dataframe
idx_HO_W9 <- lavInspect(onefac3items_HO_W9, "case.idx")
vec_HO_W9_fs <- (lavPredict(onefac3items_HO_W9, newdata = df_GLES17[,c("Homogeneity_W9_1", 
                                                                       "Homogeneity_W9_2",
                                                                       "Homogeneity_W9_3")]))
for (fs_HO_W9 in colnames(vec_HO_W9_fs)) {
  df_GLES17[idx_HO_W9, fs_HO_W9] <- vec_HO_W9_fs[ , fs_HO_W9]
}
#correlation
cor_HO_meanfs_W9 <- cor(df_GLES17$Homogeneity_Mean_W9, df_GLES17$fs_HO_W9, use="complete")

#### Homogeneity - Wave 13

#fit CFA
mla_HO_W13  <- ' fs_HO_W13  =~ Homogeneity_W13_1 + Homogeneity_W13_2 + Homogeneity_W13_3'
onefac3items_HO_W13 <- cfa(mla_HO_W13, data=df_GLES17) 
summary(onefac3items_HO_W13)

#merge cfa scores with original dataframe
idx_HO_W13 <- lavInspect(onefac3items_HO_W13, "case.idx")
vec_HO_W13_fs <- (lavPredict(onefac3items_HO_W13, newdata = df_GLES17[,c("Homogeneity_W13_1", 
                                                                         "Homogeneity_W13_2",
                                                                         "Homogeneity_W13_3")]))
for (fs_HO_W13 in colnames(vec_HO_W13_fs)) {
  df_GLES17[idx_HO_W13, fs_HO_W13] <- vec_HO_W13_fs[ , fs_HO_W13]
}
#correlation
cor_HO_meanfs_W13 <- cor(df_GLES17$Homogeneity_Mean_W13, df_GLES17$fs_HO_W13, use="complete")

#### Homogeneity - Wave 14

#fit CFA
mla_HO_W14  <- ' fs_HO_W14  =~ Homogeneity_W14_1 + Homogeneity_W14_2 + Homogeneity_W14_3'
onefac3items_HO_W14 <- cfa(mla_HO_W14, data=df_GLES17) 
summary(onefac3items_HO_W14)

#merge cfa scores with original dataframe
idx_HO_W14 <- lavInspect(onefac3items_HO_W14, "case.idx")
vec_HO_W14_fs <- (lavPredict(onefac3items_HO_W14, newdata = df_GLES17[,c("Homogeneity_W14_1", 
                                                                         "Homogeneity_W14_2",
                                                                         "Homogeneity_W14_3")]))
for (fs_HO_W14 in colnames(vec_HO_W14_fs)) {
  df_GLES17[idx_HO_W14, fs_HO_W14] <- vec_HO_W14_fs[ , fs_HO_W14]
}
#correlation
cor_HO_meanfs_W14 <- cor(df_GLES17$Homogeneity_Mean_W14, df_GLES17$fs_HO_W14, use="complete")

#### Homogeneity - Wave 15

#fit CFA
mla_HO_W15  <- ' fs_HO_W15  =~ Homogeneity_W15_1 + Homogeneity_W15_2 + Homogeneity_W15_3'
onefac3items_HO_W15 <- cfa(mla_HO_W15, data=df_GLES17) 
summary(onefac3items_HO_W15)

#merge cfa scores with original dataframe
idx_HO_W15 <- lavInspect(onefac3items_HO_W15, "case.idx")
vec_HO_W15_fs <- (lavPredict(onefac3items_HO_W15, newdata = df_GLES17[,c("Homogeneity_W15_1", 
                                                                         "Homogeneity_W15_2",
                                                                         "Homogeneity_W15_3")]))
for (fs_HO_W15 in colnames(vec_HO_W15_fs)) {
  df_GLES17[idx_HO_W15, fs_HO_W15] <- vec_HO_W15_fs[ , fs_HO_W15]
}
#correlation
cor_HO_meanfs_W15 <- cor(df_GLES17$Homogeneity_Mean_W15, df_GLES17$fs_HO_W15, use="complete")

#### Combine correlations and check range:
mean_cfa_cor_HO <- cbind(round(rbind(cor_HO_meanfs_W5, cor_HO_meanfs_W8,
                                     cor_HO_meanfs_W9, cor_HO_meanfs_W13,
                                     cor_HO_meanfs_W14, cor_HO_meanfs_W15),3),
                         c("Wave 5", "Wave 8", "Wave 9", "Wave 13",
                           "Wave 14", "Wave 15"))

#### <<<>>> Generate Mean Score: Sovereignty ####

## Note: If respondents have valid answers for less than three items, we still calculate a mean.

#Wave 5
df_GLES17$Sovereignty_Mean_W5 <- rowMeans(df_GLES17[,c("Sovereignty_W5_1", 
                                                       "Sovereignty_W5_2",
                                                       "Sovereignty_W5_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W5[is.nan(df_GLES17$Sovereignty_Mean_W5)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W5_na_count <- apply(df_GLES17[,c("Sovereignty_W5_1", 
                                                        "Sovereignty_W5_2",
                                                        "Sovereignty_W5_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W5_na_count))
df_GLES17$Sovereignty_Mean_W5[df_GLES17$Sovereignty_W5_na_count>0] <- NA

#Wave 8
df_GLES17$Sovereignty_Mean_W8 <- rowMeans(df_GLES17[,c("Sovereignty_W8_1", 
                                                       "Sovereignty_W8_2",
                                                       "Sovereignty_W8_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W8[is.nan(df_GLES17$Sovereignty_Mean_W8)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W8_na_count <- apply(df_GLES17[,c("Sovereignty_W8_1", 
                                                        "Sovereignty_W8_2",
                                                        "Sovereignty_W8_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W8_na_count))
df_GLES17$Sovereignty_Mean_W8[df_GLES17$Sovereignty_W8_na_count>0] <- NA

#Wave 9
df_GLES17$Sovereignty_Mean_W9 <- rowMeans(df_GLES17[,c("Sovereignty_W9_1", 
                                                       "Sovereignty_W9_2",
                                                       "Sovereignty_W9_3")], 
                                          na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W9[is.nan(df_GLES17$Sovereignty_Mean_W9)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W9_na_count <- apply(df_GLES17[,c("Sovereignty_W9_1", 
                                                        "Sovereignty_W9_2",
                                                        "Sovereignty_W9_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W9_na_count))
df_GLES17$Sovereignty_Mean_W9[df_GLES17$Sovereignty_W9_na_count>0] <- NA

#Wave 13
df_GLES17$Sovereignty_Mean_W13 <- rowMeans(df_GLES17[,c("Sovereignty_W13_1", 
                                                        "Sovereignty_W13_2",
                                                        "Sovereignty_W13_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W13[is.nan(df_GLES17$Sovereignty_Mean_W13)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W13_na_count <- apply(df_GLES17[,c("Sovereignty_W13_1", 
                                                         "Sovereignty_W13_2",
                                                         "Sovereignty_W13_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W13_na_count))
df_GLES17$Sovereignty_Mean_W13[df_GLES17$Sovereignty_W13_na_count>0] <- NA

#Wave 14
df_GLES17$Sovereignty_Mean_W14 <- rowMeans(df_GLES17[,c("Sovereignty_W14_1", 
                                                        "Sovereignty_W14_2",
                                                        "Sovereignty_W14_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W14[is.nan(df_GLES17$Sovereignty_Mean_W14)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W14_na_count <- apply(df_GLES17[,c("Sovereignty_W14_1", 
                                                         "Sovereignty_W14_2",
                                                         "Sovereignty_W14_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W14_na_count))
df_GLES17$Sovereignty_Mean_W14[df_GLES17$Sovereignty_W14_na_count>0] <- NA

#Wave 15
df_GLES17$Sovereignty_Mean_W15 <- rowMeans(df_GLES17[,c("Sovereignty_W15_1", 
                                                        "Sovereignty_W15_2",
                                                        "Sovereignty_W15_3")], 
                                           na.rm = T, dims = 1)
df_GLES17$Sovereignty_Mean_W15[is.nan(df_GLES17$Sovereignty_Mean_W15)] <- NA
# Count NAs for who we use mean across two items or score of one item
df_GLES17$Sovereignty_W15_na_count <- apply(df_GLES17[,c("Sovereignty_W15_1", 
                                                         "Sovereignty_W15_2",
                                                         "Sovereignty_W15_3")], 1, function(x) sum(is.na(x)))
prop.table(table(df_GLES17$Sovereignty_W15_na_count))
df_GLES17$Sovereignty_Mean_W15[df_GLES17$Sovereignty_W15_na_count>0] <- NA


#### <<<>>> Compare People Sovereignty Mean Score to predicted CFA score for robustness reported in Appendix ####

# We fit a cfa for each of the dimensions at each point in time and calculate correlation
# between mean score and predicted factor scores

#### Sovereignty - Wave 5

#fit CFA
mla_SO_W5  <- ' fs_SO_W5  =~ Sovereignty_W5_1 + Sovereignty_W5_2 + Sovereignty_W5_3'
onefac3items_SO_W5 <- cfa(mla_SO_W5, data=df_GLES17) 
summary(onefac3items_SO_W5)

#merge cfa scores with original dataframe
idx_SO_W5 <- lavInspect(onefac3items_SO_W5, "case.idx")

vec_SO_W5_fs <- (lavPredict(onefac3items_SO_W5, newdata = df_GLES17[,c("Sovereignty_W5_1", 
                                                                       "Sovereignty_W5_2",
                                                                       "Sovereignty_W5_3")]))
for (fs_SO_W5 in colnames(vec_SO_W5_fs)) {
  df_GLES17[idx_SO_W5, fs_SO_W5] <- vec_SO_W5_fs[ , fs_SO_W5]
}

#correlation
cor_SO_meanfs_W5 <- cor(df_GLES17$Sovereignty_Mean_W5, df_GLES17$fs_SO_W5, use="complete")

#### Sovereignty - Wave 8

#fit CFA
mla_SO_W8  <- ' fs_SO_W8  =~ Sovereignty_W8_1 + Sovereignty_W8_2 + Sovereignty_W8_3'
onefac3items_SO_W8 <- cfa(mla_SO_W8, data=df_GLES17) 
summary(onefac3items_SO_W8)

#merge cfa scores with original dataframe
idx_SO_W8 <- lavInspect(onefac3items_SO_W8, "case.idx")
vec_SO_W8_fs <- (lavPredict(onefac3items_SO_W8, newdata = df_GLES17[,c("Sovereignty_W8_1", 
                                                                       "Sovereignty_W8_2",
                                                                       "Sovereignty_W8_3")]))
for (fs_SO_W8 in colnames(vec_SO_W8_fs)) {
  df_GLES17[idx_SO_W8, fs_SO_W8] <- vec_SO_W8_fs[ , fs_SO_W8]
}
#correlation
cor_SO_meanfs_W8 <- cor(df_GLES17$Sovereignty_Mean_W8, df_GLES17$fs_SO_W8, use="complete")

#### Sovereignty - Wave 9

#fit CFA
mla_SO_W9  <- ' fs_SO_W9  =~ Sovereignty_W9_1 + Sovereignty_W9_2 + Sovereignty_W9_3'
onefac3items_SO_W9 <- cfa(mla_SO_W9, data=df_GLES17) 
summary(onefac3items_SO_W9)

#merge cfa scores with original dataframe
idx_SO_W9 <- lavInspect(onefac3items_SO_W9, "case.idx")
vec_SO_W9_fs <- (lavPredict(onefac3items_SO_W9, newdata = df_GLES17[,c("Sovereignty_W9_1", 
                                                                       "Sovereignty_W9_2",
                                                                       "Sovereignty_W9_3")]))
for (fs_SO_W9 in colnames(vec_SO_W9_fs)) {
  df_GLES17[idx_SO_W9, fs_SO_W9] <- vec_SO_W9_fs[ , fs_SO_W9]
}
#correlation
cor_SO_meanfs_W9 <- cor(df_GLES17$Sovereignty_Mean_W9, df_GLES17$fs_SO_W9, use="complete")

#### Sovereignty - Wave 13

#fit CFA
mla_SO_W13  <- ' fs_SO_W13  =~ Sovereignty_W13_1 + Sovereignty_W13_2 + Sovereignty_W13_3'
onefac3items_SO_W13 <- cfa(mla_SO_W13, data=df_GLES17) 
summary(onefac3items_SO_W13)

#merge cfa scores with original dataframe
idx_SO_W13 <- lavInspect(onefac3items_SO_W13, "case.idx")
vec_SO_W13_fs <- (lavPredict(onefac3items_SO_W13, newdata = df_GLES17[,c("Sovereignty_W13_1", 
                                                                         "Sovereignty_W13_2",
                                                                         "Sovereignty_W13_3")]))
for (fs_SO_W13 in colnames(vec_SO_W13_fs)) {
  df_GLES17[idx_SO_W13, fs_SO_W13] <- vec_SO_W13_fs[ , fs_SO_W13]
}
#correlation
cor_SO_meanfs_W13 <- cor(df_GLES17$Sovereignty_Mean_W13, df_GLES17$fs_SO_W13, use="complete")

#### Sovereignty - Wave 14

#fit CFA
mla_SO_W14  <- ' fs_SO_W14  =~ Sovereignty_W14_1 + Sovereignty_W14_2 + Sovereignty_W14_3'
onefac3items_SO_W14 <- cfa(mla_SO_W14, data=df_GLES17) 
summary(onefac3items_SO_W14)

#merge cfa scores with original dataframe
idx_SO_W14 <- lavInspect(onefac3items_SO_W14, "case.idx")
vec_SO_W14_fs <- (lavPredict(onefac3items_SO_W14, newdata = df_GLES17[,c("Sovereignty_W14_1", 
                                                                         "Sovereignty_W14_2",
                                                                         "Sovereignty_W14_3")]))
for (fs_SO_W14 in colnames(vec_SO_W14_fs)) {
  df_GLES17[idx_SO_W14, fs_SO_W14] <- vec_SO_W14_fs[ , fs_SO_W14]
}
#correlation
cor_SO_meanfs_W14 <- cor(df_GLES17$Sovereignty_Mean_W14, df_GLES17$fs_SO_W14, use="complete")

#### Sovereignty - Wave 15

#fit CFA
mla_SO_W15  <- ' fs_SO_W15  =~ Sovereignty_W15_1 + Sovereignty_W15_2 + Sovereignty_W15_3'
onefac3items_SO_W15 <- cfa(mla_SO_W15, data=df_GLES17) 
summary(onefac3items_SO_W15)

#merge cfa scores with original dataframe
idx_SO_W15 <- lavInspect(onefac3items_SO_W15, "case.idx")
vec_SO_W15_fs <- (lavPredict(onefac3items_SO_W15, newdata = df_GLES17[,c("Sovereignty_W15_1", 
                                                                         "Sovereignty_W15_2",
                                                                         "Sovereignty_W15_3")]))
for (fs_SO_W15 in colnames(vec_SO_W15_fs)) {
  df_GLES17[idx_SO_W15, fs_SO_W15] <- vec_SO_W15_fs[ , fs_SO_W15]
}
#correlation
cor_SO_meanfs_W15 <- cor(df_GLES17$Sovereignty_Mean_W15, df_GLES17$fs_SO_W15, use="complete")

#### Combine correlations and check range:
mean_cfa_cor_SO <- cbind(round(rbind(cor_SO_meanfs_W5, cor_SO_meanfs_W8,
                                     cor_SO_meanfs_W9, cor_SO_meanfs_W13,
                                     cor_SO_meanfs_W14, cor_SO_meanfs_W15),3),
                         c("Wave 5", "Wave 8", "Wave 9", "Wave 13",
                           "Wave 14", "Wave 15"))

#######################################################################/
#### >>> Populism Score: Goertz (Absolute - Minimum; three dimensions) ####
#######################################################################/
#### Wave 5
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W5",
                                                                                "Homogeneity_Mean_W5",
                                                                                "Sovereignty_Mean_W5")])),
                                                        na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W5",
                                                                            "Homogeneity_Mean_W5",
                                                                            "Sovereignty_Mean_W5")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Anti_Elitism_Mean_W5] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Homogeneity_Mean_W5] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Sovereignty_Mean_W5] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Anti_Elitism_Mean_W5 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Homogeneity_Mean_W5] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Anti_Elitism_Mean_W5 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Sovereignty_Mean_W5] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Homogeneity_Mean_W5 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==df_GLES17$Sovereignty_Mean_W5] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                   "Other Dimension")

#### Wave 8
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W8",
                                                                                "Homogeneity_Mean_W8",
                                                                                "Sovereignty_Mean_W8")])),
                                                        na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W8)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W8",
                                                                            "Homogeneity_Mean_W8",
                                                                            "Sovereignty_Mean_W8")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Anti_Elitism_Mean_W8] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Homogeneity_Mean_W8] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Sovereignty_Mean_W8] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Anti_Elitism_Mean_W8 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Homogeneity_Mean_W8] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Anti_Elitism_Mean_W8 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Sovereignty_Mean_W8] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Homogeneity_Mean_W8 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==df_GLES17$Sovereignty_Mean_W8] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W8_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                   "Other Dimension")

##Wave 9
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W9",
                                                                                "Homogeneity_Mean_W9",
                                                                                "Sovereignty_Mean_W9")])),
                                                        na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W9)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W9",
                                                                            "Homogeneity_Mean_W9",
                                                                            "Sovereignty_Mean_W9")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Anti_Elitism_Mean_W9] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Homogeneity_Mean_W9] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Sovereignty_Mean_W9] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Anti_Elitism_Mean_W9 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Homogeneity_Mean_W9] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Anti_Elitism_Mean_W9 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Sovereignty_Mean_W9] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Homogeneity_Mean_W9 &
                                                    df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==df_GLES17$Sovereignty_Mean_W9] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W9_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                   "Other Dimension")

##Wave 13
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W13",
                                                                                 "Homogeneity_Mean_W13",
                                                                                 "Sovereignty_Mean_W13")])),
                                                         na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W13)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W13",
                                                                             "Homogeneity_Mean_W13",
                                                                             "Sovereignty_Mean_W13")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Anti_Elitism_Mean_W13] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Homogeneity_Mean_W13] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Sovereignty_Mean_W13] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Anti_Elitism_Mean_W13 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Homogeneity_Mean_W13] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Anti_Elitism_Mean_W13 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Sovereignty_Mean_W13] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Homogeneity_Mean_W13 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==df_GLES17$Sovereignty_Mean_W13] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W13_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                    "Other Dimension")

##Wave 14
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W14",
                                                                                 "Homogeneity_Mean_W14",
                                                                                 "Sovereignty_Mean_W14")])),
                                                         na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W14)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W14",
                                                                             "Homogeneity_Mean_W14",
                                                                             "Sovereignty_Mean_W14")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Anti_Elitism_Mean_W14] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Homogeneity_Mean_W14] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Sovereignty_Mean_W14] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Anti_Elitism_Mean_W14 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Homogeneity_Mean_W14] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Anti_Elitism_Mean_W14 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Sovereignty_Mean_W14] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Homogeneity_Mean_W14 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==df_GLES17$Sovereignty_Mean_W14] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W14_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                    "Other Dimension")

##Wave 15
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W15",
                                                                                 "Homogeneity_Mean_W15",
                                                                                 "Sovereignty_Mean_W15")])),
                                                         na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_W15)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W15",
                                                                             "Homogeneity_Mean_W15",
                                                                             "Sovereignty_Mean_W15")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_NA_Count>0] <- NA

# -> which dimension is the minimum dimension? 
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name  <- NA
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Anti_Elitism_Mean_W15] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Homogeneity_Mean_W15] <- 1
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Sovereignty_Mean_W15] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Anti_Elitism_Mean_W15 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Homogeneity_Mean_W15] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Anti_Elitism_Mean_W15 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Sovereignty_Mean_W15] <- 3
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Homogeneity_Mean_W15 &
                                                     df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==df_GLES17$Sovereignty_Mean_W15] <- 2
df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name_Fac <- as.factor(df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name)
levels(df_GLES17$Populism_Goertz_AbsoluteMinimum_W15_Name_Fac) <- c("Homogeneity", "Homogeneity/Other Dimension",
                                                                    "Other Dimension")


#######################################################################/
#### >>> Populism Score: Goertz (Absolute - Minimum; two dimensions) ####
#######################################################################/

# This score includes the anti-elitism and popular sovereignty dimensions only.

#### Wave 5
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W5",
                                                                                       "Sovereignty_Mean_W5")])),
                                                               na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W5",
                                                                                   "Sovereignty_Mean_W5")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5_NA_Count>0] <- NA

#### Wave 8
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W8",
                                                                                       "Sovereignty_Mean_W8")])),
                                                               na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W8",
                                                                                   "Sovereignty_Mean_W8")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8_NA_Count>0] <- NA

##Wave 9
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W9",
                                                                                       "Sovereignty_Mean_W9")])),
                                                               na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W9",
                                                                                   "Sovereignty_Mean_W9")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9_NA_Count>0] <- NA

##Wave 13
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W13",
                                                                                        "Sovereignty_Mean_W13")])),
                                                                na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W13",
                                                                                    "Sovereignty_Mean_W13")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13_NA_Count>0] <- NA

##Wave 14
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W14",
                                                                                        "Sovereignty_Mean_W14")])),
                                                                na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W14",
                                                                                    "Sovereignty_Mean_W14")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14_NA_Count>0] <- NA

##Wave 15
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15 <- rowMins(as.matrix((df_GLES17[,c("Anti_Elitism_Mean_W15",
                                                                                        "Sovereignty_Mean_W15")])),
                                                                na.rm=T)
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15[is.infinite(df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15)] <- NA

# -> code respondents for whom scores are no available for all three dimensions as missing:
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15_NA_Count <- apply(df_GLES17[,c("Anti_Elitism_Mean_W15",
                                                                                    "Sovereignty_Mean_W15")], 1, function(x) sum(is.na(x)))
df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15_NA_Count>0] <- NA

############################################################/
#### >>> Populism Score: Goertz - light (multiplication) ####
###########################################################/

#### Wave 5
df_GLES17$Populism_Goertz_Multiplication_W5 <- df_GLES17$Anti_Elitism_Mean_W5*df_GLES17$Homogeneity_Mean_W5*df_GLES17$Sovereignty_Mean_W5
#### Wave 8
df_GLES17$Populism_Goertz_Multiplication_W8 <- df_GLES17$Anti_Elitism_Mean_W8*df_GLES17$Homogeneity_Mean_W8*df_GLES17$Sovereignty_Mean_W8
#### Wave 9
df_GLES17$Populism_Goertz_Multiplication_W9 <- df_GLES17$Anti_Elitism_Mean_W9*df_GLES17$Homogeneity_Mean_W9*df_GLES17$Sovereignty_Mean_W9
#### Wave 13
df_GLES17$Populism_Goertz_Multiplication_W13 <- df_GLES17$Anti_Elitism_Mean_W13*df_GLES17$Homogeneity_Mean_W13*df_GLES17$Sovereignty_Mean_W13
#### Wave 14
df_GLES17$Populism_Goertz_Multiplication_W14 <- df_GLES17$Anti_Elitism_Mean_W14*df_GLES17$Homogeneity_Mean_W14*df_GLES17$Sovereignty_Mean_W14
#### Wave 15
df_GLES17$Populism_Goertz_Multiplication_W15 <- df_GLES17$Anti_Elitism_Mean_W15*df_GLES17$Homogeneity_Mean_W15*df_GLES17$Sovereignty_Mean_W15


######################################################################################/
#### >>> Recode Populism Variable into Categories - Goertz Minimum (3 dimensions) ####
######################################################################################/

# In this section, we use the numerical Goertz Populism Score and recode it into
# categories that distinguish between respondents disagree, neither agreeing nor 
# disagreeing, and agreeing with populist ideas. Using the minimum is identical
# to stating, for example, the condition that a score must be >4 for all three
# individual dimensions as stated in the paper. Using the minimum score makes
# the coding a bit less cumbersome. 

#### <<<>>> Categorical variable - V1 ####

# 5=Fully disagree with populist ideas (1>= to <2)
# 4=Disagree  with populist ideas (>=2 to <3)
# 3=Neither agree nor disagree  with populist ideas (>=3 to <4)
# 2=Agree  with populist ideas (>=4 to <5)
# 1=Fully agree  with populist ideas (==5)

# Wave 5
df_GLES17$Populism_Cat_V1_W5 <- NA
df_GLES17$Populism_Cat_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=2 but should belong into the category >=4 get recoded into
# category 4
df_GLES17$Populism_Cat_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=2] <- 4
df_GLES17$Populism_Cat_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=3] <- 3
df_GLES17$Populism_Cat_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=4] <- 2
df_GLES17$Populism_Cat_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==5] <- 1


# Wave 8
df_GLES17$Populism_Cat_V1_W8 <- NA
df_GLES17$Populism_Cat_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=1] <- 5
df_GLES17$Populism_Cat_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=2] <- 4
df_GLES17$Populism_Cat_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=3] <- 3
df_GLES17$Populism_Cat_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=4] <- 2
df_GLES17$Populism_Cat_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8==5] <- 1

# Wave 9
df_GLES17$Populism_Cat_V1_W9 <- NA
df_GLES17$Populism_Cat_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=1] <- 5
df_GLES17$Populism_Cat_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=2] <- 4
df_GLES17$Populism_Cat_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=3] <- 3
df_GLES17$Populism_Cat_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=4] <- 2
df_GLES17$Populism_Cat_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9==5] <- 1

# Wave 13
df_GLES17$Populism_Cat_V1_W13 <- NA
df_GLES17$Populism_Cat_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=1] <- 5
df_GLES17$Populism_Cat_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=2] <- 4
df_GLES17$Populism_Cat_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=3] <- 3
df_GLES17$Populism_Cat_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=4] <- 2
df_GLES17$Populism_Cat_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13==5] <- 1

# Wave 14
df_GLES17$Populism_Cat_V1_W14 <- NA
df_GLES17$Populism_Cat_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=1] <- 5
df_GLES17$Populism_Cat_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=2] <- 4
df_GLES17$Populism_Cat_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=3] <- 3
df_GLES17$Populism_Cat_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=4] <- 2
df_GLES17$Populism_Cat_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14==5] <- 1

# Wave 15
df_GLES17$Populism_Cat_V1_W15 <- NA
df_GLES17$Populism_Cat_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=1] <- 5
df_GLES17$Populism_Cat_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=2] <- 4
df_GLES17$Populism_Cat_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=3] <- 3
df_GLES17$Populism_Cat_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=4] <- 2
df_GLES17$Populism_Cat_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15==5] <- 1

#### <<<>>> Categorical variable - V2 (3 categories) ####

# 3=Fully disagree/disagree with populist ideas (<3)
# 2=Neither agree nor disagree  with populist ideas (>=3 to <4)
# 1=Fully agree/Agree  with populist ideas (>=4 )

# Wave 5
df_GLES17$Populism_Cat_V2_W5 <- NA
df_GLES17$Populism_Cat_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5<3] <- 3
df_GLES17$Populism_Cat_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=3 &
                               df_GLES17$Populism_Goertz_AbsoluteMinimum_W5<4] <- 2
df_GLES17$Populism_Cat_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_W5>=4] <- 1

# Wave 8
df_GLES17$Populism_Cat_V2_W8 <- NA
df_GLES17$Populism_Cat_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8<3] <- 3
df_GLES17$Populism_Cat_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=3 &
                               df_GLES17$Populism_Goertz_AbsoluteMinimum_W8<4] <- 2
df_GLES17$Populism_Cat_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_W8>=4] <- 1

# Wave 9
df_GLES17$Populism_Cat_V2_W9 <- NA
df_GLES17$Populism_Cat_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9<3] <- 3
df_GLES17$Populism_Cat_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=3 &
                               df_GLES17$Populism_Goertz_AbsoluteMinimum_W9<4] <- 2
df_GLES17$Populism_Cat_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_W9>=4] <- 1

# Wave 13
df_GLES17$Populism_Cat_V2_W13 <- NA
df_GLES17$Populism_Cat_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13<3] <- 3
df_GLES17$Populism_Cat_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=3 &
                                df_GLES17$Populism_Goertz_AbsoluteMinimum_W13<4] <- 2
df_GLES17$Populism_Cat_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_W13>=4] <- 1

# Wave 14
df_GLES17$Populism_Cat_V2_W14 <- NA
df_GLES17$Populism_Cat_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14<3] <- 3
df_GLES17$Populism_Cat_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=3 &
                                df_GLES17$Populism_Goertz_AbsoluteMinimum_W14<4] <- 2
df_GLES17$Populism_Cat_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_W14>=4] <- 1

# Wave 15
df_GLES17$Populism_Cat_V2_W15 <- NA
df_GLES17$Populism_Cat_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15<3] <- 3
df_GLES17$Populism_Cat_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=3 &
                                df_GLES17$Populism_Goertz_AbsoluteMinimum_W15<4] <- 2
df_GLES17$Populism_Cat_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_W15>=4] <- 1


######################################################################################/
#### >>> Recode Populism Variable into Categories - Goertz Minimum (2 dimensions) ####
######################################################################################/

#### <<<>>> Categorical variable - V1 ####

# 5=Fully disagree with populist ideas (1>= to <2)
# 4=Disagree  with populist ideas (>=2 to <3)
# 3=Neither agree nor disagree  with populist ideas (>=3 to <4)
# 2=Agree  with populist ideas (>=4 to <5)
# 1=Fully agree  with populist ideas (==5)

# Wave 5
df_GLES17$Populism_Cat_TwoDim_V1_W5 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=2 but should belong into the category >=4 get recoded into
# category 4
df_GLES17$Populism_Cat_TwoDim_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5==5] <- 1


# Wave 8
df_GLES17$Populism_Cat_TwoDim_V1_W8 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=1] <- 5
df_GLES17$Populism_Cat_TwoDim_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8==5] <- 1

# Wave 9
df_GLES17$Populism_Cat_TwoDim_V1_W9 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=1] <- 5
df_GLES17$Populism_Cat_TwoDim_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9==5] <- 1

# Wave 13
df_GLES17$Populism_Cat_TwoDim_V1_W13 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=1] <- 5
df_GLES17$Populism_Cat_TwoDim_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13==5] <- 1

# Wave 14
df_GLES17$Populism_Cat_TwoDim_V1_W14 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=1] <- 5
df_GLES17$Populism_Cat_TwoDim_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14==5] <- 1

# Wave 15
df_GLES17$Populism_Cat_TwoDim_V1_W15 <- NA
df_GLES17$Populism_Cat_TwoDim_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=1] <- 5
df_GLES17$Populism_Cat_TwoDim_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=2] <- 4
df_GLES17$Populism_Cat_TwoDim_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=3] <- 3
df_GLES17$Populism_Cat_TwoDim_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=4] <- 2
df_GLES17$Populism_Cat_TwoDim_V1_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15==5] <- 1


#### <<<>>> Categorical Variable - V2 ####

# We use the numerical Goertz Populism Score (two-dimensions) and recode it into
# categories that distinguish between respondents disagree, neither agreeing nor 
# disagreeing, and agreeing with populist ideas. Using the minimum is identical
# to stating, for example, the condition that a score must be >4 for both
# individual dimensions as stated in the paper. Using the minimum score makes
# the coding a bit less cumbersome. 

# 3=Fully disagree/disagree with populist ideas (<3)
# 2=Neither agree nor disagree  with populist ideas (>=3 to <4)
# 1=Fully agree/Agree  with populist ideas (>=4 )

# Wave 5
df_GLES17$Populism_Cat_TwoDim_V2_W5 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=3 &
                                      df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W5[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W5>=4] <- 1

# Wave 8
df_GLES17$Populism_Cat_TwoDim_V2_W8 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=3 &
                                      df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W8[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W8>=4] <- 1

# Wave 9
df_GLES17$Populism_Cat_TwoDim_V2_W9 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=3 &
                                      df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W9[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W9>=4] <- 1

# Wave 13
df_GLES17$Populism_Cat_TwoDim_V2_W13 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=3 &
                                       df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W13[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W13>=4] <- 1

# Wave 14
df_GLES17$Populism_Cat_TwoDim_V2_W14 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=3 &
                                       df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W14[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W14>=4] <- 1

# Wave 15
df_GLES17$Populism_Cat_TwoDim_V2_W15 <- NA
df_GLES17$Populism_Cat_TwoDim_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15<3] <- 3
df_GLES17$Populism_Cat_TwoDim_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=3 &
                                       df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15<4] <- 2
df_GLES17$Populism_Cat_TwoDim_V2_W15[df_GLES17$Populism_Goertz_AbsoluteMinimum_TwoDim_W15>=4] <- 1

############################################################################/
#### >>> Recode Populism Variable into Categories - Goertz Multiplication ####
#############################################################################/

# In this section, we use the numerical MULTIPLICATION Goertz Populism Score and recode it into
# categories that distinguish between respondents disagree, neither agreeing nor 
# disagreeing, and agreeing with populist ideas. 
# Because we multiplied dimensions here, the cut off points are not evenly 
# distributed across the space from 1 (minimum) to 125 (maximum). We use
# even cut-off points at both end of the scale though also code a version
# that uses a minimum score across all three dimensions (see V2).



#### <<<>>> Categorical variable - V1 ####

# The coding is akin to stating that values of smaller than 1.5 implicate full
# agreement and that values between 1.5 and less than 2.5 imply agreement and so
# on. Because the scale consists of three multiplied scores, the cut-off points
# are determined by taking all cut-off values to the power of 3.

# 5=Fully disagree with populist ideas (1>= to <3.375) (3.375=1.5^3)
# 4=Disagree  with populist ideas (>=3.375 to <15.625)
# 3=Neither agree nor disagree  with populist ideas (>=15.625 to <42.875)
# 2=Agree  with populist ideas (>=42.875 to <91.125)
# 1=Fully agree  with populist ideas (>=91.125)

# Wave 5
df_GLES17$Populism_Cat_Mult_V1_W5 <- NA
df_GLES17$Populism_Cat_Mult_V1_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W5[df_GLES17$Populism_Goertz_Multiplication_W5==91.125] <- 1

# Wave 8
df_GLES17$Populism_Cat_Mult_V1_W8 <- NA
df_GLES17$Populism_Cat_Mult_V1_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W8[df_GLES17$Populism_Goertz_Multiplication_W8==91.125] <- 1

# Wave 9
df_GLES17$Populism_Cat_Mult_V1_W9 <- NA
df_GLES17$Populism_Cat_Mult_V1_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W9[df_GLES17$Populism_Goertz_Multiplication_W9==91.125] <- 1

# Wave 13
df_GLES17$Populism_Cat_Mult_V1_W13 <- NA
df_GLES17$Populism_Cat_Mult_V1_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W13[df_GLES17$Populism_Goertz_Multiplication_W13==91.125] <- 1

# Wave 14
df_GLES17$Populism_Cat_Mult_V1_W14 <- NA
df_GLES17$Populism_Cat_Mult_V1_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W14[df_GLES17$Populism_Goertz_Multiplication_W14==91.125] <- 1

# Wave 15
df_GLES17$Populism_Cat_Mult_V1_W15 <- NA
df_GLES17$Populism_Cat_Mult_V1_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=1] <- 5
df_GLES17$Populism_Cat_Mult_V1_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=3.375] <- 4
df_GLES17$Populism_Cat_Mult_V1_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=15.625] <- 3
df_GLES17$Populism_Cat_Mult_V1_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=42.875] <- 2
df_GLES17$Populism_Cat_Mult_V1_W15[df_GLES17$Populism_Goertz_Multiplication_W15==91.125] <- 1


#### <<<>>> Categorical variable - V2 ####

# 5=Fully disagree with populist ideas (1>= to <8) (8=2^3 with 2=value below which respondents fully disagree with a dimension)
# 4=Disagree  with populist ideas (>=8 to <27)
# 3=Neither agree nor disagree  with populist ideas (>=27 to <64)
# 2=Agree  with populist ideas (>=64 to <125)
# 1=Fully agree  with populist ideas (==125)

# Wave 5
df_GLES17$Populism_Cat_Mult_V2_W5 <- NA
df_GLES17$Populism_Cat_Mult_V2_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W5[df_GLES17$Populism_Goertz_Multiplication_W5>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W5[df_GLES17$Populism_Goertz_Multiplication_W5==125] <- 1

# Wave 8
df_GLES17$Populism_Cat_Mult_V2_W8 <- NA
df_GLES17$Populism_Cat_Mult_V2_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W8[df_GLES17$Populism_Goertz_Multiplication_W8>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W8[df_GLES17$Populism_Goertz_Multiplication_W8==125] <- 1

# Wave 9
df_GLES17$Populism_Cat_Mult_V2_W9 <- NA
df_GLES17$Populism_Cat_Mult_V2_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W9[df_GLES17$Populism_Goertz_Multiplication_W9>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W9[df_GLES17$Populism_Goertz_Multiplication_W9==125] <- 1

# Wave 13
df_GLES17$Populism_Cat_Mult_V2_W13 <- NA
df_GLES17$Populism_Cat_Mult_V2_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W13[df_GLES17$Populism_Goertz_Multiplication_W13>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W13[df_GLES17$Populism_Goertz_Multiplication_W13==125] <- 1

# Wave 14
df_GLES17$Populism_Cat_Mult_V2_W14 <- NA
df_GLES17$Populism_Cat_Mult_V2_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W14[df_GLES17$Populism_Goertz_Multiplication_W14>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W14[df_GLES17$Populism_Goertz_Multiplication_W14==125] <- 1

# Wave 15
df_GLES17$Populism_Cat_Mult_V2_W15 <- NA
df_GLES17$Populism_Cat_Mult_V2_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=1] <- 5
#rather than specifying multiple conditions, we just go down the list so that people
#who say have a score of >=8 but should belong into the category >=64 get recoded into
# category 4
df_GLES17$Populism_Cat_Mult_V2_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=8] <- 4
df_GLES17$Populism_Cat_Mult_V2_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=27] <- 3
df_GLES17$Populism_Cat_Mult_V2_W15[df_GLES17$Populism_Goertz_Multiplication_W15>=64] <- 2
df_GLES17$Populism_Cat_Mult_V2_W15[df_GLES17$Populism_Goertz_Multiplication_W15==125] <- 1

############################################################################/
#### >>> Recode Anti-Elitism Variable into Categories                 ####
#############################################################################/


#### <<<>>> Categorical variable - V1 ####

# 5=Fully disagree with anti-elitism (1 to <1.5)
# 4=Disagree  with anti-elitism (>=1.5 to <2.5)
# 3=Neither agree nor disagree  with anti-elitism (>=2.5 to <3.5)
# 2=Agree  with anti-elitism (>=3.5 to <4.5)
# 1=Fully agree  with anti-elitism (>4.5)

# Wave 5
df_GLES17$Anti_Elitism_Cat_V1_W5 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W5[df_GLES17$Anti_Elitism_Mean_W5<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W5[df_GLES17$Anti_Elitism_Mean_W5>=1.5 &
                                   df_GLES17$Anti_Elitism_Mean_W5<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W5[df_GLES17$Anti_Elitism_Mean_W5>=2.5 &
                                   df_GLES17$Anti_Elitism_Mean_W5<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W5[df_GLES17$Anti_Elitism_Mean_W5>=3.5 &
                                   df_GLES17$Anti_Elitism_Mean_W5<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W5[df_GLES17$Anti_Elitism_Mean_W5>4.5] <- 1

# Wave 8
df_GLES17$Anti_Elitism_Cat_V1_W8 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W8[df_GLES17$Anti_Elitism_Mean_W8<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W8[df_GLES17$Anti_Elitism_Mean_W8>=1.5 &
                                   df_GLES17$Anti_Elitism_Mean_W8<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W8[df_GLES17$Anti_Elitism_Mean_W8>=2.5 &
                                   df_GLES17$Anti_Elitism_Mean_W8<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W8[df_GLES17$Anti_Elitism_Mean_W8>=3.5 &
                                   df_GLES17$Anti_Elitism_Mean_W8<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W8[df_GLES17$Anti_Elitism_Mean_W8>4.5] <- 1

# Wave 9
df_GLES17$Anti_Elitism_Cat_V1_W9 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W9[df_GLES17$Anti_Elitism_Mean_W9<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W9[df_GLES17$Anti_Elitism_Mean_W9>=1.5 &
                                   df_GLES17$Anti_Elitism_Mean_W9<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W9[df_GLES17$Anti_Elitism_Mean_W9>=2.5 &
                                   df_GLES17$Anti_Elitism_Mean_W9<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W9[df_GLES17$Anti_Elitism_Mean_W9>=3.5 &
                                   df_GLES17$Anti_Elitism_Mean_W9<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W9[df_GLES17$Anti_Elitism_Mean_W9>4.5] <- 1

# Wave 13
df_GLES17$Anti_Elitism_Cat_V1_W13 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W13[df_GLES17$Anti_Elitism_Mean_W13<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W13[df_GLES17$Anti_Elitism_Mean_W13>=1.5 &
                                    df_GLES17$Anti_Elitism_Mean_W13<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W13[df_GLES17$Anti_Elitism_Mean_W13>=2.5 &
                                    df_GLES17$Anti_Elitism_Mean_W13<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W13[df_GLES17$Anti_Elitism_Mean_W13>=3.5 &
                                    df_GLES17$Anti_Elitism_Mean_W13<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W13[df_GLES17$Anti_Elitism_Mean_W13>4.5] <- 1

# Wave 14
df_GLES17$Anti_Elitism_Cat_V1_W14 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W14[df_GLES17$Anti_Elitism_Mean_W14<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W14[df_GLES17$Anti_Elitism_Mean_W14>=1.5 &
                                    df_GLES17$Anti_Elitism_Mean_W14<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W14[df_GLES17$Anti_Elitism_Mean_W14>=2.5 &
                                    df_GLES17$Anti_Elitism_Mean_W14<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W14[df_GLES17$Anti_Elitism_Mean_W14>=3.5 &
                                    df_GLES17$Anti_Elitism_Mean_W14<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W14[df_GLES17$Anti_Elitism_Mean_W14>4.5] <- 1

# Wave 15
df_GLES17$Anti_Elitism_Cat_V1_W15 <- NA
df_GLES17$Anti_Elitism_Cat_V1_W15[df_GLES17$Anti_Elitism_Mean_W15<1.5] <- 5
df_GLES17$Anti_Elitism_Cat_V1_W15[df_GLES17$Anti_Elitism_Mean_W15>=1.5 &
                                    df_GLES17$Anti_Elitism_Mean_W15<2.5] <- 4
df_GLES17$Anti_Elitism_Cat_V1_W15[df_GLES17$Anti_Elitism_Mean_W15>=2.5 &
                                    df_GLES17$Anti_Elitism_Mean_W15<3.5] <- 3
df_GLES17$Anti_Elitism_Cat_V1_W15[df_GLES17$Anti_Elitism_Mean_W15>=3.5 &
                                    df_GLES17$Anti_Elitism_Mean_W15<4.5] <- 2
df_GLES17$Anti_Elitism_Cat_V1_W15[df_GLES17$Anti_Elitism_Mean_W15>4.5] <- 1


############################################################################/
#### >>> Recode Sovereignty Variable into Categories                 ####
#############################################################################/

#### <<<>>> Categorical variable - V1 ####

# 5=Full disagree with Sovereignty (1 to <1.5)
# 4=Disagree  with Sovereignty (>=1.5 to <2.5)
# 3=Neither agree nor disagree  with Sovereignty (>=2.5 to <3.5)
# 2=Agree  with Sovereignty (>=3.5 to <4.5)
# 1=Full agree  with Sovereignty (>4.5)

# Wave 5
df_GLES17$Sovereignty_Cat_V1_W5 <- NA
df_GLES17$Sovereignty_Cat_V1_W5[df_GLES17$Sovereignty_Mean_W5<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W5[df_GLES17$Sovereignty_Mean_W5>=1.5 &
                                  df_GLES17$Sovereignty_Mean_W5<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W5[df_GLES17$Sovereignty_Mean_W5>=2.5 &
                                  df_GLES17$Sovereignty_Mean_W5<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W5[df_GLES17$Sovereignty_Mean_W5>=3.5 &
                                  df_GLES17$Sovereignty_Mean_W5<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W5[df_GLES17$Sovereignty_Mean_W5>4.5] <- 1

# Wave 8
df_GLES17$Sovereignty_Cat_V1_W8 <- NA
df_GLES17$Sovereignty_Cat_V1_W8[df_GLES17$Sovereignty_Mean_W8<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W8[df_GLES17$Sovereignty_Mean_W8>=1.5 &
                                  df_GLES17$Sovereignty_Mean_W8<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W8[df_GLES17$Sovereignty_Mean_W8>=2.5 &
                                  df_GLES17$Sovereignty_Mean_W8<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W8[df_GLES17$Sovereignty_Mean_W8>=3.5 &
                                  df_GLES17$Sovereignty_Mean_W8<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W8[df_GLES17$Sovereignty_Mean_W8>4.5] <- 1

# Wave 9
df_GLES17$Sovereignty_Cat_V1_W9 <- NA
df_GLES17$Sovereignty_Cat_V1_W9[df_GLES17$Sovereignty_Mean_W9<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W9[df_GLES17$Sovereignty_Mean_W9>=1.5 &
                                  df_GLES17$Sovereignty_Mean_W9<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W9[df_GLES17$Sovereignty_Mean_W9>=2.5 &
                                  df_GLES17$Sovereignty_Mean_W9<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W9[df_GLES17$Sovereignty_Mean_W9>=3.5 &
                                  df_GLES17$Sovereignty_Mean_W9<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W9[df_GLES17$Sovereignty_Mean_W9>4.5] <- 1

# Wave 13
df_GLES17$Sovereignty_Cat_V1_W13 <- NA
df_GLES17$Sovereignty_Cat_V1_W13[df_GLES17$Sovereignty_Mean_W13<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W13[df_GLES17$Sovereignty_Mean_W13>=1.5 &
                                   df_GLES17$Sovereignty_Mean_W13<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W13[df_GLES17$Sovereignty_Mean_W13>=2.5 &
                                   df_GLES17$Sovereignty_Mean_W13<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W13[df_GLES17$Sovereignty_Mean_W13>=3.5 &
                                   df_GLES17$Sovereignty_Mean_W13<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W13[df_GLES17$Sovereignty_Mean_W13>4.5] <- 1

# Wave 14
df_GLES17$Sovereignty_Cat_V1_W14 <- NA
df_GLES17$Sovereignty_Cat_V1_W14[df_GLES17$Sovereignty_Mean_W14<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W14[df_GLES17$Sovereignty_Mean_W14>=1.5 &
                                   df_GLES17$Sovereignty_Mean_W14<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W14[df_GLES17$Sovereignty_Mean_W14>=2.5 &
                                   df_GLES17$Sovereignty_Mean_W14<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W14[df_GLES17$Sovereignty_Mean_W14>=3.5 &
                                   df_GLES17$Sovereignty_Mean_W14<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W14[df_GLES17$Sovereignty_Mean_W14>4.5] <- 1

# Wave 15
df_GLES17$Sovereignty_Cat_V1_W15 <- NA
df_GLES17$Sovereignty_Cat_V1_W15[df_GLES17$Sovereignty_Mean_W15<1.5] <- 5
df_GLES17$Sovereignty_Cat_V1_W15[df_GLES17$Sovereignty_Mean_W15>=1.5 &
                                   df_GLES17$Sovereignty_Mean_W15<2.5] <- 4
df_GLES17$Sovereignty_Cat_V1_W15[df_GLES17$Sovereignty_Mean_W15>=2.5 &
                                   df_GLES17$Sovereignty_Mean_W15<3.5] <- 3
df_GLES17$Sovereignty_Cat_V1_W15[df_GLES17$Sovereignty_Mean_W15>=3.5 &
                                   df_GLES17$Sovereignty_Mean_W15<4.5] <- 2
df_GLES17$Sovereignty_Cat_V1_W15[df_GLES17$Sovereignty_Mean_W15>4.5] <- 1


############################################################################/
#### >>> Recode Homogeneity Variable into Categories                 ####
#############################################################################/

#### <<<>>> Categorical variable - V1 ####

# 5=Full disagree with Homogeneity (1 to <1.5)
# 4=Disagree  with Homogeneity (>=1.5 to <2.5)
# 3=Neither agree nor disagree  with Homogeneity (>=2.5 to <3.5)
# 2=Agree  with Homogeneity (>=3.5 to <4.5)
# 1=Full agree  with Homogeneity (>4.5)

# Wave 5
df_GLES17$Homogeneity_Cat_V1_W5 <- NA
df_GLES17$Homogeneity_Cat_V1_W5[df_GLES17$Homogeneity_Mean_W5<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W5[df_GLES17$Homogeneity_Mean_W5>=1.5 &
                                  df_GLES17$Homogeneity_Mean_W5<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W5[df_GLES17$Homogeneity_Mean_W5>=2.5 &
                                  df_GLES17$Homogeneity_Mean_W5<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W5[df_GLES17$Homogeneity_Mean_W5>=3.5 &
                                  df_GLES17$Homogeneity_Mean_W5<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W5[df_GLES17$Homogeneity_Mean_W5>4.5] <- 1

# Wave 8
df_GLES17$Homogeneity_Cat_V1_W8 <- NA
df_GLES17$Homogeneity_Cat_V1_W8[df_GLES17$Homogeneity_Mean_W8<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W8[df_GLES17$Homogeneity_Mean_W8>=1.5 &
                                  df_GLES17$Homogeneity_Mean_W8<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W8[df_GLES17$Homogeneity_Mean_W8>=2.5 &
                                  df_GLES17$Homogeneity_Mean_W8<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W8[df_GLES17$Homogeneity_Mean_W8>=3.5 &
                                  df_GLES17$Homogeneity_Mean_W8<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W8[df_GLES17$Homogeneity_Mean_W8>4.5] <- 1

# Wave 9
df_GLES17$Homogeneity_Cat_V1_W9 <- NA
df_GLES17$Homogeneity_Cat_V1_W9[df_GLES17$Homogeneity_Mean_W9<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W9[df_GLES17$Homogeneity_Mean_W9>=1.5 &
                                  df_GLES17$Homogeneity_Mean_W9<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W9[df_GLES17$Homogeneity_Mean_W9>=2.5 &
                                  df_GLES17$Homogeneity_Mean_W9<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W9[df_GLES17$Homogeneity_Mean_W9>=3.5 &
                                  df_GLES17$Homogeneity_Mean_W9<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W9[df_GLES17$Homogeneity_Mean_W9>4.5] <- 1

# Wave 13
df_GLES17$Homogeneity_Cat_V1_W13 <- NA
df_GLES17$Homogeneity_Cat_V1_W13[df_GLES17$Homogeneity_Mean_W13<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W13[df_GLES17$Homogeneity_Mean_W13>=1.5 &
                                   df_GLES17$Homogeneity_Mean_W13<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W13[df_GLES17$Homogeneity_Mean_W13>=2.5 &
                                   df_GLES17$Homogeneity_Mean_W13<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W13[df_GLES17$Homogeneity_Mean_W13>=3.5 &
                                   df_GLES17$Homogeneity_Mean_W13<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W13[df_GLES17$Homogeneity_Mean_W13>4.5] <- 1

# Wave 14
df_GLES17$Homogeneity_Cat_V1_W14 <- NA
df_GLES17$Homogeneity_Cat_V1_W14[df_GLES17$Homogeneity_Mean_W14<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W14[df_GLES17$Homogeneity_Mean_W14>=1.5 &
                                   df_GLES17$Homogeneity_Mean_W14<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W14[df_GLES17$Homogeneity_Mean_W14>=2.5 &
                                   df_GLES17$Homogeneity_Mean_W14<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W14[df_GLES17$Homogeneity_Mean_W14>=3.5 &
                                   df_GLES17$Homogeneity_Mean_W14<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W14[df_GLES17$Homogeneity_Mean_W14>4.5] <- 1

# Wave 15
df_GLES17$Homogeneity_Cat_V1_W15 <- NA
df_GLES17$Homogeneity_Cat_V1_W15[df_GLES17$Homogeneity_Mean_W15<1.5] <- 5
df_GLES17$Homogeneity_Cat_V1_W15[df_GLES17$Homogeneity_Mean_W15>=1.5 &
                                   df_GLES17$Homogeneity_Mean_W15<2.5] <- 4
df_GLES17$Homogeneity_Cat_V1_W15[df_GLES17$Homogeneity_Mean_W15>=2.5 &
                                   df_GLES17$Homogeneity_Mean_W15<3.5] <- 3
df_GLES17$Homogeneity_Cat_V1_W15[df_GLES17$Homogeneity_Mean_W15>=3.5 &
                                   df_GLES17$Homogeneity_Mean_W15<4.5] <- 2
df_GLES17$Homogeneity_Cat_V1_W15[df_GLES17$Homogeneity_Mean_W15>4.5] <- 1


#### >>> Variable (alternative): stable populists & non-populists (Wave5-Wave t; Goertz Minimum) ####

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). The code is based on the recategorized
## minimal populism score variable (Goertz Minimum). Coding:
## 1=Other
## 2=Stable Populists
## 3=Stable Non-Populists

## W5-W8
df_GLES17$StablePop_W5W8 <- 1
#Populists
df_GLES17$StablePop_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                     df_GLES17$Populism_Cat_V1_W8<3,2,df_GLES17$StablePop_W5W8)
#Non-Populists
df_GLES17$StablePop_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                     df_GLES17$Populism_Cat_V1_W8>3,3,df_GLES17$StablePop_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                     is.na(df_GLES17$Populism_Cat_V1_W8),NA,df_GLES17$StablePop_W5W8)

## W5-W9
df_GLES17$StablePop_W5W9 <- 1
#Populists
df_GLES17$StablePop_W5W9 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                     df_GLES17$Populism_Cat_V1_W8<3 &
                                     df_GLES17$Populism_Cat_V1_W9<3,2,df_GLES17$StablePop_W5W9)
#Non-Populists
df_GLES17$StablePop_W5W9 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                     df_GLES17$Populism_Cat_V1_W8>3 &
                                     df_GLES17$Populism_Cat_V1_W9>3,3,df_GLES17$StablePop_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W5W9 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                     is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                     is.na(df_GLES17$Populism_Cat_V1_W9),NA,df_GLES17$StablePop_W5W9)

## W5-W13
df_GLES17$StablePop_W5W13 <- 1
#Populists
df_GLES17$StablePop_W5W13 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                      df_GLES17$Populism_Cat_V1_W8<3 &
                                      df_GLES17$Populism_Cat_V1_W9<3 &
                                      df_GLES17$Populism_Cat_V1_W13<3,2,df_GLES17$StablePop_W5W13)
#Non-Populists
df_GLES17$StablePop_W5W13 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                      df_GLES17$Populism_Cat_V1_W8>3 &
                                      df_GLES17$Populism_Cat_V1_W9>3 &
                                      df_GLES17$Populism_Cat_V1_W13>3,3,df_GLES17$StablePop_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W5W13 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W9)| 
                                      is.na(df_GLES17$Populism_Cat_V1_W13),NA,df_GLES17$StablePop_W5W13)

## W5-W14
df_GLES17$StablePop_W5W14 <- 1
#Populists
df_GLES17$StablePop_W5W14 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                      df_GLES17$Populism_Cat_V1_W8<3 &
                                      df_GLES17$Populism_Cat_V1_W9<3 &
                                      df_GLES17$Populism_Cat_V1_W13<3 &
                                      df_GLES17$Populism_Cat_V1_W14<3,2,df_GLES17$StablePop_W5W14)
#Non-Populists
df_GLES17$StablePop_W5W14 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                      df_GLES17$Populism_Cat_V1_W8>3 &
                                      df_GLES17$Populism_Cat_V1_W9>3 &
                                      df_GLES17$Populism_Cat_V1_W13>3 &
                                      df_GLES17$Populism_Cat_V1_W14>3,3,df_GLES17$StablePop_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W5W14 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W14),NA,df_GLES17$StablePop_W5W14)

## W5-W15
df_GLES17$StablePop_W5W15 <- 1
#Populists
df_GLES17$StablePop_W5W15 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                      df_GLES17$Populism_Cat_V1_W8<3 &
                                      df_GLES17$Populism_Cat_V1_W9<3 &
                                      df_GLES17$Populism_Cat_V1_W13<3 &
                                      df_GLES17$Populism_Cat_V1_W14<3 &
                                      df_GLES17$Populism_Cat_V1_W15<3,2,df_GLES17$StablePop_W5W15)
#Non-Populists
df_GLES17$StablePop_W5W15 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                      df_GLES17$Populism_Cat_V1_W8>3 &
                                      df_GLES17$Populism_Cat_V1_W9>3 &
                                      df_GLES17$Populism_Cat_V1_W13>3 &
                                      df_GLES17$Populism_Cat_V1_W14>3 &
                                      df_GLES17$Populism_Cat_V1_W15>3,3,df_GLES17$StablePop_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W5W15 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W14) | 
                                      is.na(df_GLES17$Populism_Cat_V1_W15),NA,df_GLES17$StablePop_W5W15)


####################################################################################################/
#### >>> Variable (alternative): Unstable & stable populist attitude respondents (wave-to-wave; Goertz Minimum) ####
####################################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave-to-Wave). Coding:
## 1=Unstable
## 2=Stable Populists/Stable Non-Populists

## W5-W8
df_GLES17$StablePop_W2W_W5W8 <- 1
#Populists
df_GLES17$StablePop_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                         df_GLES17$Populism_Cat_V1_W8<3,2,df_GLES17$StablePop_W2W_W5W8)
#Non-Populists
df_GLES17$StablePop_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                         df_GLES17$Populism_Cat_V1_W8>3,2,df_GLES17$StablePop_W2W_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W2W_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W8),NA,df_GLES17$StablePop_W2W_W5W8)

## W8-W9
df_GLES17$StablePop_W2W_W8W9 <- 1
#Populists
df_GLES17$StablePop_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8<3 &
                                         df_GLES17$Populism_Cat_V1_W9<3,2,df_GLES17$StablePop_W2W_W8W9)
#Non-Populists
df_GLES17$StablePop_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8>3 &
                                         df_GLES17$Populism_Cat_V1_W9>3,2,df_GLES17$StablePop_W2W_W8W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W2W_W8W9 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W9),NA,df_GLES17$StablePop_W2W_W8W9)

## W9-W13
df_GLES17$StablePop_W2W_W9W13 <- 1
#Populists
df_GLES17$StablePop_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9<3 &
                                          df_GLES17$Populism_Cat_V1_W13<3,2,df_GLES17$StablePop_W2W_W9W13)
#Non-Populists
df_GLES17$StablePop_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9>3 &
                                          df_GLES17$Populism_Cat_V1_W13>3,2,df_GLES17$StablePop_W2W_W9W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W2W_W9W13 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                          is.na(df_GLES17$Populism_Cat_V1_W13),NA,df_GLES17$StablePop_W2W_W9W13)

## W13-W14
df_GLES17$StablePop_W2W_W13W14 <- 1
#Populists
df_GLES17$StablePop_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13<3 &
                                           df_GLES17$Populism_Cat_V1_W14<3,2,df_GLES17$StablePop_W2W_W13W14)
#Non-Populists
df_GLES17$StablePop_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13>3 &
                                           df_GLES17$Populism_Cat_V1_W14>3,2,df_GLES17$StablePop_W2W_W13W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W2W_W13W14 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                           is.na(df_GLES17$Populism_Cat_V1_W14),NA,df_GLES17$StablePop_W2W_W13W14)

## W14-W15
df_GLES17$StablePop_W2W_W14W15 <- 1
#Populists
df_GLES17$StablePop_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14<3 &
                                           df_GLES17$Populism_Cat_V1_W15<3,2,df_GLES17$StablePop_W2W_W14W15)
#Non-Populists
df_GLES17$StablePop_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14>3 &
                                           df_GLES17$Populism_Cat_V1_W15>3,2,df_GLES17$StablePop_W2W_W14W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_W2W_W14W15 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W14) | 
                                           is.na(df_GLES17$Populism_Cat_V1_W15),NA,df_GLES17$StablePop_W2W_W14W15)

######################################################################################################/
#### >>> Variable (alternative): unstable, stable populists & stable non-populists (wave-to-wave; Goertz Minimium) ####
#######################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave-to-Wave). Coding:
## 1=Unstable
## 2=Stable Populists
## 3=Stable Non-Populists

## W5-W8
df_GLES17$StablePop_Tri_W2W_W5W8 <- 1
#Populists
df_GLES17$StablePop_Tri_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                             df_GLES17$Populism_Cat_V1_W8<3,2,df_GLES17$StablePop_Tri_W2W_W5W8)
#Non-Populists
df_GLES17$StablePop_Tri_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                             df_GLES17$Populism_Cat_V1_W8>3,3,df_GLES17$StablePop_Tri_W2W_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Tri_W2W_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                             is.na(df_GLES17$Populism_Cat_V1_W8),NA,df_GLES17$StablePop_Tri_W2W_W5W8)

## W8-W9
df_GLES17$StablePop_Tri_W2W_W8W9 <- 1
#Populists
df_GLES17$StablePop_Tri_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8<3 &
                                             df_GLES17$Populism_Cat_V1_W9<3,2,df_GLES17$StablePop_Tri_W2W_W8W9)
#Non-Populists
df_GLES17$StablePop_Tri_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8>3 &
                                             df_GLES17$Populism_Cat_V1_W9>3,3,df_GLES17$StablePop_Tri_W2W_W8W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Tri_W2W_W8W9 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                             is.na(df_GLES17$Populism_Cat_V1_W9),NA,df_GLES17$StablePop_Tri_W2W_W8W9)

## W9-W13
df_GLES17$StablePop_Tri_W2W_W9W13 <- 1
#Populists
df_GLES17$StablePop_Tri_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9<3 &
                                              df_GLES17$Populism_Cat_V1_W13<3,2,df_GLES17$StablePop_Tri_W2W_W9W13)
#Non-Populists
df_GLES17$StablePop_Tri_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9>3 &
                                              df_GLES17$Populism_Cat_V1_W13>3,3,df_GLES17$StablePop_Tri_W2W_W9W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Tri_W2W_W9W13 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                              is.na(df_GLES17$Populism_Cat_V1_W13),NA,df_GLES17$StablePop_Tri_W2W_W9W13)

## W13-W14
df_GLES17$StablePop_Tri_W2W_W13W14 <- 1
#Populists
df_GLES17$StablePop_Tri_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13<3 &
                                               df_GLES17$Populism_Cat_V1_W14<3,2,df_GLES17$StablePop_Tri_W2W_W13W14)
#Non-Populists
df_GLES17$StablePop_Tri_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13>3 &
                                               df_GLES17$Populism_Cat_V1_W14>3,3,df_GLES17$StablePop_Tri_W2W_W13W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Tri_W2W_W13W14 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                               is.na(df_GLES17$Populism_Cat_V1_W14),NA,df_GLES17$StablePop_Tri_W2W_W13W14)

## W14-W15
df_GLES17$StablePop_Tri_W2W_W14W15 <- 1
#Populists
df_GLES17$StablePop_Tri_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14<3 &
                                               df_GLES17$Populism_Cat_V1_W15<3,2,df_GLES17$StablePop_Tri_W2W_W14W15)
#Non-Populists
df_GLES17$StablePop_Tri_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14>3 &
                                               df_GLES17$Populism_Cat_V1_W15>3,3,df_GLES17$StablePop_Tri_W2W_W14W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Tri_W2W_W14W15 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W14) | 
                                               is.na(df_GLES17$Populism_Cat_V1_W15),NA,df_GLES17$StablePop_Tri_W2W_W14W15)

##################################################################################################################/
#### >>> Variable (main): stable populists & non-populists (Wave5-Wave t; Goertz Minimum) ####
#################################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Stable Populists
## 3=Stable Non-Populists
## 4=Stable middle category

## W5-W8
df_GLES17$StablePop_V2_W5W8 <- 1
#Populists
df_GLES17$StablePop_V2_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                        df_GLES17$Populism_Cat_V1_W8<3,2,df_GLES17$StablePop_V2_W5W8)
#Non-Populists
df_GLES17$StablePop_V2_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                        df_GLES17$Populism_Cat_V1_W8>3,3,df_GLES17$StablePop_V2_W5W8)
#Middle Category
df_GLES17$StablePop_V2_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                        df_GLES17$Populism_Cat_V1_W8==3,4,df_GLES17$StablePop_V2_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                        is.na(df_GLES17$Populism_Cat_V1_W8),NA,df_GLES17$StablePop_V2_W5W8)

## W5-W9
df_GLES17$StablePop_V2_W5W9 <- 1
#Populists
df_GLES17$StablePop_V2_W5W9 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                        df_GLES17$Populism_Cat_V1_W8<3 &
                                        df_GLES17$Populism_Cat_V1_W9<3,2,df_GLES17$StablePop_V2_W5W9)
#Non-Populists
df_GLES17$StablePop_V2_W5W9 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                        df_GLES17$Populism_Cat_V1_W8>3 &
                                        df_GLES17$Populism_Cat_V1_W9>3,3,df_GLES17$StablePop_V2_W5W9)
#Middle Category
df_GLES17$StablePop_V2_W5W9 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                        df_GLES17$Populism_Cat_V1_W8==3 &
                                        df_GLES17$Populism_Cat_V1_W9==3,4,df_GLES17$StablePop_V2_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W5W9 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                        is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                        is.na(df_GLES17$Populism_Cat_V1_W9),NA,df_GLES17$StablePop_V2_W5W9)

## W5-W13
df_GLES17$StablePop_V2_W5W13 <- 1
#Populists
df_GLES17$StablePop_V2_W5W13 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                         df_GLES17$Populism_Cat_V1_W8<3 &
                                         df_GLES17$Populism_Cat_V1_W9<3 &
                                         df_GLES17$Populism_Cat_V1_W13<3,2,df_GLES17$StablePop_V2_W5W13)
#Non-Populists
df_GLES17$StablePop_V2_W5W13 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                         df_GLES17$Populism_Cat_V1_W8>3 &
                                         df_GLES17$Populism_Cat_V1_W9>3 &
                                         df_GLES17$Populism_Cat_V1_W13>3,3,df_GLES17$StablePop_V2_W5W13)
#Middle Category
df_GLES17$StablePop_V2_W5W13 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                         df_GLES17$Populism_Cat_V1_W8==3 &
                                         df_GLES17$Populism_Cat_V1_W9==3 &
                                         df_GLES17$Populism_Cat_V1_W13==3,4,df_GLES17$StablePop_V2_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W5W13 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W9)| 
                                         is.na(df_GLES17$Populism_Cat_V1_W13),NA,df_GLES17$StablePop_V2_W5W13)

## W5-W14
df_GLES17$StablePop_V2_W5W14 <- 1
#Populists
df_GLES17$StablePop_V2_W5W14 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                         df_GLES17$Populism_Cat_V1_W8<3 &
                                         df_GLES17$Populism_Cat_V1_W9<3 &
                                         df_GLES17$Populism_Cat_V1_W13<3 &
                                         df_GLES17$Populism_Cat_V1_W14<3,2,df_GLES17$StablePop_V2_W5W14)
#Non-Populists
df_GLES17$StablePop_V2_W5W14 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                         df_GLES17$Populism_Cat_V1_W8>3 &
                                         df_GLES17$Populism_Cat_V1_W9>3 &
                                         df_GLES17$Populism_Cat_V1_W13>3 &
                                         df_GLES17$Populism_Cat_V1_W14>3,3,df_GLES17$StablePop_V2_W5W14)
#Middle Category
df_GLES17$StablePop_V2_W5W14 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                         df_GLES17$Populism_Cat_V1_W8==3 &
                                         df_GLES17$Populism_Cat_V1_W9==3 &
                                         df_GLES17$Populism_Cat_V1_W13==3 &
                                         df_GLES17$Populism_Cat_V1_W14==3,4,df_GLES17$StablePop_V2_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W5W14 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W14),NA,df_GLES17$StablePop_V2_W5W14)

## W5-W15
df_GLES17$StablePop_V2_W5W15 <- 1
#Populists
df_GLES17$StablePop_V2_W5W15 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                         df_GLES17$Populism_Cat_V1_W8<3 &
                                         df_GLES17$Populism_Cat_V1_W9<3 &
                                         df_GLES17$Populism_Cat_V1_W13<3 &
                                         df_GLES17$Populism_Cat_V1_W14<3 &
                                         df_GLES17$Populism_Cat_V1_W15<3,2,df_GLES17$StablePop_V2_W5W15)
#Non-Populists
df_GLES17$StablePop_V2_W5W15 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                         df_GLES17$Populism_Cat_V1_W8>3 &
                                         df_GLES17$Populism_Cat_V1_W9>3 &
                                         df_GLES17$Populism_Cat_V1_W13>3 &
                                         df_GLES17$Populism_Cat_V1_W14>3 &
                                         df_GLES17$Populism_Cat_V1_W15>3,3,df_GLES17$StablePop_V2_W5W15)
#Middle Category
df_GLES17$StablePop_V2_W5W15 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                         df_GLES17$Populism_Cat_V1_W8==3 &
                                         df_GLES17$Populism_Cat_V1_W9==3 &
                                         df_GLES17$Populism_Cat_V1_W13==3 &
                                         df_GLES17$Populism_Cat_V1_W14==3 &
                                         df_GLES17$Populism_Cat_V1_W15==3,4,df_GLES17$StablePop_V2_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W5W15 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W14) | 
                                         is.na(df_GLES17$Populism_Cat_V1_W15),NA,df_GLES17$StablePop_V2_W5W15)

#################################################################################################################################/
#### >>> Variable (main V2): unstable & stable populist attitude respondents (wave-to-wave; Goertz Minimun) ####
################################################################################################################################/

## Stat provides number of people who either agree, disagree, or are in the middle category across time span.
## Stat is calculated for five different times spans (Wave-to-Wave). Coding:
## 1=Unstable
## 2=Stable Populists/Stable Non-Populists/Stable middle category

## W5-W8
df_GLES17$StablePop_V2_W2W_W5W8 <- 1
#Populists
df_GLES17$StablePop_V2_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5<3 &
                                            df_GLES17$Populism_Cat_V1_W8<3,2,df_GLES17$StablePop_V2_W2W_W5W8)
#Non-Populists
df_GLES17$StablePop_V2_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5>3 &
                                            df_GLES17$Populism_Cat_V1_W8>3,2,df_GLES17$StablePop_V2_W2W_W5W8)
#Middle category
df_GLES17$StablePop_V2_W2W_W5W8 <- ifelse(df_GLES17$Populism_Cat_V1_W5==3 &
                                            df_GLES17$Populism_Cat_V1_W8==3,2,df_GLES17$StablePop_V2_W2W_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W2W_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W5) | 
                                            is.na(df_GLES17$Populism_Cat_V1_W8),NA,df_GLES17$StablePop_V2_W2W_W5W8)

## W8-W9
df_GLES17$StablePop_V2_W2W_W8W9 <- 1
#Populists
df_GLES17$StablePop_V2_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8<3 &
                                            df_GLES17$Populism_Cat_V1_W9<3,2,df_GLES17$StablePop_V2_W2W_W8W9)
#Non-Populists
df_GLES17$StablePop_V2_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8>3 &
                                            df_GLES17$Populism_Cat_V1_W9>3,2,df_GLES17$StablePop_V2_W2W_W8W9)
#Middle Category
df_GLES17$StablePop_V2_W2W_W8W9 <- ifelse(df_GLES17$Populism_Cat_V1_W8==3 &
                                            df_GLES17$Populism_Cat_V1_W9==3,2,df_GLES17$StablePop_V2_W2W_W8W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W2W_W8W9 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W8) | 
                                            is.na(df_GLES17$Populism_Cat_V1_W9),NA,df_GLES17$StablePop_V2_W2W_W8W9)

## W9-W13
df_GLES17$StablePop_V2_W2W_W9W13 <- 1
#Populists
df_GLES17$StablePop_V2_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9<3 &
                                             df_GLES17$Populism_Cat_V1_W13<3,2,df_GLES17$StablePop_V2_W2W_W9W13)
#Non-Populists
df_GLES17$StablePop_V2_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9>3 &
                                             df_GLES17$Populism_Cat_V1_W13>3,2,df_GLES17$StablePop_V2_W2W_W9W13)
#Middle Category
df_GLES17$StablePop_V2_W2W_W9W13 <- ifelse(df_GLES17$Populism_Cat_V1_W9==3 &
                                             df_GLES17$Populism_Cat_V1_W13==3,2,df_GLES17$StablePop_V2_W2W_W9W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W2W_W9W13 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W9) | 
                                             is.na(df_GLES17$Populism_Cat_V1_W13),NA,df_GLES17$StablePop_V2_W2W_W9W13)

## W13-W14
df_GLES17$StablePop_V2_W2W_W13W14 <- 1
#Populists
df_GLES17$StablePop_V2_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13<3 &
                                              df_GLES17$Populism_Cat_V1_W14<3,2,df_GLES17$StablePop_V2_W2W_W13W14)
#Non-Populists
df_GLES17$StablePop_V2_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13>3 &
                                              df_GLES17$Populism_Cat_V1_W14>3,2,df_GLES17$StablePop_V2_W2W_W13W14)
#Middle Category
df_GLES17$StablePop_V2_W2W_W13W14 <- ifelse(df_GLES17$Populism_Cat_V1_W13==3 &
                                              df_GLES17$Populism_Cat_V1_W14==3,2,df_GLES17$StablePop_V2_W2W_W13W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W2W_W13W14 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W13) | 
                                              is.na(df_GLES17$Populism_Cat_V1_W14),NA,df_GLES17$StablePop_V2_W2W_W13W14)

## W14-W15
df_GLES17$StablePop_V2_W2W_W14W15 <- 1
#Populists
df_GLES17$StablePop_V2_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14<3 &
                                              df_GLES17$Populism_Cat_V1_W15<3,2,df_GLES17$StablePop_V2_W2W_W14W15)
#Non-Populists
df_GLES17$StablePop_V2_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14>3 &
                                              df_GLES17$Populism_Cat_V1_W15>3,2,df_GLES17$StablePop_V2_W2W_W14W15)
#Middle Category
df_GLES17$StablePop_V2_W2W_W14W15 <- ifelse(df_GLES17$Populism_Cat_V1_W14==3 &
                                              df_GLES17$Populism_Cat_V1_W15==3,2,df_GLES17$StablePop_V2_W2W_W14W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_V2_W2W_W14W15 <- ifelse(is.na(df_GLES17$Populism_Cat_V1_W14) | 
                                              is.na(df_GLES17$Populism_Cat_V1_W15),NA,df_GLES17$StablePop_V2_W2W_W14W15)

############################################################################################################/
#### >>>Variable (main):  stable populists & non-populists (Wave5-Wave t; Goertz Two Dimensions) ####
###########################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). The code is based on the recategorized
## minimal populism score variable (Goertz Minimum) based on two dimensions.
## Coding:
## 1=Other
## 2=Stable Populists
## 3=Stable Non-Populists
## 4=Middle category

## W5-W8
df_GLES17$StablePop_TwoDim_W5W8 <- 1
#Populists
df_GLES17$StablePop_TwoDim_W5W8 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5<3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8<3,2,df_GLES17$StablePop_TwoDim_W5W8)
#Non-Populists
df_GLES17$StablePop_TwoDim_W5W8 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5>3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8>3,3,df_GLES17$StablePop_TwoDim_W5W8)
#Middle
df_GLES17$StablePop_TwoDim_W5W8 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5==3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8==3,4,df_GLES17$StablePop_TwoDim_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_TwoDim_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_TwoDim_V1_W5) | 
                                            is.na(df_GLES17$Populism_Cat_TwoDim_V1_W8),NA,df_GLES17$StablePop_TwoDim_W5W8)

## W5-W9
df_GLES17$StablePop_TwoDim_W5W9 <- 1
#Populists
df_GLES17$StablePop_TwoDim_W5W9 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5<3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8<3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W9<3,2,df_GLES17$StablePop_TwoDim_W5W9)
#Non-Populists
df_GLES17$StablePop_TwoDim_W5W9 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5>3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8>3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W9>3,3,df_GLES17$StablePop_TwoDim_W5W9)
#Middle
df_GLES17$StablePop_TwoDim_W5W9 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5==3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W8==3 &
                                            df_GLES17$Populism_Cat_TwoDim_V1_W9==3,4,df_GLES17$StablePop_TwoDim_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_TwoDim_W5W9 <- ifelse(is.na(df_GLES17$Populism_Cat_TwoDim_V1_W5) | 
                                            is.na(df_GLES17$Populism_Cat_TwoDim_V1_W8) | 
                                            is.na(df_GLES17$Populism_Cat_TwoDim_V1_W9),NA,df_GLES17$StablePop_TwoDim_W5W9)

## W5-W13
df_GLES17$StablePop_TwoDim_W5W13 <- 1
#Populists
df_GLES17$StablePop_TwoDim_W5W13 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13<3,2,df_GLES17$StablePop_TwoDim_W5W13)
#Non-Populists
df_GLES17$StablePop_TwoDim_W5W13 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13>3,3,df_GLES17$StablePop_TwoDim_W5W13)
#Middle
df_GLES17$StablePop_TwoDim_W5W13 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13==3,4,df_GLES17$StablePop_TwoDim_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_TwoDim_W5W13 <- ifelse(is.na(df_GLES17$Populism_Cat_TwoDim_V1_W5) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W8) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W9)| 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W13),NA,df_GLES17$StablePop_TwoDim_W5W13)

## W5-W14
df_GLES17$StablePop_TwoDim_W5W14 <- 1
#Populists
df_GLES17$StablePop_TwoDim_W5W14 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14<3,2,df_GLES17$StablePop_TwoDim_W5W14)
#Non-Populists
df_GLES17$StablePop_TwoDim_W5W14 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14>3,3,df_GLES17$StablePop_TwoDim_W5W14)
#Middle
df_GLES17$StablePop_TwoDim_W5W14 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14==3,4,df_GLES17$StablePop_TwoDim_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_TwoDim_W5W14 <- ifelse(is.na(df_GLES17$Populism_Cat_TwoDim_V1_W5) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W8) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W9) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W13) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W14),NA,df_GLES17$StablePop_TwoDim_W5W14)

## W5-W15
df_GLES17$StablePop_TwoDim_W5W15 <- 1
#Populists
df_GLES17$StablePop_TwoDim_W5W15 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14<3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W15<3,2,df_GLES17$StablePop_TwoDim_W5W15)
#Non-Populists
df_GLES17$StablePop_TwoDim_W5W15 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14>3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W15>3,3,df_GLES17$StablePop_TwoDim_W5W15)
#Middle
df_GLES17$StablePop_TwoDim_W5W15 <- ifelse(df_GLES17$Populism_Cat_TwoDim_V1_W5==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W8==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W9==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W13==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W14==3 &
                                             df_GLES17$Populism_Cat_TwoDim_V1_W15==3,4,df_GLES17$StablePop_TwoDim_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_TwoDim_W5W15 <- ifelse(is.na(df_GLES17$Populism_Cat_TwoDim_V1_W5) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W8) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W9) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W13) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W14) | 
                                             is.na(df_GLES17$Populism_Cat_TwoDim_V1_W15),NA,df_GLES17$StablePop_TwoDim_W5W15)


############################################################################################################/
#### >>>Variable (main): stable populists & non-populists (Wave5-Wave t; Goertz Multiplied Score) ####
###########################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). The code is based on the re categorized
## minimal populism score variable (Goertz Multiplied) based on two dimensions.
## Coding:
## 1=Other
## 2=Stable Populists
## 3=Stable Non-Populists
## 4=Middle

## W5-W8
df_GLES17$StablePop_Mult_W5W8 <- 1
#Populists
df_GLES17$StablePop_Mult_W5W8 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5<3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8<3,2,df_GLES17$StablePop_Mult_W5W8)
#Non-Populists
df_GLES17$StablePop_Mult_W5W8 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5>3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8>3,3,df_GLES17$StablePop_Mult_W5W8)
#Middle
df_GLES17$StablePop_Mult_W5W8 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5==3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8==3,3,df_GLES17$StablePop_Mult_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Mult_W5W8 <- ifelse(is.na(df_GLES17$Populism_Cat_Mult_V1_W5) | 
                                          is.na(df_GLES17$Populism_Cat_Mult_V1_W8),NA,df_GLES17$StablePop_Mult_W5W8)

## W5-W9
df_GLES17$StablePop_Mult_W5W9 <- 1
#Populists
df_GLES17$StablePop_Mult_W5W9 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5<3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8<3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W9<3,2,df_GLES17$StablePop_Mult_W5W9)
#Non-Populists
df_GLES17$StablePop_Mult_W5W9 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5>3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8>3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W9>3,3,df_GLES17$StablePop_Mult_W5W9)
#Middle
df_GLES17$StablePop_Mult_W5W9 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5==3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W8==3 &
                                          df_GLES17$Populism_Cat_Mult_V1_W9==3,3,df_GLES17$StablePop_Mult_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Mult_W5W9 <- ifelse(is.na(df_GLES17$Populism_Cat_Mult_V1_W5) | 
                                          is.na(df_GLES17$Populism_Cat_Mult_V1_W8) | 
                                          is.na(df_GLES17$Populism_Cat_Mult_V1_W9),NA,df_GLES17$StablePop_Mult_W5W9)

## W5-W13
df_GLES17$StablePop_Mult_W5W13 <- 1
#Populists
df_GLES17$StablePop_Mult_W5W13 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13<3,2,df_GLES17$StablePop_Mult_W5W13)
#Non-Populists
df_GLES17$StablePop_Mult_W5W13 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13>3,3,df_GLES17$StablePop_Mult_W5W13)
#Middle
df_GLES17$StablePop_Mult_W5W13 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13==3,3,df_GLES17$StablePop_Mult_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Mult_W5W13 <- ifelse(is.na(df_GLES17$Populism_Cat_Mult_V1_W5) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W8) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W9)| 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W13),NA,df_GLES17$StablePop_Mult_W5W13)

## W5-W14
df_GLES17$StablePop_Mult_W5W14 <- 1
#Populists
df_GLES17$StablePop_Mult_W5W14 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14<3,2,df_GLES17$StablePop_Mult_W5W14)
#Non-Populists
df_GLES17$StablePop_Mult_W5W14 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14>3,3,df_GLES17$StablePop_Mult_W5W14)
#Middle
df_GLES17$StablePop_Mult_W5W14 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14==3,3,df_GLES17$StablePop_Mult_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Mult_W5W14 <- ifelse(is.na(df_GLES17$Populism_Cat_Mult_V1_W5) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W8) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W9) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W13) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W14),NA,df_GLES17$StablePop_Mult_W5W14)

## W5-W15
df_GLES17$StablePop_Mult_W5W15 <- 1
#Populists
df_GLES17$StablePop_Mult_W5W15 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14<3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W15<3,2,df_GLES17$StablePop_Mult_W5W15)
#Non-Populists
df_GLES17$StablePop_Mult_W5W15 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14>3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W15>3,3,df_GLES17$StablePop_Mult_W5W15)
#Middle
df_GLES17$StablePop_Mult_W5W15 <- ifelse(df_GLES17$Populism_Cat_Mult_V1_W5==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W8==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W9==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W13==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W14==3 &
                                           df_GLES17$Populism_Cat_Mult_V1_W15==3,3,df_GLES17$StablePop_Mult_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Mult_W5W15 <- ifelse(is.na(df_GLES17$Populism_Cat_Mult_V1_W5) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W8) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W9) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W13) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W14) | 
                                           is.na(df_GLES17$Populism_Cat_Mult_V1_W15),NA,df_GLES17$StablePop_Mult_W5W15)

###############################################################################################/
#### >>> Variable (main): capturing stable anti-elitists & non-anti-elitists (Wave5-Wave t) ####
###############################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Stable Anti-Elitists
## 3=Stable Non-Anti-Elitists
## 4=Stable Middle Category

## W5-W8
df_GLES17$StableAntiElite_W5W8 <- 1
#Populists
df_GLES17$StableAntiElite_W5W8 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8<3,2,df_GLES17$StableAntiElite_W5W8)
#Non-Populists
df_GLES17$StableAntiElite_W5W8 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8>3,3,df_GLES17$StableAntiElite_W5W8)
#Middle
df_GLES17$StableAntiElite_W5W8 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5==3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8==3,4,df_GLES17$StableAntiElite_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StableAntiElite_W5W8 <- ifelse(is.na(df_GLES17$Anti_Elitism_Cat_V1_W5) | 
                                           is.na(df_GLES17$Anti_Elitism_Cat_V1_W8),NA,df_GLES17$StableAntiElite_W5W8)

## W5-W9
df_GLES17$StableAntiElite_W5W9 <- 1
#Populists
df_GLES17$StableAntiElite_W5W9 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8<3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W9<3,2,df_GLES17$StableAntiElite_W5W9)
#Non-Populists
df_GLES17$StableAntiElite_W5W9 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8>3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W9>3,3,df_GLES17$StableAntiElite_W5W9)
#Middle
df_GLES17$StableAntiElite_W5W9 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5==3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W8==3 &
                                           df_GLES17$Anti_Elitism_Cat_V1_W9==3,4,df_GLES17$StableAntiElite_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StableAntiElite_W5W9 <- ifelse(is.na(df_GLES17$Anti_Elitism_Cat_V1_W5) | 
                                           is.na(df_GLES17$Anti_Elitism_Cat_V1_W8) | 
                                           is.na(df_GLES17$Anti_Elitism_Cat_V1_W9),NA,df_GLES17$StableAntiElite_W5W9)

## W5-W13
df_GLES17$StableAntiElite_W5W13 <- 1
#Populists
df_GLES17$StableAntiElite_W5W13 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13<3,2,df_GLES17$StableAntiElite_W5W13)
#Non-Populists
df_GLES17$StableAntiElite_W5W13 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13>3,3,df_GLES17$StableAntiElite_W5W13)
#Middle
df_GLES17$StableAntiElite_W5W13 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13==3,4,df_GLES17$StableAntiElite_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StableAntiElite_W5W13 <- ifelse(is.na(df_GLES17$Anti_Elitism_Cat_V1_W5) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W8) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W9)| 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W13),NA,df_GLES17$StableAntiElite_W5W13)

## W5-W14
df_GLES17$StableAntiElite_W5W14 <- 1
#Populists
df_GLES17$StableAntiElite_W5W14 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14<3,2,df_GLES17$StableAntiElite_W5W14)
#Non-Populists
df_GLES17$StableAntiElite_W5W14 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14>3,3,df_GLES17$StableAntiElite_W5W14)
#Middle
df_GLES17$StableAntiElite_W5W14 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14==3,4,df_GLES17$StableAntiElite_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StableAntiElite_W5W14 <- ifelse(is.na(df_GLES17$Anti_Elitism_Cat_V1_W5) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W8) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W9) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W13) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W14),NA,df_GLES17$StableAntiElite_W5W14)

## W5-W15
df_GLES17$StableAntiElite_W5W15 <- 1
#Populists
df_GLES17$StableAntiElite_W5W15 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14<3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W15<3,2,df_GLES17$StableAntiElite_W5W15)
#Non-Populists
df_GLES17$StableAntiElite_W5W15 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14>3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W15>3,3,df_GLES17$StableAntiElite_W5W15)
#Middle
df_GLES17$StableAntiElite_W5W15 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W8==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W9==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W13==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W14==3 &
                                            df_GLES17$Anti_Elitism_Cat_V1_W15==3,4,df_GLES17$StableAntiElite_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StableAntiElite_W5W15 <- ifelse(is.na(df_GLES17$Anti_Elitism_Cat_V1_W5) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W8) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W9) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W13) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W14) | 
                                            is.na(df_GLES17$Anti_Elitism_Cat_V1_W15),NA,df_GLES17$StableAntiElite_W5W15)

#####################################################################################################/
#### >>> Variable (main): stable people-sovereigntists & non-people-sovereigntists (Wave5-Wave t) ####
#####################################################################################################/

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Stable people-sovereigntists
## 3=Stable Non-people-sovereigntists
## 4=Stable middle category

## W5-W8
df_GLES17$Stable_PeopleSov_W5W8 <- 1
#sovereigntists
df_GLES17$Stable_PeopleSov_W5W8 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8<3,2,df_GLES17$Stable_PeopleSov_W5W8)
#Non-sovereigntists
df_GLES17$Stable_PeopleSov_W5W8 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8>3,3,df_GLES17$Stable_PeopleSov_W5W8)
#Middle
df_GLES17$Stable_PeopleSov_W5W8 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5==3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8==3,4,df_GLES17$Stable_PeopleSov_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_PeopleSov_W5W8 <- ifelse(is.na(df_GLES17$Sovereignty_Cat_V1_W5) | 
                                            is.na(df_GLES17$Sovereignty_Cat_V1_W8),NA,df_GLES17$Stable_PeopleSov_W5W8)

## W5-W9
df_GLES17$Stable_PeopleSov_W5W9 <- 1
#sovereigntists
df_GLES17$Stable_PeopleSov_W5W9 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                            df_GLES17$Sovereignty_Cat_V1_W9<3,2,df_GLES17$Stable_PeopleSov_W5W9)
#Non-sovereigntists
df_GLES17$Stable_PeopleSov_W5W9 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                            df_GLES17$Sovereignty_Cat_V1_W9>3,3,df_GLES17$Stable_PeopleSov_W5W9)
#Middle
df_GLES17$Stable_PeopleSov_W5W9 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5==3 &
                                            df_GLES17$Sovereignty_Cat_V1_W8==3 &
                                            df_GLES17$Sovereignty_Cat_V1_W9==3,4,df_GLES17$Stable_PeopleSov_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_PeopleSov_W5W9 <- ifelse(is.na(df_GLES17$Sovereignty_Cat_V1_W5) | 
                                            is.na(df_GLES17$Sovereignty_Cat_V1_W8) | 
                                            is.na(df_GLES17$Sovereignty_Cat_V1_W9),NA,df_GLES17$Stable_PeopleSov_W5W9)

## W5-W13
df_GLES17$Stable_PeopleSov_W5W13 <- 1
#sovereigntists
df_GLES17$Stable_PeopleSov_W5W13 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13<3,2,df_GLES17$Stable_PeopleSov_W5W13)
#Non-sovereigntists
df_GLES17$Stable_PeopleSov_W5W13 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13>3,3,df_GLES17$Stable_PeopleSov_W5W13)
#Middle
df_GLES17$Stable_PeopleSov_W5W13 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13==3,4,df_GLES17$Stable_PeopleSov_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_PeopleSov_W5W13 <- ifelse(is.na(df_GLES17$Sovereignty_Cat_V1_W5) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W8) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W9)| 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W13),NA,df_GLES17$Stable_PeopleSov_W5W13)

## W5-W14
df_GLES17$Stable_PeopleSov_W5W14 <- 1
#sovereigntists
df_GLES17$Stable_PeopleSov_W5W14 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14<3,2,df_GLES17$Stable_PeopleSov_W5W14)
#Non-sovereigntists
df_GLES17$Stable_PeopleSov_W5W14 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14>3,3,df_GLES17$Stable_PeopleSov_W5W14)
#Middle
df_GLES17$Stable_PeopleSov_W5W14 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14==3,4,df_GLES17$Stable_PeopleSov_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_PeopleSov_W5W14 <- ifelse(is.na(df_GLES17$Sovereignty_Cat_V1_W5) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W8) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W9) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W13) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W14),NA,df_GLES17$Stable_PeopleSov_W5W14)

## W5-W15
df_GLES17$Stable_PeopleSov_W5W15 <- 1
#sovereigntists
df_GLES17$Stable_PeopleSov_W5W15 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14<3 &
                                             df_GLES17$Sovereignty_Cat_V1_W15<3,2,df_GLES17$Stable_PeopleSov_W5W15)
#Non-sovereigntists
df_GLES17$Stable_PeopleSov_W5W15 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14>3 &
                                             df_GLES17$Sovereignty_Cat_V1_W15>3,3,df_GLES17$Stable_PeopleSov_W5W15)
#Middle
df_GLES17$Stable_PeopleSov_W5W15 <- ifelse(df_GLES17$Sovereignty_Cat_V1_W5==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W8==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W9==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W13==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W14==3 &
                                             df_GLES17$Sovereignty_Cat_V1_W15==3,4,df_GLES17$Stable_PeopleSov_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_PeopleSov_W5W15 <- ifelse(is.na(df_GLES17$Sovereignty_Cat_V1_W5) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W8) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W9) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W13) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W14) | 
                                             is.na(df_GLES17$Sovereignty_Cat_V1_W15),NA,df_GLES17$Stable_PeopleSov_W5W15)

#### >>> Coding variables capturing stable homogeneity & non-homogeneity (Wave5-Wave t) ####

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Stable homogeneity
## 3=Stable Non-homogeneity
## 4=Stable middle category

## W5-W8
df_GLES17$Stable_Homogeneity_W5W8 <- 1
#homogeneity
df_GLES17$Stable_Homogeneity_W5W8 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8<3,2,df_GLES17$Stable_Homogeneity_W5W8)
#Non-homogeneity
df_GLES17$Stable_Homogeneity_W5W8 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8>3,3,df_GLES17$Stable_Homogeneity_W5W8)
#Middle category
df_GLES17$Stable_Homogeneity_W5W8 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5==3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8==3,4,df_GLES17$Stable_Homogeneity_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_Homogeneity_W5W8 <- ifelse(is.na(df_GLES17$Homogeneity_Cat_V1_W5) | 
                                              is.na(df_GLES17$Homogeneity_Cat_V1_W8),NA,df_GLES17$Stable_Homogeneity_W5W8)

## W5-W9
df_GLES17$Stable_Homogeneity_W5W9 <- 1
#homogeneity
df_GLES17$Stable_Homogeneity_W5W9 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                              df_GLES17$Homogeneity_Cat_V1_W9<3,2,df_GLES17$Stable_Homogeneity_W5W9)
#Non-homogeneity
df_GLES17$Stable_Homogeneity_W5W9 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                              df_GLES17$Homogeneity_Cat_V1_W9>3,3,df_GLES17$Stable_Homogeneity_W5W9)
#middle
df_GLES17$Stable_Homogeneity_W5W9 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5==3 &
                                              df_GLES17$Homogeneity_Cat_V1_W8==3 &
                                              df_GLES17$Homogeneity_Cat_V1_W9==3,4,df_GLES17$Stable_Homogeneity_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_Homogeneity_W5W9 <- ifelse(is.na(df_GLES17$Homogeneity_Cat_V1_W5) | 
                                              is.na(df_GLES17$Homogeneity_Cat_V1_W8) | 
                                              is.na(df_GLES17$Homogeneity_Cat_V1_W9),NA,df_GLES17$Stable_Homogeneity_W5W9)

## W5-W13
df_GLES17$Stable_Homogeneity_W5W13 <- 1
#homogeneity
df_GLES17$Stable_Homogeneity_W5W13 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13<3,2,df_GLES17$Stable_Homogeneity_W5W13)
#Non-homogeneity
df_GLES17$Stable_Homogeneity_W5W13 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13>3,3,df_GLES17$Stable_Homogeneity_W5W13)
#middle
df_GLES17$Stable_Homogeneity_W5W13 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13==3,4,df_GLES17$Stable_Homogeneity_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_Homogeneity_W5W13 <- ifelse(is.na(df_GLES17$Homogeneity_Cat_V1_W5) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W8) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W9)| 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W13),NA,df_GLES17$Stable_Homogeneity_W5W13)

## W5-W14
df_GLES17$Stable_Homogeneity_W5W14 <- 1
#homogeneity
df_GLES17$Stable_Homogeneity_W5W14 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14<3,2,df_GLES17$Stable_Homogeneity_W5W14)
#Non-homogeneity
df_GLES17$Stable_Homogeneity_W5W14 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14>3,3,df_GLES17$Stable_Homogeneity_W5W14)
#middle
df_GLES17$Stable_Homogeneity_W5W14 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14==3,4,df_GLES17$Stable_Homogeneity_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_Homogeneity_W5W14 <- ifelse(is.na(df_GLES17$Homogeneity_Cat_V1_W5) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W8) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W9) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W13) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W14),NA,df_GLES17$Stable_Homogeneity_W5W14)

## W5-W15
df_GLES17$Stable_Homogeneity_W5W15 <- 1
#homogeneity
df_GLES17$Stable_Homogeneity_W5W15 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14<3 &
                                               df_GLES17$Homogeneity_Cat_V1_W15<3,2,df_GLES17$Stable_Homogeneity_W5W15)
#Non-homogeneity
df_GLES17$Stable_Homogeneity_W5W15 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14>3 &
                                               df_GLES17$Homogeneity_Cat_V1_W15>3,3,df_GLES17$Stable_Homogeneity_W5W15)
#middle
df_GLES17$Stable_Homogeneity_W5W15 <- ifelse(df_GLES17$Homogeneity_Cat_V1_W5==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W8==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W9==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W13==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W14==3 &
                                               df_GLES17$Homogeneity_Cat_V1_W15==3,4,df_GLES17$Stable_Homogeneity_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$Stable_Homogeneity_W5W15 <- ifelse(is.na(df_GLES17$Homogeneity_Cat_V1_W5) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W8) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W9) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W13) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W14) | 
                                               is.na(df_GLES17$Homogeneity_Cat_V1_W15),NA,df_GLES17$Stable_Homogeneity_W5W15)



#### >>> Alternative Code - variables capturing stable populists & non-populists (Wave5-Wave t) ####

## Stat provides number of people who either agree or disagree across time span.
## Stat is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Unlike the primary code, which is based on 
## the recategorized minimal populism score variable (Goertz Minimum), this coding
## starts from the individual dimensions. For example, a respondent is coded as 
## a stable populist between two waves when the respondent agrees on all three
## dimensions AND does so in both waves. Coding:
## 1=Other, incl. (Stable Mixture (e.g., respondents who consistently disagree with 
##     popular sovereignty but also consistently agree with anti-elitism and homogeneity))
## 2=Stable Populists
## 3=Stable Non-Populists

## W5-W8
df_GLES17$StablePop_Alt_W5W8 <- 1
#Populists
df_GLES17$StablePop_Alt_W5W8 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                         df_GLES17$Anti_Elitism_Cat_V1_W8<3 & 
                                         df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                         df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                         df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                         df_GLES17$Homogeneity_Cat_V1_W8<3 ,2,df_GLES17$StablePop_Alt_W5W8)
#Non-Populists
df_GLES17$StablePop_Alt_W5W8 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                         df_GLES17$Anti_Elitism_Cat_V1_W8>3 & 
                                         df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                         df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                         df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                         df_GLES17$Homogeneity_Cat_V1_W8>3,3,df_GLES17$StablePop_Alt_W5W8)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Alt_W5W8 <- ifelse(is.na(df_GLES17$StablePop_W5W8),NA,df_GLES17$StablePop_Alt_W5W8)

## W5-W9
df_GLES17$StablePop_Alt_W5W9 <- 1
#Populists
df_GLES17$StablePop_Alt_W5W9 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                         df_GLES17$Anti_Elitism_Cat_V1_W8<3 & 
                                         df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                         df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                         df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                         df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                         df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                         df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                         df_GLES17$Homogeneity_Cat_V1_W9<3,2,df_GLES17$StablePop_Alt_W5W9)
#Non-Populists
df_GLES17$StablePop_Alt_W5W9 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                         df_GLES17$Anti_Elitism_Cat_V1_W8>3 & 
                                         df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                         df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                         df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                         df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                         df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                         df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                         df_GLES17$Homogeneity_Cat_V1_W9>3,3,df_GLES17$StablePop_Alt_W5W9)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Alt_W5W9 <- ifelse(is.na(df_GLES17$StablePop_W5W9),NA,df_GLES17$StablePop_Alt_W5W9)

## W5-W13
df_GLES17$StablePop_Alt_W5W13 <- 1
#Populists
df_GLES17$StablePop_Alt_W5W13 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8<3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13<3,2,df_GLES17$StablePop_Alt_W5W13)
#Non-Populists
df_GLES17$StablePop_Alt_W5W13 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8>3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13>3,3,df_GLES17$StablePop_Alt_W5W13)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Alt_W5W13 <- ifelse(is.na(df_GLES17$StablePop_W5W13),NA,df_GLES17$StablePop_Alt_W5W13)

## W5-W14
df_GLES17$StablePop_Alt_W5W14 <- 1
#Populists
df_GLES17$StablePop_Alt_W5W14 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8<3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W14<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W14<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W14<3,2,df_GLES17$StablePop_Alt_W5W14)
#Non-Populists
df_GLES17$StablePop_Alt_W5W14 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8>3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W14>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W14>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W14>3,3,df_GLES17$StablePop_Alt_W5W14)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Alt_W5W14 <- ifelse(is.na(df_GLES17$StablePop_W5W14),NA,df_GLES17$StablePop_Alt_W5W14)


## W5-W15
df_GLES17$StablePop_Alt_W5W15 <- 1
#Populists
df_GLES17$StablePop_Alt_W5W15 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8<3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W14<3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W15<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W14<3 &
                                          df_GLES17$Sovereignty_Cat_V1_W15<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W14<3 &
                                          df_GLES17$Homogeneity_Cat_V1_W15<3,2,df_GLES17$StablePop_Alt_W5W15)
#Non-Populists
df_GLES17$StablePop_Alt_W5W15 <- ifelse(df_GLES17$Anti_Elitism_Cat_V1_W5>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W8>3 & 
                                          df_GLES17$Anti_Elitism_Cat_V1_W9>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W13>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W14>3 &
                                          df_GLES17$Anti_Elitism_Cat_V1_W15>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W5>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W8>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W9>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W13>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W14>3 &
                                          df_GLES17$Sovereignty_Cat_V1_W15>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W5>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W8>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W9>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W13>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W14>3 &
                                          df_GLES17$Homogeneity_Cat_V1_W15>3,3,df_GLES17$StablePop_Alt_W5W15)
#Code all those with missing values on either of the populism variables as missing:
df_GLES17$StablePop_Alt_W5W15 <- ifelse(is.na(df_GLES17$StablePop_W5W15),NA,df_GLES17$StablePop_Alt_W5W15)




#### >>> Covariates for Sub-Group Test ####

#### <<<>>> Age-Group ####

## Based on CSES categories
#01. YOUNGEST - 24 YEARS  
#02.       25 - 34 YEARS  
#03.       35 - 44 YEARS
#04.       45 - 54 YEARS  
#05.       55 - OLDEST
# (Note: CSES has one additional category with "55-64". However, we only have year of year of birth available with detailed year going 
# back to 1955. GLES has single category "1955 or before" for variable" year of birth".)

# Convert year of birth variable
df_GLES17$YoB <- as.numeric(df_GLES17$kpx_2290)

# Gen age variable
df_GLES17$Age <- 2017-df_GLES17$YoB
df_GLES17$Age[df_GLES17$kpx_2290s=="1955 und frueher"] <- 62

# gen age cat variable
df_GLES17$Age_Cat <- NA
df_GLES17$Age_Cat[df_GLES17$Age<25] <- 1
df_GLES17$Age_Cat[df_GLES17$Age>24 & df_GLES17$Age<35] <- 2
df_GLES17$Age_Cat[df_GLES17$Age>34 & df_GLES17$Age<45] <- 3
df_GLES17$Age_Cat[df_GLES17$Age>44 & df_GLES17$Age<55] <- 4
df_GLES17$Age_Cat[df_GLES17$Age>54 ] <- 5
df_GLES17$Age_Cat <- as.factor(df_GLES17$Age_Cat)
levels(df_GLES17$Age_Cat) <- c("24 or younger", "25-34", "35-44", "45-54"," 55 or older")


#### <<<>>> Education Level ####

# Respondents are assigned to one of two categories:
# 0. No University (or comparable education) completed
# 1. University education completed (includes respondents who have "Fachhochschulabschluss" (University of
# Applied Science Degree) and "Hochschulabschluss" (University Degree)).

#Note: Some respondents were included in sample between waves 3 and 4. Hence, there are two distinct
# education variables. One for respondents included in the begining (kp1_2330) and one for respondents
# who were added to the panel later on (kpa1_2330)

df_GLES17$Uni_Edu <- 0
df_GLES17$Uni_Edu[df_GLES17$kp1_2330=="Fachhochschulabschluss" | df_GLES17$kp1_2330=="Hochschulabschluss"] <- 1
df_GLES17$Uni_Edu[df_GLES17$kpa1_2330=="Fachhochschulabschluss" | df_GLES17$kpa1_2330=="Hochschulabschluss"] <- 1
df_GLES17$Uni_Edu[df_GLES17$kp1_2330=="keine Angabe"] <- NA
df_GLES17$Uni_Edu[df_GLES17$kpa1_2330=="keine Angabe"] <- NA
df_GLES17$Uni_Edu <- as.factor(df_GLES17$Uni_Edu)
levels(df_GLES17$Uni_Edu) <- c("No University Degree", "University Degree")

#### <<<>>> Partisanship ####

# Recode respondents one of the following groups:
# 0 = Non-Partisan
# 1 = Partisan

#Sample A component
df_GLES17$PiD_A <- NA
df_GLES17$PiD_A <- ifelse(df_GLES17$kp4_2090a=="keine Partei",0,1)
df_GLES17$PiD_A <- ifelse(df_GLES17$kp4_2090a=="Interview abgebrochen" |
                            df_GLES17$kp4_2090a=="nicht teilgenommen" |
                            df_GLES17$kp4_2090a=="keine Angabe"  ,NA,df_GLES17$PiD_A)
#Sample A1 component
df_GLES17$PiD_A1 <- NA
df_GLES17$PiD_A1 <- ifelse(df_GLES17$kpa1_2090a=="keine Partei",0,1)
df_GLES17$PiD_A1 <- ifelse(df_GLES17$kpa1_2090a=="Interview abgebrochen" |
                             df_GLES17$kpa1_2090a=="nicht teilgenommen" |
                             df_GLES17$kpa1_2090a=="keine Angabe"  ,NA,df_GLES17$PiD_A1)

# Combined PiD
df_GLES17$PiD <- df_GLES17$PiD_A
df_GLES17$PiD[df_GLES17$PiD_A1==0] <- 0
df_GLES17$PiD[df_GLES17$PiD_A1==1] <- 1
df_GLES17$PiD <- as.factor(df_GLES17$PiD)
levels(df_GLES17$PiD) <- c("Non-Partisan", "Partisan")

#### <<<>>> Election  2017 - Turnout ####

# Recode respondents one of the following groups:
# 0 = Did not vote
# 1 = Did vote
# Note: variable only available for Sample A component

df_GLES17$Turnout <- NA
df_GLES17$Turnout[df_GLES17$kp8_180=="habe nicht gewaehlt"] <- 0
df_GLES17$Turnout[df_GLES17$kp8_180=="hatte bereits Briefwahl gemacht"] <- 1 #include mail voters
df_GLES17$Turnout[df_GLES17$kp8_180=="gewaehlt"] <- 1
df_GLES17$Turnout <- as.factor(df_GLES17$Turnout)
levels(df_GLES17$Turnout) <- c("Non-Voter", "Voter")

#### <<<>>> Extremity of Populist Attitudes ####

## measures whether people hold extreme point attitudes (<2 or =5) during the
## first panel wave for which we measure populist attitudes.
# Coding:
# 0=not extreme
# 1=extreme

df_GLES17$Populism_Extremity_W5 <- NA
df_GLES17$Populism_Extremity_W5 <- ifelse(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5<2 |
                                            df_GLES17$Populism_Goertz_AbsoluteMinimum_W5==5,
                                          1,0)

#### <<<>>> Electoral beahviour Election 2017 - Zweitstimme ####

# This variable contains information about peoples' list vote, combining both
# mail and in-person voting. Coding:
# 1 - CDU/CSU (Christlich Demokratische Union/Christlich-Soziale Union)
# 2 - SPD (Sozialdemokratische Partei Deutschlands)
# 3 - FDP (Freie Demokratische Partei)
# 4 - B�ndnis 90/Die Gr�nen
# 5 - Die Linke
# 6 - AfD (Alternative f�r Deutschland)
# 7 - Andere Partei

## Variables measured in Waves 5 (mail voting) and Wave 8 (in-person voting)
df_GLES17$Vote_List_W58 <- NA
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="CDU/CSU" | df_GLES17$kp8_200ba=="CDU/CSU"] <- 1
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="SPD" | df_GLES17$kp8_200ba=="SPD"] <- 2
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="FDP" | df_GLES17$kp8_200ba=="FDP"] <- 3
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="GRUENE" | df_GLES17$kp8_200ba=="GRUENE"] <- 4
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="DIE LINKE" | df_GLES17$kp8_200ba=="DIE LINKE"] <- 5
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="AfD" | df_GLES17$kp8_200ba=="AfD"] <- 6
df_GLES17$Vote_List_W58[df_GLES17$kp5_191ba=="andere Partei" | df_GLES17$kp8_200ba=="andere Partei"] <- 7

## Variables measured in Waves 9
df_GLES17$Vote_List_W9 <- NA
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="CDU/CSU" | df_GLES17$kp9_200ba=="CDU/CSU"] <- 1
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="SPD" | df_GLES17$kp9_200ba=="SPD"] <- 2
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="FDP" | df_GLES17$kp9_200ba=="FDP"] <- 3
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="GRUENE" | df_GLES17$kp9_200ba=="GRUENE"] <- 4
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="DIE LINKE" | df_GLES17$kp9_200ba=="DIE LINKE"] <- 5
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="AfD" | df_GLES17$kp9_200ba=="AfD"] <- 6
df_GLES17$Vote_List_W9[df_GLES17$kp9_191ba=="andere Partei" | df_GLES17$kp9_200ba=="andere Partei"] <- 7


#### <<<>>> Attitudes Towards Democracy ####

# Item 1: Jede demokratische Partei sollte grunds�tzlich die Chance haben, an die Regierung zu kommen. (kpX_050c)
# Item 2: Jeder sollte das Recht haben, f�r seine Meinung einzutreten, auch wenn die Mehrheit anderer Meinung ist. (kpX_050g)
# Item 3: Eine lebensf�hige Demokratie ist ohne politische Opposition nicht denkbar. (kpX_050j)

# Items available for Waves 2/a1 (refreshing sample), 9, 10, 12, 14, and 15. Measures from Wave
# 10 are excluded because item 2 uses entirely different wording.
# Coding:
# 1 - fully disagree
# 2 - disagree
# 3 - neither agree nor disagree
# 4 - agree
# 5 - fully agree

## Item 1 (every party should have the chance to become part of the government)
#W2/a1 
df_GLES17$DemAtt_IT1_W2 <- NA
df_GLES17$DemAtt_IT1_W2[df_GLES17$kp2_050c=="stimme ueberhaupt nicht zu" | df_GLES17$kpa1_050c=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT1_W2[df_GLES17$kp2_050c=="stimme eher nicht zu" | df_GLES17$kpa1_050c=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT1_W2[df_GLES17$kp2_050c=="teils/teils" | df_GLES17$kpa1_050c=="teils/teils"] <- 3
df_GLES17$DemAtt_IT1_W2[df_GLES17$kp2_050c=="stimme eher zu" | df_GLES17$kpa1_050c=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT1_W2[df_GLES17$kp2_050c=="stimme voll und ganz zu" | df_GLES17$kpa1_050c=="stimme voll und ganz zu"] <- 5

#W9
df_GLES17$DemAtt_IT1_W9 <- NA
df_GLES17$DemAtt_IT1_W9[df_GLES17$kp9_050c=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT1_W9[df_GLES17$kp9_050c=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT1_W9[df_GLES17$kp9_050c=="teils/teils"] <- 3
df_GLES17$DemAtt_IT1_W9[df_GLES17$kp9_050c=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT1_W9[df_GLES17$kp9_050c=="stimme voll und ganz zu"] <- 5

#W12
df_GLES17$DemAtt_IT1_W12 <- NA
df_GLES17$DemAtt_IT1_W12[df_GLES17$kp12_050c=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT1_W12[df_GLES17$kp12_050c=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT1_W12[df_GLES17$kp12_050c=="teils/teils"] <- 3
df_GLES17$DemAtt_IT1_W12[df_GLES17$kp12_050c=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT1_W12[df_GLES17$kp12_050c=="stimme voll und ganz zu"] <- 5

#W14
df_GLES17$DemAtt_IT1_W14 <- NA
df_GLES17$DemAtt_IT1_W14[df_GLES17$kp14_050c=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT1_W14[df_GLES17$kp14_050c=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT1_W14[df_GLES17$kp14_050c=="teils/teils"] <- 3
df_GLES17$DemAtt_IT1_W14[df_GLES17$kp14_050c=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT1_W14[df_GLES17$kp14_050c=="stimme voll und ganz zu"] <- 5

#W15
df_GLES17$DemAtt_IT1_W15 <- NA
df_GLES17$DemAtt_IT1_W15[df_GLES17$kp15_050c=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT1_W15[df_GLES17$kp15_050c=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT1_W15[df_GLES17$kp15_050c=="teils/teils"] <- 3
df_GLES17$DemAtt_IT1_W15[df_GLES17$kp15_050c=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT1_W15[df_GLES17$kp15_050c=="stimme voll und ganz zu"] <- 5


## Item 2 (everyone should have the right to stand up for their opinion even if the majority has a different opinion)
#W2/a1 
df_GLES17$DemAtt_IT2_W2 <- NA
df_GLES17$DemAtt_IT2_W2[df_GLES17$kp2_050g=="stimme ueberhaupt nicht zu" | df_GLES17$kpa1_050g=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT2_W2[df_GLES17$kp2_050g=="stimme eher nicht zu" | df_GLES17$kpa1_050g=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT2_W2[df_GLES17$kp2_050g=="teils/teils" | df_GLES17$kpa1_050g=="teils/teils"] <- 3
df_GLES17$DemAtt_IT2_W2[df_GLES17$kp2_050g=="stimme eher zu" | df_GLES17$kpa1_050g=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT2_W2[df_GLES17$kp2_050g=="stimme voll und ganz zu" | df_GLES17$kpa1_050g=="stimme voll und ganz zu"] <- 5

#W9
df_GLES17$DemAtt_IT2_W9 <- NA
df_GLES17$DemAtt_IT2_W9[df_GLES17$kp9_050g=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT2_W9[df_GLES17$kp9_050g=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT2_W9[df_GLES17$kp9_050g=="teils/teils"] <- 3
df_GLES17$DemAtt_IT2_W9[df_GLES17$kp9_050g=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT2_W9[df_GLES17$kp9_050g=="stimme voll und ganz zu"] <- 5

#W12
df_GLES17$DemAtt_IT2_W12 <- NA
df_GLES17$DemAtt_IT2_W12[df_GLES17$kp12_050g=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT2_W12[df_GLES17$kp12_050g=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT2_W12[df_GLES17$kp12_050g=="teils/teils"] <- 3
df_GLES17$DemAtt_IT2_W12[df_GLES17$kp12_050g=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT2_W12[df_GLES17$kp12_050g=="stimme voll und ganz zu"] <- 5

#W14
df_GLES17$DemAtt_IT2_W14 <- NA
df_GLES17$DemAtt_IT2_W14[df_GLES17$kp14_050g=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT2_W14[df_GLES17$kp14_050g=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT2_W14[df_GLES17$kp14_050g=="teils/teils"] <- 3
df_GLES17$DemAtt_IT2_W14[df_GLES17$kp14_050g=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT2_W14[df_GLES17$kp14_050g=="stimme voll und ganz zu"] <- 5

#W15
df_GLES17$DemAtt_IT2_W15 <- NA
df_GLES17$DemAtt_IT2_W15[df_GLES17$kp15_050g=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT2_W15[df_GLES17$kp15_050g=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT2_W15[df_GLES17$kp15_050g=="teils/teils"] <- 3
df_GLES17$DemAtt_IT2_W15[df_GLES17$kp15_050g=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT2_W15[df_GLES17$kp15_050g=="stimme voll und ganz zu"] <- 5


## Item 3 (a vibrant democracy is unthinkable without an opposition)
#W2/a1 
df_GLES17$DemAtt_IT3_W2 <- NA
df_GLES17$DemAtt_IT3_W2[df_GLES17$kp2_050j=="stimme ueberhaupt nicht zu" | df_GLES17$kpa1_050j=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT3_W2[df_GLES17$kp2_050j=="stimme eher nicht zu" | df_GLES17$kpa1_050j=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT3_W2[df_GLES17$kp2_050j=="teils/teils" | df_GLES17$kpa1_050j=="teils/teils"] <- 3
df_GLES17$DemAtt_IT3_W2[df_GLES17$kp2_050j=="stimme eher zu" | df_GLES17$kpa1_050j=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT3_W2[df_GLES17$kp2_050j=="stimme voll und ganz zu" | df_GLES17$kpa1_050j=="stimme voll und ganz zu"] <- 5

#W9
df_GLES17$DemAtt_IT3_W9 <- NA
df_GLES17$DemAtt_IT3_W9[df_GLES17$kp9_050j=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT3_W9[df_GLES17$kp9_050j=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT3_W9[df_GLES17$kp9_050j=="teils/teils"] <- 3
df_GLES17$DemAtt_IT3_W9[df_GLES17$kp9_050j=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT3_W9[df_GLES17$kp9_050j=="stimme voll und ganz zu"] <- 5

#W12
df_GLES17$DemAtt_IT3_W12 <- NA
df_GLES17$DemAtt_IT3_W12[df_GLES17$kp12_050j=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT3_W12[df_GLES17$kp12_050j=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT3_W12[df_GLES17$kp12_050j=="teils/teils"] <- 3
df_GLES17$DemAtt_IT3_W12[df_GLES17$kp12_050j=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT3_W12[df_GLES17$kp12_050j=="stimme voll und ganz zu"] <- 5

#W14
df_GLES17$DemAtt_IT3_W14 <- NA
df_GLES17$DemAtt_IT3_W14[df_GLES17$kp14_050j=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT3_W14[df_GLES17$kp14_050j=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT3_W14[df_GLES17$kp14_050j=="teils/teils"] <- 3
df_GLES17$DemAtt_IT3_W14[df_GLES17$kp14_050j=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT3_W14[df_GLES17$kp14_050j=="stimme voll und ganz zu"] <- 5

#W15
df_GLES17$DemAtt_IT3_W15 <- NA
df_GLES17$DemAtt_IT3_W15[df_GLES17$kp15_050j=="stimme ueberhaupt nicht zu"] <- 1
df_GLES17$DemAtt_IT3_W15[df_GLES17$kp15_050j=="stimme eher nicht zu"] <- 2
df_GLES17$DemAtt_IT3_W15[df_GLES17$kp15_050j=="teils/teils"] <- 3
df_GLES17$DemAtt_IT3_W15[df_GLES17$kp15_050j=="stimme eher zu"] <- 4
df_GLES17$DemAtt_IT3_W15[df_GLES17$kp15_050j=="stimme voll und ganz zu"] <- 5


#### <<<>>> Political Interest ####

# Question: "How interested are you in politics in general?"
# Categories:
# 1=very strongly
# 2=strongly
# 3=average
# 4=less strongly
# 5=not at all

#W5:
df_GLES17$PolInt_W5 <- NA
df_GLES17$PolInt_W5[df_GLES17$kp5_010=="sehr stark"] <- 1
df_GLES17$PolInt_W5[df_GLES17$kp5_010=="stark"] <- 2
df_GLES17$PolInt_W5[df_GLES17$kp5_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W5[df_GLES17$kp5_010=="weniger stark"] <- 4
df_GLES17$PolInt_W5[df_GLES17$kp5_010=="ueberhaupt nicht"] <- 5

#W6:
df_GLES17$PolInt_W6 <- NA
df_GLES17$PolInt_W6[df_GLES17$kp6_010=="sehr stark"] <- 1
df_GLES17$PolInt_W6[df_GLES17$kp6_010=="stark"] <- 2
df_GLES17$PolInt_W6[df_GLES17$kp6_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W6[df_GLES17$kp6_010=="weniger stark"] <- 4
df_GLES17$PolInt_W6[df_GLES17$kp6_010=="ueberhaupt nicht"] <- 5

#W7:
df_GLES17$PolInt_W7 <- NA
df_GLES17$PolInt_W7[df_GLES17$kp7_010=="sehr stark"] <- 1
df_GLES17$PolInt_W7[df_GLES17$kp7_010=="stark"] <- 2
df_GLES17$PolInt_W7[df_GLES17$kp7_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W7[df_GLES17$kp7_010=="weniger stark"] <- 4
df_GLES17$PolInt_W7[df_GLES17$kp7_010=="ueberhaupt nicht"] <- 5

#W8:
df_GLES17$PolInt_W8 <- NA
df_GLES17$PolInt_W8[df_GLES17$kp8_010=="sehr stark"] <- 1
df_GLES17$PolInt_W8[df_GLES17$kp8_010=="stark"] <- 2
df_GLES17$PolInt_W8[df_GLES17$kp8_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W8[df_GLES17$kp8_010=="weniger stark"] <- 4
df_GLES17$PolInt_W8[df_GLES17$kp8_010=="ueberhaupt nicht"] <- 5

#W9:
df_GLES17$PolInt_W9 <- NA
df_GLES17$PolInt_W9[df_GLES17$kp9_010=="sehr stark"] <- 1
df_GLES17$PolInt_W9[df_GLES17$kp9_010=="stark"] <- 2
df_GLES17$PolInt_W9[df_GLES17$kp9_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W9[df_GLES17$kp9_010=="weniger stark"] <- 4
df_GLES17$PolInt_W9[df_GLES17$kp9_010=="ueberhaupt nicht"] <- 5

#W10:
df_GLES17$PolInt_W10 <- NA
df_GLES17$PolInt_W10[df_GLES17$kp10_010=="sehr stark"] <- 1
df_GLES17$PolInt_W10[df_GLES17$kp10_010=="stark"] <- 2
df_GLES17$PolInt_W10[df_GLES17$kp10_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W10[df_GLES17$kp10_010=="weniger stark"] <- 4
df_GLES17$PolInt_W10[df_GLES17$kp10_010=="ueberhaupt nicht"] <- 5

#W11:
df_GLES17$PolInt_W11 <- NA
df_GLES17$PolInt_W11[df_GLES17$kp11_010=="sehr stark"] <- 1
df_GLES17$PolInt_W11[df_GLES17$kp11_010=="stark"] <- 2
df_GLES17$PolInt_W11[df_GLES17$kp11_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W11[df_GLES17$kp11_010=="weniger stark"] <- 4
df_GLES17$PolInt_W11[df_GLES17$kp11_010=="ueberhaupt nicht"] <- 5

#W12:
df_GLES17$PolInt_W12 <- NA
df_GLES17$PolInt_W12[df_GLES17$kp12_010=="sehr stark"] <- 1
df_GLES17$PolInt_W12[df_GLES17$kp12_010=="stark"] <- 2
df_GLES17$PolInt_W12[df_GLES17$kp12_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W12[df_GLES17$kp12_010=="weniger stark"] <- 4
df_GLES17$PolInt_W12[df_GLES17$kp12_010=="ueberhaupt nicht"] <- 5

#W13:
df_GLES17$PolInt_W13 <- NA
df_GLES17$PolInt_W13[df_GLES17$kp13_010=="sehr stark"] <- 1
df_GLES17$PolInt_W13[df_GLES17$kp13_010=="stark"] <- 2
df_GLES17$PolInt_W13[df_GLES17$kp13_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W13[df_GLES17$kp13_010=="weniger stark"] <- 4
df_GLES17$PolInt_W13[df_GLES17$kp13_010=="ueberhaupt nicht"] <- 5

#W14:
df_GLES17$PolInt_W14 <- NA
df_GLES17$PolInt_W14[df_GLES17$kp14_010=="sehr stark"] <- 1
df_GLES17$PolInt_W14[df_GLES17$kp14_010=="stark"] <- 2
df_GLES17$PolInt_W14[df_GLES17$kp14_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W14[df_GLES17$kp14_010=="weniger stark"] <- 4
df_GLES17$PolInt_W14[df_GLES17$kp14_010=="ueberhaupt nicht"] <- 5

#W15:
df_GLES17$PolInt_W15 <- NA
df_GLES17$PolInt_W15[df_GLES17$kp15_010=="sehr stark"] <- 1
df_GLES17$PolInt_W15[df_GLES17$kp15_010=="stark"] <- 2
df_GLES17$PolInt_W15[df_GLES17$kp15_010=="mittelmaessig"] <- 3
df_GLES17$PolInt_W15[df_GLES17$kp15_010=="weniger stark"] <- 4
df_GLES17$PolInt_W15[df_GLES17$kp15_010=="ueberhaupt nicht"] <- 5


#### >>> Variable: Stable politically interested & non-interested (global) ####

## Variable provides number of people who either are interested in politics or who
## are not interested in politics over time.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Interested in politics
## 3=Not interested in politics

## W5-W8
df_GLES17$StableInt_W5W8 <- 1
#Non-Interested
df_GLES17$StableInt_W5W8 <- ifelse(df_GLES17$PolInt_W5<3 &
                                     df_GLES17$PolInt_W8<3,2,df_GLES17$StableInt_W5W8)
#Interested
df_GLES17$StableInt_W5W8 <- ifelse(df_GLES17$PolInt_W5>3 &
                                     df_GLES17$PolInt_W8>3,3,df_GLES17$StableInt_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W5W8 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                     is.na(df_GLES17$PolInt_W8),NA,df_GLES17$StableInt_W5W8)

## W5-W9
df_GLES17$StableInt_W5W9 <- 1
#Non-Interested
df_GLES17$StableInt_W5W9 <- ifelse(df_GLES17$PolInt_W5<3 &
                                     df_GLES17$PolInt_W8<3 &
                                     df_GLES17$PolInt_W9<3,2,df_GLES17$StableInt_W5W9)
#Interested
df_GLES17$StableInt_W5W9 <- ifelse(df_GLES17$PolInt_W5>3 &
                                     df_GLES17$PolInt_W8>3 &
                                     df_GLES17$PolInt_W9>3,3,df_GLES17$StableInt_W5W9)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W5W9 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                     is.na(df_GLES17$PolInt_W8) | 
                                     is.na(df_GLES17$PolInt_W9),NA,df_GLES17$StableInt_W5W9)

## W5-W13
df_GLES17$StableInt_W5W13 <- 1
#Non-Interested
df_GLES17$StableInt_W5W13 <- ifelse(df_GLES17$PolInt_W5<3 &
                                      df_GLES17$PolInt_W8<3 &
                                      df_GLES17$PolInt_W9<3 &
                                      df_GLES17$PolInt_W13<3,2,df_GLES17$StableInt_W5W13)
#Interested
df_GLES17$StableInt_W5W13 <- ifelse(df_GLES17$PolInt_W5>3 &
                                      df_GLES17$PolInt_W8>3 &
                                      df_GLES17$PolInt_W9>3 &
                                      df_GLES17$PolInt_W13>3,3,df_GLES17$StableInt_W5W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W5W13 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                      is.na(df_GLES17$PolInt_W8) | 
                                      is.na(df_GLES17$PolInt_W9)| 
                                      is.na(df_GLES17$PolInt_W13),NA,df_GLES17$StableInt_W5W13)

## W5-W14
df_GLES17$StableInt_W5W14 <- 1
#Non-Interested
df_GLES17$StableInt_W5W14 <- ifelse(df_GLES17$PolInt_W5<3 &
                                      df_GLES17$PolInt_W8<3 &
                                      df_GLES17$PolInt_W9<3 &
                                      df_GLES17$PolInt_W13<3 &
                                      df_GLES17$PolInt_W14<3,2,df_GLES17$StableInt_W5W14)
#Interested
df_GLES17$StableInt_W5W14 <- ifelse(df_GLES17$PolInt_W5>3 &
                                      df_GLES17$PolInt_W8>3 &
                                      df_GLES17$PolInt_W9>3 &
                                      df_GLES17$PolInt_W13>3 &
                                      df_GLES17$PolInt_W14>3,3,df_GLES17$StableInt_W5W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W5W14 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                      is.na(df_GLES17$PolInt_W8) | 
                                      is.na(df_GLES17$PolInt_W9) | 
                                      is.na(df_GLES17$PolInt_W13) | 
                                      is.na(df_GLES17$PolInt_W14),NA,df_GLES17$StableInt_W5W14)

## W5-W15
df_GLES17$StableInt_W5W15 <- 1
#Non-Interested
df_GLES17$StableInt_W5W15 <- ifelse(df_GLES17$PolInt_W5<3 &
                                      df_GLES17$PolInt_W8<3 &
                                      df_GLES17$PolInt_W9<3 &
                                      df_GLES17$PolInt_W13<3 &
                                      df_GLES17$PolInt_W14<3 &
                                      df_GLES17$PolInt_W15<3,2,df_GLES17$StableInt_W5W15)
#Interested
df_GLES17$StableInt_W5W15 <- ifelse(df_GLES17$PolInt_W5>3 &
                                      df_GLES17$PolInt_W8>3 &
                                      df_GLES17$PolInt_W9>3 &
                                      df_GLES17$PolInt_W13>3 &
                                      df_GLES17$PolInt_W14>3 &
                                      df_GLES17$PolInt_W15>3,3,df_GLES17$StableInt_W5W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W5W15 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                      is.na(df_GLES17$PolInt_W8) | 
                                      is.na(df_GLES17$PolInt_W9) | 
                                      is.na(df_GLES17$PolInt_W13) | 
                                      is.na(df_GLES17$PolInt_W14) | 
                                      is.na(df_GLES17$PolInt_W15),NA,df_GLES17$StableInt_W5W15)

#### >>> Variable: Alternative - Stable politically interested & non-interested (global) ####

## Variable provides number of people who either are interested in politics or who
## are not interested in politics over time.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Interested in politics
## 3=Not interested in politics
## 4=middle category (average interest)

## W5-W8
df_GLES17$StableInt_V2_W5W8 <- 1
#Non-Interested
df_GLES17$StableInt_V2_W5W8 <- ifelse(df_GLES17$PolInt_W5<3 &
                                        df_GLES17$PolInt_W8<3,2,df_GLES17$StableInt_V2_W5W8)
#Interested
df_GLES17$StableInt_V2_W5W8 <- ifelse(df_GLES17$PolInt_W5>3 &
                                        df_GLES17$PolInt_W8>3,3,df_GLES17$StableInt_V2_W5W8)
#Average 
df_GLES17$StableInt_V2_W5W8 <- ifelse(df_GLES17$PolInt_W5==3 &
                                        df_GLES17$PolInt_W8==3,4,df_GLES17$StableInt_V2_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_V2_W5W8 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                        is.na(df_GLES17$PolInt_W8),NA,df_GLES17$StableInt_V2_W5W8)

## W5-W9
df_GLES17$StableInt_V2_W5W9 <- 1
#Non-Interested
df_GLES17$StableInt_V2_W5W9 <- ifelse(df_GLES17$PolInt_W5<3 &
                                        df_GLES17$PolInt_W8<3 &
                                        df_GLES17$PolInt_W9<3,2,df_GLES17$StableInt_V2_W5W9)
#Interested
df_GLES17$StableInt_V2_W5W9 <- ifelse(df_GLES17$PolInt_W5>3 &
                                        df_GLES17$PolInt_W8>3 &
                                        df_GLES17$PolInt_W9>3,3,df_GLES17$StableInt_V2_W5W9)
#Average
df_GLES17$StableInt_V2_W5W9 <- ifelse(df_GLES17$PolInt_W5==3 &
                                        df_GLES17$PolInt_W8==3 &
                                        df_GLES17$PolInt_W9==3,4,df_GLES17$StableInt_V2_W5W9)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_V2_W5W9 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                        is.na(df_GLES17$PolInt_W8) | 
                                        is.na(df_GLES17$PolInt_W9),NA,df_GLES17$StableInt_V2_W5W9)

## W5-W13
df_GLES17$StableInt_V2_W5W13 <- 1
#Non-Interested
df_GLES17$StableInt_V2_W5W13 <- ifelse(df_GLES17$PolInt_W5<3 &
                                         df_GLES17$PolInt_W8<3 &
                                         df_GLES17$PolInt_W9<3 &
                                         df_GLES17$PolInt_W13<3,2,df_GLES17$StableInt_V2_W5W13)
#Interested
df_GLES17$StableInt_V2_W5W13 <- ifelse(df_GLES17$PolInt_W5>3 &
                                         df_GLES17$PolInt_W8>3 &
                                         df_GLES17$PolInt_W9>3 &
                                         df_GLES17$PolInt_W13>3,3,df_GLES17$StableInt_V2_W5W13)
#Average
df_GLES17$StableInt_V2_W5W13 <- ifelse(df_GLES17$PolInt_W5==3 &
                                         df_GLES17$PolInt_W8==3 &
                                         df_GLES17$PolInt_W9==3 &
                                         df_GLES17$PolInt_W13==3,4,df_GLES17$StableInt_V2_W5W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_V2_W5W13 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                         is.na(df_GLES17$PolInt_W8) | 
                                         is.na(df_GLES17$PolInt_W9)| 
                                         is.na(df_GLES17$PolInt_W13),NA,df_GLES17$StableInt_V2_W5W13)

## W5-W14
df_GLES17$StableInt_V2_W5W14 <- 1
#Non-Interested
df_GLES17$StableInt_V2_W5W14 <- ifelse(df_GLES17$PolInt_W5<3 &
                                         df_GLES17$PolInt_W8<3 &
                                         df_GLES17$PolInt_W9<3 &
                                         df_GLES17$PolInt_W13<3 &
                                         df_GLES17$PolInt_W14<3,2,df_GLES17$StableInt_V2_W5W14)
#Interested
df_GLES17$StableInt_V2_W5W14 <- ifelse(df_GLES17$PolInt_W5>3 &
                                         df_GLES17$PolInt_W8>3 &
                                         df_GLES17$PolInt_W9>3 &
                                         df_GLES17$PolInt_W13>3 &
                                         df_GLES17$PolInt_W14>3,3,df_GLES17$StableInt_V2_W5W14)
#Average
df_GLES17$StableInt_V2_W5W14 <- ifelse(df_GLES17$PolInt_W5==3 &
                                         df_GLES17$PolInt_W8==3 &
                                         df_GLES17$PolInt_W9==3 &
                                         df_GLES17$PolInt_W13==3 &
                                         df_GLES17$PolInt_W14==3,4,df_GLES17$StableInt_V2_W5W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_V2_W5W14 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                         is.na(df_GLES17$PolInt_W8) | 
                                         is.na(df_GLES17$PolInt_W9) | 
                                         is.na(df_GLES17$PolInt_W13) | 
                                         is.na(df_GLES17$PolInt_W14),NA,df_GLES17$StableInt_V2_W5W14)

## W5-W15
df_GLES17$StableInt_V2_W5W15 <- 1
#Non-Interested
df_GLES17$StableInt_V2_W5W15 <- ifelse(df_GLES17$PolInt_W5<3 &
                                         df_GLES17$PolInt_W8<3 &
                                         df_GLES17$PolInt_W9<3 &
                                         df_GLES17$PolInt_W13<3 &
                                         df_GLES17$PolInt_W14<3 &
                                         df_GLES17$PolInt_W15<3,2,df_GLES17$StableInt_V2_W5W15)
#Interested
df_GLES17$StableInt_V2_W5W15 <- ifelse(df_GLES17$PolInt_W5>3 &
                                         df_GLES17$PolInt_W8>3 &
                                         df_GLES17$PolInt_W9>3 &
                                         df_GLES17$PolInt_W13>3 &
                                         df_GLES17$PolInt_W14>3 &
                                         df_GLES17$PolInt_W15>3,3,df_GLES17$StableInt_V2_W5W15)
#average
df_GLES17$StableInt_V2_W5W15 <- ifelse(df_GLES17$PolInt_W5==3 &
                                         df_GLES17$PolInt_W8==3 &
                                         df_GLES17$PolInt_W9==3 &
                                         df_GLES17$PolInt_W13==3 &
                                         df_GLES17$PolInt_W14==3 &
                                         df_GLES17$PolInt_W15==3,4,df_GLES17$StableInt_V2_W5W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_V2_W5W15 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                         is.na(df_GLES17$PolInt_W8) | 
                                         is.na(df_GLES17$PolInt_W9) | 
                                         is.na(df_GLES17$PolInt_W13) | 
                                         is.na(df_GLES17$PolInt_W14) | 
                                         is.na(df_GLES17$PolInt_W15),NA,df_GLES17$StableInt_V2_W5W15)

#### >>> Variable: Stable politically interested & non-interested vs unstable (wave-2-wave) ####

## Variable provides number of people who either are interested in politics or who
## are not interested in politics over time.
## Variable is calculated for five different times spans (Wave to Wave). Coding:
## 1=Unstable
## 2=Stable Interested in politics/Stable Not interested in politics

## W5-W8
df_GLES17$StableInt_W2W_W5W8 <- 1
#Non-Interested
df_GLES17$StableInt_W2W_W5W8 <- ifelse(df_GLES17$PolInt_W5<3 &
                                         df_GLES17$PolInt_W8<3,2,df_GLES17$StableInt_W2W_W5W8)
#Interested
df_GLES17$StableInt_W2W_W5W8 <- ifelse(df_GLES17$PolInt_W5>3 &
                                         df_GLES17$PolInt_W8>3,2,df_GLES17$StableInt_W2W_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W2W_W5W8 <- ifelse(is.na(df_GLES17$PolInt_W5) | 
                                         is.na(df_GLES17$PolInt_W8),NA,df_GLES17$StableInt_W2W_W5W8)

## W8-W9
df_GLES17$StableInt_W2W_W8W9 <- 1
#Non-Interested
df_GLES17$StableInt_W2W_W8W9 <- ifelse(df_GLES17$PolInt_W8<3 &
                                         df_GLES17$PolInt_W9<3,2,df_GLES17$StableInt_W2W_W8W9)
#Interested
df_GLES17$StableInt_W2W_W8W9 <- ifelse(df_GLES17$PolInt_W8>3 &
                                         df_GLES17$PolInt_W9>3,2,df_GLES17$StableInt_W2W_W8W9)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W2W_W8W9 <- ifelse(is.na(df_GLES17$PolInt_W8) | 
                                         is.na(df_GLES17$PolInt_W9),NA,df_GLES17$StableInt_W2W_W8W9)

## W9-W13
df_GLES17$StableInt_W2W_W9W13 <- 1
#Non-Interested
df_GLES17$StableInt_W2W_W9W13 <- ifelse(df_GLES17$PolInt_W9<3 &
                                          df_GLES17$PolInt_W13<3,2,df_GLES17$StableInt_W2W_W9W13)
#Interested
df_GLES17$StableInt_W2W_W9W13 <- ifelse(df_GLES17$PolInt_W9>3 &
                                          df_GLES17$PolInt_W13>3,2,df_GLES17$StableInt_W2W_W9W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W2W_W9W13 <- ifelse(is.na(df_GLES17$PolInt_W9) | 
                                          is.na(df_GLES17$PolInt_W13),NA,df_GLES17$StableInt_W2W_W9W13)

## W13-W14
df_GLES17$StableInt_W2W_W13W14 <- 1
#Non-Interested
df_GLES17$StableInt_W2W_W13W14 <- ifelse(df_GLES17$PolInt_W13<3 &
                                           df_GLES17$PolInt_W14<3,2,df_GLES17$StableInt_W2W_W13W14)
#Interested
df_GLES17$StableInt_W2W_W13W14 <- ifelse(df_GLES17$PolInt_W13>3 &
                                           df_GLES17$PolInt_W14>3,2,df_GLES17$StableInt_W2W_W13W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W2W_W13W14 <- ifelse(is.na(df_GLES17$PolInt_W13) | 
                                           is.na(df_GLES17$PolInt_W14),NA,df_GLES17$StableInt_W2W_W13W14)

## W14-W15
df_GLES17$StableInt_W2W_W14W15 <- 1
#Non-Interested
df_GLES17$StableInt_W2W_W14W15 <- ifelse(df_GLES17$PolInt_W14<3 &
                                           df_GLES17$PolInt_W15<3,2,df_GLES17$StableInt_W2W_W14W15)
#Interested
df_GLES17$StableInt_W2W_W14W15 <- ifelse(df_GLES17$PolInt_W14>3 &
                                           df_GLES17$PolInt_W15>3,2,df_GLES17$StableInt_W2W_W14W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableInt_W2W_W14W15 <- ifelse(is.na(df_GLES17$PolInt_W14) | 
                                           is.na(df_GLES17$PolInt_W15),NA,df_GLES17$StableInt_W2W_W14W15)



#### <<<>>> Satisfaction with Government Performance ####

# For HK model, we collaps the scale into five categories:
# <=2      = 5 Strongly dissatisfied)
# >2 & <5  = 4 Dissatisfied)
# 5        = 3 Neither dissatisfied nor satisfied
# >5 & < 8 = 2 Satisfied
# >=8      = 1 Completely satisfied

# W5
df_GLES17$GovSat_W5_H <- as.numeric(as.character(df_GLES17$kp5_730))
df_GLES17$GovSat_W5_H[df_GLES17$kp5_730=="-5 voellig unzufrieden"] <- -5
df_GLES17$GovSat_W5_H[df_GLES17$kp5_730=="+5 voellig zufrieden"] <- 5
df_GLES17$GovSat_W5_H<- df_GLES17$GovSat_W5_H+5
df_GLES17$GovSat_W5 <- NA
df_GLES17$GovSat_W5[df_GLES17$GovSat_W5_H<=2] <-5
df_GLES17$GovSat_W5[df_GLES17$GovSat_W5_H>2 &
                      df_GLES17$GovSat_W5_H<5   ] <-4
df_GLES17$GovSat_W5[df_GLES17$GovSat_W5_H==5] <-3
df_GLES17$GovSat_W5[df_GLES17$GovSat_W5_H>5 &
                      df_GLES17$GovSat_W5_H<8] <-2
df_GLES17$GovSat_W5[df_GLES17$GovSat_W5_H>=8] <-1
table(df_GLES17$GovSat_W5, useNA="always")

# W8
df_GLES17$GovSat_W8_H <- as.numeric(as.character(df_GLES17$kp8_730))
df_GLES17$GovSat_W8_H[df_GLES17$kp8_730=="-5 voellig unzufrieden"] <- -5
df_GLES17$GovSat_W8_H[df_GLES17$kp8_730=="+5 voellig zufrieden"] <- 5
df_GLES17$GovSat_W8_H<- df_GLES17$GovSat_W8_H+5
df_GLES17$GovSat_W8 <- NA
df_GLES17$GovSat_W8[df_GLES17$GovSat_W8_H<=2] <-5
df_GLES17$GovSat_W8[df_GLES17$GovSat_W8_H>2 &
                      df_GLES17$GovSat_W8_H<5   ] <-4
df_GLES17$GovSat_W8[df_GLES17$GovSat_W8_H==5] <-3
df_GLES17$GovSat_W8[df_GLES17$GovSat_W8_H>5 &
                      df_GLES17$GovSat_W8_H<8] <-2
df_GLES17$GovSat_W8[df_GLES17$GovSat_W8_H>=8] <-1
table(df_GLES17$GovSat_W8, useNA="always")

# W13
df_GLES17$GovSat_W13_H <- as.numeric(as.character(df_GLES17$kp13_730))
df_GLES17$GovSat_W13_H[df_GLES17$kp13_730=="-5 voellig unzufrieden"] <- -5
df_GLES17$GovSat_W13_H[df_GLES17$kp13_730=="+5 voellig zufrieden"] <- 5
df_GLES17$GovSat_W13_H<- df_GLES17$GovSat_W13_H+5
df_GLES17$GovSat_W13 <- NA
df_GLES17$GovSat_W13[df_GLES17$GovSat_W13_H<=2] <-5
df_GLES17$GovSat_W13[df_GLES17$GovSat_W13_H>2 &
                       df_GLES17$GovSat_W13_H<5   ] <-4
df_GLES17$GovSat_W13[df_GLES17$GovSat_W13_H==5] <-3
df_GLES17$GovSat_W13[df_GLES17$GovSat_W13_H>5 &
                       df_GLES17$GovSat_W13_H<8] <-2
df_GLES17$GovSat_W13[df_GLES17$GovSat_W13_H>=8] <-1
table(df_GLES17$GovSat_W13, useNA="always")

# W14
df_GLES17$GovSat_W14_H <- as.numeric(as.character(df_GLES17$kp14_730))
df_GLES17$GovSat_W14_H[df_GLES17$kp14_730=="-5 voellig unzufrieden"] <- -5
df_GLES17$GovSat_W14_H[df_GLES17$kp14_730=="+5 voellig zufrieden"] <- 5
df_GLES17$GovSat_W14_H<- df_GLES17$GovSat_W14_H+5
df_GLES17$GovSat_W14 <- NA
df_GLES17$GovSat_W14[df_GLES17$GovSat_W14_H<=2] <-5
df_GLES17$GovSat_W14[df_GLES17$GovSat_W14_H>2 &
                       df_GLES17$GovSat_W14_H<5   ] <-4
df_GLES17$GovSat_W14[df_GLES17$GovSat_W14_H==5] <-3
df_GLES17$GovSat_W14[df_GLES17$GovSat_W14_H>5 &
                       df_GLES17$GovSat_W14_H<8] <-2
df_GLES17$GovSat_W14[df_GLES17$GovSat_W14_H>=8] <-1
table(df_GLES17$GovSat_W14, useNA="always")

# W15
df_GLES17$GovSat_W15_H <- as.numeric(as.character(df_GLES17$kp15_730))
df_GLES17$GovSat_W15_H[df_GLES17$kp15_730=="-5 voellig unzufrieden"] <- -5
df_GLES17$GovSat_W15_H[df_GLES17$kp15_730=="+5 voellig zufrieden"] <- 5
df_GLES17$GovSat_W15_H<- df_GLES17$GovSat_W15_H+5
df_GLES17$GovSat_W15 <- NA
df_GLES17$GovSat_W15[df_GLES17$GovSat_W15_H<=2] <-5
df_GLES17$GovSat_W15[df_GLES17$GovSat_W15_H>2 &
                       df_GLES17$GovSat_W15_H<5   ] <-4
df_GLES17$GovSat_W15[df_GLES17$GovSat_W15_H==5] <-3
df_GLES17$GovSat_W15[df_GLES17$GovSat_W15_H>5 &
                       df_GLES17$GovSat_W15_H<8] <-2
df_GLES17$GovSat_W15[df_GLES17$GovSat_W15_H>=8] <-1
table(df_GLES17$GovSat_W15, useNA="always")


#### >>> Variable: Stable satisfaction & non-satisfaction with government (global) ####

## Variable provides number of people who either consistently are satisfied with government
## or who consistently are not satisfied with government.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Satisfied with government
## 3=Not satisfied with government

## W5-W8
df_GLES17$StableGovSat_W5W8 <- 1
#Not satisfied
df_GLES17$StableGovSat_W5W8 <- ifelse(df_GLES17$GovSat_W5<3 &
                                        df_GLES17$GovSat_W8<3,2,df_GLES17$StableGovSat_W5W8)
#Satisfied
df_GLES17$StableGovSat_W5W8 <- ifelse(df_GLES17$GovSat_W5>3 &
                                        df_GLES17$GovSat_W8>3,3,df_GLES17$StableGovSat_W5W8)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W5W8 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                        is.na(df_GLES17$GovSat_W8),NA,df_GLES17$StableGovSat_W5W8)

## W5-W13
df_GLES17$StableGovSat_W5W13 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W5W13 <- ifelse(df_GLES17$GovSat_W5<3 &
                                         df_GLES17$GovSat_W8<3 &
                                         df_GLES17$GovSat_W13<3,2,df_GLES17$StableGovSat_W5W13)
#Satisfied
df_GLES17$StableGovSat_W5W13 <- ifelse(df_GLES17$GovSat_W5>3 &
                                         df_GLES17$GovSat_W8>3 &
                                         df_GLES17$GovSat_W13>3,3,df_GLES17$StableGovSat_W5W13)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W5W13 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                         is.na(df_GLES17$GovSat_W8) | 
                                         is.na(df_GLES17$GovSat_W13),NA,df_GLES17$StableGovSat_W5W13)

## W5-W14
df_GLES17$StableGovSat_W5W14 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W5W14 <- ifelse(df_GLES17$GovSat_W5<3 &
                                         df_GLES17$GovSat_W8<3 &
                                         df_GLES17$GovSat_W13<3 &
                                         df_GLES17$GovSat_W14<3,2,df_GLES17$StableGovSat_W5W14)
#Satisfied
df_GLES17$StableGovSat_W5W14 <- ifelse(df_GLES17$GovSat_W5>3 &
                                         df_GLES17$GovSat_W8>3 &
                                         df_GLES17$GovSat_W13>3 &
                                         df_GLES17$GovSat_W14>3,3,df_GLES17$StableGovSat_W5W14)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W5W14 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                         is.na(df_GLES17$GovSat_W8) | 
                                         is.na(df_GLES17$GovSat_W13) | 
                                         is.na(df_GLES17$GovSat_W14),NA,df_GLES17$StableGovSat_W5W14)

## W5-W15
df_GLES17$StableGovSat_W5W15 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W5W15 <- ifelse(df_GLES17$GovSat_W5<3 &
                                         df_GLES17$GovSat_W8<3 &
                                         df_GLES17$GovSat_W13<3 &
                                         df_GLES17$GovSat_W14<3 &
                                         df_GLES17$GovSat_W15<3,2,df_GLES17$StableGovSat_W5W15)
#Satisfied
df_GLES17$StableGovSat_W5W15 <- ifelse(df_GLES17$GovSat_W5>3 &
                                         df_GLES17$GovSat_W8>3 &
                                         df_GLES17$GovSat_W13>3 &
                                         df_GLES17$GovSat_W14>3 &
                                         df_GLES17$GovSat_W15>3,3,df_GLES17$StableGovSat_W5W15)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W5W15 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                         is.na(df_GLES17$GovSat_W8) | 
                                         is.na(df_GLES17$GovSat_W13) | 
                                         is.na(df_GLES17$GovSat_W14) | 
                                         is.na(df_GLES17$GovSat_W15),NA,df_GLES17$StableGovSat_W5W15)

#### >>> Variable: Alternative - Stable satisfaction & non-satisfaction with government (global) ####

## Variable provides number of people who either consistently are satisfied with government
## or who consistently are not satisfied with government.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Satisfied with government
## 3=Not satisfied with government
## 4=Neither satisfied nor disatisfied

## W5-W8
df_GLES17$StableGovSat_V2_W5W8 <- 1
#Not satisfied
df_GLES17$StableGovSat_V2_W5W8 <- ifelse(df_GLES17$GovSat_W5<3 &
                                           df_GLES17$GovSat_W8<3,2,df_GLES17$StableGovSat_V2_W5W8)
#Satisfied
df_GLES17$StableGovSat_V2_W5W8 <- ifelse(df_GLES17$GovSat_W5>3 &
                                           df_GLES17$GovSat_W8>3,3,df_GLES17$StableGovSat_V2_W5W8)
#Neither/nor
df_GLES17$StableGovSat_V2_W5W8 <- ifelse(df_GLES17$GovSat_W5==3 &
                                           df_GLES17$GovSat_W8==3,4,df_GLES17$StableGovSat_V2_W5W8)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_V2_W5W8 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                           is.na(df_GLES17$GovSat_W8),NA,df_GLES17$StableGovSat_V2_W5W8)

## W5-W13
df_GLES17$StableGovSat_V2_W5W13 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_V2_W5W13 <- ifelse(df_GLES17$GovSat_W5<3 &
                                            df_GLES17$GovSat_W8<3 &
                                            df_GLES17$GovSat_W13<3,2,df_GLES17$StableGovSat_V2_W5W13)
#Satisfied
df_GLES17$StableGovSat_V2_W5W13 <- ifelse(df_GLES17$GovSat_W5>3 &
                                            df_GLES17$GovSat_W8>3 &
                                            df_GLES17$GovSat_W13>3,3,df_GLES17$StableGovSat_V2_W5W13)
#Neither/nor
df_GLES17$StableGovSat_V2_W5W13 <- ifelse(df_GLES17$GovSat_W5==3 &
                                            df_GLES17$GovSat_W8==3 &
                                            df_GLES17$GovSat_W13==3,4,df_GLES17$StableGovSat_V2_W5W13)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_V2_W5W13 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                            is.na(df_GLES17$GovSat_W8) | 
                                            is.na(df_GLES17$GovSat_W13),NA,df_GLES17$StableGovSat_V2_W5W13)

## W5-W14
df_GLES17$StableGovSat_V2_W5W14 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_V2_W5W14 <- ifelse(df_GLES17$GovSat_W5<3 &
                                            df_GLES17$GovSat_W8<3 &
                                            df_GLES17$GovSat_W13<3 &
                                            df_GLES17$GovSat_W14<3,2,df_GLES17$StableGovSat_V2_W5W14)
#Satisfied
df_GLES17$StableGovSat_V2_W5W14 <- ifelse(df_GLES17$GovSat_W5>3 &
                                            df_GLES17$GovSat_W8>3 &
                                            df_GLES17$GovSat_W13>3 &
                                            df_GLES17$GovSat_W14>3,3,df_GLES17$StableGovSat_V2_W5W14)
#Neither/Nor
df_GLES17$StableGovSat_V2_W5W14 <- ifelse(df_GLES17$GovSat_W5==3 &
                                            df_GLES17$GovSat_W8==3 &
                                            df_GLES17$GovSat_W13==3 &
                                            df_GLES17$GovSat_W14==3,4,df_GLES17$StableGovSat_V2_W5W14)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_V2_W5W14 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                            is.na(df_GLES17$GovSat_W8) | 
                                            is.na(df_GLES17$GovSat_W13) | 
                                            is.na(df_GLES17$GovSat_W14),NA,df_GLES17$StableGovSat_V2_W5W14)

## W5-W15
df_GLES17$StableGovSat_V2_W5W15 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_V2_W5W15 <- ifelse(df_GLES17$GovSat_W5<3 &
                                            df_GLES17$GovSat_W8<3 &
                                            df_GLES17$GovSat_W13<3 &
                                            df_GLES17$GovSat_W14<3 &
                                            df_GLES17$GovSat_W15<3,2,df_GLES17$StableGovSat_V2_W5W15)
#Satisfied
df_GLES17$StableGovSat_V2_W5W15 <- ifelse(df_GLES17$GovSat_W5>3 &
                                            df_GLES17$GovSat_W8>3 &
                                            df_GLES17$GovSat_W13>3 &
                                            df_GLES17$GovSat_W14>3 &
                                            df_GLES17$GovSat_W15>3,3,df_GLES17$StableGovSat_V2_W5W15)
#Neither/Nor
df_GLES17$StableGovSat_V2_W5W15 <- ifelse(df_GLES17$GovSat_W5==3 &
                                            df_GLES17$GovSat_W8==3 &
                                            df_GLES17$GovSat_W13==3 &
                                            df_GLES17$GovSat_W14==3 &
                                            df_GLES17$GovSat_W15==3,4,df_GLES17$StableGovSat_V2_W5W15)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_V2_W5W15 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                            is.na(df_GLES17$GovSat_W8) | 
                                            is.na(df_GLES17$GovSat_W13) | 
                                            is.na(df_GLES17$GovSat_W14) | 
                                            is.na(df_GLES17$GovSat_W15),NA,df_GLES17$StableGovSat_V2_W5W15)

#### >>> Variable: unstable, Stable satisfaction/stable non-satisfaction with government (wave2wave) ####

## Variable provides number of people who either consistently are satisfied with government
## or who consistently are not satisfied with government.
## Variable is calculated for five different times spans (wave-to-wave). Coding:
## 1=unstable
## 2=stable Satisfied with government/stable Not satisfied with government

## W5-W8
df_GLES17$StableGovSat_W2W_W5W8 <- 1
#Not satisfied
df_GLES17$StableGovSat_W2W_W5W8 <- ifelse(df_GLES17$GovSat_W5<3 &
                                            df_GLES17$GovSat_W8<3,2,df_GLES17$StableGovSat_W2W_W5W8)
#Satisfied
df_GLES17$StableGovSat_W2W_W5W8 <- ifelse(df_GLES17$GovSat_W5>3 &
                                            df_GLES17$GovSat_W8>3,2,df_GLES17$StableGovSat_W2W_W5W8)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W2W_W5W8 <- ifelse(is.na(df_GLES17$GovSat_W5) | 
                                            is.na(df_GLES17$GovSat_W8),NA,df_GLES17$StableGovSat_W2W_W5W8)

## W8-W13
df_GLES17$StableGovSat_W2W_W8W13 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W2W_W8W13 <- ifelse(df_GLES17$GovSat_W8<3 &
                                             df_GLES17$GovSat_W13<3,2,df_GLES17$StableGovSat_W2W_W8W13)
#Satisfied
df_GLES17$StableGovSat_W2W_W8W13 <- ifelse(df_GLES17$GovSat_W8>3 &
                                             df_GLES17$GovSat_W13>3,2,df_GLES17$StableGovSat_W2W_W8W13)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W2W_W8W13 <- ifelse(is.na(df_GLES17$GovSat_W8) | 
                                             is.na(df_GLES17$GovSat_W13),NA,df_GLES17$StableGovSat_W2W_W8W13)

## W13-W14
df_GLES17$StableGovSat_W2W_W13W14 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W2W_W13W14 <- ifelse(df_GLES17$GovSat_W13<3 &
                                              df_GLES17$GovSat_W14<3,2,df_GLES17$StableGovSat_W2W_W13W14)
#Satisfied
df_GLES17$StableGovSat_W2W_W13W14 <- ifelse(df_GLES17$GovSat_W13>3 &
                                              df_GLES17$GovSat_W14>3,2,df_GLES17$StableGovSat_W2W_W13W14)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W2W_W13W14 <- ifelse(is.na(df_GLES17$GovSat_W13) | 
                                              is.na(df_GLES17$GovSat_W14),NA,df_GLES17$StableGovSat_W2W_W13W14)

## W14-W15
df_GLES17$StableGovSat_W2W_W14W15 <- 1
#Non-Satisfied
df_GLES17$StableGovSat_W2W_W14W15 <- ifelse(df_GLES17$GovSat_W14<3 &
                                              df_GLES17$GovSat_W15<3,2,df_GLES17$StableGovSat_W2W_W14W15)
#Satisfied
df_GLES17$StableGovSat_W2W_W14W15 <- ifelse(df_GLES17$GovSat_W14>3 &
                                              df_GLES17$GovSat_W15>3,2,df_GLES17$StableGovSat_W2W_W14W15)
#Code all those with missing values on either of the gov satisfaction variables as missing:
df_GLES17$StableGovSat_W2W_W14W15 <- ifelse(is.na(df_GLES17$GovSat_W14) | 
                                              is.na(df_GLES17$GovSat_W15),NA,df_GLES17$StableGovSat_W2W_W14W15)


#### <<<>>> Perceived Economic Situation (Sociotropic) ####

# Coding:
# 5=Very bad
# 4=Bad
# 3=Neither bad nor good
# 2=Good
# 1=Very good

# W5
df_GLES17$EcoPercSocio_W5 <- NA
df_GLES17$EcoPercSocio_W5[df_GLES17$kp5_820=="sehr schlecht"] <- 5 
df_GLES17$EcoPercSocio_W5[df_GLES17$kp5_820=="schlecht"] <- 4
df_GLES17$EcoPercSocio_W5[df_GLES17$kp5_820=="teils/teils"] <- 3 
df_GLES17$EcoPercSocio_W5[df_GLES17$kp5_820=="gut"] <- 2 
df_GLES17$EcoPercSocio_W5[df_GLES17$kp5_820=="sehr gut"] <- 1 
table(df_GLES17$EcoPercSocio_W5, useNA="always")

# W8
df_GLES17$EcoPercSocio_W8 <- NA
df_GLES17$EcoPercSocio_W8[df_GLES17$kp8_820=="sehr schlecht"] <- 5 
df_GLES17$EcoPercSocio_W8[df_GLES17$kp8_820=="schlecht"] <- 4
df_GLES17$EcoPercSocio_W8[df_GLES17$kp8_820=="teils/teils"] <- 3 
df_GLES17$EcoPercSocio_W8[df_GLES17$kp8_820=="gut"] <- 2 
df_GLES17$EcoPercSocio_W8[df_GLES17$kp8_820=="sehr gut"] <- 1 
table(df_GLES17$EcoPercSocio_W8, useNA="always")

# W13
df_GLES17$EcoPercSocio_W13 <- NA
df_GLES17$EcoPercSocio_W13[df_GLES17$kp13_820=="sehr schlecht"] <- 5 
df_GLES17$EcoPercSocio_W13[df_GLES17$kp13_820=="schlecht"] <- 4
df_GLES17$EcoPercSocio_W13[df_GLES17$kp13_820=="teils/teils"] <- 3 
df_GLES17$EcoPercSocio_W13[df_GLES17$kp13_820=="gut"] <- 2 
df_GLES17$EcoPercSocio_W13[df_GLES17$kp13_820=="sehr gut"] <- 1 
table(df_GLES17$EcoPercSocio_W13, useNA="always")

# W14
df_GLES17$EcoPercSocio_W14 <- NA
df_GLES17$EcoPercSocio_W14[df_GLES17$kp14_820=="sehr schlecht"] <- 5 
df_GLES17$EcoPercSocio_W14[df_GLES17$kp14_820=="schlecht"] <- 4
df_GLES17$EcoPercSocio_W14[df_GLES17$kp14_820=="teils/teils"] <- 3 
df_GLES17$EcoPercSocio_W14[df_GLES17$kp14_820=="gut"] <- 2 
df_GLES17$EcoPercSocio_W14[df_GLES17$kp14_820=="sehr gut"] <- 1 
table(df_GLES17$EcoPercSocio_W14, useNA="always")

# W15
df_GLES17$EcoPercSocio_W15 <- NA
df_GLES17$EcoPercSocio_W15[df_GLES17$kp15_820=="sehr schlecht"] <- 5 
df_GLES17$EcoPercSocio_W15[df_GLES17$kp15_820=="schlecht"] <- 4
df_GLES17$EcoPercSocio_W15[df_GLES17$kp15_820=="teils/teils"] <- 3 
df_GLES17$EcoPercSocio_W15[df_GLES17$kp15_820=="gut"] <- 2 
df_GLES17$EcoPercSocio_W15[df_GLES17$kp15_820=="sehr gut"] <- 1 
table(df_GLES17$EcoPercSocio_W15, useNA="always")


#### >>> Variable: Stable perceived poor economic & good economic (global) ####

## Variable provides number of people who either constantly perceive economy as bad
## over time or as good.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Economy is doing well
## 3=Economy is doing poorly

## W5-W8
df_GLES17$StableEcon_W5W8 <- 1
#Non-Interested
df_GLES17$StableEcon_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                      df_GLES17$EcoPercSocio_W8<3,2,df_GLES17$StableEcon_W5W8)
#Interested
df_GLES17$StableEcon_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                      df_GLES17$EcoPercSocio_W8>3,3,df_GLES17$StableEcon_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W5W8 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                      is.na(df_GLES17$EcoPercSocio_W8),NA,df_GLES17$StableEcon_W5W8)

## W5-W13
df_GLES17$StableEcon_W5W13 <- 1
#Non-Interested
df_GLES17$StableEcon_W5W13 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                       df_GLES17$EcoPercSocio_W8<3 &
                                       df_GLES17$EcoPercSocio_W13<3,2,df_GLES17$StableEcon_W5W13)
#Interested
df_GLES17$StableEcon_W5W13 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                       df_GLES17$EcoPercSocio_W8>3 &
                                       df_GLES17$EcoPercSocio_W13>3,3,df_GLES17$StableEcon_W5W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W5W13 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                       is.na(df_GLES17$EcoPercSocio_W8) | 
                                       is.na(df_GLES17$EcoPercSocio_W13),NA,df_GLES17$StableEcon_W5W13)

## W5-W14
df_GLES17$StableEcon_W5W14 <- 1
#Non-Interested
df_GLES17$StableEcon_W5W14 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                       df_GLES17$EcoPercSocio_W8<3 &
                                       df_GLES17$EcoPercSocio_W13<3 &
                                       df_GLES17$EcoPercSocio_W14<3,2,df_GLES17$StableEcon_W5W14)
#Interested
df_GLES17$StableEcon_W5W14 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                       df_GLES17$EcoPercSocio_W8>3 &
                                       df_GLES17$EcoPercSocio_W13>3 &
                                       df_GLES17$EcoPercSocio_W14>3,3,df_GLES17$StableEcon_W5W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W5W14 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                       is.na(df_GLES17$EcoPercSocio_W8) | 
                                       is.na(df_GLES17$EcoPercSocio_W13) | 
                                       is.na(df_GLES17$EcoPercSocio_W14),NA,df_GLES17$StableEcon_W5W14)

## W5-W15
df_GLES17$StableEcon_W5W15 <- 1
#Non-Interested
df_GLES17$StableEcon_W5W15 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                       df_GLES17$EcoPercSocio_W8<3 &
                                       df_GLES17$EcoPercSocio_W13<3 &
                                       df_GLES17$EcoPercSocio_W14<3 &
                                       df_GLES17$EcoPercSocio_W15<3,2,df_GLES17$StableEcon_W5W15)
#Interested
df_GLES17$StableEcon_W5W15 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                       df_GLES17$EcoPercSocio_W8>3 &
                                       df_GLES17$EcoPercSocio_W13>3 &
                                       df_GLES17$EcoPercSocio_W14>3 &
                                       df_GLES17$EcoPercSocio_W15>3,3,df_GLES17$StableEcon_W5W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W5W15 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                       is.na(df_GLES17$EcoPercSocio_W8) | 
                                       is.na(df_GLES17$EcoPercSocio_W13) | 
                                       is.na(df_GLES17$EcoPercSocio_W14) | 
                                       is.na(df_GLES17$EcoPercSocio_W15),NA,df_GLES17$StableEcon_W5W15)

#### >>> Variable: Alternative - Stable perceived poor economic & good economic (global) ####

## Variable provides number of people who either constantly perceive economy as bad
## over time or as good.
## Variable is calculated for five different times spans (Wave 5=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=Economy is doing well
## 3=Economy is doing poorly
## 4=Neither bad nor good

## W5-W8
df_GLES17$StableEcon_V2_W5W8 <- 1
#Non-Interested
df_GLES17$StableEcon_V2_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                         df_GLES17$EcoPercSocio_W8<3,2,df_GLES17$StableEcon_V2_W5W8)
#Interested
df_GLES17$StableEcon_V2_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                         df_GLES17$EcoPercSocio_W8>3,3,df_GLES17$StableEcon_V2_W5W8)
#Neither/Nor
df_GLES17$StableEcon_V2_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5==3 &
                                         df_GLES17$EcoPercSocio_W8==3,4,df_GLES17$StableEcon_V2_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_V2_W5W8 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                         is.na(df_GLES17$EcoPercSocio_W8),NA,df_GLES17$StableEcon_V2_W5W8)

## W5-W13
df_GLES17$StableEcon_V2_W5W13 <- 1
#Non-Interested
df_GLES17$StableEcon_V2_W5W13 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                          df_GLES17$EcoPercSocio_W8<3 &
                                          df_GLES17$EcoPercSocio_W13<3,2,df_GLES17$StableEcon_V2_W5W13)
#Interested
df_GLES17$StableEcon_V2_W5W13 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                          df_GLES17$EcoPercSocio_W8>3 &
                                          df_GLES17$EcoPercSocio_W13>3,3,df_GLES17$StableEcon_V2_W5W13)
#Neither/nor
df_GLES17$StableEcon_V2_W5W13 <- ifelse(df_GLES17$EcoPercSocio_W5==3 &
                                          df_GLES17$EcoPercSocio_W8==3 &
                                          df_GLES17$EcoPercSocio_W13==3,4,df_GLES17$StableEcon_V2_W5W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_V2_W5W13 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                          is.na(df_GLES17$EcoPercSocio_W8) | 
                                          is.na(df_GLES17$EcoPercSocio_W13),NA,df_GLES17$StableEcon_V2_W5W13)

## W5-W14
df_GLES17$StableEcon_V2_W5W14 <- 1
#Non-Interested
df_GLES17$StableEcon_V2_W5W14 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                          df_GLES17$EcoPercSocio_W8<3 &
                                          df_GLES17$EcoPercSocio_W13<3 &
                                          df_GLES17$EcoPercSocio_W14<3,2,df_GLES17$StableEcon_V2_W5W14)
#Interested
df_GLES17$StableEcon_V2_W5W14 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                          df_GLES17$EcoPercSocio_W8>3 &
                                          df_GLES17$EcoPercSocio_W13>3 &
                                          df_GLES17$EcoPercSocio_W14>3,3,df_GLES17$StableEcon_V2_W5W14)
#Neither/nor
df_GLES17$StableEcon_V2_W5W14 <- ifelse(df_GLES17$EcoPercSocio_W5==3 &
                                          df_GLES17$EcoPercSocio_W8==3 &
                                          df_GLES17$EcoPercSocio_W13==3 &
                                          df_GLES17$EcoPercSocio_W14==3,4,df_GLES17$StableEcon_V2_W5W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_V2_W5W14 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                          is.na(df_GLES17$EcoPercSocio_W8) | 
                                          is.na(df_GLES17$EcoPercSocio_W13) | 
                                          is.na(df_GLES17$EcoPercSocio_W14),NA,df_GLES17$StableEcon_V2_W5W14)

## W5-W15
df_GLES17$StableEcon_V2_W5W15 <- 1
#Non-Interested
df_GLES17$StableEcon_V2_W5W15 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                          df_GLES17$EcoPercSocio_W8<3 &
                                          df_GLES17$EcoPercSocio_W13<3 &
                                          df_GLES17$EcoPercSocio_W14<3 &
                                          df_GLES17$EcoPercSocio_W15<3,2,df_GLES17$StableEcon_V2_W5W15)
#Interested
df_GLES17$StableEcon_V2_W5W15 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                          df_GLES17$EcoPercSocio_W8>3 &
                                          df_GLES17$EcoPercSocio_W13>3 &
                                          df_GLES17$EcoPercSocio_W14>3 &
                                          df_GLES17$EcoPercSocio_W15>3,3,df_GLES17$StableEcon_V2_W5W15)
#Neither/Nor
df_GLES17$StableEcon_V2_W5W15 <- ifelse(df_GLES17$EcoPercSocio_W5==3 &
                                          df_GLES17$EcoPercSocio_W8==3 &
                                          df_GLES17$EcoPercSocio_W13==3 &
                                          df_GLES17$EcoPercSocio_W14==3 &
                                          df_GLES17$EcoPercSocio_W15==3,4,df_GLES17$StableEcon_V2_W5W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_V2_W5W15 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                          is.na(df_GLES17$EcoPercSocio_W8) | 
                                          is.na(df_GLES17$EcoPercSocio_W13) | 
                                          is.na(df_GLES17$EcoPercSocio_W14) | 
                                          is.na(df_GLES17$EcoPercSocio_W15),NA,df_GLES17$StableEcon_V2_W5W15)


#### >>> Variable: Unstable versus Stable perceived poor economic/stable good economic (wave2wave) ####

## Variable provides number of people who either constantly perceive economy as bad
## over time or as good.
## Variable is calculated for five different times spans (wave to wave). Coding:
## 1=Unstable
## 2=Stable Economy is doing well/Economy is doing poorly

## W5-W8
df_GLES17$StableEcon_W2W_W5W8 <- 1
#Non-Interested
df_GLES17$StableEcon_W2W_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5<3 &
                                          df_GLES17$EcoPercSocio_W8<3,2,df_GLES17$StableEcon_W2W_W5W8)
#Interested
df_GLES17$StableEcon_W2W_W5W8 <- ifelse(df_GLES17$EcoPercSocio_W5>3 &
                                          df_GLES17$EcoPercSocio_W8>3,2,df_GLES17$StableEcon_W2W_W5W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W2W_W5W8 <- ifelse(is.na(df_GLES17$EcoPercSocio_W5) | 
                                          is.na(df_GLES17$EcoPercSocio_W8),NA,df_GLES17$StableEcon_W2W_W5W8)

## W8-W13
df_GLES17$StableEcon_W2W_W8W13 <- 1
#Non-Interested
df_GLES17$StableEcon_W2W_W8W13 <- ifelse(df_GLES17$EcoPercSocio_W8<3 &
                                           df_GLES17$EcoPercSocio_W13<3,2,df_GLES17$StableEcon_W2W_W8W13)
#Interested
df_GLES17$StableEcon_W2W_W8W13 <- ifelse(df_GLES17$EcoPercSocio_W8>3 &
                                           df_GLES17$EcoPercSocio_W13>3,2,df_GLES17$StableEcon_W2W_W8W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W2W_W8W13 <- ifelse(is.na(df_GLES17$EcoPercSocio_W8) | 
                                           is.na(df_GLES17$EcoPercSocio_W13),NA,df_GLES17$StableEcon_W2W_W8W13)

## W13-W14
df_GLES17$StableEcon_W2W_W13W14 <- 1
#Non-Interested
df_GLES17$StableEcon_W2W_W13W14 <- ifelse(df_GLES17$EcoPercSocio_W13<3 &
                                            df_GLES17$EcoPercSocio_W14<3,2,df_GLES17$StableEcon_W2W_W13W14)
#Interested
df_GLES17$StableEcon_W2W_W13W14 <- ifelse(df_GLES17$EcoPercSocio_W13>3 &
                                            df_GLES17$EcoPercSocio_W14>3,2,df_GLES17$StableEcon_W2W_W13W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W2W_W13W14 <- ifelse(is.na(df_GLES17$EcoPercSocio_W13) | 
                                            is.na(df_GLES17$EcoPercSocio_W14),NA,df_GLES17$StableEcon_W2W_W13W14)

## W14-W15
df_GLES17$StableEcon_W2W_W14W15 <- 1
#Non-Interested
df_GLES17$StableEcon_W2W_W14W15 <- ifelse(df_GLES17$EcoPercSocio_W14<3 &
                                            df_GLES17$EcoPercSocio_W15<3,2,df_GLES17$StableEcon_W2W_W14W15)
#Interested
df_GLES17$StableEcon_W2W_W14W15 <- ifelse(df_GLES17$EcoPercSocio_W14>3 &
                                            df_GLES17$EcoPercSocio_W15>3,2,df_GLES17$StableEcon_W2W_W14W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableEcon_W2W_W14W15 <- ifelse(is.na(df_GLES17$EcoPercSocio_W14) | 
                                            is.na(df_GLES17$EcoPercSocio_W15),NA,df_GLES17$StableEcon_W2W_W14W15)


#### <<<>>> Climate Protection ####

# Seven point scale with:
# 1 = Fighting climate change takes priority over economic growth
# ...
# 7 = Economic growth takes priority over fighting climate change

#W4
# -> for respondents from refresher sample (A1), answers are taken from 
#    Wave A1:
df_GLES17$ClimateChange_W4 <- as.numeric(as.character(df_GLES17$kp4_1290))
df_GLES17$ClimateChange_W4[df_GLES17$kp4_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W4[df_GLES17$kp4_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7
#add refresher sample:
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="2"] <-2
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="3"] <-3
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="4"] <-4
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="5"] <-5
df_GLES17$ClimateChange_W4[df_GLES17$kpa1_1290=="6"] <-6

#W7
df_GLES17$ClimateChange_W7 <- as.numeric(as.character(df_GLES17$kp7_1290))
df_GLES17$ClimateChange_W7[df_GLES17$kp7_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W7[df_GLES17$kp7_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W8
df_GLES17$ClimateChange_W8 <- as.numeric(as.character(df_GLES17$kp8_1290))
df_GLES17$ClimateChange_W8[df_GLES17$kp8_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W8[df_GLES17$kp8_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W10
df_GLES17$ClimateChange_W10 <- as.numeric(as.character(df_GLES17$kp10_1290))
df_GLES17$ClimateChange_W10[df_GLES17$kp10_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W10[df_GLES17$kp10_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W11
df_GLES17$ClimateChange_W11 <- as.numeric(as.character(df_GLES17$kp11_1290))
df_GLES17$ClimateChange_W11[df_GLES17$kp11_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W11[df_GLES17$kp11_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W12
df_GLES17$ClimateChange_W12 <- as.numeric(as.character(df_GLES17$kp12_1290))
df_GLES17$ClimateChange_W12[df_GLES17$kp12_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W12[df_GLES17$kp12_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W13
df_GLES17$ClimateChange_W13 <- as.numeric(as.character(df_GLES17$kp13_1290))
df_GLES17$ClimateChange_W13[df_GLES17$kp13_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W13[df_GLES17$kp13_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W14
df_GLES17$ClimateChange_W14 <- as.numeric(as.character(df_GLES17$kp14_1290))
df_GLES17$ClimateChange_W14[df_GLES17$kp14_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W14[df_GLES17$kp14_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7

#W15
df_GLES17$ClimateChange_W15 <- as.numeric(as.character(df_GLES17$kp15_1290))
df_GLES17$ClimateChange_W15[df_GLES17$kp15_1290=="1 Vorrang fuer Bekaempfung des Klimawandels"] <- 1
df_GLES17$ClimateChange_W15[df_GLES17$kp15_1290=="7 Vorrang fuer Wirtschaftswachstum"] <-7



#### >>> Variable: Stable climate over economy & economy over climate (global) ####

## Variable provides number of people who are either in favor over prioritizing climate
## protection measures over economy or vice-versa.
## Variable is calculated for five different times spans (Wave 4=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=climate over economy
## 3=economy over climate

## W4-W8
df_GLES17$StableClimate_W4W8 <- 1
#climate over economy
df_GLES17$StableClimate_W4W8 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                         df_GLES17$ClimateChange_W8<4,2,df_GLES17$StableClimate_W4W8)
#economy over climate
df_GLES17$StableClimate_W4W8 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                         df_GLES17$ClimateChange_W8>4,3,df_GLES17$StableClimate_W4W8)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_W4W8 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                         is.na(df_GLES17$ClimateChange_W8),NA,df_GLES17$StableClimate_W4W8)

## W4-W13
df_GLES17$StableClimate_W4W13 <- 1
#climate over economy
df_GLES17$StableClimate_W4W13 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                          df_GLES17$ClimateChange_W8<4 &
                                          df_GLES17$ClimateChange_W13<4,2,df_GLES17$StableClimate_W4W13)
#economy over climate
df_GLES17$StableClimate_W4W13 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                          df_GLES17$ClimateChange_W8>4 &
                                          df_GLES17$ClimateChange_W13>4,3,df_GLES17$StableClimate_W4W13)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_W4W13 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                          is.na(df_GLES17$ClimateChange_W8) | 
                                          is.na(df_GLES17$ClimateChange_W13),NA,df_GLES17$StableClimate_W4W13)

## W4-W14
df_GLES17$StableClimate_W4W14 <- 1
#climate over economy
df_GLES17$StableClimate_W4W14 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                          df_GLES17$ClimateChange_W8<4 &
                                          df_GLES17$ClimateChange_W13<4 &
                                          df_GLES17$ClimateChange_W14<4,2,df_GLES17$StableClimate_W4W14)
#economy over climate
df_GLES17$StableClimate_W4W14 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                          df_GLES17$ClimateChange_W8>4 &
                                          df_GLES17$ClimateChange_W13>4 &
                                          df_GLES17$ClimateChange_W14>4,3,df_GLES17$StableClimate_W4W14)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_W4W14 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                          is.na(df_GLES17$ClimateChange_W8) | 
                                          is.na(df_GLES17$ClimateChange_W13) | 
                                          is.na(df_GLES17$ClimateChange_W14),NA,df_GLES17$StableClimate_W4W14)

## W4-W15
df_GLES17$StableClimate_W4W15 <- 1
#climate over economy
df_GLES17$StableClimate_W4W15 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                          df_GLES17$ClimateChange_W8<4 &
                                          df_GLES17$ClimateChange_W13<4 &
                                          df_GLES17$ClimateChange_W14<4 &
                                          df_GLES17$ClimateChange_W15<4,2,df_GLES17$StableClimate_W4W15)
#economy over climate
df_GLES17$StableClimate_W4W15 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                          df_GLES17$ClimateChange_W8>4 &
                                          df_GLES17$ClimateChange_W13>4 &
                                          df_GLES17$ClimateChange_W14>4 &
                                          df_GLES17$ClimateChange_W15>4,3,df_GLES17$StableClimate_W4W15)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_W4W15 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                          is.na(df_GLES17$ClimateChange_W8) | 
                                          is.na(df_GLES17$ClimateChange_W13) | 
                                          is.na(df_GLES17$ClimateChange_W14) | 
                                          is.na(df_GLES17$ClimateChange_W15),NA,df_GLES17$StableClimate_W4W15)

#### >>> Variable: Alternative - Stable climate over economy & economy over climate (global) ####

## Variable provides number of people who are either in favor over prioritizing climate
## protection measures over economy or vice-versa.
## Variable is calculated for five different times spans (Wave 4=baseline in each,
## subsequent waves as end-point). Coding:
## 1=Other
## 2=climate over economy
## 3=economy over climate
## 4=Neither/nor

## W4-W8
df_GLES17$StableClimate_V2_W4W8 <- 1
#climate over economy
df_GLES17$StableClimate_V2_W4W8 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                            df_GLES17$ClimateChange_W8<4,2,df_GLES17$StableClimate_V2_W4W8)
#economy over climate
df_GLES17$StableClimate_V2_W4W8 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                            df_GLES17$ClimateChange_W8>4,3,df_GLES17$StableClimate_V2_W4W8)
#neither/nor
df_GLES17$StableClimate_V2_W4W8 <- ifelse(df_GLES17$ClimateChange_W4==4 &
                                            df_GLES17$ClimateChange_W8==4,4,df_GLES17$StableClimate_V2_W4W8)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_V2_W4W8 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                            is.na(df_GLES17$ClimateChange_W8),NA,df_GLES17$StableClimate_V2_W4W8)

## W4-W13
df_GLES17$StableClimate_V2_W4W13 <- 1
#climate over economy
df_GLES17$StableClimate_V2_W4W13 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                             df_GLES17$ClimateChange_W8<4 &
                                             df_GLES17$ClimateChange_W13<4,2,df_GLES17$StableClimate_V2_W4W13)
#economy over climate
df_GLES17$StableClimate_V2_W4W13 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                             df_GLES17$ClimateChange_W8>4 &
                                             df_GLES17$ClimateChange_W13>4,3,df_GLES17$StableClimate_V2_W4W13)
#neither/nor
df_GLES17$StableClimate_V2_W4W13 <- ifelse(df_GLES17$ClimateChange_W4==4 &
                                             df_GLES17$ClimateChange_W8==4 &
                                             df_GLES17$ClimateChange_W13==4,4,df_GLES17$StableClimate_V2_W4W13)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_V2_W4W13 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                             is.na(df_GLES17$ClimateChange_W8) | 
                                             is.na(df_GLES17$ClimateChange_W13),NA,df_GLES17$StableClimate_V2_W4W13)

## W4-W14
df_GLES17$StableClimate_V2_W4W14 <- 1
#climate over economy
df_GLES17$StableClimate_V2_W4W14 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                             df_GLES17$ClimateChange_W8<4 &
                                             df_GLES17$ClimateChange_W13<4 &
                                             df_GLES17$ClimateChange_W14<4,2,df_GLES17$StableClimate_V2_W4W14)
#economy over climate
df_GLES17$StableClimate_V2_W4W14 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                             df_GLES17$ClimateChange_W8>4 &
                                             df_GLES17$ClimateChange_W13>4 &
                                             df_GLES17$ClimateChange_W14>4,3,df_GLES17$StableClimate_V2_W4W14)
#neither/nor
df_GLES17$StableClimate_V2_W4W14 <- ifelse(df_GLES17$ClimateChange_W4==4 &
                                             df_GLES17$ClimateChange_W8==4 &
                                             df_GLES17$ClimateChange_W13==4 &
                                             df_GLES17$ClimateChange_W14==4,4,df_GLES17$StableClimate_V2_W4W14)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_V2_W4W14 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                             is.na(df_GLES17$ClimateChange_W8) | 
                                             is.na(df_GLES17$ClimateChange_W13) | 
                                             is.na(df_GLES17$ClimateChange_W14),NA,df_GLES17$StableClimate_V2_W4W14)

## W4-W15
df_GLES17$StableClimate_V2_W4W15 <- 1
#climate over economy
df_GLES17$StableClimate_V2_W4W15 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                             df_GLES17$ClimateChange_W8<4 &
                                             df_GLES17$ClimateChange_W13<4 &
                                             df_GLES17$ClimateChange_W14<4 &
                                             df_GLES17$ClimateChange_W15<4,2,df_GLES17$StableClimate_V2_W4W15)
#economy over climate
df_GLES17$StableClimate_V2_W4W15 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                             df_GLES17$ClimateChange_W8>4 &
                                             df_GLES17$ClimateChange_W13>4 &
                                             df_GLES17$ClimateChange_W14>4 &
                                             df_GLES17$ClimateChange_W15>4,3,df_GLES17$StableClimate_V2_W4W15)
#economy over climate
df_GLES17$StableClimate_V2_W4W15 <- ifelse(df_GLES17$ClimateChange_W4==4 &
                                             df_GLES17$ClimateChange_W8==4 &
                                             df_GLES17$ClimateChange_W13==4 &
                                             df_GLES17$ClimateChange_W14==4 &
                                             df_GLES17$ClimateChange_W15==4,4,df_GLES17$StableClimate_V2_W4W15)
#Code all those with missing values on either of the climate policy variables as missing:
df_GLES17$StableClimate_V2_W4W15 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                             is.na(df_GLES17$ClimateChange_W8) | 
                                             is.na(df_GLES17$ClimateChange_W13) | 
                                             is.na(df_GLES17$ClimateChange_W14) | 
                                             is.na(df_GLES17$ClimateChange_W15),NA,df_GLES17$StableClimate_V2_W4W15)

#### >>> Variable: unstable, Stable climate over economy/stable economy over climate (wave2wave) ####

## Variable provides number of people who are either in favor over prioritizing climate
## protection measures over economy or vice-versa.
## Variable is calculated for five different times spans (wave to wave). Coding:
## 1=Other
## 2=stable climate over economy/stable economy over climate

## W4-W8
df_GLES17$StableClimate_W2W_W4W8 <- 1
#Non-Interested
df_GLES17$StableClimate_W2W_W4W8 <- ifelse(df_GLES17$ClimateChange_W4<4 &
                                             df_GLES17$ClimateChange_W8<4,2,df_GLES17$StableClimate_W2W_W4W8)
#Interested
df_GLES17$StableClimate_W2W_W4W8 <- ifelse(df_GLES17$ClimateChange_W4>4 &
                                             df_GLES17$ClimateChange_W8>4,2,df_GLES17$StableClimate_W2W_W4W8)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableClimate_W2W_W4W8 <- ifelse(is.na(df_GLES17$ClimateChange_W4) | 
                                             is.na(df_GLES17$ClimateChange_W8),NA,df_GLES17$StableClimate_W2W_W4W8)

## W8-W13
df_GLES17$StableClimate_W2W_W8W13 <- 1
#Non-Interested
df_GLES17$StableClimate_W2W_W8W13 <- ifelse(df_GLES17$ClimateChange_W8<4 &
                                              df_GLES17$ClimateChange_W13<4,2,df_GLES17$StableClimate_W2W_W8W13)
#Interested
df_GLES17$StableClimate_W2W_W8W13 <- ifelse(df_GLES17$ClimateChange_W8>4 &
                                              df_GLES17$ClimateChange_W13>4,2,df_GLES17$StableClimate_W2W_W8W13)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableClimate_W2W_W8W13 <- ifelse(is.na(df_GLES17$ClimateChange_W8) | 
                                              is.na(df_GLES17$ClimateChange_W13),NA,df_GLES17$StableClimate_W2W_W8W13)

## W13-W14
df_GLES17$StableClimate_W2W_W13W14 <- 1
#Non-Interested
df_GLES17$StableClimate_W2W_W13W14 <- ifelse(df_GLES17$ClimateChange_W13<4 &
                                               df_GLES17$ClimateChange_W14<4,2,df_GLES17$StableClimate_W2W_W13W14)
#Interested
df_GLES17$StableClimate_W2W_W13W14 <- ifelse(df_GLES17$ClimateChange_W13>4 &
                                               df_GLES17$ClimateChange_W14>4,2,df_GLES17$StableClimate_W2W_W13W14)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableClimate_W2W_W13W14 <- ifelse(is.na(df_GLES17$ClimateChange_W13) | 
                                               is.na(df_GLES17$ClimateChange_W14),NA,df_GLES17$StableClimate_W2W_W13W14)

## W14-W15
df_GLES17$StableClimate_W2W_W14W15 <- 1
#Non-Interested
df_GLES17$StableClimate_W2W_W14W15 <- ifelse(df_GLES17$ClimateChange_W14<4 &
                                               df_GLES17$ClimateChange_W15<4,2,df_GLES17$StableClimate_W2W_W14W15)
#Interested
df_GLES17$StableClimate_W2W_W14W15 <- ifelse(df_GLES17$ClimateChange_W14>4 &
                                               df_GLES17$ClimateChange_W15>4,2,df_GLES17$StableClimate_W2W_W14W15)
#Code all those with missing values on either of the political interest variables as missing:
df_GLES17$StableClimate_W2W_W14W15 <- ifelse(is.na(df_GLES17$ClimateChange_W14) | 
                                               is.na(df_GLES17$ClimateChange_W15),NA,df_GLES17$StableClimate_W2W_W14W15)


#### >>> Absolute differences in scores between panel waves ####

## Because the scales of different concepts do have different ranges, we could normalize
## here using the proportion of maximum scaling method. This approach maintains
## "the proportions of the absolute distances between the observed response
## options." (Moeller 2015, 3)
# Moeller, J. 2015. A word on standardization in longitudinal studies: don't.
# Frontiers in Psychology. Vol.6, 1389.
## However, since the climate scale is the only scale that runs on seven points,
## we rescale it so that it runs from 1 to 5.

## Step 1: rescaling climate change scale

# Function to rescale from seven to five points:
scaling15 <- function(x){(x-1)*(4/6) + 1}

## normalizing the measures
df_GLES17 <- df_GLES17 %>%
  ##Climate Protection 5 point scale
  mutate(ClimateChange_W4_5pscaled=scaling15(ClimateChange_W4), #measured in Wave 4
         ClimateChange_W8_5pscaled=scaling15(ClimateChange_W8),
         ClimateChange_W9_5pscaled=NA, #econ perceptions not measured in Wave 9
         ClimateChange_W13_5pscaled=scaling15(ClimateChange_W13),
         ClimateChange_W14_5pscaled=scaling15(ClimateChange_W14),
         ClimateChange_W15_5pscaled=scaling15(ClimateChange_W15))

## Step 2: absolute distances in scores between panel waves

## adding absolute distance
df_GLES17 <- df_GLES17 %>%
  ##Populism (continuous measure)
  mutate(Pop_W5_W8_Abs=abs(Populism_Goertz_AbsoluteMinimum_W5-
                             Populism_Goertz_AbsoluteMinimum_W8), 
         Pop_W8_W9_Abs=abs(Populism_Goertz_AbsoluteMinimum_W8-
                             Populism_Goertz_AbsoluteMinimum_W9),
         Pop_W9_W13_Abs=abs(Populism_Goertz_AbsoluteMinimum_W9-
                              Populism_Goertz_AbsoluteMinimum_W13),
         Pop_W13_W14_Abs=abs(Populism_Goertz_AbsoluteMinimum_W13-
                               Populism_Goertz_AbsoluteMinimum_W14),
         Pop_W14_W15_Abs=abs(Populism_Goertz_AbsoluteMinimum_W14-
                               Populism_Goertz_AbsoluteMinimum_W15)) %>%
  ##Populism (continuous measure recategorized)
  mutate(Pop_W5_W8_Abs_cat=abs(Populism_Cat_V1_W5-
                                 Populism_Cat_V1_W8), 
         Pop_W8_W9_Abs_cat=abs(Populism_Cat_V1_W8-
                                 Populism_Cat_V1_W9),
         Pop_W9_W13_Abs_cat=abs(Populism_Cat_V1_W9-
                                  Populism_Cat_V1_W13),
         Pop_W13_W14_Abs_cat=abs(Populism_Cat_V1_W13-
                                   Populism_Cat_V1_W14),
         Pop_W14_W15_Abs_cat=abs(Populism_Cat_V1_W14-
                                   Populism_Cat_V1_W15)) %>%
  ##Political Interest
  mutate(PolInt_W5_W8_Abs=abs(PolInt_W5-
                                PolInt_W8), 
         PolInt_W8_W9_Abs=abs(PolInt_W8-
                                PolInt_W9),
         PolInt_W9_W13_Abs=abs(PolInt_W9-
                                 PolInt_W13),
         PolInt_W13_W14_Abs=abs(PolInt_W13-
                                  PolInt_W14),
         PolInt_W14_W15_Abs=abs(PolInt_W14-
                                  PolInt_W15)) %>%
  ##Government Satisfaction
  mutate(GovSat_W5_W8_Abs=abs(GovSat_W5-
                                GovSat_W8), 
         GovSat_W8_W9_Abs=NA, #not measured in Wave 9
         GovSat_W8_W13_Abs=abs(GovSat_W8- #captures change between two available measure points
                                 GovSat_W13),
         GovSat_W13_W14_Abs=abs(GovSat_W13- #captures change between two available measure points
                                  GovSat_W14),
         GovSat_W14_W15_Abs=abs(GovSat_W14-
                                  GovSat_W15)) %>%
  ##Economic Evaluation
  mutate(EcoPercSocio_W5_W8_Abs=abs(EcoPercSocio_W5-
                                      EcoPercSocio_W8), 
         EcoPercSocio_W8_W9_Abs=NA, #not measured in Wave 9
         EcoPercSocio_W8_W13_Abs=abs(EcoPercSocio_W8- #captures change between two available measure points
                                       EcoPercSocio_W13),
         EcoPercSocio_W13_W14_Abs=abs(EcoPercSocio_W13- #captures change between two available measure points
                                        EcoPercSocio_W14),
         EcoPercSocio_W14_W15_Abs=abs(EcoPercSocio_W14-
                                        EcoPercSocio_W15)) %>%
  ##Climate Protection
  mutate(ClimateChange_W5_W8_Abs=abs(ClimateChange_W4_5pscaled- # measured in Wave 4 insted of 5
                                       ClimateChange_W8_5pscaled), 
         ClimateChange_W8_W9_Abs=NA, #not measured in Wave 9
         ClimateChange_W8_W13_Abs=abs(ClimateChange_W8_5pscaled- 
                                        ClimateChange_W13_5pscaled),
         ClimateChange_W13_W14_Abs=abs(ClimateChange_W13_5pscaled- #captures change between two available measure points
                                         ClimateChange_W14_5pscaled),
         ClimateChange_W14_W15_Abs=abs(ClimateChange_W14_5pscaled-
                                         ClimateChange_W15_5pscaled)) %>%
  ##Anti-Elitism
  mutate(AE_W5_W8_Abs=abs(Anti_Elitism_Mean_W5-
                            Anti_Elitism_Mean_W8), 
         AE_W8_W9_Abs=abs(Anti_Elitism_Mean_W8-
                            Anti_Elitism_Mean_W9),
         AE_W9_W13_Abs=abs(Anti_Elitism_Mean_W9-
                             Anti_Elitism_Mean_W13),
         AE_W13_W14_Abs=abs(Anti_Elitism_Mean_W13-
                              Anti_Elitism_Mean_W14),
         AE_W14_W15_Abs=abs(Anti_Elitism_Mean_W14-
                              Anti_Elitism_Mean_W15)) %>%
  ##Homogeneity
  mutate(HO_W5_W8_Abs=abs(Homogeneity_Mean_W5-
                            Homogeneity_Mean_W8), 
         HO_W8_W9_Abs=abs(Homogeneity_Mean_W8-
                            Homogeneity_Mean_W9),
         HO_W9_W13_Abs=abs(Homogeneity_Mean_W9-
                             Homogeneity_Mean_W13),
         HO_W13_W14_Abs=abs(Homogeneity_Mean_W13-
                              Homogeneity_Mean_W14),
         HO_W14_W15_Abs=abs(Homogeneity_Mean_W14-
                              Homogeneity_Mean_W15)) %>%
  ##Sovereignty
  mutate(SO_W5_W8_Abs=abs(Sovereignty_Mean_W5-
                            Sovereignty_Mean_W8), 
         SO_W8_W9_Abs=abs(Sovereignty_Mean_W8-
                            Sovereignty_Mean_W9),
         SO_W9_W13_Abs=abs(Sovereignty_Mean_W9-
                             Sovereignty_Mean_W13),
         SO_W13_W14_Abs=abs(Sovereignty_Mean_W13-
                              Sovereignty_Mean_W14),
         SO_W14_W15_Abs=abs(Sovereignty_Mean_W14-
                              Sovereignty_Mean_W15))

## Add within respondent average abs change and sd (absolute change and pop attitudes)
df_GLES17 <- df_GLES17 %>%
  rowwise() %>%
  ##Populism (continuous)
  mutate(Pop_W5_W15_Av_Abs=mean(c(Pop_W5_W8_Abs, Pop_W8_W9_Abs,
                                  Pop_W9_W13_Abs, Pop_W13_W14_Abs, 
                                  Pop_W14_W15_Abs), na.rm=T),
         #let's get average score across the waves for each respondent, too
         Pop_W5_W15_mean=mean(c(Populism_Goertz_AbsoluteMinimum_W5, Populism_Goertz_AbsoluteMinimum_W8,
                                Populism_Goertz_AbsoluteMinimum_W9, Populism_Goertz_AbsoluteMinimum_W13, 
                                Populism_Goertz_AbsoluteMinimum_W14, Populism_Goertz_AbsoluteMinimum_W15), na.rm=T),
         Pop_W5_W15_sd=sd(c(Populism_Goertz_AbsoluteMinimum_W5, Populism_Goertz_AbsoluteMinimum_W8,
                            Populism_Goertz_AbsoluteMinimum_W9, Populism_Goertz_AbsoluteMinimum_W13, 
                            Populism_Goertz_AbsoluteMinimum_W14, Populism_Goertz_AbsoluteMinimum_W15), na.rm=T),
         Pop_W5_W15_sd_Abs=sd(c(Pop_W5_W8_Abs, Pop_W8_W9_Abs,
                                Pop_W9_W13_Abs, Pop_W13_W14_Abs, 
                                Pop_W14_W15_Abs), na.rm=T))%>%
  ##Populism (recategorized into five point scale)
  mutate(Pop_W5_W15_Av_Abs_cat=mean(c(Pop_W5_W8_Abs_cat, Pop_W8_W9_Abs_cat,
                                      Pop_W9_W13_Abs_cat, Pop_W13_W14_Abs_cat, 
                                      Pop_W14_W15_Abs_cat), na.rm=T),
         Pop_W5_W15_mean_cat=mean(c(Populism_Cat_V1_W5, Populism_Cat_V1_W8,
                                    Populism_Cat_V1_W9, Populism_Cat_V1_W13, 
                                    Populism_Cat_V1_W14, Populism_Cat_V1_W15), na.rm=T),
         Pop_W5_W15_sd_cat=sd(c(Populism_Cat_V1_W5, Populism_Cat_V1_W8,
                                Populism_Cat_V1_W9, Populism_Cat_V1_W13, 
                                Populism_Cat_V1_W14, Populism_Cat_V1_W15), na.rm=T),
         Pop_W5_W15_sd_Abs_cat=sd(c(Pop_W5_W8_Abs_cat, Pop_W8_W9_Abs_cat,
                                    Pop_W9_W13_Abs_cat, Pop_W13_W14_Abs_cat, 
                                    Pop_W14_W15_Abs_cat), na.rm=T))%>%
  ##Political Interest
  mutate(PolInt_W5_W15_Av_Abs=mean(c(PolInt_W5_W8_Abs, PolInt_W8_W9_Abs,
                                     PolInt_W9_W13_Abs, PolInt_W13_W14_Abs, 
                                     PolInt_W14_W15_Abs), na.rm=T),
         PolInt_W5_W15_mean=mean(c(PolInt_W5, PolInt_W8,
                                   PolInt_W9, PolInt_W13, 
                                   PolInt_W14, PolInt_W15), na.rm=T),
         PolInt_W5_W15_sd=sd(c(PolInt_W5, PolInt_W8,
                               PolInt_W9, PolInt_W13, 
                               PolInt_W14, PolInt_W15), na.rm=T),
         PolInt_W5_W15_sd_Abs=sd(c(PolInt_W5_W8_Abs, PolInt_W8_W9_Abs,
                                   PolInt_W9_W13_Abs, PolInt_W13_W14_Abs, 
                                   PolInt_W14_W15_Abs), na.rm=T))%>%
  ##Government Satisfaction
  mutate(GovSat_W5_W15_Av_Abs=mean(c(GovSat_W5_W8_Abs, 
                                     GovSat_W8_W13_Abs, GovSat_W13_W14_Abs, 
                                     GovSat_W14_W15_Abs), na.rm=T),
         GovSat_W5_W15_mean=mean(c(GovSat_W5, GovSat_W8,
                                   GovSat_W13, 
                                   GovSat_W14, GovSat_W15), na.rm=T),
         GovSat_W5_W15_sd=sd(c(GovSat_W5, GovSat_W8,
                               GovSat_W13, 
                               GovSat_W14, GovSat_W15), na.rm=T),
         GovSat_W5_W15_sd_Abs=sd(c(GovSat_W5_W8_Abs, 
                                   GovSat_W8_W13_Abs, GovSat_W13_W14_Abs, 
                                   GovSat_W14_W15_Abs), na.rm=T))%>%
  ##Economic Evaluation
  mutate(EcoPercSocio_W5_W15_Av_Abs=mean(c(EcoPercSocio_W5_W8_Abs, 
                                           EcoPercSocio_W8_W13_Abs, 
                                           EcoPercSocio_W13_W14_Abs, 
                                           EcoPercSocio_W14_W15_Abs), na.rm=T),
         EcoPercSocio_W5_W15_mean=mean(c(EcoPercSocio_W5, EcoPercSocio_W8,
                                         EcoPercSocio_W13, 
                                         EcoPercSocio_W14, EcoPercSocio_W15), na.rm=T),
         EcoPercSocio_W5_W15_sd=sd(c(EcoPercSocio_W5, EcoPercSocio_W8,
                                     EcoPercSocio_W13, 
                                     EcoPercSocio_W14, EcoPercSocio_W15), na.rm=T),
         EcoPercSocio_W5_W15_sd_Abs=sd(c(EcoPercSocio_W5_W8_Abs, 
                                         EcoPercSocio_W8_W13_Abs, 
                                         EcoPercSocio_W13_W14_Abs, 
                                         EcoPercSocio_W14_W15_Abs), na.rm=T))%>%
  ##Climate Protection
  mutate(ClimateChange_W5_W15_Av_Abs=mean(c(ClimateChange_W5_W8_Abs, 
                                            ClimateChange_W8_W13_Abs, 
                                            ClimateChange_W13_W14_Abs, 
                                            ClimateChange_W14_W15_Abs), na.rm=T),
         ClimateChange_W5_W15_mean=mean(c(ClimateChange_W4_5pscaled, ClimateChange_W8_5pscaled,
                                          ClimateChange_W13_5pscaled, 
                                          ClimateChange_W14_5pscaled, ClimateChange_W15_5pscaled), na.rm=T),
         ClimateChange_W5_W15_sd=sd(c(ClimateChange_W4_5pscaled, ClimateChange_W8_5pscaled,
                                      ClimateChange_W13_5pscaled, 
                                      ClimateChange_W14_5pscaled, ClimateChange_W15_5pscaled), na.rm=T),
         ClimateChange_W5_W15_sd_Abs=sd(c(ClimateChange_W5_W8_Abs, 
                                          ClimateChange_W8_W13_Abs, 
                                          ClimateChange_W13_W14_Abs, 
                                          ClimateChange_W14_W15_Abs), na.rm=T)) %>%
  ##Anti-Elitism
  mutate(AE_W5_W15_Av_Abs=mean(c(AE_W5_W8_Abs, AE_W8_W9_Abs,
                                 AE_W9_W13_Abs, AE_W13_W14_Abs, 
                                 AE_W14_W15_Abs), na.rm=T),
         AE_W5_W15_mean=mean(c(Anti_Elitism_Mean_W5, Anti_Elitism_Mean_W8,
                               Anti_Elitism_Mean_W9, Anti_Elitism_Mean_W13, 
                               Anti_Elitism_Mean_W14, Anti_Elitism_Mean_W15), na.rm=T),
         AE_W5_W15_sd=sd(c(Anti_Elitism_Mean_W5, Anti_Elitism_Mean_W8,
                           Anti_Elitism_Mean_W9, Anti_Elitism_Mean_W13, 
                           Anti_Elitism_Mean_W14, Anti_Elitism_Mean_W15), na.rm=T),
         AE_W5_W15_sd_Abs=sd(c(AE_W5_W8_Abs, AE_W8_W9_Abs,
                               AE_W9_W13_Abs, AE_W13_W14_Abs, 
                               AE_W14_W15_Abs), na.rm=T))%>%
  ##Homogeneity
  mutate(HO_W5_W15_Av_Abs=mean(c(HO_W5_W8_Abs, HO_W8_W9_Abs,
                                 HO_W9_W13_Abs, HO_W13_W14_Abs, 
                                 HO_W14_W15_Abs), na.rm=T),
         HO_W5_W15_mean=mean(c(Homogeneity_Mean_W5, Homogeneity_Mean_W8,
                               Homogeneity_Mean_W9, Homogeneity_Mean_W13, 
                               Homogeneity_Mean_W14, Homogeneity_Mean_W15), na.rm=T),
         HO_W5_W15_sd=sd(c(Homogeneity_Mean_W5, Homogeneity_Mean_W8,
                           Homogeneity_Mean_W9, Homogeneity_Mean_W13, 
                           Homogeneity_Mean_W14, Homogeneity_Mean_W15), na.rm=T),
         HO_W5_W15_sd_Abs=sd(c(HO_W5_W8_Abs, HO_W8_W9_Abs,
                               HO_W9_W13_Abs, HO_W13_W14_Abs, 
                               HO_W14_W15_Abs), na.rm=T))%>%
  ##Sovereignty
  mutate(SO_W5_W15_Av_Abs=mean(c(SO_W5_W8_Abs, SO_W8_W9_Abs,
                                 SO_W9_W13_Abs, SO_W13_W14_Abs, 
                                 SO_W14_W15_Abs), na.rm=T),
         SO_W5_W15_mean=mean(c(Sovereignty_Mean_W5, Sovereignty_Mean_W8,
                               Sovereignty_Mean_W9, Sovereignty_Mean_W13, 
                               Sovereignty_Mean_W14, Sovereignty_Mean_W15), na.rm=T),
         SO_W5_W15_sd=sd(c(Sovereignty_Mean_W5, Sovereignty_Mean_W8,
                           Sovereignty_Mean_W9, Sovereignty_Mean_W13, 
                           Sovereignty_Mean_W14, Sovereignty_Mean_W15), na.rm=T),
         SO_W5_W15_sd_Abs=sd(c(SO_W5_W8_Abs, SO_W8_W9_Abs,
                               SO_W9_W13_Abs, SO_W13_W14_Abs, 
                               SO_W14_W15_Abs), na.rm=T)) %>%
  ungroup()

##################################################################################################################/
#### >>> Variable: Number of times R crosses opinion boundaries (Wave 5 to W15; Goertz Minimum) ####
#################################################################################################################/

## Counting middle category as ambivalent/lack of opinion
# This variable captures how often respondents cross an opinion boundary such as between
# fully disagree/disagreeing and indifference. Coding is based on StablePop_W2W_W
# variables and counts how often respondents are instable between different waves
# which is equivalent to the number of changes.
switch.count <- df_GLES17 %>%
  select(starts_with("StablePop_V2_W2W_")) %>% 
  filter(complete.cases(.)) %>% ##using only complete cases to ensure we are 
  # looking at the same set of respondents that 
  # we include in the final analysis.
  apply(., 1, function(x) length(which(x=="1"))) 
table(switch.count)

#Add count variable
df_GLES17$switch.count <- apply(df_GLES17[c("StablePop_V2_W2W_W5W8", 
                                            "StablePop_V2_W2W_W8W9",
                                            "StablePop_V2_W2W_W9W13",
                                            "StablePop_V2_W2W_W13W14",
                                            "StablePop_V2_W2W_W14W15")], 1, function(x) length(which(x=="1")))
df_GLES17$switch.count[is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W8) |
                         is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W9) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W13) |
                         is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W14) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W15)] <- NA


#### >>> Variable (alternative) number of times R crosses opinion boundaries (Wave 5 to W15) ####

# This variable captures how often respondents cross an opinion boundary such as between
# fully disagree/disagreeing and indifference. Coding is based on StablePop_W2W_W
# variables and counts how often respondents are instable between different waves
# which is equivalent to the number of changes.
switch.count2 <- df_GLES17 %>%
  select(starts_with("StablePop_W2W_")) %>% 
  filter(complete.cases(.)) %>% ##using only complete cases to ensure we are 
  # looking at the same set of respondents that 
  # we include in the final analysis.
  apply(., 1, function(x) length(which(x=="1"))) 
table(switch.count2)

#Add count variable
df_GLES17$switch.count2 <- apply(df_GLES17[c("StablePop_W2W_W5W8", 
                                             "StablePop_W2W_W8W9",
                                             "StablePop_W2W_W9W13",
                                             "StablePop_W2W_W13W14",
                                             "StablePop_W2W_W14W15")], 1, function(x) length(which(x=="1")))
df_GLES17$switch.count2[is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W5) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W8) |
                          is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W9) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W13) |
                          is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W14) | is.na(df_GLES17$Populism_Goertz_AbsoluteMinimum_W15)] <- NA


#### /// Generate Dataset with variables relevant for final analyses ####

#### This creates a dataframe that includes all recoded variables necessary to 
#### run the full analyses
df_GLES17_recoded <- df_GLES17 %>%
  select(lfdn, #ID Variable
         starts_with(c("Anti_Elite_W", "Homogeneity_W", "Sovereignty_W", #Individual items for invariance test
                       #Mean scores for each dimension
                       "Anti_Elitism_Mean_", "Homogeneity_Mean_", "Sovereignty_Mean_",
                       #Minimum populist dimension scores (different aggregations)
                       "Populism_Goertz_AbsoluteMinimum_", 
                       "Populism_Goertz_Multiplication_",
                       "Populism_Goertz_AbsoluteMinimum_TwoDim_",
                       #Populism score as categorical variable
                       "Populism_Cat_",
                       #Economic evaluations, government satisfaction, 
                       #immigration attitudes, climate change (econ vs climate) attitudes,
                       #political interest
                       "EcoPercSocio_", "GovSat_", "Immigration_", 
                       "ClimateChange_", "PolInt_", 
                       #Variables capturing intra-individual stability: mid point as 
                       #nuanced opinion (Vars with _V2) & mid point as ambiguity (Vars
                       #WITHOUT _V2)
                       "StablePop_", "StableInt_", "StableGovSat_", "StableEcon_", "StableClimate_",
                       "StableAntiElite_", "Stable_PeopleSov_", "Stable_Homogeneity_",
                       #Count of times people switched
                       "switch.cou",
                       #Democratic Attitudes
                       "DemAtt_")
         ),
         ###Variable capturing absolute change
         #Wave 5 to 8
         "Pop_W5_W8_Abs", "Pop_W5_W8_Abs_cat", "PolInt_W5_W8_Abs", "GovSat_W5_W8_Abs",
         "EcoPercSocio_W5_W8_Abs", "ClimateChange_W5_W8_Abs", "AE_W5_W8_Abs", 
         "HO_W5_W8_Abs", "SO_W5_W8_Abs",
         #Wave 8 to 9
         "Pop_W8_W9_Abs", "Pop_W8_W9_Abs_cat", "PolInt_W8_W9_Abs", "GovSat_W8_W9_Abs",
         "EcoPercSocio_W8_W9_Abs", "ClimateChange_W8_W9_Abs", "AE_W8_W9_Abs", 
         "HO_W8_W9_Abs", "SO_W8_W9_Abs",
         #Wave 9 to 13 (or 8 to 13 in cases of GovSat, Eco, and Climate Change)
         "Pop_W9_W13_Abs", "Pop_W9_W13_Abs_cat", "PolInt_W9_W13_Abs", "GovSat_W8_W13_Abs",
         "EcoPercSocio_W8_W13_Abs", "ClimateChange_W8_W13_Abs", "AE_W9_W13_Abs", 
         "HO_W9_W13_Abs", "SO_W9_W13_Abs",
         #Wave 13 to 14
         "Pop_W13_W14_Abs", "Pop_W13_W14_Abs_cat", "PolInt_W13_W14_Abs", "GovSat_W13_W14_Abs",
         "EcoPercSocio_W13_W14_Abs", "ClimateChange_W13_W14_Abs", "AE_W13_W14_Abs", 
         "HO_W13_W14_Abs", "SO_W13_W14_Abs",
         #Wave 14 to 15
         "Pop_W14_W15_Abs", "Pop_W14_W15_Abs_cat", "PolInt_W14_W15_Abs", "GovSat_W14_W15_Abs",
         "EcoPercSocio_W14_W15_Abs", "ClimateChange_W14_W15_Abs", "AE_W14_W15_Abs", 
         "HO_W14_W15_Abs", "SO_W14_W15_Abs",
         #Across Waves
         "Pop_W5_W15_Av_Abs", "Pop_W5_W15_Av_Abs_cat", "PolInt_W5_W15_Av_Abs",
         "GovSat_W5_W15_Av_Abs", "EcoPercSocio_W5_W15_Av_Abs", "ClimateChange_W5_W15_Av_Abs",
         "AE_W5_W15_Av_Abs", "HO_W5_W15_Av_Abs", "SO_W5_W15_Av_Abs",
         #Across Waves
         "Pop_W5_W15_sd_Abs", "Pop_W5_W15_sd_Abs_cat", "PolInt_W5_W15_sd_Abs",
         "GovSat_W5_W15_sd_Abs", "EcoPercSocio_W5_W15_sd_Abs", "ClimateChange_W5_W15_sd_Abs",
         "AE_W5_W15_sd_Abs", "HO_W5_W15_sd_Abs", "SO_W5_W15_sd_Abs",
         #Vote Choice
         "Vote_List_W58",
         #Additional variables
         "Populism_Extremity_W5", "PiD", "Turnout", "Age", "Uni_Edu", "ostwest"
  )
write.csv(df_GLES17_recoded, "df_GLES17_recoded.csv")

#### R-Script END ####