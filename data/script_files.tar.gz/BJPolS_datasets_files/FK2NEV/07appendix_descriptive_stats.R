rm(list = ls())
gc()

library(lubridate)
library(tidyverse)
library(foreign)
library(ggplot2)
library(ggthemes)
library(estimatr)
library(mice)
library(summarytools)

df = readRDS("data/svy.rds")

df$intg_connected
df %>% names
df$location_its

# Econ Lebanon ------------------------------------------------------------
econ_well_being_leb = c("head_work_legal", "head_work_days_4", "head_work_hours_4", "head_income",
                        "hh_inc_source_aid", "aid_atm", "aid_wfp", "hh_leb_2011", "hh_inc_stable", 
                        "aid_chg", "own_items_1", "own_items_2", "own_items_3", "own_items_4", "own_items_5",
                        "own_items_6", "own_items_7", "own_items_8", "own_items_10", "own_items_11",
                        "expenses_ability", "assets_value", "assets_months", "hh_income")


x = summarytools::descr(df[,econ_well_being_leb], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,econ_well_being_leb], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
        "aid_atm" =  "Aid: atm card",
        "aid_chg" = "Aid change from last year",
        "aid_wfp" = "Aid: wfp card",
        "assets_months" = "Assets: months left",
        "assets_value" = "Assets: value upon arrival",
        "expenses_ability" = "Ability to cover expenses",
        "head_income" = "Income",
        "head_work_days_4" = "Work days past 4 weeks",
        "head_work_hours_4" = "Work hours past 4 weeks",
        "head_work_legal" = "Able to work legally",
        "hh_inc_source_aid" = "Income source: aid",
        "hh_inc_stable" = "Stable household income",
        "hh_income" = "Household income",
        "hh_leb_2011" = "HH worked in Leb. before 2011",
        "own_items_1" = "Own refrigerator",
        "own_items_10" = "Have indoor toilet",
        "own_items_11" = "Have central heating",
        "own_items_2" = "Own washing machine",
        "own_items_3" = "Own oven/stove",
        "own_items_4" = "Own computer",
        "own_items_5" = "Own car",
        "own_items_6" = "Own microwave oven",
        "own_items_7" = "Own television",
        "own_items_8" = "Have internet"
        ))

tab = x %>% xtable::xtable() %>% 
  xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_econ_leb.tex")




 # Social Lebanon ------------------------------------------------------------
df$ipl_connected = 6 - df$intg_connected
df$ipl_outsider = 6 - df$intg_outsider
df$ipl_arabic = 4 - df$enum_arabic #reversing order of variable
df$ipl_literate = 4 - df$head_literate #reversing order of variable
df$ipl_politics = 6 - df$intg_politics #reversing order of variable
df$ipl_discuss = df$intg_discuss
df$ipl_meal = df$meal_share
df$ipl_lebanese = df$lebanese_contacts
df$ipl_doctor = 6 - df$intg_access_doctor #reversing order of variable
df$ipl_job = 6 - df$intg_access_job #reversing order of variable
df$ipl_syrian = df$syrian_contacts

df$ind_public_treat = df$public_treat_person
df$ind_public_treat = 5 - df$ind_public_treat #reverse coding 
df$public_treat_person = NULL

df$ind_auth_treat = df$auth_treat_person
df$ind_auth_treat = 5 - df$ind_auth_treat #reverse coding 

df$not_detained = df$detained
df$not_detained = 1 - df$not_detained #reverse coding
df$detained = NULL

df$no_disc_housing = df$disc_housing
df$disc_housing = NULL

df$ind_mobility = df$mobility
df$ind_mobility = 5 - df$ind_mobility #reverse coding

df$ind_mobility_hh = df$mobility_hh
df$ind_mobility_hh = 4 - df$ind_mobility_hh #revers coding
df$mobility_hh = NULL

soc_well_being_leb = c("ipl_connected", "ipl_outsider", "ipl_arabic", "ipl_literate", "ipl_politics", "ipl_discuss", 
                       "ipl_job", "length_stay", "curfews_never", 
                       "no_curfews_now", "ind_public_treat", "ind_auth_treat", "not_detained", "no_disc_housing", 
                       "ind_mobility", "ind_mobility_hh")

quantile(df$intg_connected, na.rm = T)
sum(df$intg_outsider <= 2, na.rm = T)/3003
df$disc_housing %>% table(useNA = "always") %>% prop.table

table(df$disc_healthcare, useNA = "always") %>% prop.table
table(df$curfews_never) %>% prop.table
df$no_disc_housing %>% table
for(i in 1:length(soc_well_being_leb)){
  x = quantile(df[,soc_well_being_leb[i]], na.rm = T)
  print(soc_well_being_leb[i])
  print(x)
}

x = summarytools::descr(df[,soc_well_being_leb], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,soc_well_being_leb], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "curfews_never" =  "Never had curfews",
                           "ind_auth_treat" = "Authorities discrimination (higher is less)",
                           "ind_mobility" = "Ease of mobility",
                           "ind_mobility_hh" = "Ease of mobility for household",
                           "ind_public_treat" = "Public discrimination (higher is less)",
                           "ipl_arabic" = "Arabic speaking ability",
                           "ipl_connected" = "Relation with Lebanese",
                           "ipl_discuss" = "Discuss Lebanese politics",
                           "ipl_job" = "Ease job search",
                           "ipl_literate" = "Literacy level",
                           "ipl_outsider" = "Feeling outsider (higher is less)",
                           "ipl_politics" = "Know Lebanese politics",
                           "length_stay" = "Time in Lebanon",
                           "no_curfews_now" = "No curfew now",
                           "no_disc_housing" = "Housing discrimination (higher is less)",
                           "not_detained" = "Never detained"))


tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_soc_leb.tex")



# H3 services Lebanon --------------------------------------------------
df$head_not_sick = 1 - df$head_sick #reverse order 
df$head_sick = NULL

df$stability_towns = df$towns_leb
df$stability_towns = with(df, ifelse(stability_towns == 1, 3,
                                         ifelse(stability_towns == 2, 2,
                                                ifelse(stability_towns > 2, 1, stability_towns))))
df$towns_leb = NULL

df = df %>% 
  mutate(stability_current = cut(stability_current, breaks = quantile(stability_current, na.rm = T), include.lowest = T),
         stability_current = as.numeric(stability_current)) %>% 
  ungroup()

df$access_legal = 6 - df$intg_access_legal #reverse coding


services_lebanon = c("head_not_sick", "head_treated", "person_nosick", "person_treat", 
                     "ipl_doctor", "disc_healthcare", "no_need_school", 
                     "stability_towns", "stability_current", "scl_not_preventive", "access_legal", "own_items_9")
summary(df[, services_lebanon])
df$head_not_sick %>% table
df$head_treated %>% table
df$head_sick %>% table
df$head_treated %>% table
table(df$intg_access_legal)

sum(df$intg_access_legal <= 2, na.rm = T)/3003
sum(df$intg_access_legal >= 4, na.rm = T)/3003

for(i in 1:length(services_lebanon)){
  x = quantile(df[,services_lebanon[i]], na.rm = T)
  print(services_lebanon[i])
  print(x)
}


x = summarytools::descr(df[,services_lebanon], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,services_lebanon], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")

x = x %>%
  mutate(Variable = recode(Variable, 
                           "access_legal" =  "Can access legal services",
                           "disc_healthcare" = "No healthcare discrimination",
                           "head_not_sick" = "Not sick",
                           "head_treated" = "Received treatment (if sick)",
                           "ipl_doctor" = "Can access doctor",
                           "no_need_school" = "No Kids need school",
                           "own_items_9" = "Have running water",
                           "person_nosick" = "No HH member sick",
                           "person_treat" = "HH members treated if sick",
                           "scl_not_preventive" = "School not preventive",
                           "stability_current" = "Period in current town",
                           "stability_towns" = "Towns lived in Lebanon"))

x %>% xtable::xtable() %>% xtable::print.xtable()

tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_services_leb.tex")

# H4: Legal well-being ----------------------------------------------------
df$resident %>% table(useNA = "always")
df$registered %>% table(useNA = "always")

legal_lebanon = c("registered", "resident")
df[,legal_lebanon] %>% summary

table(df$resident) %>% prop.table
table(df$registered) %>% prop.table

x = summarytools::descr(df[,legal_lebanon], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,legal_lebanon], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")

x = x %>%
  mutate(Variable = recode(Variable, 
                           "resident" =  "Legal resident in Lebanon",
                           "registered" = "Registered with UNHCR/UNRWA (or resident)"))


tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_legal_leb.tex")


# H5 Syria safety ---------------------------------------------------------
df$safety_current = df$risk_urban
df$risk_urban = NULL

df$exposure_violence = df$head_violence
df$head_violence = NULL 

df$safe_future = df$safety_chg
df$safe_future = 5 - df$safe_future #reverse coding
df$safety_chg = NULL

df$info_oppsn = rowSums(df[, c("info_trust_arabiya", "info_trust_jazeera")], na.rm = T)/2
df$info_regime = rowSums(df[, c("info_trust_mayadeen", "info_trust_manar")], na.rm = T)/2

df$oppsn_sympathy = ifelse(df$info_oppsn > df$info_regime, 1, 0)

control_syria = c("control_now_regime", "control_now_oppsn", "control_now_russia", "control_now_turkey",
                  "control_now_kurds", "contested_now", "control_past_oppsn", "control_past_russia", 
                  "control_past_regime", "control_past_kurds", "control_past_turkey", "contested_past", "isis_control")

df[, control_syria] %>% summary

x = summarytools::descr(df[,control_syria], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,control_syria], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "contested_now" =  "Contested Now",
                           "contested_past" = "Contested before leaving",
                           "control_now_kurds" =  "Controlled by Kurds now",
                           "control_now_oppsn" =  "Controlled by oppsn/FSA now",
                           "control_now_regime" =  "Controlled by regime now",
                           "control_now_russia" =  "Controlled by Russia now",
                           "control_now_turkey" =  "Controlled by Turkey now",
                           "control_past_kurds" =  "Controlled by Kurds before leaving",
                           "control_past_oppsn" =  "Controlled by oppsn/FSA before leaving",
                           "control_past_regime" =  "Controlled by regime before leaving",
                           "control_past_russia" =  "Controlled by Russia before leaving",
                           "control_past_turkey" =  "Controlled by Turkey before leaving",
                           "isis_control" =  "Controlled by ISIS at some point"))



tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_control_syr.tex")



safety_syria = c("safety_current", "oppsn_sympathy", "protests", "exposure_violence",
                 "safe_future", "conscription")

x = summarytools::descr(df[,safety_syria], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,safety_syria], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "conscription" =  "HH male at conscription age",
                           "exposure_violence" = "Exposed to violence",
                           "oppsn_sympathy" =  "Follow anti-regime media more than pro-regime media",
                           "protests" =  "Hometown had protests",
                           "safe_future" =  "Expect hometown to be safe",
                           "safety_current" =  "Current safety in hometown"))



tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_safety_syr.tex")


# H6 Econ Syria --------------------------------------------------------------
df$debt_fin = NA
df$debt_fin[df$syr_debt == 0] = 0
df$debt_fin[df$syr_debt %in% c(1,2)] = 1
df$debt_fin[df$syr_debt > 2] = 2
df$syr_debt = NULL

econ_syria = c("jobs_origin", "debt_fin", "syr_property_1", "syr_property_2", "syr_property_3", 
               "syr_land_future", "syr_home_doc")

summary(df[, econ_syria])


x = summarytools::descr(df[,econ_syria], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,econ_syria], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "debt_fin" =  "Debt in Syria",
                           "jobs_origin" = "Job situation in origin",
                           "syr_home_doc" =  "Home ownership docs (1 for some, 2 for everything)",
                           "syr_land_future" =  "Can operate land in future",
                           "syr_property_1" =  "Own house in Syria",
                           "syr_property_2" =  "Own apt in Syria",
                           "syr_property_3" =  "Own land in Syria"))

x %>% xtable::xtable() %>% xtable::print.xtable()


tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_econ_syr.tex")


# Services Syria ----------------------------------------------------------
df$services_syr_elect = 6 - df$elect_origin
df$elect_origin = NULL

df$services_syr_water = 6 - df$water_origin
df$water_origin = NULL

df$services_syr_scl = df$schools_origin
df$schools_origin = NULL

df$services_syr_health = df$health_origin
df$health_origin = NULL

df$services_syr_improve = 5 - df$services_chg
df$services_chg = NULL

services_syria = c("services_syr_elect", "services_syr_water", "services_syr_scl", 
                   "services_syr_health", "services_syr_improve")

summary(df[, services_syria])



x = summarytools::descr(df[,services_syria], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,services_syria], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "services_syr_elect" =  "Electricity in origin",
                           "services_syr_health" = "Health services in origin",
                           "services_syr_improve" =  "Expect services to improve in 1 year",
                           "services_syr_scl" =  "Schools in origin",
                           "services_syr_water" =  "Running water in origin"))





tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_services_syr.tex")


# Networks Syria ----------------------------------------------------------
df$syr_stay %>% table(useNA = "always")
df$relatives_rtrn1 %>% table(useNA = "always")
df$relatives_rtrn2 %>% table(useNA = "always")
df$hh_rtrn %>% table(useNA = "always")

networks_syria = c("syr_stay", "relatives_rtrn1", "relatives_rtrn2", "hh_rtrn")
summary(df[, networks_syria])


x = summarytools::descr(df[,networks_syria], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,networks_syria], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "hh_rtrn" =  "No. HH members returned to Syria",
                           "relatives_rtrn1" = "Relatives permanently return to Syria",
                           "relatives_rtrn2" =  "Relatives return to origin",
                           "syr_stay" =  "Syria HH members living in Syria now"))



tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_networks_syr.tex")


# Networks Lebanon --------------------------------------------------------
df$leban_relatives2 = recode(df$leban_relatives, "3" = 0, "2" = 1, "1" = 2, .default = NA_real_)

networks_lebanon = c("hh_syr_leb", "ipl_lebanese", "ipl_syrian", "leban_relatives2", "ipl_meal")
summary(df[, networks_lebanon])

df$leban_relatives %>% table %>% prop.table

x = summarytools::descr(df[,networks_lebanon], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,networks_lebanon], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "hh_syr_leb" =  "Syria HH members living in Leb. now",
                           "ipl_lebanese" = "Lebanese phone contacts",
                           "ipl_meal" =  "Share meals with Lebanese",
                           "ipl_syrian" =  "Syrian phone contacts",
                           "leban_relatives2" = "Lebanese relatives"))



tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_networks_leb.tex")



# Information 9.1 ---------------------------------------------------------
df$info_safe = ifelse(df$know_safe == 1, 1, ifelse(df$know_safe %in% c(2, 3), 0, NA))
df$info_jobs = ifelse(df$know_jobs == 1, 1, ifelse(df$know_jobs %in% c(2, 3), 0, NA))
df$info_services = ifelse(df$know_services == 1, 1, ifelse(df$know_services %in% c(2, 3), 0, NA))
df$info_conscription = ifelse(df$know_conscription == 1, 1, ifelse(df$know_conscription %in% c(2, 3), 0, NA))

df$info_syr_communicate = df$communicate_freq_urb
df$info_syr_communicate = 7 - df$info_syr_communicate

info_quality = c("info_safe", "info_jobs", "info_services", "info_conscription", "info_syr_rln", "info_syr_communicate")
summary(df[, info_quality])


x = summarytools::descr(df[,info_quality], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,info_quality], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "info_conscription" =  "Know Syr. conscription policy",
                           "info_jobs" = "Know employment in origin",
                           "info_safe" =  "Know safety in origin",
                           "info_services" =  "Know services in origin",
                           "info_syr_communicate" = "Communication freq. with origin",
                           "info_syr_rln" = "Communication with someone in Syria"))





tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_info_syr.tex")



# Preparation outcome -------------------------------------------------------
df$prep_resources = df$rtrn_resources
df$rtrn_resources = NULL

df$prep_docs = df$rtrn_docs
df$rtrn_docs = NULL

df$prep_author = df$rtrn_author
df$rtrn_author = NULL

df$prep_unhcr = df$rtrn_unhcr
df$rtrn_unhcr = NULL

df$prep_scope = df$rtrn_scope
df$rtrn_scope = NULL

df$prep_abort = df$rtrn_abort
df$rtrn_abort = NULL

vars = c("prep_resources", "prep_docs", "prep_author", "prep_unhcr", "prep_scope", "prep_abort")
df[,vars] %>% summary

x = summarytools::descr(df[,vars], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,vars], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "prep_abort" =  "Planned to return but aborted",
                           "prep_author" = "Reached to Leb. authorities about return",
                           "prep_docs" =  "Prepared docs for return",
                           "prep_resources" =  "Saved resources for return",
                           "prep_scope" = "Conducting scoping trip to Syria",
                           "prep_unhcr" = "Reached to UNHCR about return"))





tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_prep_rtrn.tex")



# Summary covariates -------------------------------------------------------
df$head_educ2 = recode(df$head_educ, "6" = 1, "5" = 1, "4" = 1, "3" = 0, "2" = 0, "1" = 0, .default = NA_real_)
df$head_educ = NULL

# switch source
hezb = readRDS("data/hezb_control.rds")
hezb$response_num %>% summary
hezb$hezb_control %>% table

df = df %>% left_join(hezb)
df$hezb_control %>% table(useNA = "always")

covars = c("syr_origin_urban", "location_its", "sick", "head_educ2", "toddler", "elderly", "female_headed_hh", "hezb_control")
df[,covars] %>% summary

x = summarytools::descr(df[,covars], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,covars], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "elderly" =  "Household includes elderly",
                           "female_headed_hh" = "Female headed single-parent household",
                           "head_educ2" =  "High school graduate",
                           "hezb_control" =  "Hezbollah controlled area",
                           "location_its" = "Location: Tental settlement",
                           "sick" = "Sick required medical treatment",
                           "syr_origin_urban" = "Syria origin: urban",
                           "toddler" = "Household includes toddler"))





tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_covars.tex")



# mobility index ----------------------------------------------------------
mobility = read.csv("data/google_maps_travel_distance_output.csv", stringsAsFactors = F)

mobility = mobility %>% select(response_num, log_travel_distance) %>% rename(index_mobility = log_travel_distance)

df = df %>% left_join(mobility)

df$index_family = log(df$hh_size + 1) #family size = household size + head of household

mobility_inputs = c("index_family", "index_mobility")
df[,mobility_inputs] %>% summary


x = summarytools::descr(df[,mobility_inputs], transpose = T, stats = c("mean", "sd", "min", "med", "max", "n.valid", "pct.valid"), round.digits = 2)
x$N.Valid = NULL
x$Pct.Missing = 100 - x$Pct.Valid
x$Pct.Valid = NULL
x$Unweighted.Mean = x$Mean
x$Mean = NULL
x$Variable = row.names(x)
x = x %>% as_tibble

weighted = summarytools::descr(df[,mobility_inputs], transpose = T, stats = c("mean", "sd"), weights = df$weights)
weighted$Variable = row.names(weighted)
weighted = weighted %>% as_tibble

weighted = weighted %>% select(Variable, Mean) %>% rename(Weighted.Mean = Mean)
x = x %>% left_join(weighted)

x = x %>% select(Variable, Weighted.Mean, Unweighted.Mean, everything())
x$Pct.Missing[x$Pct.Missing < 0.005 & x$Pct.Missing > 0]
x[,2:ncol(x)] = x[,2:ncol(x)] %>% round(2)
x$Pct.Missing = sapply(x$Pct.Missing, sprintf, fmt = "%.2f", how = "replace")

x$Pct.Missing = paste0(x$Pct.Missing, "%")
x = x %>%
  mutate(Variable = recode(Variable, 
                           "index_family" =  "household size (logged)",
                           "index_mobility" = "travel distance (logged)"))


tab = x %>% xtable::xtable() %>% xtable::print.xtable(include.rownames = F)

tab = substr(tab, str_locate(tab, "centering")[2]+2, str_locate(tab, "end\\{table")[2]-10)

cat(tab, file = "out/descriptive/summary_mobility.tex")

