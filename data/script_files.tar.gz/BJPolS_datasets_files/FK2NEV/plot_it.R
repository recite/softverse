plotit2 <- function(d, effect.label,x.lower = NULL,x.upper = NULL, labs, title, facet = NULL, legend = FALSE){  
  
  if(labs == F){
    lab = "element_blank()"
    h_just = 0.4 #title position
  }else{
    lab = "element_text(size = base_size, hjust = 0 , vjust=.5, face = rev(plot.face))"
    h_just = 0.55
  }
  
  
  CIs <- function(d){
    d$upper90 <-d$pe + d$z90*d$se
    d$lower90 <-d$pe - d$z90*d$se
    d$upper95 <-d$pe + d$z95*d$se
    d$lower95 <-d$pe - d$z95*d$se
    return(d)
  }
  d <- CIs(d)
  
  plot.labels <- as.character(d$name)
  
  plot.labels[d$group != "empty" & 
                !is.na(plot.labels) & d$solo == 0] <- 
    paste("    ",
          plot.labels[d$group != "empty" & 
                        !is.na(plot.labels) & d$solo == 0], sep = "")
  
  d$solo = 0
  
  plot.face <- ifelse(is.na(d$pe) | d$solo == 1, "bold", "plain")
  
  d$ref <- ifelse(d$type == "indiv_indices", "Individual indices", "All indices")
  
  d$order <- as.factor(d$order)
  
  legend_position = ifelse(legend == TRUE, "bottom", "none")
  
  #Construct plot
  p <- ggplot(d,aes(y=pe,x=order,color=group,shape=ref, group = type))
  
  if (!is.null(x.lower) & !is.null(x.upper)){
    p <- p + coord_flip(ylim = c(x.lower,x.upper)) 
  } else {
    p <- p + coord_flip() 
  }
  
  # if(!is.null(facet)){
  #   p <- p + facet_wrap(facet)
  # }
  
  p <- p + ylab(effect.label)
  p <- p + geom_hline(yintercept = 0,size=.5,colour="darkgrey",linetype=1) 
  p <- p + geom_pointrange(aes(ymin=lower90,ymax=upper90), 
                           position= position_dodge(width = .7), size = 0.5) + 
    geom_pointrange(aes(ymin=lower95, ymax=upper95, alpha = I(0.65)),
                    position= position_dodge(width = .7), size = 0.5)
  
  
  p <- p + scale_colour_discrete("Attribute:", guide = FALSE) + 
    scale_x_discrete(name="",labels=rev(plot.labels))
  
  theme_bw1 <- function(base_size = 8, base_family = "") {
    theme_economist(base_size = base_size, base_family = base_family)
    theme(
      axis.text.x = element_text(size = base_size, hjust = .5 , vjust=1, colour = "black"),
      axis.text.y = eval(parse(text = lab)),
      axis.ticks.y = element_line(colour = "grey50"),
      axis.ticks.x = element_blank(),
      axis.title.y = element_text(size = base_size+2,angle=90,
                                  vjust=.01,hjust=.1),
      axis.title.x = element_text(size = base_size),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size),
      legend.position = legend_position
    )
  }
  base_size = 8
  base_family = ""
  p <- p + theme_economist() + theme(axis.text.x = element_text(size = base_size, hjust = .5 , vjust=1, colour = "black"),
                                     axis.text.y = eval(parse(text = lab)),
                                     #axis.ticks.y = element_line(colour = "grey50"),
                                     axis.ticks.x = element_blank(),
                                     axis.title.y = element_text(size = base_size+1,angle=90,
                                                                 vjust=.01,hjust=.1),
                                     axis.title.x = element_text(size = base_size+1),
                                     legend.title = element_blank(),
                                     legend.position = legend_position,
                                     legend.text = element_text(size = base_size),
                                     plot.title = element_text(size = base_size+2, face = "bold", hjust = h_just))
  p <- p + theme(panel.grid.major = element_line(size = 0.28)) + 
    theme(panel.grid.minor = element_blank())
  p <- p + labs(title = title) + 
    theme(title = element_text(size = 5))
  # p <- p + scale_fill_manual(values = c("black", "white")) + 
  #   scale_shape_manual(values = c(16,21))
  return(p)
  
}