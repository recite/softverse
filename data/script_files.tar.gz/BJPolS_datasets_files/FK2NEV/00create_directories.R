#Create necessary directors (Note: functions should already be in `functions` folder. Raw data should already be in `data` folder. See ReadMe.txt for more information)

if(!dir.exists("figures")){
  dir.create("figures")
}

if(!dir.exists("figures/appendix")){
  dir.create("figures/appendix")
}

if(!dir.exists("out")){
  dir.create("out")
}

if(!dir.exists("out/mi_loadings")){
  dir.create("out/mi_loadings")
}

if(!dir.exists("out/mi_variance")){
  dir.create("out/mi_variance")
}

if(!dir.exists("out/descriptive")){
  dir.create("out/descriptive")
}

if(!dir.exists("out/info_boot")){
  dir.create("out/info_boot")
}

if(!dir.exists("out/jordan")){
  dir.create("out/jordan")
}

if(!dir.exists("out/jordan/loadings")){
  dir.create("out/jordan/loadings")
}

if(!dir.exists("out/jordan/variance")){
  dir.create("out/jordan/variance")
}

if(!dir.exists("tables")){
  dir.create("tables")
}


