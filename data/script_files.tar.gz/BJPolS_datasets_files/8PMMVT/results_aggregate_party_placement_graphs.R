###Figure 1


library(foreign)
library(readstata13)
library(dplyr)

setwd("C:/Users/kevin/Dropbox/Social_Media_Lab/Data_Survey/YouGov_Data/apsr_replication/")
load("merged_nr_soma.RData")

 #############################

####Aggregate over the whole situation
##note that I have to rename some things bc of Stata variable length restraints
data$place_conservatives_spending_w1<-data$place_conserv_spending_w1
data$place_conservatives_immigration_w1<-data$place_conserv_immigration_w1
data$place_conservatives_spending_w4<-data$place_conserv_spending_w4
data$place_conservatives_immigration_w4<-data$place_conserv_immigration_w4

means1<-vector()
sds1<-vector()
ppl<-c( "UKIP","libdem", "labour", "conservatives",  "self")
issues<-c("spending", "EU", "immigration")

for(j in 1:length(issues)){
  
  for(i in 1:length(ppl)){
    means1<-c(means1, mean(data[[paste0("place_", ppl[i], "_", issues[j], "_w1")]], na.rm =TRUE))
    sds1<-c(sds1, sd(data[[paste0("place_", ppl[i], "_", issues[j], "_w1")]], na.rm =TRUE)) 
  }
}

means4<-vector()
sds4<-vector()
names1<-character()
for(j in 1:length(issues)){
  
  for(i in 1:length(ppl)){
    means4<-c(means4, mean(data[[paste0("place_", ppl[i], "_", issues[j], "_w4")]], na.rm =TRUE))
    sds4<-c(sds4, sd(data[[paste0("place_", ppl[i], "_", issues[j], "_w4")]], na.rm =TRUE)) 
    names1<-c(names1, paste0(ppl[i], " ", issues[j]))
  }
}

names<-c("Taxes/Spending UKIP","Taxes/Spending LibDem","Taxes/Spending Labour","Taxes/Spending Conservative", "Taxes/Spending Self", 
         "Ties to EU UKIP","Ties to EU LibDem","Ties to EU Labour","Ties to EU Conservative", "Ties to EU Self",
         "Immigration UKIP","Immigration LibDem", "Immigration Labour","Immigration Conservative","Immigration Self" )

pdf(paste0("results/place_all_parties.pdf"), 8,12)
par(mar=c(4, 12, 4, 2)  )
index<-seq(.1, by=.1, length.out = length(names))

index1<-seq(.11, by=.1, length.out = length(names))
index4<-seq(.09, by=.1, length.out = length(names))

plot( means1, index1, xlim=c(0,100), ylim=c(.09, 1.51), ylab="", yaxt="n", xlab="Left                                        Right",
      main = paste0("Issue Placement Means and Standard Deviations, Waves 1 and 4"), pch=15)

axis(2, at=index, labels =paste0(names), las=2)
abline(v=50)
for(i in 1:length(means1)){
  lines(c(means1[i] - sds1[i],pmin(means1[i] + sds1[i], 100)), c(index1[i],index1[i]))
}

points(means4 , index4, pch=16)
for(i in 1:length(means4)){
  lines(c(means4[i] - sds4[i],pmin(means4[i] + sds4[i], 100)), c(index4[i],index4[i]), lty=3)
}

legend("bottomright", legend = c( "Wave 1", "Wave 4"), bty = "o",
       lwd = 2, cex = .7,  lty = c(1,3), pch = c(15, 16))

dev.off()

