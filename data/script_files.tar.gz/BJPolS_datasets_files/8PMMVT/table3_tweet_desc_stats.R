###Table 3


library(foreign)
library(readstata13)
library(dplyr)

setwd("C:/Users/kevin/Dropbox/Social_Media_Lab/Data_Survey/YouGov_Data/apsr_replication/")
load("merged_nr_soma.RData")

t_issues=c("isis", "economy", "immigr")

##isis counts
j=1

data$tory_isis= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_tory"))) +
   eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_tory")))+
   eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_tory")))+
   eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_tory")))+
   eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_tory")))

data$ukip_isis= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_ukip"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_ukip")))

data$lide_isis= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_lide"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_lide")))

data$labo_isis= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_labo"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_labo")))



###econ coutns
j=2

data$tory_economy= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_tory"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_tory")))

data$ukip_economy= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_ukip"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_ukip")))

data$lide_economy= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_lide"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_lide")))

data$labo_economy= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_labo"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_labo")))

##immigration counts

j=3

data$tory_immigr= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_tory"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_tory")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_tory")))

data$ukip_immigr= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_ukip"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_ukip")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_ukip")))

data$lide_immigr= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_lide"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_lide")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_lide")))


data$labo_immigr= 
  eval(parse(text=paste0("data$p3_1", "_", t_issues[j], "_labo"))) +
  eval(parse(text=paste0("data$p3_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_1", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p4_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p2_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_2", "_", t_issues[j], "_labo")))+
  eval(parse(text=paste0("data$p1_1", "_", t_issues[j], "_labo")))

##EU counts
data$tory_eu= 
  eval(parse(text=paste0("data$p3_1_eu_tory"))) +
  eval(parse(text=paste0("data$p3_2_eu_tory")))+
  eval(parse(text=paste0("data$p4_1_eu_tory")))+
  eval(parse(text=paste0("data$p2_1_eu_tory")))+
  eval(parse(text=paste0("data$p4_2_eu_tory")))+
  eval(parse(text=paste0("data$p2_2_eu_tory")))+
  eval(parse(text=paste0("data$p1_2_eu_tory")))+
  eval(parse(text=paste0("data$p1_1_eu_tory")))

data$ukip_eu= 
  eval(parse(text=paste0("data$p3_1_eu_ukip"))) +
  eval(parse(text=paste0("data$p3_2_eu_ukip")))+
  eval(parse(text=paste0("data$p4_1_eu_ukip")))+
  eval(parse(text=paste0("data$p2_1_eu_ukip")))+
  eval(parse(text=paste0("data$p4_2_eu_ukip")))+
  eval(parse(text=paste0("data$p2_2_eu_ukip")))+
  eval(parse(text=paste0("data$p1_2_eu_ukip")))+
  eval(parse(text=paste0("data$p1_1_eu_ukip")))

data$lide_eu= 
  eval(parse(text=paste0("data$p3_1_eu_lide"))) +
  eval(parse(text=paste0("data$p3_2_eu_lide")))+
  eval(parse(text=paste0("data$p4_1_eu_lide")))+
  eval(parse(text=paste0("data$p2_1_eu_lide")))+
  eval(parse(text=paste0("data$p4_2_eu_lide")))+
  eval(parse(text=paste0("data$p2_2_eu_lide")))+
  eval(parse(text=paste0("data$p1_2_eu_lide")))+
  eval(parse(text=paste0("data$p1_1_eu_lide")))


data$labo_eu= 
  eval(parse(text=paste0("data$p3_1_eu_labo"))) +
  eval(parse(text=paste0("data$p3_2_eu_labo")))+
  eval(parse(text=paste0("data$p4_1_eu_labo")))+
  eval(parse(text=paste0("data$p2_1_eu_labo")))+
  eval(parse(text=paste0("data$p4_2_eu_labo")))+
  eval(parse(text=paste0("data$p2_2_eu_labo")))+
  eval(parse(text=paste0("data$p1_2_eu_labo")))+
  eval(parse(text=paste0("data$p1_1_eu_labo")))







####caluclate the percentages


data$labo<-data$labo_eu + data$labo_isis + data$labo_economy + data$labo_immigr
data$ukip<-data$ukip_eu + data$ukip_isis + data$ukip_economy + data$ukip_immigr
data$lide<-data$lide_eu + data$lide_isis + data$lide_economy + data$lide_immigr
data$tory<-data$tory_eu + data$tory_isis + data$tory_economy + data$tory_immigr

data$media_right<-data$media_right_eu + data$media_right_isis + data$media_right_economy + data$media_right_immigr
data$media_left<-data$media_left_eu + data$media_left_isis + data$media_left_economy + data$media_left_immigr
data$media_cent<-data$media_cent_eu + data$media_cent_isis + data$media_cent_economy + data$media_cent_immigr


tweets<-data$labo + data$ukip + data$lide + data$tory + data$media_right + data$media_left + data$media_cent




sum(is.na(tweets))


yes<-sum(tweets > 0, na.rm =  T  )

no<-sum(tweets == 0, na.rm =  T  )
yes + no + 2096

xx<-filter(data, tory>0)

mean(xx$tory_eu/xx$tory)
mean(xx$tory_isis/xx$tory)
mean(xx$tory_immigr/xx$tory)
mean(xx$tory_economy/xx$tory)

xx<-filter(data, labo>0)

mean(xx$labo_eu/xx$labo)
mean(xx$labo_isis/xx$labo)
mean(xx$labo_immigr/xx$labo)
mean(xx$labo_economy/xx$labo)


xx<-filter(data, lide>0)

mean(xx$lide_eu/xx$lide)
mean(xx$lide_isis/xx$lide)
mean(xx$lide_immigr/xx$lide)
mean(xx$lide_economy/xx$lide)


xx<-filter(data, ukip>0)

mean(xx$ukip_eu/xx$ukip)
mean(xx$ukip_isis/xx$ukip)
mean(xx$ukip_immigr/xx$ukip)
mean(xx$ukip_economy/xx$ukip)

xx<-filter(data, media_left>0)

mean(xx$media_left_eu/xx$media_left)
mean(xx$media_left_isis/xx$media_left)
mean(xx$media_left_immigr/xx$media_left)
mean(xx$media_left_economy/xx$media_left)

xx<-filter(data, media_right>0)

mean(xx$media_right_eu/xx$media_right)
mean(xx$media_right_isis/xx$media_right)
mean(xx$media_right_immigr/xx$media_right)
mean(xx$media_right_economy/xx$media_right)

xx<-filter(data, media_cent>0)

mean(xx$media_cent_eu/xx$media_cent)
mean(xx$media_cent_isis/xx$media_cent)
mean(xx$media_cent_immigr/xx$media_cent)
mean(xx$media_cent_economy/xx$media_cent)
