###Table 1


library(foreign)
library(readstata13)
library(dplyr)

setwd("C:/Users/kevin/Dropbox/Social_Media_Lab/Data_Survey/YouGov_Data/apsr_replication/")
load("merged_nr_soma.RData")



no_twitter<-filter(data, twitter_user==0 | twitter_freq_inc  <2)

yes_twitter<-filter(data, twitter_user==1 & twitter_freq_inc  >1)



wtd.mean(no_twitter$gender)
wtd.mean(yes_twitter$gender)



education<-table(no_twitter$profile_education_age)

education['5']/sum(education)


education<-table(yes_twitter$profile_education_age)

education['5']/sum(education)


summary(no_twitter$age)
summary(yes_twitter$age)


table(no_twitter$profile_income_old_w2)
summary((no_twitter$profile_income))
summary((yes_twitter$profile_income))





summary(no_twitter$self_ideology)
summary(yes_twitter$self_ideology)



votes<-table(no_twitter$vote_choice_w4)
votes<-votes[1:7]
votes/sum(votes)
summary(no_twitter$vote_choice_obscure_w4)

#greens
37/sum(votes)


votes<-table(yes_twitter$vote_choice_w4)
votes<-votes[1:7]
votes/sum(votes)
summary(yes_twitter$vote_choice_obscure_w4)

#greens
183/sum(votes)



####pid


table(no_twitter$profile_partyid_w2)/length(no_twitter$profile_partyid_w2[is.na(no_twitter$profile_partyid_w2)==F])

table(yes_twitter$profile_partyid_w2)/length(yes_twitter$profile_partyid_w2[is.na(yes_twitter$profile_partyid_w2)==F])

