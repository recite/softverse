rm(list=ls())
library(ggplot2)
library(dplyr)
library(extrafont)
font_import()
loadfonts(device="win")       #Register fonts for Windows bitmap output
fonts()               

setwd("C:/Users/czj968/Dropbox/Turnout/Our products/Work in progress/Co-residence/replication_archive")

data <- read.csv("Figure6_couples.csv", sep = ";", header = TRUE)

data <- 
  data %>% 
  mutate(couples_share = (married_couples + other_couple)/
           (single_men + single_women + married_couples + other_couple), 
         single_share = (single_men + single_women)/
           (single_men + single_women + married_couples + other_couple))

ggplot(data = data,
       aes(x = year, 
           y = couples_share, 
           linetype = "Couples")) + 
  geom_line() +
  geom_line(aes(x = year, y = single_share, linetype = "Singles")) +
  theme_classic() + 
  scale_y_continuous(limits = c(0.3,0.7),
                     name = "Share of households",
                     breaks = seq(0.3, 0.7, 0.05)) + 
  scale_x_continuous(breaks = seq(1986, 2020, 2),
                     name = "Year") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_linetype_discrete(guide_legend(title = " "))

ggsave(last_plot(), filename = "couples_graph.png", dpi = 600, width = 8, height = 4)
