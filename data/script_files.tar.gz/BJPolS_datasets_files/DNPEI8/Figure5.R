install.packages("tidyverse")

library(tidyverse)

plot_data <- 
  read.csv("figure5_ests.csv",
           header = TRUE, 
           sep    = ";")

label_months <- c('1' = "One month before \n- One month after", 
                  '2' = "Two months before \n- Two months after")

vote_data <- 
  plot_data %>% 
  group_by(months) %>% 
  mutate(place = n():1) %>%
  ungroup() %>%
  mutate(months = as.factor(months)) 


plot_vote <- 
  ggplot(vote_data,
         aes(x    = est,
             xmax = est + se * qnorm(0.975),
             xmin = est + se * qnorm(0.025),
             y    = place)) + 
  geom_errorbarh(height = 0) + 
  geom_errorbarh(data = vote_data,
                 aes(xmax = est + se * qnorm(0.83),
                     xmin = est + se * qnorm(0.17),
                     y    = place), height = 0, lwd = 1.25) + 
  geom_point(size = 2) + 
  facet_grid(. ~ months, labeller = labeller(months = label_months)) +
  ylab("") + 
  xlab("Effect on turnout") + 
  scale_y_continuous(breaks = 1:13,
                     labels =rev(c("All",
                               "Men",
                               "Women",
                               "Under 30 (average)",
                               "Over 30 (average)",
                               "Native Dane",
                               "Not a native Dane",
                               "Less than bachelor's degree",
                               "Bachelor's degree or higher",
                               "Did not vote in 2009",
                               "Voted in 2009",
                               "Not married and without children by 2015",
                               "Married or with children by 2015"))) + 
  theme_classic() + 
  theme(axis.text    = element_text(size = 12)) + 
  geom_vline(xintercept = 0, 
             linetype   = "dashed", 
             alpha      = 0.4) + 
  geom_vline(data = vote_data %>% filter(place == 13),
             aes(xintercept = est), 
             linetype = "dotted", alpha = 0.6)
