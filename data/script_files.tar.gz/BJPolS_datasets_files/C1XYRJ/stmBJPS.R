rm(list=ls())
library(stm)

setwd("C:/Users/dtingley/Dropbox/TingleyMildenberger/ContactCongress/data/BJPSReplication/data")
load("STMReplication-BJPS.RData")

temp<-textProcessor(documents=temp1$textcontent,metadata=temp1)
meta<-temp$meta
vocab<-temp$vocab
docs<-temp$documents
out <- prepDocuments(docs, vocab, meta)
docs<-out$documents
vocab<-out$vocab
meta <-out$meta


z<-stm(docs,vocab,K=7, prevalence=~textcondition*happenBIN,data=meta, init.type="Spectral")
save(z,meta,file="happenPeopleNew.RData")

load("happenPeopleNew.RData")

prep<-estimateEffect(~textcondition*happenBIN,stmobj=z,metadata=meta )

m1<-c("Topic 1: Scientific Evidence","Topic 2: Liberal Agenda/Hoax","Topic 3: Geological Evidence","Topic 4: Change is Normal","Topic 5: Role of Carbon Dioxide","Topic 6: Weather is Cyclical","Topic 7: Natural Changes")
#pdf("Paper/Figures/happenPEOPLE-happencontrast-new.pdf",width=16,height=16)
par(mfrow=c(2,2),mar=c(5,5.1,2,1),oma=c(1,1,0,0))
plot(z,type="labels",labeltype="frex",main="Topics with Exclusive Words",topic.names=m1, text.cex=1.5, n=15, width=70)
plot(prep,"textcondition",method="difference",cov.value1="happenPEOPLE",cov.value2="nohappenPEOPLE",verbose.labels=F,main="Talk about CC Happening vs. Not Happening" ,xlab="- CC Not Happening + CC Happening")
plot(prep,"happenBIN",method="difference",cov.value1=0,cov.value2=1,moderator="textcondition", moderator.value="happenPEOPLE", verbose.labels=F,main="Talk about Climate Change Happening",xlab="Respondent View: - CC Not Happening + CC Happening")
plot(prep,"happenBIN",method="difference",cov.value1=0,cov.value2=1,moderator="textcondition", moderator.value="nohappenPEOPLE", verbose.labels=F,main="Talk about Climate Change Not Happening",xlab="Respondent View: - CC Not Happening + CC Happening")
#dev.off()
