
install.packages("maps")
install.packages("ggmap")
install.packages("mapproj")
# Libraries
library(ggplot2)
library(dplyr)
library(haven)
library(mapproj)
library(tidyverse)
# Get the world polygon and extract UK
library(maps)
Spain <- map_data("world") %>% filter(region=="Spain")



##DATA FOR FIGURE 1 (TOP PANEL)
attacks<-read_dta("attacks_tomap.dta")
##
  
#FIGURE 1, TOP PANEL (MAP)

attacks <- attacks %>%
  rename (lat="_Y2",
          lon="_X2")

attacks$group<-as.factor(attacks$group)

attacks<-attacks %>%
  mutate(group = fct_recode(group,
                              "ETA"    = "1",
                              "GRAPO"      = "2",
                              "Far Right" = "3",
                              "Other" = "0"  ))
table(attacks$group)
# Left chart
map <- ggplot() +
  geom_polygon(data = Spain, aes(x=long, y = lat, group = group), fill="grey", alpha=0.3) +
  geom_jitter( data=attacks, aes(x=lon, y=lat, color=group), width = 0.15, height = 0.15) +
  coord_map() +
  ylim(36,44)  +
  theme_void() +  scale_color_discrete(name="Authorship") +
  theme(legend.justification=c(1,0), legend.position=c(.95,0.2))
map
#ggsave("map_attacks.pdf")
