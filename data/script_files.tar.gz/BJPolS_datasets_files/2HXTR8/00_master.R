##### ##################################################################### ######
#####                                                                       ######
##### The Effects of Female Leadership on Women's Voice in Political Debate ######
#####                         Jack Blumenau                                 ######
#####             British Journal of Political Science                      ######
#####                         Master script                                 ######
#####                                                                       ######
##### ##################################################################### ######

rm(list= ls())

# Create directory structure

directories <- c("latex/tables", 
                 "latex/tables/usefulNumbers", 
                 "latex/tables/topics/", 
                 "plots", 
                 "plots/diagnostics",
                 "working", 
                 "working/topics", 
                 "working/topics/mod.out",
                 "timings")

lapply(directories, function(x) dir.create(x))

# Data prep

system("(time Rscript 01_influence_prep.R 2> tmp.txt;) 2> timings/01_influence_prep.txt") # 37 mins
system("(time Rscript 02_direct_references_prep.R 2> tmp.txt;) 2> timings/02_direct_references_prep.txt") # 42 mins
system("(time Rscript 03_prep_topics.R 2> tmp.txt;) 2> timings/03_prep_topics.txt") # 7 hours

# Analysis

## 04_analysis_participation.R
system("(time Rscript 04_analysis_participation.R 2> tmp.txt;) 2> timings/04_analysis_participation.txt") 
## Approximate time: 4 hours
## Outputs: Tables 1, S1, S2, S3, Figure S7

## 05_subset_analyses.R
system("(time Rscript 05_subset_analyses.R 2> tmp.txt;) 2> timings/05_subset_analyses.txt")
## Approximate time: 3.5 hours
## Outputs: Tables S4, S5, S6, S8, S9, S10, Figures S4

## 06_analysis_influence.R
system("(time Rscript 06_analysis_influence.R 2> tmp.txt;) 2> timings/06_analysis_influence.txt") 
## Approximate time: 1 hour
## Outputs:  Tables 2, S11, S12, S13, S16, S19, Figure 3, S6, S7, S8

## 07_analysis_responsiveness.R
system("(time Rscript 07_analysis_responsiveness.R 2> tmp.txt;) 2> timings/07_analysis_responsiveness.txt")
## Approximate time: 1.5 hours
## Outputs:  Tables 3, S14, S15, S17, S18, S20, Figure 4

## 08_graphical_analysis.R
system("(time Rscript 08_graphical_analysis.R 2> tmp.txt;) 2> timings/08_graphical_analysis.txt")
## Approximate time: 20 seconds
## Outputs: Figures 1, 2, S1, S2, S3

## 09_analysis_topics.R
system("(time Rscript 09_analysis_topics.R 2> tmp.txt;) 2> timings/09_analysis_topics.txt") 
## Approximate time: 2.5 minutes
## Outputs: Table S21, Figure S9
