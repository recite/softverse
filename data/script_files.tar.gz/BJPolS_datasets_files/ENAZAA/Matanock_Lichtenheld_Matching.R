# LOAD DATA:

rm(list=ls(all=TRUE))

library(foreign)
install.packages("Matching")
library(Matching)
install.packages("rgenoud")
library(rgenoud)

setwd("/Users/alichtenheld/Dropbox/PKO Research/Data/PKO Rematch/Main Analysis")

### FIRST SET OF MODELS ###
# ANY UN MISSION

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
attach(In.Peace)

# SET GENMATCH INPUTS:

X <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout <- GenMatch(Tr=UN, X=X, BalanceMatrix=BalanceMat, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10,int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout <- Match(Y=ldur, Tr=UN, X=X, estimand="ATT", Weight.matrix=genout, M=1)
summary(mout, full=TRUE)
         
p.match <- rbind(In.Peace[mout$index.treated,], In.Peace[mout$index.control,])
write.dta(p.match,'peace_post_match_ANYUN.dta')

# CHECK BALANCE:

mb <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop +
lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout, nboots=500, ks=TRUE, paired=FALSE)

#CI MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NFC <- subset(In.Peace, !(nfc == 0 & nonfc == 1))
attach(In.Peace.NFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout3 <- GenMatch(Tr=nfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10,
int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=nfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.NFC[mout3$index.treated,], In.Peace.NFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_NFC.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (nfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

#NO CI

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFC <-  subset(In.Peace, !(nfc == 1 & nonfc == 0))
attach(In.Peace.NoNFC)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=nonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=nonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFC[mout4$index.treated,], In.Peace.NoNFC[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFC.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (nonfc ~ lwdeaths + lwdurat + ethfrac + pop +
lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

# COERCIVE MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.Force <- subset(In.Peace, !(noforce == 1 & force == 0))
attach(In.Peace.Force)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod, miltnum)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod, miltnum)

# BALANCE:

genout1 <- GenMatch(Tr=force, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=force, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.Force[mout1$index.treated,], In.Peace.Force[mout1$index.control,])
write.dta(p.match1,'peace_post_match_FORCE.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (force ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum + tperiod + miltnum, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

#NON-COERCIVE MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoForce <- subset(In.Peace, !(noforce == 0 & force == 1))
attach(In.Peace.NoForce)

# SET GENMATCH INPUTS:

X2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod, miltnum)

BalanceMat2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod, miltnum)

# BALANCE:

genout2 <- GenMatch(Tr=noforce, X=X2, BalanceMatrix=BalanceMat2, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout2 <- Match(Y=ldur, Tr=noforce, X=X2, estimand="ATT", Weight.matrix=genout2, M=1)
summary(mout2, full=TRUE)

p.match2 <- rbind(In.Peace.NoForce[mout2$index.treated,], In.Peace.NoForce[mout2$index.control,])
write.dta(p.match2,'peace_post_match_NOFORCE.dta')

# CHECK BALANCE:

mb2 <- MatchBalance (noforce ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout2, nboots=500, ks=TRUE, paired=FALSE)

####SECOND SET OF MODELS ###

rm(list=ls(all=TRUE))

# ANY UN MISSION

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
attach(In.Peace)

# SET GENMATCH INPUTS:

X <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout <- GenMatch(Tr=UN, X=X, BalanceMatrix=BalanceMat, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10,int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout <- Match(Y=ldur, Tr=UN, X=X, estimand="ATT", Weight.matrix=genout, M=1)
summary(mout, full=TRUE)

p.match <- rbind(In.Peace[mout$index.treated,], In.Peace[mout$index.control,])
write.dta(p.match,'peace_post_match_ANYUN2.dta')

# CHECK BALANCE:

mb <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + ethnicwar + terr + marxist, match.out=mout, nboots=500, ks=TRUE, paired=FALSE)

#CI MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NFC <- subset(In.Peace, !(nfc == 0 & nonfc == 1))
attach(In.Peace.NFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout3 <- GenMatch(Tr=nfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=nfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.NFC[mout3$index.treated,], In.Peace.NFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_NFC2.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (nfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

#NO CI

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFC <-  subset(In.Peace, !(nfc == 1 & nonfc == 0))
attach(In.Peace.NoNFC)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=nonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=nonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFC[mout4$index.treated,], In.Peace.NoNFC[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFC2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (nonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

# FORCEFUL MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.Force <- subset(In.Peace, !(noforce == 1 & force == 0))
attach(In.Peace.Force)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

# BALANCE:

genout1 <- GenMatch(Tr=force, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=force, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.Force[mout1$index.treated,], In.Peace.Force[mout1$index.control,])
write.dta(p.match1,'peace_post_match_FORCE2.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (force ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + tperiod + ethnicwar + marxist + terr, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

#NOFORCE MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoForce <- subset(In.Peace, !(noforce == 0 & force == 1))
attach(In.Peace.NoForce)

# SET GENMATCH INPUTS:

X2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

BalanceMat2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

# BALANCE:

genout2 <- GenMatch(Tr=noforce, X=X2, BalanceMatrix=BalanceMat2, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout2 <- Match(Y=ldur, Tr=noforce, X=X2, estimand="ATT", Weight.matrix=genout2, M=1)
summary(mout2, full=TRUE)

p.match2 <- rbind(In.Peace.NoForce[mout2$index.treated,], In.Peace.NoForce[mout2$index.control,])
write.dta(p.match2,'peace_post_match_NOFORCE2.dta')

# CHECK BALANCE:

mb2 <- MatchBalance (noforce ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout2, nboots=500, ks=TRUE, paired=FALSE)

#SEPARATE CI and FORCE, CHECK DIFFERENT COMBOS OF MISSIONS#

##FIRST SET OF MODELS####
## FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.ForceNFC <- subset(In.Peace, !(forcenfc == 0 & forcenonfc == 1 | forcenfc == 0 & noforcenfc == 1 | forcenfc == 0 & noforcenonfc == 1))
attach(In.Peace.ForceNFC)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, tperiod, ethnicwar, terr, marxist)

# BALANCE:

genout1 <- GenMatch(Tr=UN, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=UN, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.ForceNFC[mout1$index.treated,], In.Peace.ForceNFC[mout1$index.control,])
write.dta(p.match1,'peace_post_match_NFCFORCE2.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist + tperiod, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

## NON FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoForceNFC <- subset(In.Peace, !(noforcenfc == 0 & forcenfc == 1 | noforcenfc == 0 & forcenonfc == 1 | noforcenfc == 0 & noforcenonfc == 1))
attach(In.Peace.NoForceNFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, ethnicwar, terr, marxist, miltnum, tperiod)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, ethnicwar, terr, marxist, nafrme, miltnum, tperiod)

# BALANCE:

genout3 <- GenMatch(Tr=UN, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=UN, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.NoForceNFC[mout3$index.treated,], In.Peace.NoForceNFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_NFCnoforce2.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

## NO CI WITH FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFCforce <- subset(In.Peace, !(forcenonfc == 0 & forcenfc == 1 | forcenonfc == 0 & noforcenfc == 1 | forcenonfc == 0 & noforcenonfc == 1))
attach(In.Peace.NoNFCforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=UN, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=UN, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFCforce[mout4$index.treated,], In.Peace.NoNFCforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFCforce2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## NO NFC NO FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFCnoforce <- subset(In.Peace, !(noforcenonfc == 0 & forcenfc == 1 | noforcenonfc == 0 & noforcenfc == 1 | noforcenonfc == 0 & forcenonfc == 1))
attach(In.Peace.NoNFCnoforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=UN, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=UN, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFCnoforce[mout4$index.treated,], In.Peace.NoNFCnoforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFCnoforce2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)


##SECOND SET OF MODELS####

## FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.ForceNFC <- subset(In.Peace, !(forcenfc == 0 & forcenonfc == 1 | forcenfc == 0 & noforcenfc == 1 | forcenfc == 0 & noforcenonfc == 1))
attach(In.Peace.ForceNFC)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist, tperiod)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist, tperiod)

# BALANCE:

genout1 <- GenMatch(Tr=UN, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=UN, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.ForceNFC[mout1$index.treated,], In.Peace.ForceNFC[mout1$index.control,])
write.dta(p.match1,'peace_post_match_NFCFORCE.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + ethnicwar + terr + marxist + miltnum + tperiod, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

## NON FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoForceNFC <- subset(In.Peace, !(noforcenfc == 0 & forcenfc == 1 | noforcenfc == 0 & forcenonfc == 1 | noforcenfc == 0 & noforcenonfc == 1))
attach(In.Peace.NoForceNFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

# BALANCE:

genout3 <- GenMatch(Tr=UN, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=UN, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.NoForceNFC[mout3$index.treated,], In.Peace.NoForceNFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_NFCnoforce.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

## NO CI WITH FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFCforce <- subset(In.Peace, !(forcenonfc == 0 & forcenfc == 1 | forcenonfc == 0 & noforcenfc == 1 | forcenonfc == 0 & noforcenonfc == 1))
attach(In.Peace.NoNFCforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, tperiod, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, tperiod, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=UN, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=UN, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFCforce[mout4$index.treated,], In.Peace.NoNFCforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFCforce.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## NO NFC NO FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.NoNFCnoforce <- subset(In.Peace, !(noforcenonfc == 0 & forcenfc == 1 | noforcenonfc == 0 & noforcenfc == 1 | noforcenonfc == 0 & forcenonfc == 1))
attach(In.Peace.NoNFCnoforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, nafrme, lamerica, tperiod, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=UN, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=UN, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.NoNFCnoforce[mout4$index.treated,], In.Peace.NoNFCnoforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_NONFCnoforce.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (UN ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

##WITHIN PKO MATCHING (BY PKO TYPE)

# FORCEFUL MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WIforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WIforce)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

# BALANCE:

genout1 <- GenMatch(Tr=force, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=force, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.WIforce[mout1$index.treated,], In.Peace.WIforce[mout1$index.control,])
write.dta(p.match1,'peace_post_match_WIFORCE.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (force ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

#NOFORCE MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WInoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WInoforce)

# SET GENMATCH INPUTS:

X2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

BalanceMat2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum, tperiod)

# BALANCE:

genout2 <- GenMatch(Tr=noforce, X=X2, BalanceMatrix=BalanceMat2, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout2 <- Match(Y=ldur, Tr=noforce, X=X2, estimand="ATT", Weight.matrix=genout2, M=1)
summary(mout2, full=TRUE)

p.match2 <- rbind(In.Peace.WInoforce[mout2$index.treated,], In.Peace.WInoforce[mout2$index.control,])
write.dta(p.match2,'peace_post_match_WINOFORCE.dta')

# CHECK BALANCE:

mb2 <- MatchBalance (noforce ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout2, nboots=500, ks=TRUE, paired=FALSE)

#CI MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WINFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout3 <- GenMatch(Tr=nfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=nfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.WINFC[mout3$index.treated,], In.Peace.WINFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_WINFC.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (nfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

#NO CI

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFC)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=nonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=nonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFC[mout4$index.treated,], In.Peace.WINoNFC[mout4$index.control,])
write.dta(p.match4,'peace_post_match_WINONFC.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (nonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

##SECOND SET OF MODELS

# FORCEFUL MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WIforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WIforce)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout1 <- GenMatch(Tr=force, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=force, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.WIforce[mout1$index.treated,], In.Peace.WIforce[mout1$index.control,])
write.dta(p.match1,'peace_post_match_WIFORCE2.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (force ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

#NOFORCE MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WInoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WInoforce)

# SET GENMATCH INPUTS:

X2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat2 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout2 <- GenMatch(Tr=noforce, X=X2, BalanceMatrix=BalanceMat2, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout2 <- Match(Y=ldur, Tr=noforce, X=X2, estimand="ATT", Weight.matrix=genout2, M=1)
summary(mout2, full=TRUE)

p.match2 <- rbind(In.Peace.WInoforce[mout2$index.treated,], In.Peace.WInoforce[mout2$index.control,])
write.dta(p.match2,'peace_post_match_WINOFORCE2.dta')

# CHECK BALANCE:

mb2 <- MatchBalance (noforce ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout2, nboots=500, ks=TRUE, paired=FALSE)

#CI MISSIONS

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WINFC)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout3 <- GenMatch(Tr=nfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=nfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.WINFC[mout3$index.treated,], In.Peace.WINFC[mout3$index.control,])
write.dta(p.match3,'peace_post_match_WINFC2.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (nfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

#NO CI

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFC)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=nonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=nonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFC[mout4$index.treated,], In.Peace.WINoNFC[mout4$index.control,])
write.dta(p.match4,'peace_post_match_WINONFC2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (nonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WIForceNFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WIForceNFC)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

# BALANCE:

genout1 <- GenMatch(Tr=forcenfc, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=forcenfc, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.WIForceNFC[mout1$index.treated,], In.Peace.WIForceNFC[mout1$index.control,])
write.dta(p.match1,'peace_post_match_WINFCFORCE.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (forcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

## NON FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINFCnoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINFCnoforce)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

# BALANCE:

genout3 <- GenMatch(Tr=noforcenfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=noforcenfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.WINFCnoforce[mout3$index.treated,], In.Peace.WINFCnoforce[mout3$index.control,])
write.dta(p.match3,'peace_post_match_WINFCnoforce.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (noforcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

## NO CI WITH FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFCforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFCforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, tperiod, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, tperiod, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=forcenonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=forcenonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFCforce[mout4$index.treated,], In.Peace.WINoNFCforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_WINONFCforce.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (forcenonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## NO CI NO FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFCnoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFCnoforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, eeurop, bwplty2, ssafrica, asia, lamerica, nafrme, tperiod, miltnum)

# BALANCE:

genout4 <- GenMatch(Tr=noforcenonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=noforcenonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFCnoforce[mout4$index.treated,], (In.Peace.WINoNFCnoforce[mout4$index.control,]))
write.dta(p.match4,'peace_post_match_WINONFCnoforce.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (noforcenonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + tperiod + miltnum, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

##SECOND SET OF MODELS


rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WIForceNFC <- subset(In.Peace, UN == 1)
attach(In.Peace.WIForceNFC)

X1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat1 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout1 <- GenMatch(Tr=forcenfc, X=X1, BalanceMatrix=BalanceMat1, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout1 <- Match(Y=ldur, Tr=forcenfc, X=X1, estimand="ATT", Weight.matrix=genout1, M=1)
summary(mout1, full=TRUE)

p.match1 <- rbind(In.Peace.WIForceNFC[mout1$index.treated,], In.Peace.WIForceNFC[mout1$index.control,])
write.dta(p.match1,'peace_post_match_WINFCFORCE2.dta')

# CHECK BALANCE:

mb1 <- MatchBalance (forcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout1, nboots=500, ks=TRUE, paired=FALSE)

## NON FORCEFUL MISSIONS WITH CI ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINFCnoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINFCnoforce)

# SET GENMATCH INPUTS:

X3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat3 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout3 <- GenMatch(Tr=noforcenfc, X=X3, BalanceMatrix=BalanceMat3, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout3 <- Match(Y=ldur, Tr=noforcenfc, X=X3, estimand="ATT", Weight.matrix=genout3, M=1)
summary(mout3, full=TRUE)

p.match3 <- rbind(In.Peace.WINFCnoforce[mout3$index.treated,], In.Peace.WINFCnoforce[mout3$index.control,])
write.dta(p.match3,'peace_post_match_WINFCnoforce2.dta')

# CHECK BALANCE:

mb3 <- MatchBalance (noforcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout3, nboots=500, ks=TRUE, paired=FALSE)

## NO CI WITH FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFCforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFCforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=forcenonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=forcenonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFCforce[mout4$index.treated,], In.Peace.WINoNFCforce[mout4$index.control,])
write.dta(p.match4,'peace_post_match_WINONFCforce2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (forcenonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## NO CI NO FORCE ##

rm(list=ls(all=TRUE))

In.Peace <- read.csv('GS_pre-match.csv')
In.Peace [is.na(In.Peace)] <- 0
In.Peace.WINoNFCnoforce <- subset(In.Peace, UN == 1)
attach(In.Peace.WINoNFCnoforce)

X4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

BalanceMat4 <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, tperiod, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout4 <- GenMatch(Tr=noforcenonfc, X=X4, BalanceMatrix=BalanceMat4, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10, int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout4 <- Match(Y=ldur, Tr=noforcenonfc, X=X4, estimand="ATT", Weight.matrix=genout4, M=1)
summary(mout4, full=TRUE)

p.match4 <- rbind(In.Peace.WINoNFCnoforce[mout4$index.treated,], (In.Peace.WINoNFCnoforce[mout4$index.control,]))
write.dta(p.match4,'peace_post_match_WINONFCnoforce2.dta')

# CHECK BALANCE:

mb4 <- MatchBalance (noforcenonfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + tperiod + miltnum + ethnicwar + terr + marxist, match.out=mout4, nboots=500, ks=TRUE, paired=FALSE)

## CI ONLY COERCION ONLY ##


In.Peace <- read.csv('GS_pre-match_CICOER.csv')
In.Peace [is.na(In.Peace)] <- 0
attach(In.Peace)

# SET GENMATCH INPUTS:

X <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

BalanceMat <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, eeurop, ssafrica, asia, lamerica, nafrme, miltnum)

# BALANCE:

genout <- GenMatch(Tr=noforcenfc, X=X, BalanceMatrix=BalanceMat, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10,int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout <- Match(Y=ldur, Tr=noforcenfc, X=X, estimand="ATT", Weight.matrix=genout, M=1)
summary(mout, full=TRUE)

p.match <- rbind(In.Peace[mout$index.treated,], In.Peace[mout$index.control,])
write.dta(p.match,'peace_post_match_CICOER.dta')

# CHECK BALANCE:

mb <- MatchBalance (noforcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + eeurop + lamerica + asia + nafrme + ssafrica + miltnum, match.out=mout, nboots=500, ks=TRUE, paired=FALSE)

rm(list=ls(all=TRUE))

# MATCH 2

In.Peace <- read.csv('GS_pre-match_CICOER.csv')
In.Peace [is.na(In.Peace)] <- 0
attach(In.Peace)

# SET GENMATCH INPUTS:

X <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

BalanceMat <- cbind(lwdeaths, lwdurat, milper, pop, ethfrac, lmtnest, bwplty2, miltnum, ethnicwar, terr, marxist)

# BALANCE:

genout <- GenMatch(Tr=noforcenfc, X=X, BalanceMatrix=BalanceMat, estimand="ATT", M=1, pop.size=1000, max.generations=100, wait.generations=10,int.seed=7, unif.seed=10, data.type.int=FALSE)

# MATCH:

mout <- Match(Y=ldur, Tr=noforcenfc, X=X, estimand="ATT", Weight.matrix=genout, M=1)
summary(mout, full=TRUE)

p.match <- rbind(In.Peace[mout$index.treated,], In.Peace[mout$index.control,])
write.dta(p.match,'peace_post_match_CICOER2.dta')

# CHECK BALANCE:

mb <- MatchBalance (noforcenfc ~ lwdeaths + lwdurat + ethfrac + pop + lmtnest + milper + bwgdp + bwplty2 + ethnicwar + terr + marxist, match.out=mout, nboots=500, ks=TRUE, paired=FALSE)


