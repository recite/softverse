
# Replication file for Appendix I

#install.packages("Hmisc")
require(Hmisc)
#install.packages("stargazer")
require(stargazer)

load("Brexit_Rep.RData")

leavers.sub <- brexit.sub2[which(brexit.sub2$leaver == 1),]
remainers.sub <- brexit.sub2[which(brexit.sub2$leaver == 0),]

dvs <- Cs(migs.take.jobs.6,migs.more.terror.6,closed.immigrants.6,hurt.standing.refugee.6,
          threaten.culture.refugee.6,overwhelm.welfare.refugee.6)

leavers.sub[dvs] <- lapply(leavers.sub[dvs], factor)
remainers.sub[dvs] <- lapply(remainers.sub[dvs], factor)



ate.l <- vector(length(dvs), mode = "list")
names(ate.l) <- dvs

ate.r <- vector(length(dvs), mode = "list")
names(ate.r) <- dvs


for (i in 1:(length(dvs))){
  
  modelformula <- paste(dvs[i],"~ post")
  print(modelformula)
  
  ate.l[[dvs[i]]] <- eval(substitute(polr(.modelformula, data = leavers.sub, 
                                        weights = w8w6, Hess = TRUE), list(.modelformula = modelformula)))
  
}


for (i in 1:(length(dvs))){
  
  modelformula <- paste(dvs[i],"~ post")
  print(modelformula)
  
  ate.r[[dvs[i]]] <- eval(substitute(polr(.modelformula, data = remainers.sub, 
                                        weights = w8w6, Hess = TRUE), list(.modelformula = modelformula)))
  
}

stargazer(ate.l[[1]], ate.r[[1]], ate.l[[2]], ate.r[[2]], ate.l[[3]], ate.r[[3]])
stargazer(ate.l[[5]], ate.r[[5]], ate.l[[6]], ate.r[[6]], ate.l[[4]], ate.r[[4]], keep.stat = c("aic", "rsq", "n"))


