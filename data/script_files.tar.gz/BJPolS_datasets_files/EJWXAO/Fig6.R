
# Run Multiple_Mediation.R to generate the objects necessary for this figure. 

# Leavers

l <- length(dvs)
m.pt.est.l <- matrix(NA,l,1) # AMCE
m.ci.l <- matrix(NA,l,2) # CI of AMCE 


for(i in 1:l){  
  
  med.tmp <- m.all.leavers[[i]][[1]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.l[i,] <- ci
  m.pt.est.l[i,] <- med.tmp$d.ave.lb[1]
}

m.ci.1.l <- m.ci.l[,1]
m.ci.2.l <- m.ci.l[,2]


# Remainers


l <- length(dvs)
m.pt.est.r <- matrix(NA,l,1) # AMCE
m.ci.r <- matrix(NA,l,2) # CI of AMCE 

for(i in 1:l){  
  
  med.tmp <- m.all.remainers[[i]][[1]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.r[i,] <- ci
  m.pt.est.r[i,] <- med.tmp$d.ave.lb[1]
}


m.ci.1.r <- m.ci.r[,1]
m.ci.2.r <- m.ci.r[,2]



yr.lab <- c(1,2,3,4,5,6)

jitter<-.1

varlbls <-c("Migs. Take\nJobs", "Migs. Bring\nTerror","Not\nOpen to\nMigs.",
            "Refs. Don't\nImprove\nUK Image","Refs.\nThreaten\nCulture","Refs.\nOverwhelm\nServices")



pdf("Fig6.pdf",height=6, width=8)
nf <- layout(matrix(c(1,2), 1, 2, byrow = TRUE), widths=c(1,1))
#layout.show(nf)

# Positive AMCE

par(mar =c(4,5, 6, 0.01), cex.axis=.8, cex.main=.9)
plot(m.pt.est.l, yr.lab, type="n", ylab ="", xlab = "", 
     main="Aversion to Farage", yaxt="n", xlim = c(-0.11,0.11))
axis(2, at=yr.lab, labels=varlbls, las = 2, cex.axis=0.8)
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
segments(m.ci.1.l,yr.lab, m.ci.2.l, yr.lab, lty=1)
points(m.pt.est.l, yr.lab, pch= 19, cex=.8)

segments(m.ci.1.r, yr.lab+jitter, m.ci.2.r, yr.lab+jitter, lty=1)
points(m.pt.est.r, yr.lab+jitter, pch= 19, cex=.8, col = "white")
points(m.pt.est.r, yr.lab+jitter, pch= 1, cex=.8)

abline(v=0)
legend(0.05, 6, pch=c(19,1), legend=c("Leave", "Remain"), cex =.8, border = "black")
mtext("",side=2,line=0.5,outer=TRUE)

dev.off()


