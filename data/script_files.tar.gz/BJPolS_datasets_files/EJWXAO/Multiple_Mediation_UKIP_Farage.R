

load("Brexit_Rep.RData")

ukipper.sub <- brexit.sub2[which(brexit.sub2$partyid.main.5 == 4),]
ukipper.sub <- as.data.frame(ukipper.sub)

dvs <- Cs(migs.take.jobs.6,migs.more.terror.6,closed.immigrants.6,hurt.standing.refugee.6,
          threaten.culture.refugee.6,overwhelm.welfare.refugee.6)

all.mediators.6 <- Cs(efficacy.vote.6,gov.trust.6, 
                      bad.past.econ.6,hh.bad.past.econ.6) 
all.mediators.5 <- Cs(farage.5,efficacy.vote.5,gov.trust.5, 
                      bad.past.econ.5,hh.bad.past.econ.5)  


m.all.ukippers <- vector(length(dvs), mode = "list")
names(m.all.ukippers) <- dvs


require(mediation)


for (i in 1:(length(dvs))){
  
    
    x <- multimed(outcome = dvs[i], med.main = "farage.6", 
                  med.alt = all.mediators.6,
                  treat = "post", covariates = all.mediators.5, data = ukipper.sub, sims = 1000, 
                  weight = "w8w6")
    
    print(x)
    
    m.all.ukippers[[dvs[i]]] <- x
    
  }

