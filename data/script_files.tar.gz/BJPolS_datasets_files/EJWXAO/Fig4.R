
# Run Multiple_Mediation.R to generate the objects necessary for this figure. 

l <- length(dvs)

#Leavers
m.pt.est.li <- matrix(NA,l,1) # AMCE
m.ci.li <- matrix(NA,l,2) # CI of AMCE 
m.pt.est.lh <- matrix(NA,l,1) # AMCE
m.ci.lh <- matrix(NA,l,2) # CI of AMCE 

#Remainers

m.pt.est.ri <- matrix(NA,l,1) # AMCE
m.ci.ri <- matrix(NA,l,2) # CI of AMCE 
m.pt.est.rh <- matrix(NA,l,1) # AMCE
m.ci.rh <- matrix(NA,l,2) # CI of AMCE 


# Overall Insecurity
for(i in 1:l){  
  
  med.tmp <- m.all.leavers[[i]][[4]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.li[i,] <- ci
  m.pt.est.li[i,] <- med.tmp$d.ave.lb[1]
  
  print(m.pt.est.li[i,]) 
  print(m.ci.li[i,])
}

m.ci.1.li <- m.ci.li[,1]
m.ci.2.li <- m.ci.li[,2]

# Overall Insecurity
for(i in 1:l){  
  
  med.tmp <- m.all.remainers[[i]][[4]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.ri[i,] <- ci
  m.pt.est.ri[i,] <- med.tmp$d.ave.lb[1]
  
  print(m.pt.est.ri[i,]) 
  print(m.ci.ri[i,])
}

m.ci.1.ri <- m.ci.ri[,1]
m.ci.2.ri <- m.ci.ri[,2]


# Household insecurity
for(i in 1:l){  
  
  med.tmp <- m.all.leavers[[i]][[5]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.lh[i,] <- ci
  m.pt.est.lh[i,] <- med.tmp$d.ave.lb[1]
  
  print(m.pt.est.lh[i,]) 
  print(m.ci.lh[i,])
}

m.ci.1.lh <- m.ci.lh[,1]
m.ci.2.lh <- m.ci.lh[,2]

# Household Insecurity
for(i in 1:l){  
  
  med.tmp <- m.all.remainers[[i]][[5]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.rh[i,] <- ci
  m.pt.est.rh[i,] <- med.tmp$d.ave.lb[1]
  
  print(m.pt.est.rh[i,]) 
  print(m.ci.rh[i,])
}

m.ci.1.rh <- m.ci.rh[,1]
m.ci.2.rh <- m.ci.rh[,2]



yr.lab <- c(1,2,3,4,5,6)

jitter<-.1

varlbls <-c("Migs. Take\nJobs", "Migs. Bring\nTerror","Not\nOpen to\nMigs.",
            "Refs. Don't\nImprove\nUK Image","Refs.\nThreaten\nCulture","Refs.\nOverwhelm\nServices")


#dev.off()
pdf("Fig4.pdf",height=6, width=8.1)
nf <- layout(matrix(c(1,2), 1, 2, byrow = TRUE), widths=c(1,1))

# Sociotropic AMCE

par(mar =c(4,5, 6, 0.01), cex.axis=.8, cex.main=.9)

plot(m.pt.est.li, yr.lab, type="n", ylab ="", xlab = "", 
     main="Sociotropic Insecurity", yaxt="n", xlim = c(-0.03,0.03))
axis(2, at=yr.lab, labels=varlbls, las = 2, cex.axis=0.8)
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
segments(m.ci.1.li,yr.lab, m.ci.2.li, yr.lab, lty=1)
points(m.pt.est.li, yr.lab, pch= 19, cex=.8)

segments(m.ci.1.ri, yr.lab+jitter, m.ci.2.ri, yr.lab+jitter, lty=1)
points(m.pt.est.ri, yr.lab+jitter, pch= 19, cex=.8, col = "white")
points(m.pt.est.ri, yr.lab+jitter, pch= 1, cex=.8)

abline(v=0)

# Pocketbook AMCE

par(mar =c(4,2, 6, 3), cex.axis=.8, cex.main=.9)
plot(m.pt.est.lh, yr.lab, type="n", ylab ="", xlab = "", 
     main="Pocketbook Insecurity", yaxt="n", xlim = c(-0.03,0.03))
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
segments(m.ci.1.lh,yr.lab, m.ci.2.lh, yr.lab, lty=1)
points(m.pt.est.lh, yr.lab, pch= 19, cex=.8)

segments(m.ci.1.rh, yr.lab+jitter, m.ci.2.rh, yr.lab+jitter, lty=1)
points(m.pt.est.rh, yr.lab+jitter, pch= 19, cex=.8, col = "white")
points(m.pt.est.rh, yr.lab+jitter, pch= 1, cex=.8)

abline(v=0)
legend(0.013, 6, pch=c(19,1), legend=c("Leave", "Remain"), cex =.8, border = "black")
mtext("",side=2,line=0.5,outer=TRUE)

dev.off()
