#Replication file for Fig. 3 (body) and Appendix G.3. Tables 27 and 28

#install.packages("Hmisc")
require(Hmisc)
#install.packages("stargazer")
require(stargazer)

load("Brexit_Rep.RData")

leavers.sub <- brexit.sub2[which(brexit.sub2$leaver == 1),]
remainers.sub <- brexit.sub2[which(brexit.sub2$leaver == 0),]

#####

all.mediators.6 <- Cs(farage.6,efficacy.vote.6,gov.trust.6, 
                      bad.past.econ.6,hh.bad.past.econ.6) 

# Prior wave lag
all.mediators.5 <- Cs(farage.5,efficacy.vote.5,gov.trust.5, 
                      bad.past.econ.5,hh.bad.past.econ.5)  

dvs <- Cs(migs.take.jobs.6,migs.more.terror.6,closed.immigrants.6,hurt.standing.refugee.6,
          threaten.culture.refugee.6,overwhelm.welfare.refugee.6)


zm.l <- vector(length(all.mediators.6), mode = "list")
names(zm.l) <- all.mediators.6

zm.r <- vector(length(all.mediators.6), mode = "list")
names(zm.r) <- all.mediators.6

# Leavers

for (i in 1:(length(all.mediators.6))){
  
  modelformula <- paste(all.mediators.6[i],"~ post +",all.mediators.5[i])
  print(modelformula)
  
  zm.l[[all.mediators.6[i]]] <-  eval(substitute(lm(.modelformula, data = leavers.sub, weights = w8w6), 
                                                     list(.modelformula = modelformula)))
  
  print(summary(zm.l[[all.mediators.6[i]]]))
  
}

# Remainers

for (i in 1:(length(all.mediators.6))){
  
  modelformula <- paste(all.mediators.6[i],"~ post +",all.mediators.5[i])
  print(modelformula)
  
  zm.r[[all.mediators.6[i]]] <-  eval(substitute(lm(.modelformula, data = remainers.sub, weights = w8w6), 
                                                 list(.modelformula = modelformula)))
  
  print(summary(zm.r[[all.mediators.6[i]]]))
  
  
}

# Appendix G.3. Tables


stargazer(zm.l[[1]], zm.r[[1]],zm.l[[2]],zm.r[[2]], zm.l[[3]], zm.r[[3]])
stargazer(zm.l[[4]], zm.r[[4]],zm.l[[5]],zm.r[[5]])


# Coefplots


cis.l <- matrix(NA,length(all.mediators.6),2)
b.l <- matrix(NA,length(all.mediators.6),1)
cis.r <- matrix(NA,length(all.mediators.6),2)
b.r <- matrix(NA,length(all.mediators.6),1)

for (i in 1:length(all.mediators.6))
{
  b.l[i] <- zm.l[[i]]$coefficients[2]
  print(zm.l[[i]]$coefficients[2])
  ci <- confint(zm.l[[i]])
  #print(ci)
  lb <- ci[2,1]
  ub <- ci[2,2]
  cis.l[i,] <- cbind(lb,ub)
}

for (i in 1:length(all.mediators.6))
{
  b.r[i] <- zm.r[[i]]$coefficients[2]
  ci <- confint(zm.r[[i]])
  print(b.r[i])
  lb <- ci[2,1]
  ub <- ci[2,2]
  cis.r[i,] <- cbind(lb,ub)
}



vnames <- c("Aversion to\nFarage","Political\nEfficacy","Government,\nTrust",
            "Economic\nInsecurity,\nSociotropic","Economic\nInsecurity,\nPocketbook")


y.lab <- seq(from = 1, to=length(all.mediators.6),by=1)

jitter <-  0.1

#pdf("Fig3.pdf", height = 5, width=5)
par(mar =c(1.2,3.1, 4.1, 0.01), oma=c(1,5,.2,.2), cex.axis=.8, cex.main=.9)
plot(b.l, y.lab, type="n", ylab ="", xlab = "", yaxt="n", xlim = c(-0.6,0.6), ylim=c(1,5.1))
axis(2, at=y.lab, labels=vnames, las = 2, cex.axis=0.8)
points(b.l, y.lab, pch= 19, cex=.8, col = "black")
segments(cis.l[,1], y.lab, cis.l[,2], y.lab, lty=1, col = "black")
segments(cis.r[,1], y.lab+jitter, cis.r[,2], y.lab+jitter, lty=1, col = "black")
points(b.r, y.lab+jitter, pch= 19, cex=.8, col = "white")
points(b.r, y.lab+jitter, pch= 1, cex=.8)
abline(v=0)
legend(0.3, 5.1, pch=c(19,1), legend=c("Leave", "Remain"), cex =.8, border = "black")
dev.off()

