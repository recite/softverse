
#Replication file for Appendix A

#install.packages("weights")
library(weights)
library(dplyr)
library(readr)

load("Brexit_Rep.RData")

treated.sub.d <-  brexit.sub2[which(brexit.sub2$post == 1),]
control.sub.d <-  brexit.sub2[which(brexit.sub2$post == 0),]

props <- function(x) {x/sum(x, na.rm=TRUE)}


# % Male (=1)

t.gender <- Hmisc::wtd.table(treated.sub.d$Gender, weights= treated.sub.d$w8w6, type = 'table')
c.gender <- Hmisc::wtd.table(control.sub.d$Gender, weights= control.sub.d$w8w6, type = 'table')

g <- rbind(t.gender, c.gender)

props(t.gender)
props(c.gender)

chisq.test(g)

# Age

wtd.mean(treated.sub.d$Age, weights= treated.sub.d$w8w6)
wtd.mean(control.sub.d$Age, weights= control.sub.d$w8w6)

age.lm <- lm(Age ~ post, data = brexit.sub2, weights = w8w6)
summary(age.lm)

age.ks <- ks.test(treated.sub.d$Age, control.sub.d$Age, alternative = "two.sided")

age.ks


treated.sub.d <- treated.sub.d %>%
  
  mutate(agecat = Age,
         agecat = case_when(
           Age %in% 18:24 ~ "18-24",
           Age %in% 25:39 ~ "25-39",
           Age %in% 40:59 ~ "40-59",
           Age >= 60 ~ "60+"))

control.sub.d <- control.sub.d %>%
  
  mutate(agecat = Age,
         agecat = case_when(
           Age %in% 18:24 ~ "18-24",
           Age %in% 25:39 ~ "25-39",
           Age %in% 40:59 ~ "40-59",
           Age >= 60 ~ "60+"))

t.agecat <- Hmisc::wtd.table(treated.sub.d$agecat, weights= treated.sub.d$w8w6, type = 'table')
c.agecat <- Hmisc::wtd.table(control.sub.d$agecat, weights= control.sub.d$w8w6, type = 'table')

props(t.agecat)
props(c.agecat)

ac <- rbind(t.agecat, c.agecat)

chisq.test(ac) # Not significant


# Income

t.income <- Hmisc::wtd.table(treated.sub.d$Hincome.rec, weights= treated.sub.d$w8w6, type = 'table')
c.income <- Hmisc::wtd.table(control.sub.d$Hincome.rec, weights= control.sub.d$w8w6, type = 'table')

i <- rbind(t.income, c.income) 

chisq.test(i)

props(t.income)
props(c.income)

# Education


t.education <- Hmisc::wtd.table(treated.sub.d$Education, weights= treated.sub.d$w8w6, type = 'table')
c.education <- Hmisc::wtd.table(control.sub.d$Education, weights= control.sub.d$w8w6, type = 'table')

e <- rbind(t.education, c.education)

chisq.test(e)

props(t.education)
props(c.education)

# Ethnicity

treated.sub.d$ethnicity <- car::recode(treated.sub.d$ethnicity_full,"2=1;3=1;4=1;5=2;6=2;7=2;8=2;9=2;10=2;11=2;12=2;13=2;14=2;15=2;16=2;
                                       17=2;18=2;19=NA;98=NA;99=NA")
control.sub.d$ethnicity <- car::recode(control.sub.d$ethnicity_full,"2=1;3=1;4=1;5=2;6=2;7=2;8=2;9=2;10=2;11=2;12=2;13=2;14=2;15=2;16=2;
                                       17=2;18=2;19=NA;98=NA;99=NA")

t.ethnicity <- Hmisc::wtd.table(treated.sub.d$ethnicity, weights= treated.sub.d$w8w6, type = 'table')
c.ethnicity <- Hmisc::wtd.table(control.sub.d$ethnicity, weights= control.sub.d$w8w6, type = 'table')

e <- rbind(t.ethnicity, c.ethnicity)
chisq.test(e)

props(t.ethnicity)
props(c.ethnicity)

# Religion -- Variable not there

t.religion <- Hmisc::wtd.table(treated.sub.d$relig.freq, weights= treated.sub.d$w8w6, type = 'table')
c.religion <- Hmisc::wtd.table(control.sub.d$relig.freq, weights= control.sub.d$w8w6, type = 'table')

r <- rbind(t.religion, c.religion)
chisq.test(r)

props(t.religion)
props(c.religion)

# Children 

treated.sub.d$children <- car::recode(treated.sub.d$household_children_full,"1=0;2=1;3=2;4=3;5=4;6=5;8=NA;9=NA;10=NA;98=NA")
control.sub.d$children <- car::recode(control.sub.d$household_children_full,"1=0;2=1;3=2;4=3;5=4;6=5;8=NA;9=NA;10=NA;98=NA")

t.children <- Hmisc::wtd.table(treated.sub.d$children, weights= treated.sub.d$w8w6, type = 'table')
c.children <- Hmisc::wtd.table(control.sub.d$children, weights= control.sub.d$w8w6, type = 'table')

k <- rbind(t.children, c.children)
k

chisq.test(k)

props(t.children)
props(c.children)

# Marital status

control.sub.d$marstat <- control.sub.d$marital_stat_full
control.sub.d$marstat[control.sub.d$marstat > 1] <- 0

treated.sub.d$marstat <- treated.sub.d$marital_stat_full
treated.sub.d$marstat[treated.sub.d$marstat > 1] <- 0

t.marstat <- Hmisc::wtd.table(treated.sub.d$marstat, weights= treated.sub.d$w8w6, type = 'table')
c.marstat <- Hmisc::wtd.table(control.sub.d$marstat, weights= control.sub.d$w8w6, type = 'table')

m <- rbind(t.marstat, c.marstat)
m

chisq.test(m)

props(t.marstat)
props(c.marstat)

# Work type

treated.sub.d$work.type <- car::recode(treated.sub.d$work_type_full, "2=1;3=2;4=2;5=3;6=4;7=4;8=5;9=6")
control.sub.d$work.type <- car::recode(control.sub.d$work_type_full, "2=1;3=2;4=2;5=3;6=4;7=4;8=5;9=6")

treated.sub.d$work.type <- labelled(treated.sub.d$work.type, c("Professional/Manager" = 1,"Clerical/Sales" = 2,
                                                               "Supervisor"=3,"Skilled/Semi-Skilled Manual"= 4,"Other" = 5, "Never Worked" = 6))

control.sub.d$work.type <- labelled(control.sub.d$work.type, c("Professional/Manager" = 1,"Clerical/Sales" = 2,
                                                               "Supervisor"=3,"Skilled/Semi-Skilled Manual"= 4,"Other" = 5, "Never Worked" = 6))


t.work.type <- Hmisc::wtd.table(treated.sub.d$work.type, weights= treated.sub.d$w8w6, type = 'table')
c.work.type <- Hmisc::wtd.table(control.sub.d$work.type, weights= control.sub.d$w8w6, type = 'table')

w <- rbind(t.work.type, c.work.type)
w

chisq.test(w)

props(t.work.type)
props(c.work.type)


# EU Support
# Disaggregated
all.leave <- Hmisc::wtd.table(brexit.sub$eu.disapprove, weights=brexit.sub$w8w6, type = 'table')

t.leave.d <- Hmisc::wtd.table(treated.sub.d$eu.disapprove, weights= treated.sub.d$w8w6, type = 'table')
c.leave.d <- Hmisc::wtd.table(control.sub.d$eu.disapprove, weights= control.sub.d$w8w6, type = 'table')

lr.d <- rbind(t.leave.d, c.leave.d) 
lr.d

chisq.test(lr.d)

props(t.leave.d)
props(c.leave.d)

# Aggregated
t.leave <- Hmisc::wtd.table(treated.sub.d$leaver, weights= treated.sub.d$w8w6, type = 'table')
c.leave <- Hmisc::wtd.table(control.sub.d$leaver, weights= control.sub.d$w8w6, type = 'table')

lr <- rbind(t.leave, c.leave) 

props(t.leave)
props(c.leave)

chisq.test(lr)

all.leave <- Hmisc::wtd.table(brexit.sub$leaver, weights=brexit.sub$w8w6, type = 'table')
props(all.leave)


# Newspaper readership 

t.newspaper <- Hmisc::wtd.table(treated.sub.d$leave.papers, weights= treated.sub.d$w8w6, type = 'table')
c.newspaper <- Hmisc::wtd.table(control.sub.d$leave.papers, weights= control.sub.d$w8w6, type = 'table')

n <- rbind(t.newspaper, c.newspaper)
chisq.test(n)

props(t.newspaper)
props(c.newspaper)

# Support for parties wave 5

t.parties5 <- Hmisc::wtd.table(treated.sub.d$partyid.main.5, weights= treated.sub.d$w8w6, type = 'table')
c.parties5 <- Hmisc::wtd.table(control.sub.d$partyid.main.5, weights= control.sub.d$w8w6, type = 'table')

p <- rbind(t.parties5, c.parties5)
p
chisq.test(p)

props(t.parties5)
props(c.parties5)


### Country in UK

t.country <- Hmisc::wtd.table(treated.sub.d$country_full, weights= treated.sub.d$w8w6, type = 'table')
c.country <- Hmisc::wtd.table(control.sub.d$country_full, weights= control.sub.d$w8w6, type = 'table')

c <- rbind(t.country, c.country)
c
chisq.test(c)

props(t.country)
props(c.country)

###

print_labels(brexit.sub2$GOR_full)

t.region <- Hmisc::wtd.table(treated.sub.d$GOR_full, weights= treated.sub.d$w8w6, type = 'table')
c.region <- Hmisc::wtd.table(control.sub.d$GOR_full, weights= control.sub.d$w8w6, type = 'table')

c <- rbind(t.region, c.region)
c
chisq.test(c)

props(t.region)
props(c.region)

#### Employment status
  
treated.sub.d$work.stat <-car::recode(treated.sub.d$work_stat_full, "2=1;3=1;4=0;5=0;6=0;7=0;8=NA")
control.sub.d$work.stat <-car::recode(control.sub.d$work_stat_full, "2=1;3=1;4=0;5=0;6=0;7=0;8=NA")

t.work.stat <- Hmisc::wtd.table(treated.sub.d$work.stat, weights= treated.sub.d$w8w6, type = 'table')
c.work.stat <- Hmisc::wtd.table(control.sub.d$work.stat, weights= control.sub.d$w8w6, type = 'table')

s <- rbind(t.work.stat, c.work.stat)

chisq.test(s)

props(t.work.stat)
props(c.work.stat)

### Social grade

print_labels(brexit.sub2$socialgrade)

t.socialgrade <- Hmisc::wtd.table(treated.sub.d$socialgrade, weights= treated.sub.d$w8w6, type = 'table')
c.socialgrade <- Hmisc::wtd.table(control.sub.d$socialgrade, weights= control.sub.d$w8w6, type = 'table')

g <- rbind(t.socialgrade, c.socialgrade)

chisq.test(g)

props(t.socialgrade)
props(c.socialgrade)
