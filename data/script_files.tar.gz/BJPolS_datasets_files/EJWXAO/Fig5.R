
# Run Multiple_Mediation.R to generate the objects necessary for this figure. 

l <- length(dvs)

#Leavers
m.pt.est.lt <- matrix(NA,l,1) # AMCE
m.ci.lt <- matrix(NA,l,2) # CI of AMCE 

m.pt.est.le <- matrix(NA,l,1) # AMCE
m.ci.le <- matrix(NA,l,2) # CI of AMCE 

#Remainers

m.pt.est.rt <- matrix(NA,l,1) # AMCE
m.ci.rt <- matrix(NA,l,2) # CI of AMCE 

m.pt.est.re <- matrix(NA,l,1) # AMCE
m.ci.re <- matrix(NA,l,2) # CI of AMCE 

# Government Trust
for(i in 1:l){  
  
  med.tmp <- m.all.leavers[[i]][[3]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.lt[i,] <- ci
  m.pt.est.lt[i,] <- med.tmp$d.ave.lb[1]
}

# Efficacy
for(i in 1:l){  
  
  med.tmp <- m.all.leavers[[i]][[2]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.le[i,] <- ci
  m.pt.est.le[i,] <- med.tmp$d.ave.lb[1]
}

m.ci.1.lt <- m.ci.lt[,1]
m.ci.2.lt <- m.ci.lt[,2]

m.ci.1.le <- m.ci.le[,1]
m.ci.2.le <- m.ci.le[,2]


# Remainers

# Government Trust
for(i in 1:l){  
  
  med.tmp <- m.all.remainers[[i]][[3]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.rt[i,] <- ci
  m.pt.est.rt[i,] <- med.tmp$d.ave.lb[1]
}

# Efficacy
for(i in 1:l){  
  
  med.tmp <- m.all.remainers[[i]][[2]]
  
  print(summary(med.tmp))
  
  d.ci.lo <- c()
  d.ci.up <- c()
  d.ci.up <- cbind(d.ci.up, med.tmp$d.ave.ci[2, ])
  d.ci.lo <- cbind(d.ci.lo, med.tmp$d.ave.ci[1, ])
  ci <- rbind(d.ci.lo[1,], d.ci.up[1, ])
  m.ci.re[i,] <- ci
  m.pt.est.re[i,] <- med.tmp$d.ave.lb[1]
}

m.ci.1.rt <- m.ci.rt[,1]
m.ci.2.rt <- m.ci.rt[,2]

m.ci.1.re <- m.ci.re[,1]
m.ci.2.re <- m.ci.re[,2]


yr.lab <- c(1,2,3,4,5,6)

jitter<-.1

varlbls <-c("Migs. Take\nJobs", "Migs. Bring\nTerror","Not\nOpen to\nMigs.",
            "Refs. Don't\nImprove\nUK Image","Refs.\nThreaten\nCulture","Refs.\nOverwhelm\nServices")




pdf("Fig5.pdf",height=6, width=8)
nf <- layout(matrix(c(1,2), 1, 2, byrow = TRUE), widths=c(1,1))

# Government Trust AMCE

par(mar =c(4,5, 6, 0.01), cex.axis=.8, cex.main=.9)
plot(m.pt.est.lt, yr.lab, type="n", ylab ="", xlab = "", 
     main="Government Trust", yaxt="n", xlim = c(-0.05,0.05))
axis(2, at=yr.lab, labels=varlbls, las = 2, cex.axis=0.8)
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
segments(m.ci.1.lt,yr.lab, m.ci.2.lt, yr.lab, lty=1)
points(m.pt.est.lt, yr.lab, pch= 19, cex=.8)

segments(m.ci.1.rt, yr.lab+jitter, m.ci.2.rt, yr.lab+jitter, lty=1)
points(m.pt.est.rt, yr.lab+jitter, pch= 19, cex=.8, col = "white")
points(m.pt.est.rt, yr.lab+jitter, pch= 1, cex=.8)

abline(v=0)

# Efficacy AMCE

par(mar =c(4,2, 6, 3), cex.axis=.8, cex.main=.9)
plot(m.pt.est.re, yr.lab, type="n", ylab ="", xlab = "", 
     main="Political Efficacy", yaxt="n", xlim = c(-0.05,0.05))
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
segments(m.ci.1.le,yr.lab, m.ci.2.le, yr.lab, lty=1)
points(m.pt.est.le, yr.lab, pch= 19, cex=.8)

segments(m.ci.1.re, yr.lab+jitter, m.ci.2.re, yr.lab+jitter, lty=1)
points(m.pt.est.re, yr.lab+jitter, pch= 19, cex=.8, col = "white")
points(m.pt.est.re, yr.lab+jitter, pch= 1, cex=.8)

abline(v=0)
legend(0.02, 6, pch=c(19,1), legend=c("Leave", "Remain"), cex =.8, border = "black")
mtext("",side=2,line=0.5,outer=TRUE)
dev.off()
