
# Replication file for Appendix E

#install.packages("Hmisc")
require(Hmisc)
#install.packages("stargazer")
require(stargazer)
#install.packages("coefplot")
#install_github("jaredlander/coefplot")
require(coefplot)


load("Brexit_Rep.RData")

leavers.sub <- brexit.sub2[which(brexit.sub2$leaver == 1),]
remainers.sub <- brexit.sub2[which(brexit.sub2$leaver == 0),]

dvs <- Cs(migs.take.jobs.6,migs.more.terror.6,closed.immigrants.6,hurt.standing.refugee.6,
          threaten.culture.refugee.6,overwhelm.welfare.refugee.6)

# Effect of Brexit on Mediators for Leavers (create empty vector to populate)
my.l <- vector(length(dvs), mode = "list")
names(my.l) <- dvs

# Effect of Brexit on Mediators for Remainers
my.r <- vector(length(dvs), mode = "list")
names(my.r) <- dvs


### Mediators on Ys


for (i in 1:(length(dvs))){
  
  modelformula <- paste(dvs[i],"~ efficacy.vote.6 + gov.trust.6 + bad.past.econ.6 + hh.bad.past.econ.6 + farage.6")
  print(modelformula)
  
  my.l[[dvs[i]]] <- eval(substitute(lm(.modelformula, data = leavers.sub, 
                                        weights = w8w6), list(.modelformula = modelformula)))
  
}


for (i in 1:(length(dvs))){
  
  modelformula <- paste(dvs[i],"~ efficacy.vote.6 + gov.trust.6 + bad.past.econ.6 + hh.bad.past.econ.6 + farage.6")
  print(modelformula)
  
  my.r[[dvs[i]]] <- eval(substitute(lm(.modelformula, data = remainers.sub, 
                                        weights = w8w6), list(.modelformula = modelformula)))
  
}

mednames <- c(efficacy.vote.6 ="Locus\nof Control,\nEfficacy", gov.trust.6="Locus\nof Control,\nTrust",
              bad.past.econ.6 ="Economic\nInsecurity,\nSociotropic", hh.bad.past.econ.6="Economic\nInsecurity,\nPocketbook",
              farage.6="Aversion to,\nFarage")

# Figure 8

pdf("MY_MigJobs_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[1]]], my.r[[dvs[1]]], intercept = F,
                    zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
                    xlab = "Effect of Mediator",
                    newNames = mednames,
                    names = c("Leavers", "Remainers"), 
                    sort = "natural", title = "") + theme_bw() +
  scale_color_manual(values=c("black","gray")) + 
  theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()

pdf("MY_MigTerror_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[2]]], my.r[[dvs[2]]], intercept = F,
                    zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
                    xlab = "Effect of Mediator",
                    newNames = mednames,
                    names = c("Leavers", "Remainers"), 
                    sort = "natural", title = "") + theme_bw() +
  scale_color_manual(values=c("black","gray")) + 
  theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()

pdf("MY_OpenMig_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[3]]], my.r[[dvs[3]]], intercept = F,
          zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
          xlab = "Effect of Mediator",
          newNames = mednames,
          names = c("Leavers", "Remainers"), 
          sort = "natural", title = "") + theme_bw() + 
         scale_color_manual(values=c("black","gray")) + 
         theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()

### Figure 9

pdf("MY_RefHarm_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[4]]], my.r[[dvs[4]]], intercept = F,
                    zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
                    xlab = "Effect of Mediator",
                    newNames = mednames,
                    names = c("Leavers", "Remainers"), 
                    sort = "natural", title = "") + theme_bw() +
  scale_color_manual(values=c("black","gray")) + 
  theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()


pdf("MY_RefCult_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[5]]], my.r[[dvs[5]]], intercept = F,
          zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
          xlab = "Effect of Mediator",
          newNames = mednames,
          names = c("Leavers", "Remainers"), sort = "natural", title = "") + theme_bw() +
  scale_color_manual(values=c("black","gray")) + 
  theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()

pdf("MY_RefWelf_BL.pdf", height = 5, width=5)
coefplot::multiplot(my.l[[dvs[6]]], my.r[[dvs[6]]], intercept = F,
          zeroColor = "black", zeroLWD = 0.5, color = "black", ylab = "", 
          xlab = "Effect of Mediator",
          newNames = mednames,
          names = c("Leavers", "Remainers"), 
          sort = "natural", title = "") + theme_bw() +
  scale_color_manual(values=c("black","gray")) + 
  theme(axis.text = element_text(size = 13), text = element_text(size = 13))
dev.off()
