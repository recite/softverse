

# Replication file for Table 1


#install.packages("Hmisc")
require(Hmisc)
#install.packages("stargazer")
require(stargazer)


load("Brexit_Rep.RData")

leavers.sub <- brexit.sub2[which(brexit.sub2$leaver == 1),]
remainers.sub <- brexit.sub2[which(brexit.sub2$leaver == 0),]


#### Row 1

Hmisc::wtd.mean(leavers.sub$threaten.culture.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
d.cult.v.l <- Hmisc::wtd.var(leavers.sub$threaten.culture.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.cult.v.l)

Hmisc::wtd.mean(remainers.sub$threaten.culture.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
d.cult.v.r <- Hmisc::wtd.var(remainers.sub$threaten.culture.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.cult.v.r)

#### Row 2

Hmisc::wtd.mean(leavers.sub$overwhelm.welfare.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
d.welf.v.l <- Hmisc::wtd.var(leavers.sub$overwhelm.welfare.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.welf.v.l)

Hmisc::wtd.mean(remainers.sub$overwhelm.welfare.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
d.welf.v.r <- Hmisc::wtd.var(remainers.sub$overwhelm.welfare.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.welf.v.r)

#### Row 3

Hmisc::wtd.mean(leavers.sub$hurt.standing.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
d.hurt.v.l <- Hmisc::wtd.var(leavers.sub$hurt.standing.refugee.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.hurt.v.l)

Hmisc::wtd.mean(remainers.sub$hurt.standing.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
d.hurt.v.r <- Hmisc::wtd.var(remainers.sub$hurt.standing.refugee.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.hurt.v.r)

#### Row 4

Hmisc::wtd.mean(leavers.sub$closed.immigrants.6, na.rm = T, weights = leavers.sub$w8w6)
d.closed.v.l <- Hmisc::wtd.var(leavers.sub$closed.immigrants.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.closed.v.l)

Hmisc::wtd.mean(remainers.sub$closed.immigrants.6, na.rm = T, weights = remainers.sub$w8w6)
d.closed.v.r <- Hmisc::wtd.var(remainers.sub$closed.immigrants.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.closed.v.r)

#### Row 5

Hmisc::wtd.mean(leavers.sub$migs.take.jobs.6, na.rm = T, weights = leavers.sub$w8w6)
d.jobs.v.l <- Hmisc::wtd.var(leavers.sub$migs.take.jobs.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.jobs.v.l)

Hmisc::wtd.mean(remainers.sub$migs.take.jobs.6, na.rm = T, weights = remainers.sub$w8w6)
d.jobs.v.r <- Hmisc::wtd.var(remainers.sub$migs.take.jobs.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.jobs.v.r)

#### Row 6

Hmisc::wtd.mean(leavers.sub$migs.more.terror.6, na.rm = T, weights = leavers.sub$w8w6)
d.terror.v.l <- Hmisc::wtd.var(leavers.sub$migs.more.terror.6, na.rm = T, weights = leavers.sub$w8w6)
sqrt(d.terror.v.l)

Hmisc::wtd.mean(remainers.sub$migs.more.terror.6, na.rm = T, weights = remainers.sub$w8w6)
d.terror.v.r <- Hmisc::wtd.var(remainers.sub$migs.more.terror.6, na.rm = T, weights = remainers.sub$w8w6)
sqrt(d.terror.v.r)




