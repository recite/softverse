
# Replication file for Appendix F, Figure 10


#install.packages("Hmisc")
require(Hmisc)
#install.packages("stargazer")
require(stargazer)

load("Brexit_Rep.RData")

ukipper.sub <- brexit.sub2[which(brexit.sub2$partyid.main.5 == 4),]

dvs <- Cs(migs.take.jobs.6,migs.more.terror.6,closed.immigrants.6,hurt.standing.refugee.6,
          threaten.culture.refugee.6,overwhelm.welfare.refugee.6)

ate.u <- vector(length(dvs), mode = "list")
names(ate.u) <- dvs

for (i in 1:(length(dvs))){
  
  modelformula <- paste(dvs[i],"~ post")
  print(modelformula)
  
  ate.u[[dvs[i]]] <- eval(substitute(lm(.modelformula, data = ukipper.sub, 
                                        weights = w8w6), list(.modelformula = modelformula)))
  
}

cis.u <- matrix(NA,length(dvs),2)
b.u <- matrix(NA,length(dvs),1)

for (i in 1:length(dvs))
{
  b.u[i] <- ate.u[[i]]$coefficients[2]
  ci <- confint(ate.u[[i]])
  lb <- ci[2,1]
  ub <- ci[2,2]
  cis.u[i,] <- cbind(lb,ub)
}

y.lab <- seq(from = 1, to=length(dvs),by=1)
vnames <-c(migs.take.jobs.6 = "Migs. Take\nJobs",migs.more.terror.6 = "Migs. Bring\nTerror", closed.immigrants.6 = "Not\nOpen to\nMigs.",
           hurt.standing.refugee.6 = "Refs. Don't\nImprove\nUK Image", threaten.culture.refugee.6 = "Refs.\nThreaten\nCulture", overwhelm.welfare.refugee.6 ="Refs.\nOverwhelm\nServices")


pdf("ATEs_UKIP.pdf", height = 5, width=5)
par(mar =c(1.2,3.1, 4.1, 0.01), oma=c(1,5,.2,.2), cex.axis=.8, cex.main=.9)
plot(b.u, y.lab, type="n", ylab ="", xlab = "", yaxt="n", xlim = c(-1,1))
axis(2, at=y.lab, labels=vnames, las = 2, cex.axis=0.8)
mtext("ACME",side=1,line=2,outer=F, cex = 0.8)
points(b.u, y.lab, pch= 19, cex=.8, col = "black")
segments(cis.u[,1], y.lab, cis.u[,2], y.lab, lty=1, col = "black")
abline(v=0)
dev.off()

