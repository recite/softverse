
# Replication file for Appendix C.

require(stargazer)

load("Brexit_Rep.RData")


lm.income <- lm(Hincome.rec ~ as_factor(work_stat_full) + as_factor(work.type) + socialgrade + as_factor(GOR_full) + Education + Gender + Age + children, data = brexit.sub2)
summary(lm.income)

varlabels <- c("Work: Part Time (8-29hrs/w)", "Work: Part Time ( < 8hrs/w)", "Work: Full Time Student", "Work: Retired", "Work: Unemployed", "Work: Not Working", "Work: Other",
               "Work Type: Clerical/Sales", "Work Type: Supervisor", "Work Type: Skilled/Semi-Skilled Manual", "Work Type: Other", 
               "Work Type: Never Worked", "Social Grade", "North West", 
               "Yorkshire and the Humber", "East Midlands", "West Midlands", "East of England","London", "South East", 
               "South West", "Wales", "Scotland", "Education", "Male", "Age", "Children","Constant")

stargazer(lm.income, covariate.labels = varlabels)

pred.inc <- predict(lm.income, data=brexit.sub2)

impute <- function (a, a.impute){
  ifelse (is.na(a), a.impute, a)
}

brexit.sub2$Hincome.imp <- impute(brexit.sub2$Hincome.rec, pred.inc)