
# Replication file for Appendix B

library(weights)
library(dplyr)
library (haven)
library(car)


load("Brexit_Rep.RData")

props <- function(x) {x/sum(x, na.rm=TRUE)}


# Country in UK

aat.country <- Hmisc::wtd.table(brexit.sub2$country_full, weights= brexit.sub2$w8w6, type = 'table')

props(aat.country)

# Region

aat.region <- Hmisc::wtd.table(brexit.sub2$GOR_full, weights= brexit.sub2$w8w6, type = 'table')
props(aat.region)


### Gender (Male = 1)

aat.gender <- Hmisc::wtd.table(brexit.sub2$Gender, weights= brexit.sub2$w8w6, type = 'table')
aat.gender 

props(aat.gender)

### Age

aat.age <- Hmisc::wtd.mean(brexit.sub2$Age, weights= brexit.sub2$w8w6)

aat.age

# Age Categories

brexit.sub2 <- brexit.sub2 %>%
  
  mutate(agecat = Age,
         agecat = case_when(
           Age %in% 18:24 ~ "18-24",
           Age %in% 25:39 ~ "25-39",
           Age %in% 40:59 ~ "40-59",
           Age >= 60 ~ "60+"))

aat.agecat <- Hmisc::wtd.table(brexit.sub2$agecat, weights= brexit.sub2$w8w6, type = 'table')

props(aat.agecat)

### Income

aat.income <- Hmisc::wtd.table(brexit.sub2$Hincome.rec, weights= brexit.sub2$w8w6, type = 'table')

props(aat.income)

# Children

brexit.sub2$children <- car::recode(brexit.sub2$household_children_full,"1=0;2=1;3=1;4=1;5=1;6=1;8=NA;9=NA;10=NA;98=NA")

aat.children <- Hmisc::wtd.table(brexit.sub2$children, weights= brexit.sub2$w8w6, type = 'table')
props(aat.children)

# Marital status

brexit.sub2$marstat <- car::recode(brexit.sub2$marital_stat_full, "8=NA;9=NA;7=2")

brexit.sub2$marstat <- labelled(brexit.sub2$marstat, c("Married" = 1, "Living with partner" = 2, 
                                                           "Separated" = 3, "Divorced" = 4, "Widowed" = 5, 
                                                         "Single" = 6))

aat.marstat <- Hmisc::wtd.table(brexit.sub2$marstat, weights= brexit.sub2$w8w6, type = 'table')

props(aat.marstat)

# Work type

brexit.sub2$work.type <-brexit.sub2$work_type_full



brexit.sub2$work.type <- car::recode(brexit.sub2$work.type,"3=2;2=3;6=4;7=4;9=5;5=6;8=6")

brexit.sub2$work.type <- labelled(brexit.sub2$work.type, c("Professional" = 1, "Clerical/Junior Manager" = 2, 
                              "Managerial" = 3, "Manual and Services" = 4, "Never Worked" = 5, "Other" = 6))

aat.work.type <- Hmisc::wtd.table(brexit.sub2$work.type, weights= brexit.sub2$w8w6, type = 'table')

props(aat.work.type)


# Party ID, wave 5

aat.parties5 <- Hmisc::wtd.table(brexit.sub2$party.id5.raw, weights= brexit.sub2$w8w6, type = 'table')

props(aat.parties5)

# EU approval

aat.eu <- Hmisc::wtd.table(brexit.sub2$eu.disapprove.raw, weights=brexit.sub2$w8w6, type = 'table')

props(aat.eu)

