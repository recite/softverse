# Clean up
rm(list = ls())

# Set working directory; please set your own here
setwd("~/Dropbox/Fragmentation/fragmentation_replication_bjps/")

# Load necessary packages
library(tidyverse)
library(readxl)

controls_overlap <- read_xlsx('Data/controls_overlap.xlsx', sheet = 'R_data')

mean <- mean(controls_overlap$max_overlap)

controls_plot <- ggplot(data = controls_overlap, aes(x = max_overlap)) +
  geom_density(fill = "green4", alpha = 0.4) +
  theme_bw() +
  scale_x_continuous(limits = c(0, 1)) +
  labs(x = 'Maximum overlap between controls in each dyad of papers', y = 'Density') +
  geom_vline(xintercept = mean, linetype = "dashed", color = "red", size = .7) 
controls_plot

ggsave("Plots/fig1.png", plot = controls_plot, width = 15, height = 15, units = "cm") 