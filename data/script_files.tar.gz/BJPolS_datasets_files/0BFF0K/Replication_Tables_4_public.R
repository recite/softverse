#################################################################
# Replication Code for Tables 4: "Personnel Politics: Elections, #
# Clientelistic Competition, and Teacher Hiring in Indonesia"   #
#               Jan Pierskalla & Audrey Sacks                   #
#################################################################

# Appendix Table 3
setwd("~/Dropbox/Replication_Personnel/")
load("~/Dropbox/Replication_Personnel/balance.Rdata")

library(Matching)
bal1 <- MatchBalance(election_year~golkar_share_all+pdip_share_all+ServicesA+rev_natural_pc_l+gini_l+rev_total_pc_l+lpop_l
                     +poverty_pc_l+lgdppc_l+elf_composite,data=data_05)

# Appendix Table 11
library(lfe)

load("~/Dropbox/Replication_Personnel/data_districts_job_changes_private.Rdata")
# Note: the data for this analysis is based on government teacher censuses and cannot be shared publicly.
# Full data have been made available to the editor for verification purposes only.


m1 <- felm(avg_job_changes ~ election_year_lead1 + election_year + 
             election_year_l + elected_leader_l + incumbency + enp_all + golkar_share_all +
             pdip_share_all + services_provision + rev_natural_pc_l + gini_l + 
             rev_total_pc2_l + lpop_l + poverty_pc_l + lgdppc_l
           | kode_neil + year | 0 | kode_neil, data=districts)
summary(m1)


m2 <- felm(guru_avg_job_changes~election_year_lead1+election_year+election_year_l+elected_leader_l+incumbency+enp_all+golkar_share_all+pdip_share_all+services_provision+rev_natural_pc_l+gini_l+rev_total_pc2_l+lpop_l+poverty_pc_l+lgdppc_l
           | kode_neil+year|0|kode_neil,data=districts)
summary(m2)

se1 <- m1$cse
se2 <- m2$cse

library(stargazer)
# Table
stargazer(m1,m2,type="latex",style="qje", 
          title            = "Elections and Job Changes",
          covariate.labels = c("Pre-Election Year",
                               "Election Year",
                               "Post-Election Year",
                               "Direct Elections",
                               "Incumbency",
                               "ENP",
                               "Golkar Share",
                               "PDI-P Share",
                               "Services Provision",
                               "Natural Resource Rev pc",
                               "Gini Index",
                               "Total Revenue pc",
                               "log(Population)",
                               "Poverty pc",
                               "log(GDP pc)"),
          dep.var.caption  = "",
          dep.var.labels.include = FALSE,
          column.labels   = c("Job Changes","Job Changes Teachers"),
          se=list(se1,se2),
          add.lines = list(c("District FE", "Yes", "Yes"),
                           c("Year FE","Yes","Yes")),
          digits=2,
          out="~/Dropbox/Replication_Personnel/appendix_table_11.tex"
)

# Appendix Table 26
# This analysis is from a related working paper "Merit,  Discrimination,  and  Democratization—An Analysis of Promotion Patterns in Indonesia’s Civil Service."
# The analysis is based on private government data that cannot be shared publicly. Due to the size of the dataset, the analysis was performed
# on the Ohio Supercomputer Cluster. Details available on request.