#################################################################
# Replication Code for Figures: "Personnel Politics: Elections, #
# Clientelistic Competition, and Teacher Hiring in Indonesia"   #
#               Jan Pierskalla & Audrey Sacks                   #
#################################################################

library(ggplot2)


#####################################
## Figure 1
#####################################

# panel a)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Indirect", "Direct")),
  pns = c(3260.448,3284.892),
  ci_lo = c(2207.725,2754.351),
  ci_hi = c(4815.148,3917.629)
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=pns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,5000),name="Number of PNS Teachers")+scale_x_discrete(name="Election Type") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p

# panel b)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Indirect", "Direct")),
  nonpns = c(1337.106,2557.041),
  ci_lo = c(867.4952,2103.042),
  ci_hi = c(2060.937,3109.052)
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=nonpns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,4500),name="Number of Contract Teachers")+scale_x_discrete(name="Election Type") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p


#####################################
## Figure 2
#####################################

# panel a)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Non-Election", "Election")),
  pns = c(3241.959,3380.798),
  ci_lo = c(2993.744,2689.598),
  ci_hi = c(3510.757,4249.629)
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=pns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,4500),name="Number of PNS Teachers")+scale_x_discrete(name="Type of Year") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p

# panel b)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Non-Election", "Election")),
  nonpns = c(1886.19, 2805.284),
  ci_lo = c(1732.365,2197.296),
  ci_hi = c(2053.675,3581.496)
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=nonpns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,4500),name="Number of Contract Teachers")+scale_x_discrete(name="Type of Year") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p


#####################################
## Figure 3
#####################################

# panel a)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Non-Election", "Election")),
  nonpns = c(exp(7.582022), exp(7.762311)),
  ci_lo = c(exp(7.387921),exp(7.457928)),
  ci_hi = c(exp(7.776124),exp(8.066694))
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=nonpns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,4500),name="Number of Contract Teachers")+scale_x_discrete(name="Type of Year") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p


# panel b)
# estimates come from the margin command, see Replication_Tables_1_public.do
df <- data.frame(
  trt = factor(c("Non-Election", "Election")),
  nonpns = c(exp(7.662328), exp(8.062843)),
  ci_lo = c(exp(7.554922),exp(7.744846)),
  ci_hi = c(exp(7.769735),exp(8.380841))
)

# Define the top and bottom of the errorbars
limits <- aes(ymax = df$ci_hi, ymin=df$ci_lo)

p <- ggplot(df, aes(y=nonpns, x=trt))
dodge <- position_dodge(width=0.9)
p <- p + geom_bar(position=dodge, stat="identity") + geom_errorbar(limits, position=dodge, width=0.25)+theme_bw()+ coord_flip()+ scale_y_continuous(limits=c(0,4500),name="Number of Contract Teachers")+scale_x_discrete(name="Type of Year") +theme(axis.text.x = element_text(colour="black",size=20,angle=90,hjust=.5,vjust=.5,face="bold"),axis.text.y = element_text(colour="black",size=20,angle=0,hjust=1,vjust=0,face="bold"),axis.title.x = element_text(colour="black",size=22,angle=0,hjust=.5,vjust=0,face="bold"),axis.title.y = element_text(colour="black",size=22,angle=90,hjust=.5,vjust=.5,face="bold"))
p

