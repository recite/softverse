library(haven)
library(plyr)
library(gsynth)
gsc <- read_dta("forgsp.dta")
gsc <- gsc[!is.na(gsc$v2x_horacc),]
gsc<-gsc[gsc$ccode!= names(table(gsc$ccode)[count(gsc, "ccode")$freq==1]),]

out1 <- gsynth(v2x_horacc ~ cnene_abmed+gdppcln+wdi_gdpgr+
                 cnaidother_pop_ln3+odacom_conm_pop_ln3+
                 region_polity, data = gsc, 
               index = c("ccode","year"), force = "two-way", 
               CV = TRUE, r = c(0, 5), se = T,na.rm=T, 
               inference = "parametric", nboots = 1000, 
               parallel = FALSE,min.T0 = 7,seed=12345)
print(out1)
plot(out1, type = "gap", main = "",theme.bw = TRUE)

out2 <- gsynth(v2x_veracc ~ cnene_abmed+gdppcln+wdi_gdpgr+
                 cnaidother_pop_ln3+odacom_conm_pop_ln3+
                 region_polity, data = gsc, 
               index = c("ccode","year"), force = "two-way", 
               CV = TRUE, r = c(0, 5), se = T,na.rm=T, 
               inference = "parametric", nboots = 1000, 
               parallel = FALSE,min.T0 = 7,seed=12345)
print(out2)
plot(out2, type = "gap", main = "",theme.bw = TRUE)