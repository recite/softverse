library(foreign)
library(readstata13)
library(Amelia)

use<-read.dta13("~/forimp.dta")
use$id<-seq_len(nrow(use))

out <- amelia(use, m = 5, cs = "ccode",ts = "year",
                 idvars = c("e_regionpol","id"))  

write.amelia(out, separate = FALSE, file.stem = "mdata", format = "dta")

