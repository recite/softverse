# Replication code for:

### Anne Rasmussen & Stefanie Reher, 
### "Inequality in Interest Group Involvement and the Legitimacy of Policy-Making", 
### British Journal of Political Science, 2022

# 12 April 2022

# Code to create Figures 2 and 5

#install.packages("ggplot2")
library(ggplot2)
#install.packages("ggpubr")
library(ggpubr)

# replace PATH with path to working directory  
setwd("PATH")

###########################################################

### Figure 2

# coefficients and SEs from Model 1, Table 1 (see do file)

labels <- c("Variable", "Category", "Coefficient", "SE")
row1 <- c("Descriptive", "Equal", 0, 0)
row2 <- c("Descriptive", "None", -0.947, 0.021)
row3 <- c("Descriptive", "More business", -0.494, 0.020)
row4 <- c("Descriptive", "More cause", -0.325, 0.020)
row5 <- c("Substantive", "Both", 0, 0)
row6 <- c("Substantive", "Neither", -0.342, 0.020)
row7 <- c("Substantive", "Only business", -0.258, 0.020)
row8 <- c("Substantive", "Only cause", -0.101, 0.020)
all <- data.frame(rbind(row1,row2,row3,row4,row5,row6,row7,row8))
names(all) <- labels
all$Coefficient <- as.numeric(as.character(all$Coefficient))
all$SE <- as.numeric(as.character(all$SE))
all$Category <- factor(all$Category, levels=c("Only cause","Only business","Neither",
                                              "Both","More cause","More business","None","Equal"))
interval <- 1.96 
plot <- ggplot(all, aes(colour = Variable))
plot <- plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
plot <- plot + geom_pointrange(aes(x = Category, y = Coefficient, ymin = Coefficient - SE*interval,
                                   ymax = Coefficient + SE*interval),
                                   lwd = 1/2, shape=20, position = position_dodge(width = 1/5), fill = "WHITE")
plot <- plot + ggtitle(" ") + theme_bw() +  xlab("Policy        Numerical \n attainment   representation \n") + 
  coord_flip() + geom_vline(xintercept = 4.5, linetype="dotted") + ylab("Effect on legitimacy")
print(plot + scale_colour_manual(name="Descriptive representation", values = c("Black", "gray45"), guide=F))
ggsave("Fig2.tiff", dpi=300)

#########################################################

### Figure 5 

# coefficients and SEs from Model 4, Table 1 (see do file)

labels <- c("Descriptive", "Substantive", "Coefficient", "SE")
row1 <- c("More cause vs. equal", "Only business",  -0.3129276,   0.0389153)
row2 <- c("More business vs. equal", "Only business",  -0.6260538,   0.0399254)
row3 <- c("More cause vs. equal", "In line with both", -0.3485455,  0.039376)
row4 <- c("More business vs. equal", "In line with both", -0.5000708, 0.0393829)
row5 <- c("More cause vs. equal", "Only cause", -0.3874802, 0.0395789)
row6 <- c("More business vs. equal", "Only cause", -0.4014481,  0.0390039)

all <- data.frame(rbind(row1,row2,row3,row4,row5,row6))
names(all) <- labels
all$Coefficient <- as.numeric(as.character(all$Coefficient))
all$SE <- as.numeric(as.character(all$SE))
all$Substantive <- factor(all$Substantive, levels=c("Only business", "In line with both", "Only cause"))
Descriptive <- c("More cause vs. equal","More business vs. equal")
interval <- 1.96  # 95% multiplier
plot <- ggplot(all, aes(shape = Descriptive))
plot <- plot + geom_hline(yintercept = 0, colour = gray(1/2), lty = 2)
plot <- plot + geom_pointrange(aes(x = Substantive, y = Coefficient, ymin = Coefficient - SE*interval,
                                   ymax = Coefficient + SE*interval, colour=Descriptive),
                                   lwd = 1/2, position = position_dodge(width = 1/5), fill = "WHITE")
plot <- plot + ggtitle(" ") + theme(plot.title = element_text(hjust = 0.5)) + theme_bw() + xlab("Policy attainment") 
plot <- plot + geom_bracket(xmin = c(1.05,2.05), xmax = c(2.05,3.05), y.position = c(-0.195, -0.23), 
                            label = c("n.s.", "n.s."), label.size = 3, tip.length = 0.02)
plot <- plot + geom_bracket(xmin = c(0.95,1.95), xmax = c(1.95,2.95), y.position = c(-0.735, -0.61), 
                            label = c("*", "n.s."), label.size = 3, tip.length = -0.02)
print(plot + scale_colour_manual(name="Numerical representation", values = c("black", "gray45")) + 
        scale_shape_manual(guide=FALSE, values=c(16, 17))) +
  guides(colour = guide_legend(override.aes = list(shape = c(16,17))) + ylab("Effect on legitimacy"))
ggsave("Fig5.tiff", dpi=300)
