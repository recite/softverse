#---------------------------------------------------------------------------------------------------------------------------#
#---Do Stereotypes Explain Discrimination Against Minority Candidates or Discrimination in Favor of Majority Candidates? ---#
#------------------------------------------- British Journal of Political Science ------------------------------------------#
#----------------------------------------------------- Lea Portmann --------------------------------------------------------#
#---------------------------------------------------- 19 October 2020 ------------------------------------------------------#
#------------------------------------------ Implicit and explicit stereotypes ----------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------#

library(dplyr)
library(plyr)
library(Hmisc)
library(ggplot2)
library(viridis)
library(ggplot2)
library(ggpubr)


rm(list=ls())
setwd(".../...")
load("dat")

# ---------------------------------------------------------------------------------------- Implicit stereotypes

describe(dat$D_Traits)
describe(dat$D_CivCit)

# ------ Traits

# test for IAT effect
mean(dat$D_Traits, na.rm=T)
sd(dat$D_Traits, na.rm=T)
t.test(dat$D_Traits)
t.test(dat$D_Traits)$p.value
t.test(dat$D_Traits)$conf.int[1:2]

#cohen d
mean(dat$D_Traits, na.rm=T) / sd(dat$D_Traits, na.rm=T)

#Figure
col <- viridis(1)
IAT_traits <- ggplot(dat, aes(x=D_Traits)) +
geom_density(color=col, fill=col) +
theme_bw() +
geom_vline(xintercept = 0, linetype="dashed", size=0.5) +
scale_y_continuous(name="Density", limits=c(0, 1.5)) +
scale_x_continuous(name="D-Score traits", limits=c(-1.5, 1.5)) + 
annotate("text", x = 0.3, 
y = 1.4, label = "stereotypic bias", size=4, 
colour='black', hjust = 0) +
geom_segment(aes(x = 0.1, y = 1.4, 
xend = 0.25, yend = 1.4), 
colour='black', size=0.5, arrow = arrow(length = unit(0.5, "cm"))) +
annotate("text", x = -0.3, 
y = 1.4, label = "counterstereotypic bias", size=4, 
colour='black', hjust = 1) +
geom_segment(aes(x = -0.1, y = 1.4, 
xend = -0.25, yend = 1.4), 
colour='black', size=0.5, arrow = arrow(length = unit(0.5, "cm")))

# ------ Civic citizenship

# test for IAT effect
mean(dat$D_CivCit, na.rm=T)
sd(dat$D_CivCit, na.rm=T)
t.test(dat$D_CivCit)
t.test(dat$D_CivCit)$p.value
t.test(dat$D_CivCit)$conf.int[1:2]

#cohen d
mean(dat$D_CivCit, na.rm=T) / sd(dat$D_CivCit, na.rm=T)

#Figure
IAT_civit <- ggplot(dat, aes(x=D_CivCit)) +
geom_density(color=col, fill=col) + theme_bw() +
geom_vline(xintercept = 0, linetype="dashed", size=0.5) +
scale_y_continuous(name="Density", limits=c(0, 1.5)) +
scale_x_continuous(name="D-Score Civic citizenship", limits=c(-1.5, 1.5)) +
annotate("text", x = 0.3, 
y = 1.4, label = "stereotypic bias", size=4, 
colour='black', hjust = 0) +
geom_segment(aes(x = 0.1, y = 1.4, 
xend = 0.25, yend = 1.4), 
colour='black', size=0.5, arrow = arrow(length = unit(0.5, "cm"))) +
annotate("text", x = -0.3, 
y = 1.4, label = "conterstereotypic bias", size=4, 
colour='black', hjust = 1) +
geom_segment(aes(x = -0.1, y = 1.4, 
xend = -0.25, yend = 1.4), 
colour='black', size=0.5, arrow = arrow(length = unit(0.5, "cm")))

# ----- Combine Figures

f_IAT <- ggarrange(IAT_traits, IAT_civit, 
labels = c("", 
""),
ncol = 2, nrow = 1)
f_IAT 

# ---------------------------------------------------------------------------------------- Explicit stereotypes

dat[,8:25] <- apply(dat[,8:25], 2, function(x) as.numeric(as.character(x)))

table(dat$EXSTYP_IT_1)

EXSTYP <- dat %>%
#na.omit() %>%
dplyr::summarize(Warm_I=mean(EXSTYP_IT_1,na.rm=TRUE), 
Honest_I=mean(EXSTYP_IT_2,na.rm=TRUE),
Helpful_I=mean(EXSTYP_IT_3,na.rm=TRUE), 
Skilled_I=mean(EXSTYP_IT_4,na.rm=TRUE), 
Competent_I=mean(EXSTYP_IT_5,na.rm=TRUE), 
Respected_I=mean(EXSTYP_IT_6,na.rm=TRUE), 
KnowPolit_I=mean(EXSTYP_IT_7,na.rm=TRUE), 
PromoteITInt_I=mean(EXSTYP_IT_8,na.rm=TRUE), 
AppreciateCult_I=mean(EXSTYP_IT_9,na.rm=TRUE),
Warm_AL=mean(EXSTYP_AL_1,na.rm=TRUE), 
Honest_AL=mean(EXSTYP_AL_2,na.rm=TRUE),
Helpful_AL=mean(EXSTYP_AL_3,na.rm=TRUE), 
Skilled_AL=mean(EXSTYP_AL_4,na.rm=TRUE), 
Competent_AL=mean(EXSTYP_AL_5,na.rm=TRUE), 
Respected_AL=mean(EXSTYP_AL_6,na.rm=TRUE), 
KnowPolit_AL=mean(EXSTYP_AL_7,na.rm=TRUE), 
PromoteITInt_AL=mean(EXSTYP_AL_8,na.rm=TRUE), 
AppreciateCult_AL=mean(EXSTYP_AL_9,na.rm=TRUE))

EXSTYP_se <- dat %>%
#na.omit() %>%
dplyr::summarize(Warm_I=sd(EXSTYP_IT_1,na.rm=TRUE)/sqrt(n()),
Honest_I=sd(EXSTYP_IT_2,na.rm=TRUE)/sqrt(n()),
Helpful_I=sd(EXSTYP_IT_3,na.rm=TRUE)/sqrt(n()), 
Skilled_I=sd(EXSTYP_IT_4,na.rm=TRUE)/sqrt(n()), 
Competent_I=sd(EXSTYP_IT_5,na.rm=TRUE)/sqrt(n()), 
Respected_I=sd(EXSTYP_IT_6,na.rm=TRUE)/sqrt(n()), 
KnowPolit_I=sd(EXSTYP_IT_7,na.rm=TRUE)/sqrt(n()), 
PromoteITInt_I=sd(EXSTYP_IT_8,na.rm=TRUE)/sqrt(n()), 
AppreciateCult_I=sd(EXSTYP_IT_9,na.rm=TRUE)/sqrt(n()),
Warm_AL=sd(EXSTYP_AL_1,na.rm=TRUE)/sqrt(n()), 
Honest_AL=sd(EXSTYP_AL_2,na.rm=TRUE)/sqrt(n()),
Helpful_AL=sd(EXSTYP_AL_3,na.rm=TRUE)/sqrt(n()), 
Skilled_AL=sd(EXSTYP_AL_4,na.rm=TRUE)/sqrt(n()), 
Competent_AL=sd(EXSTYP_AL_5,na.rm=TRUE)/sqrt(n()), 
Respected_AL=sd(EXSTYP_AL_6,na.rm=TRUE)/sqrt(n()), 
KnowPolit_AL=sd(EXSTYP_AL_7,na.rm=TRUE)/sqrt(n()), 
PromoteITInt_AL=sd(EXSTYP_AL_8,na.rm=TRUE)/sqrt(n()), 
AppreciateCult_AL=sd(EXSTYP_AL_9,na.rm=TRUE)/sqrt(n()))

EXSTYP <- as.data.frame(t(EXSTYP))
EXSTYP_se <- as.data.frame(t(EXSTYP_se))
EXSTYP <- cbind(EXSTYP, EXSTYP_se)
name <- as.data.frame(c("Italian", "Italian", "Italian", "Italian", 
"Italian", "Italian", "Italian", "Italian", "Italian", "Algerian", "Algerian", 
"Algerian", "Algerian", "Algerian", "Algerian", "Algerian", "Algerian", "Algerian"))
EXSTYP <- cbind(EXSTYP, name)
characteristics <- as.data.frame(c("cold/warm", "dishonest/trustworthy", "selfish/willing to help",
"incapable/skilled",  "incompetent/competent", "despised/respected", 
"little/extensive knowledge of Italian politics", "does not/does promote Italian interests", 
"does not appreciate/appreciates Italian culture",
"cold/warm", "dishonest/trustworthy", "selfish/willing to help", 
"incapable/skilled", "incompetent/competent", "despised/respected", 
"little/extensive knowledge of Italian politics", "does not/does promote Italian interests", 
"does not appreciate/appreciates Italian culture"))
EXSTYP <- cbind(EXSTYP, characteristics)
colnames(EXSTYP) <- c("Mean", "SE", "Name", "Characteristic")

col_expl <- viridis(3)

EXSTYP <- as.data.frame(EXSTYP)
EXSTYP$Name <- factor(EXSTYP$Name)
f_EXSTYP <- ggplot(EXSTYP, aes(factor(Characteristic), Mean)) +
geom_bar(aes(fill = Name), position="dodge", stat="identity", alpha=0.5) + 
scale_fill_manual("Name", values = c("Algerian" = "#440154FF", "Italian" = "#21908CFF")) +
geom_errorbar(aes(x=Characteristic, ymin=Mean-SE, ymax=Mean+SE, color=Name), position="dodge") +
scale_color_manual("Name", values = c("Algerian" = "#440154FF", "Italian" = "#21908CFF")) +
geom_hline(yintercept=0, linetype="longdash", color = "black", size=0.7) +
coord_flip() + theme_bw() + xlab("") + scale_y_continuous(name="Evaluation", limits=c(-0.3, 0.6)) + 
annotate("text", x=9.5, y=-0.1, label="negative", vjust=1, hjust=1, color="black", size=3.5) + 
annotate("text", x=9.5, y=0.55, label="positive", vjust=1, hjust=1, color="black", size=3.5)
f_EXSTYP
