#----------------------------------------------------------------------------------------------------------------------------#
#--- Do Stereotypes Explain Discrimination Against Minority Candidates or Discrimination in Favor of Majority Candidates? ---#
#------------------------------------------- British Journal of Political Science -------------------------------------------#
#----------------------------------------------------- Lea Portmann ---------------------------------------------------------#
#---------------------------------------------------- 19 October 2020 -------------------------------------------------------#
#------------------------------------------------------ Pilot study ---------------------------------------------------------#
#----------------------------------------------------------------------------------------------------------------------------#

# ----------------------------------------------------------------------------------- Data preparation

library(Hmisc)
library(plyr)
library(dplyr)
library(knitr)
library(ggplot2)

# --------- Read data

rm(list=ls())
setwd(".../...")
dat <- read.csv("Pilot.csv", stringsAsFactors = F)
dat <- dat[-c(1,2),]

# --------- Drop respondents from preview and SSI testing

dat <- dat[dat$DistributionChannel!="preview",]
dat <- dat[dat$Con_Q3!="Test", ]

# --------- Generate variables for measuring counterstereotypical manipulation 

cols <- c(22:30, 36:44, 50:58, 64:72, 77:86, 92:100)
dat[,cols] <- apply(dat[,cols], 2, function(x) as.numeric(as.character(x)))
dat[ ,cols][is.na(dat[ ,cols])] <- 0

dat$MC_warm <- dat$CCC_T1_MC_1 + dat$CC_T2_MC_1 + dat$CC_T3_MC_1 + dat$CC_T4_MC_1 + dat$CC_T5_MC_1 + dat$CC_T6_MC_1
dat$MC_trustworthy <- dat$CCC_T1_MC_7 + dat$CC_T2_MC_7 + dat$CC_T3_MC_7 + dat$CC_T4_MC_7 + dat$CC_T5_MC_7 + dat$CC_T6_MC_7
dat$MC_competent <- dat$CCC_T1_MC_8 + dat$CC_T2_MC_8 + dat$CC_T3_MC_8 + dat$CC_T4_MC_8 + dat$CC_T5_MC_8 + dat$CC_T6_MC_8
dat$MC_politknow <- dat$CCC_T1_MC_13 + dat$CC_T2_MC_13 + dat$CC_T3_MC_13 + dat$CC_T4_MC_13 + dat$CC_T5_MC_13 + dat$CC_T6_MC_13
dat$MC_ITint <- dat$CCC_T1_MC_14 + dat$CC_T2_MC_14 + dat$CC_T3_MC_14 + dat$CC_T4_MC_14 + dat$CC_T5_MC_14 + dat$CC_T6_MC_14
dat$MC_help <- dat$CCC_T1_MC_15 + dat$CC_T2_MC_15 + dat$CC_T3_MC_15 + dat$CC_T4_MC_15 + dat$CC_T5_MC_15 + dat$CC_T6_MC_15
dat$MC_capable <- dat$CCC_T1_MC_16 + dat$CC_T2_MC_16 + dat$CC_T3_MC_16 + dat$CC_T4_MC_16 + dat$CC_T5_MC_16 + dat$CC_T6_MC_16
dat$MC_Itcult <- dat$CCC_T1_MC_17 + dat$CC_T2_MC_17 + dat$CC_T3_MC_17 + dat$CC_T4_MC_17 + dat$CC_T5_MC_17 + dat$CC_T6_MC_17
dat$MC_respected <- dat$CCC_T1_MC_18 + dat$CC_T2_MC_18 + dat$CC_T3_MC_18 + dat$CC_T4_MC_18 + dat$CC_T5_MC_18 + dat$CC_T6_MC_18

# --------- Build variable experimental group

dat$EXP_GROUP <- NA
dat$EXP_GROUP <- ifelse(dat$FL_68_DO=="CandidatechoiceexerimentItalian1", 1, 
ifelse(dat$FL_68_DO=="CandidatechoiceexperimentItalian2", 2, 
ifelse(dat$FL_68_DO=="CandidatechoiceexperimentItalian3", 3,
ifelse(dat$FL_73_DO=="CandidatechoiceexperimentAlgerian1", 4, 
ifelse(dat$FL_73_DO=="CandidatechoiceexperimentAlgerian2", 5, 
ifelse(dat$FL_73_DO=="CandidatechoiceexperimentAlgerian3", 6, NA))))))

dat$EXP_GROUP <- factor(dat$EXP_GROUP, 
levels=c(1, 2, 3, 4, 5, 6), 
labels=c("Control Italian", "Trait Italian", "Civic citizenship Italian", 
"Control Algerian", "Trait Algerian", "Civic citizenship Algerian"))

# --------- Drop rspondnets who did not take part in experimental part

dat <- dat[!is.na(dat$EXP_GROUP), ]

# --------- Build variable counterstereotpyical manipulation

dat$VIG <- ifelse(dat$EXP_GROUP=="Control Italian" | dat$EXP_GROUP=="Control Algerian", 1, 
ifelse(dat$EXP_GROUP=="Trait Italian" | dat$EXP_GROUP=="Trait Algerian", 2,
ifelse(dat$EXP_GROUP=="Civic citizenship Italian" |
dat$EXP_GROUP=="Civic citizenship Algerian", 3, NA)))

dat$VIG  <- factor(dat$VIG, 
levels=c(1, 2, 3), 
labels=c("Control", "Positive traits", "Positive civic citizenship"))

# --------- Build variable candidate name

dat$candname <- NA
dat$candname <- ifelse(dat$EXP_GROUP=="Control Italian" | dat$EXP_GROUP=="Trait Italian" |
dat$EXP_GROUP=="Civic citizenship Italian", 0, 
ifelse(dat$EXP_GROUP=="Control Algerian" | dat$EXP_GROUP=="Trait Algerian"|
dat$EXP_GROUP=="Civic citizenship Algerian", 1, NA))
table(dat$candname)

# ----------------------------------------------------------------------------------- Table 3 online appendix: Manipulation check pilot study

dat$mtraits = (dat$MC_warm + dat$MC_trustworthy + dat$MC_help + dat$MC_competent + dat$MC_capable + dat$MC_respected)/2
dat$mtraits_warm = dat$MC_warm + dat$MC_trustworthy + dat$MC_help
dat$mcompetence = dat$MC_competent + dat$MC_capable + dat$MC_respected
dat$mcivcit = dat$MC_politknow + dat$MC_ITint + dat$MC_Itcult

dat_MC_mean <- dat %>% 
dplyr::group_by(VIG) %>% 
dplyr::summarize(mean_Traits = mean(mtraits, na.rm=TRUE),           
mean_CivCit = mean(mcivcit, na.rm=TRUE))
dat_MC_mean[2:3] <- lapply(dat_MC_mean[2:3], as.numeric)
dat_MC_mean[2:3] <- round(dat_MC_mean[2:3], digits = 2)

dat_MC_sd <- dat %>% 
dplyr::group_by(VIG) %>% 
dplyr::summarize(sd_Traits = sd(mtraits, na.rm=TRUE),
sd_CivCit = sd(mcivcit, na.rm=TRUE))
dat_MC_sd[2:3] <- lapply(dat_MC_sd[2:3], as.numeric)
dat_MC_sd[2:3] <- round(dat_MC_sd[2:3], digits = 2)
dat_MC_sd[2:3] <- lapply(dat_MC_sd[2:3], as.character)
dat_MC_sd[2:3] <- sapply(dat_MC_sd[2:3], function(x) paste0("(", x, ")"))

dat_MC_mean <- as.matrix(dat_MC_mean)
dat_MC_sd <- as.matrix(dat_MC_sd)
dat_MC <- rbind(dat_MC_mean, dat_MC_sd)
dat_MC <- as.data.frame(dat_MC)

dat_MC <- dat_MC[c(1,4,2,5,3,6), ]
colnames(dat_MC) <- c("Manipulation Information", "Traits", "Civic citizenship")

xtable(as.matrix(dat_MC), caption = "Manipulation check second pilot study")

