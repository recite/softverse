#---------------------------------------------------------------------------------------------------------------------------#
#---Do Stereotypes Explain Discrimination Against Minority Candidates or Discrimination in Favor of Majority Candidates? ---#
#------------------------------------------- British Journal of Political Science ------------------------------------------#
#----------------------------------------------------- Lea Portmann --------------------------------------------------------#
#---------------------------------------------------- 19 October 2020 ------------------------------------------------------#
#----------------------------------------- Analysis Electoral Discrimination -----------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------#

library(dplyr)
library(plyr)
library(Hmisc)
library(Rmisc)
library(ggplot2)
library(xtable)
library(texreg)
library(effects)
library(sjPlot)
library(sjmisc)
library(ggpubr)

rm(list=ls())
setwd(".../...")
load("dat")

# ----------------------------------------------------------------------------------- Descriptive statistics dependent variables

describe(dat$DV_nom)
sd(dat$DV_nom, na.rm = TRUE)
describe(dat$DV_vote)
sd(dat$DV_vote, na.rm = TRUE)
describe(dat$DV_eval_pos)
sd(dat$DV_eval_pos, na.rm = TRUE)
describe(dat$DV_eval_neg)
sd(dat$DV_eval_neg, na.rm = TRUE)
describe(dat$IDEOL_cat)

# ----------------------------------------------------------------------------------- Rescale dependent variables

dat$DV_nom <- dat$DV_nom/10
dat$DV_vote <- dat$DV_vote/10

# ----------------------------------------------------------------------------------- Tables dependent variables (for data checks)

# ---------- Nomination

dat_DV_nom <- dat %>% dplyr::group_by(treat) %>% 
dplyr::summarize(mean_DV_nom = mean(DV_nom, na.rm=TRUE))

# ---------- Vote choice

dat_DV_vote <- dat %>% dplyr::group_by(treat) %>% 
dplyr::summarize(mean_DV_vote = mean(DV_vote, na.rm=TRUE))

# ---------- Evaluation to parties

table(dat$treat, dat$DV_eval_4)
table(dat$DV_eval_pos, dat$DV_eval_4)

# ----------------------------------------------------------------------------------- Number of observations in experimental conditions (Table 1 online appendix)

dat_n_treat <- dat %>%
  dplyr::group_by(candname, Treat_c4) %>%
  dplyr::summarize(n = n())

xtable((as.matrix(dat_n_treat)), caption = "Number of observations in experimental conditions",
       col.names = c("Candidate name", "Manipulation of information", "n"))

# ----------------------------------------------------------- Evidence Electoral Discrimination independent of ideological position 

# ---------- Table 4 online appendix (linear model)

dat$IDEOL_cat <- as.factor(as.character(dat$IDEOL_cat))

dat_Control <- dat %>%
filter(treat == "CandidatechoiceexperimentAL1" | treat == "CandidatechoiceexperimentIT1")

#Linear
m1 <- lm(DV_nom ~ candname, data = dat_Control)
summary(m1)
m2 <- lm(DV_vote ~ candname, data = dat_Control)
summary(m2)
m3 <- lm(DV_eval_pos ~ candname, data = dat_Control)
summary(m3)
m4 <- lm(DV_eval_neg ~ candname, data = dat_Control)
summary(m4)

custom.name <- c("Intercept", "Candidate name (Algerian)")

texreg(list(m1, m2, m3, m4), booktabs=TRUE,
caption="Effect of candidate names on electoral support and opposition",
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Table 5 online appendix (glm)

m1 <- lm(DV_nom ~ candname, data = dat_Control)
summary(m1)
m2 <- lm(DV_vote ~ candname, data = dat_Control)
summary(m2)
m3 <- glm(DV_eval_pos ~ candname, family=binomial, data = dat_Control)
summary(m3)
m4 <- glm(DV_eval_neg ~ candname, family=binomial, data = dat_Control)
summary(m4)

custom.name <- c("Intercept", "Candidate name (Algerian)")

texreg(list(m1, m2, m3, m4), booktabs=TRUE,
       caption="Effect of candidate names on electoral support and opposition",
       custom.coef.names = custom.name,
       caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Table 6 online appendix (Without immigrant-origin respondents)

table(dat$IO_RESP)
describe(dat$IO_RESP)

dat_majority <- dat[dat$IO_RESP!="With migration background", ]

dat_Control_majority <- dat_majority %>%
filter(treat == "CandidatechoiceexperimentAL1" | treat == "CandidatechoiceexperimentIT1")

m1 <- lm(DV_nom ~ candname, data = dat_Control_majority)
summary(m1)
m2 <- lm(DV_vote ~ candname, data = dat_Control_majority)
summary(m2)
m3 <- lm(DV_eval_pos ~ candname, data = dat_Control_majority)
summary(m3)
m4 <- lm(DV_eval_neg ~ candname, data = dat_Control_majority)
summary(m4)

custom.name <- c("Intercept", "Candidate name (Algerian)")

texreg(list(m1, m2, m3, m4), booktabs=TRUE,
       caption="Effect of candidate name on electoral support and opposition, only respondents without a migration
background",
       custom.coef.names = custom.name,
       caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# ----------------------------------------------------------- Moderating effect of Ideological position on Electoral Discrimination

dat_Control_ideol <- dat_Control[dat_Control$IDEOL_cat!=4, ]

# --------- Table 8 online appendix (glm)

m1 <- lm(DV_nom ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m1)
m2 <- lm(DV_vote ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m2)
m3 <- glm(DV_eval_pos ~ candname*IDEOL_cat, family=binomial, data = dat_Control_ideol)
summary(m3)
m4 <- glm(DV_eval_neg ~ candname*IDEOL_cat, family=binomial, data = dat_Control_ideol)
summary(m4)

custom.name <- c("Intercept", "Candidate name (Algerian)", "Ideological position = Center", 
                 "Ideological position = Right", "Candidate name (Algerian)XIdeological position = Center", 
                 "Candidate name (Algerian)XIdeological position = Right")

# Table

texreg(list(m1, m2, m3, m4), booktabs=TRUE,
caption="Effect of candidate names on electoral support and opposition, by ideological position of respondents",
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Table 7 online appendix (linear)

m1 <- lm(DV_nom ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m1)
m2 <- lm(DV_vote ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m2)
m3 <- lm(DV_eval_pos ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m3)
m4 <- lm(DV_eval_neg ~ candname*IDEOL_cat, data = dat_Control_ideol)
summary(m4)

custom.name <- c("Intercept", "Candidate name (Algerian)", "Ideological position = Center", 
"Ideological position = Right", "Candidate name (Algerian)XIdeological position = Center", 
"Candidate name (Algerian)XIdeological position = Right")

# Table

texreg(list(m1, m2, m3, m4), booktabs=TRUE,
caption="Effect of candidate names on electoral support and opposition, by ideological position of respondents",
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Figure 1 (predicted values)

f_int_nom <- plot_model(m1, type = "eff", terms = c("IDEOL_cat", "candname"), 
                        colors = c("grey55", "black"),
                        dot.size = 1.4,
                        title = " ", 
                        legend.title = "Candidate name", 
                        axis.title = c("Ideological position", "Support nomination"))
f_int_nom <- f_int_nom + theme_bw() +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + 
  annotate("text", x=1.5, y=0.59, label = "Left", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=2.7, y=0.5, label = "Center", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=3.6, y=0.56, label = "Right", vjust=1, hjust=1, size=3.3) +
  scale_y_continuous(breaks = c(0.2, 0.3, 0.4, 0.5, 0.6), limit = c(0.2, 0.6))

f_int_vote <- plot_model(m2, type = "eff", terms = c("IDEOL_cat", "candname"), 
                         colors = c("grey55", "black"),
                         dot.size = 1.4,
                         title = " ", 
                         legend.title = "Candidate name", 
                         axis.title = c("Ideological position", "Probability vote for candidate"))
f_int_vote <- f_int_vote + theme_bw() +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + 
  annotate("text", x=1.5, y=0.57, label = "Left", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=2.7, y=0.51, label = "Center", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=3.6, y=0.57, label = "Right", vjust=1, hjust=1, size=3.3) +
  scale_y_continuous(breaks = c(0.2, 0.3, 0.4, 0.5, 0.6), limit = c(0.2, 0.6))

f_int_evalpos <- plot_model(m3, type = "eff", terms = c("IDEOL_cat", "candname"), 
                            colors = c("grey55", "black"),
                            dot.size = 1.4,
                            title = " ", 
                            legend.title = "Candidate name", 
                            axis.title = c("Ideological position", "Probability allocate positive rating"))
f_int_evalpos <- f_int_evalpos + theme_bw() +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + 
  annotate("text", x=1.5, y=0.47, label = "Left", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=2.7, y=0.38, label = "Center", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=3.6, y=0.55, label = "Right", vjust=1, hjust=1, size=3.3) +
  scale_y_continuous(breaks = c(0, 0.2, 0.4, 0.6), limit = c(-0.1, 0.6))

f_int_evalneg <- plot_model(m4, type = "eff", terms = c("IDEOL_cat", "candname"), 
                            colors = c("grey55", "black"),
                            dot.size = 1.4,
                            title = " ", 
                            legend.title = "Candidate name", 
                            axis.title = c("Ideological position", "Probability allocate negative rating"))
f_int_evalneg <- f_int_evalneg + theme_bw() +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank()) + 
  annotate("text", x=1.5, y=0.31, label = "Left", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=2.7, y=0.42, label = "Center", vjust=1, hjust=1, size=3.3) +
  annotate("text", x=3.6, y=0.54, label = "Right", vjust=1, hjust=1, size=3.3) +
  scale_y_continuous(breaks = c(0, 0.2, 0.4, 0.6), limit = c(-0.1, 0.6))


f1 <- ggarrange(f_int_nom, f_int_vote, f_int_evalneg, f_int_evalpos, 
labels = c("", "", "", "", "", ""),
ncol = 2, nrow = 2)
f1


