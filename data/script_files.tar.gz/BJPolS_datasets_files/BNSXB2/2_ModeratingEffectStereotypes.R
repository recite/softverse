#---------------------------------------------------------------------------------------------------------------------------#
#---Do Stereotypes Explain Discrimination Against Minority Candidates or Discrimination in Favor of Majority Candidates? ---#
#------------------------------------------- British Journal of Political Science ------------------------------------------#
#----------------------------------------------------- Lea Portmann --------------------------------------------------------#
#---------------------------------------------------- 19 October 2020 ------------------------------------------------------#
#------------------------------------------ Moderating effect stereotypes --------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------#

library(dplyr)
library(plyr)
library(Hmisc)
library(Rmisc)
library(ggplot2)
library(grid)
library(reshape2)
library(gridExtra)
library(scales)
library(texreg)
library(effects)
library(gridExtra)
library(ggpubr)

rm(list=ls())
setwd(".../...")
load("dat")

# ----------------------------------------------------------------------------------- Rescale Dependent variables

dat$DV_nom <- dat$DV_nom/10
dat$DV_vote <- dat$DV_vote/10

# ----------------------------------------------------------------------------------- Split according to ideological position of candidate

dat_id_r <- dat %>% 
dplyr::filter(IDEOL_cat == 3)

dat_id_c <- dat %>% 
dplyr::filter(IDEOL_cat == 2)

dat_id_l <- dat %>% 
dplyr::filter(IDEOL_cat == 1)

# -----------------------------------------------------------------------------------  Hetereogeneous treatment effect ideology

# -----------------------------------------------------------------------------------  Center ideology

# --------- Models

# glm (for robustness checks only, not included in article)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_c)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_c)
DV_Positive_Evaluation <- glm(DV_eval_pos ~ Treat_c4*candname, family=binomial, data=dat_id_c)
DV_Negative_Evaluation <- glm(DV_eval_neg ~ Treat_c4*candname, family=binomial, data=dat_id_c)

# lm (basis for Table 9)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_c)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_c)
DV_Positive_Evaluation <- lm(DV_eval_pos ~ Treat_c4*candname, data=dat_id_c)
DV_Negative_Evaluation <- lm(DV_eval_neg ~ Treat_c4*candname, data=dat_id_c)

# --------- Table 9 online appendix

custom.name <- c("Intercept", "Positive Traits", 
"Positive Civic citizenship", "Positive traits and Civic citizenship", "Candidate name (Algerian)", 
"Candidate name x traits", " Candidate name x Civic citizenship", 
"Candidate name x traits & Civ. cit.")

texreg(list(DV_Nominate, DV_Vote, DV_Positive_Evaluation, 
DV_Negative_Evaluation), booktabs=TRUE,
caption="Mediating effect of stereotypes, respondents in the ideological center",
reorder.coef = c(1, 5, 2, 3, 4, 6, 7, 8),
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Figure 2a Predicted values

#Nomination
ef <- effect("Treat_c4:candname", DV_Nominate)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
nom_center <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Nomination")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Voting
ef <- effect("Treat_c4:candname", DV_Vote)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
vote_center <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Vote")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Negative rating
ef <- effect("Treat_c4:candname", DV_Negative_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
neg_eval_center <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Negative rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(-0.2, 0.6))

#Positive rating
ef <- effect("Treat_c4:candname", DV_Positive_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
eval_pos_center <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Positive rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
guides(color=guide_legend(title="Candidate name")) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Figure
stereo_center <- grid.arrange(nom_center, vote_center, neg_eval_center, eval_pos_center,
ncol=4, nrow = 1,
top=c("Respondents in the center"),
widths = c(2.5, 1, 1, 2.1))

# ----------------------------------------------------------------------------------- Left ideology

# glm (for robustness checks only, not included in article)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_l)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_l)
DV_Positive_Evaluation <- glm(DV_eval_pos ~ Treat_c4*candname, family=binomial, data=dat_id_l)
DV_Negative_Evaluation <- glm(DV_eval_neg ~ Treat_c4*candname, family=binomial, data=dat_id_l)

# lm (basis for Table 10)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_l)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_l)
DV_Positive_Evaluation <- lm(DV_eval_pos ~ Treat_c4*candname, data=dat_id_l)
DV_Negative_Evaluation <- lm(DV_eval_neg ~ Treat_c4*candname, data=dat_id_l)
summary(DV_Positive_Evaluation)

# --------- Table 10 online appendix

custom.name <- c("Intercept","Positive Traits", 
"Positive Civic citizenship", "Positive traits and Civic citizenship",  "Candidate name (Algerian)", 
"Candidate name x traits", " Candidate name x Civic citizenship", 
"Candidate name x traits & Civ. cit.")

library(texreg)
texreg(list(DV_Nominate, DV_Vote, DV_Positive_Evaluation, 
DV_Negative_Evaluation), booktabs=TRUE,
caption="Mediating effect of stereotypes, respondents on the ideological left",
reorder.coef = c(1, 5, 2, 3, 4, 6, 7, 8),
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Figure 2b Predicted values

#Nomination
ef <- effect("Treat_c4:candname", DV_Nominate)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
nom_left <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Nomination")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Voting
ef <- effect("Treat_c4:candname", DV_Vote)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
vote_left <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Vote")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Negative rating
ef <- effect("Treat_c4:candname", DV_Negative_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
neg_eval_left <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Negative rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(-0.2, 0.6))

#Positive rating
ef <- effect("Treat_c4:candname", DV_Positive_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
eval_pos_left <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Positive rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
guides(color=guide_legend(title="Candidate name")) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Figure
stereo_left <- grid.arrange(nom_left, vote_left, neg_eval_left, eval_pos_left,
ncol=4, nrow = 1,
top=c("Left-wing respondents"),
widths = c(2.5, 1, 1, 2.1))

stereo_center_left <- ggarrange(stereo_center, stereo_left,
ncol = 1, nrow = 2)
stereo_center_left

# ----------------------------------------------------------- Right-wing ideology

# --------- Models

# glm (for robustness checks only, not included in article)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_r)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_r)
DV_Positive_Evaluation <- glm(DV_eval_pos ~ Treat_c4*candname, family=binomial, data=dat_id_r)
DV_Negative_Evaluation <- glm(DV_eval_neg ~ Treat_c4*candname, family=binomial, data=dat_id_r)

# lm (basis for Table 11)
DV_Nominate <- lm(DV_nom ~ Treat_c4*candname, data=dat_id_r)
DV_Vote <- lm(DV_vote ~ Treat_c4*candname, data=dat_id_r)
DV_Positive_Evaluation <- lm(DV_eval_pos ~ Treat_c4*candname, data=dat_id_r)
DV_Negative_Evaluation <- lm(DV_eval_neg ~ Treat_c4*candname, data=dat_id_r)
summary(DV_Positive_Evaluation)
summary(DV_Nominate)
summary(DV_Vote)
summary(DV_Negative_Evaluation)

# --------- Table 11 online appendix (regression output)

custom.name <- c("Intercept", "Positive Traits", 
"Positive Civic citizenship", "Positive traits and Civic citizenship", "Candidate name (Algerian)", 
"Candidate name x traits", " Candidate name x Civic citizenship", 
"Candidate name x traits & Civ. cit.")

texreg(list(DV_Nominate, DV_Vote, DV_Positive_Evaluation, 
DV_Negative_Evaluation), booktabs=TRUE,
caption="Mediating effect of stereotypes, respondents on the ideological right",
reorder.coef = c(1, 5, 2, 3, 4, 6, 7, 8),
custom.coef.names = custom.name,
caption.above = TRUE, stars = c(0.001, 0.01, 0.05, 0.1))

# --------- Figure 3 Predicted values

#Nomination
library(effects)
ef <- effect("Treat_c4:candname", DV_Nominate)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
nom_right <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Nomination")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Voting
ef <- effect("Treat_c4:candname", DV_Vote)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
vote_right <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Vote")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(0, 0.8))

#Negative rating
ef <- effect("Treat_c4:candname", DV_Negative_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
neg_eval_right <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Negative rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(legend.position = "none") + theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(-0.2, 0.6))

#Positive rating
ef <- effect("Treat_c4:candname", DV_Positive_Evaluation)
summary(ef)
ef <- as.data.frame(ef)
ef$Treat_c4 <- factor(ef$Treat_c4, 
levels = c("Positive traits & civic citizenship", "Positive civic citizenship", "Positive traits", "Control"))
colors <- c("grey55", "black")
eval_pos_right <- ggplot(ef, aes(Treat_c4, fit, color=candname, fill=candname)) + geom_point(size=2) + 
geom_errorbar(aes(ymin=lower, ymax=upper), width=0.2) + 
theme_bw(base_size=12) +
theme_bw() + labs(x="", y="", title = "Positive rating")  +
scale_colour_manual(values = colors, aesthetics = c("colour", "fill")) + 
guides(fill=FALSE) + 
theme(plot.title = element_text(size=11)) + coord_flip() + 
theme(axis.title.y=element_blank(),
axis.text.y=element_blank(), axis.ticks.y=element_blank()) + 
guides(color=guide_legend(title="Candidate name")) + 
scale_y_continuous(breaks = c(-0.2, 0, 0.2, 0.4, 0.6, 0.8), limit = c(-0.2, 0.8))

#Figure
stereo_right <- grid.arrange(top="Right-wing respondents",
nom_right, vote_right, neg_eval_right, eval_pos_right,
ncol=4, nrow = 1,
widths = c(2.5, 1, 1, 2.1))
stereo_right <- cowplot::ggdraw(stereo_right) + 
theme(plot.background = element_rect(fill="white", color = NA))
stereo_right 





