
#---------------------------------------------------------------------------------------------------------------------------#
#---Do Stereotypes Explain Discrimination Against Minority Candidates or Discrimination in Favor of Majority Candidates? ---#
#------------------------------------------- British Journal of Political Science ------------------------------------------#
#----------------------------------------------------- Lea Portmann --------------------------------------------------------#
#---------------------------------------------------- 19 October 2020 ------------------------------------------------------#
#--------------------------------------------------- Data preparation ------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------#

library(Hmisc)
library(dplyr)

rm(list=ls())
setwd(".../...")

dat <- read.csv("Data_SurveyExperiment.csv", stringsAsFactors = F)

# --------------------------------------------------------------------------------------- Demographic variables

# ----- Age

table(dat$AGE)
dat$AGE <- factor(dat$AGE, 
labels = c("18-34 years", "35-54 years", "55-74 years", "older than 74 years"))
table(dat$AGE)
describe(dat$AGE)

# ----- Gender

dat$GENDER[dat$GENDER=="" | dat$GENDER=="Altro"] <- NA

dat$GENDER <- factor(dat$GENDER, 
labels = c("Female", "Male"))
table(dat$GENDER)
describe(dat$GENDER)

# ----- Region

table(dat$REGION)
dat$REGION[dat$REGION ==""] <- NA

# ----- Education

dat$EDUC[dat$EDUC ==""] <- NA

# ----- Migration background respondent

dat$IO_RESP[dat$IO_RESP =="Preferisco non rispondere." | dat$IO_RESP ==""] <- NA 

dat$IO_RESP <- factor(dat$IO_RESP, 
labels = c("Without migration background", "With migration background"))
table(dat$IO_RESP)
describe(dat$IO_RESP)

# ----- Left-right ideology

table(dat$IDEOL)
library(plyr)
dat$IDEOL_num <- plyr::mapvalues(dat$IDEOL, 
from = c("0 (Sinistra)", "1", "2", "3", "4", "5 (Centro)", "6", "7", "8", "9", 
"10 (Destra)", "Preferisco non rispondere", "Non saprei collocarmi\n"), 
to = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 99, 999))
dat$IDEOL_num <- as.numeric(dat$IDEOL_num)
table(dat$IDEOL_num, dat$IDEOL)

dat$IDEOL_cat <- ifelse(dat$IDEOL_num == 0 | dat$IDEOL_num == 1 | dat$IDEOL_num == 2 | dat$IDEOL_num == 3, 1, 
ifelse(dat$IDEOL_num == 4 | dat$IDEOL_num == 5 | dat$IDEOL_num == 6, 2, 
ifelse(dat$IDEOL_num == 7 | dat$IDEOL_num == 8 | dat$IDEOL_num == 9 | dat$IDEOL_num == 10, 3,
ifelse(dat$IDEOL_num == 99 | dat$IDEOL_num == 999, 4, NA))))
describe(dat$IDEOL_cat)
table(dat$treat, dat$IDEOL_cat)
table(dat$IDEOL_cat)

# ----- Political ideology (numeric)

dat$IDEOL[dat$IDEOL == "Non saprei collocarmi\n" | dat$IDEOL == "Preferisco non rispondere"] <- NA

dat$IDEOL <- mapvalues(dat$IDEOL, 
from = c("0 (Sinistra)", "1", "2", "3", "4", "5 (Centro)", 
"6", "7", "8", "9", "10 (Destra)"), 
to = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
dat$IDEOL <- as.character(as.numeric(dat$IDEOL))

table(dat$IDEOL)
describe(dat$IDEOL)

# --------------------------------------------------------------------------------------- Variables experimental manipulations

# ----- Manipulation of mediator (posiive information)

dat$Treat_c4 <- NA
dat$Treat_c4 <- 
ifelse(dat$treat == "CandidatechoiceexperimentIT1" | dat$treat == "CandidatechoiceexperimentAL1", 1, 
ifelse(dat$treat == "CandidatechoiceexperimentIT2" | dat$treat == "CandidatechoiceexperimentAL2", 2,
ifelse(dat$treat == "CandidatechoiceexperimentIT3" | dat$treat == "CandidatechoiceexperimentAL3", 3, 
ifelse(dat$treat == "CandidatechoiceexperimentIT4" | dat$treat == "CandidatechoiceexperimentAL4", 4, NA))))
table(dat$Treat_c4, dat$treat)
dat$Treat_c4 <- factor(dat$Treat_c4, 
levels = c(1, 2, 3, 4), 
labels = c("Control", "Positive traits", "Positive civic citizenship", "Positive traits & civic citizenship"))

# ----- Candidate name

dat$candname <- NA
dat$candname <- ifelse(dat$treat == "CandidatechoiceexperimentIT1" | 
dat$treat == "CandidatechoiceexperimentIT2" |
dat$treat == "CandidatechoiceexperimentIT3" | dat$treat == "CandidatechoiceexperimentIT4", 0, 
ifelse(dat$treat == "CandidatechoiceexperimentAL1" | dat$treat == "CandidatechoiceexperimentAL2" |
dat$treat == "CandidatechoiceexperimentAL3" | dat$treat == "CandidatechoiceexperimentAL4", 1, NA))
table(dat$candname, dat$treat)

# --------------------------------------------------------------------------------------- Dependent variables

# ----- Dummy variables: Positive (1/0), negative (1/0) evaluation

describe(dat$DV_eval_4)
table(dat$treat, dat$DV_eval_4)
dat$DV_eval_4[dat$DV_eval_4=="No answer"] <- NA

dat$DV_eval_pos <- NA
dat$DV_eval_pos <- ifelse(dat$DV_eval_4 == "Evaluation positiv", 1, 
ifelse(dat$DV_eval_4 == "Evaluation neutral" | dat$DV_eval_4 == "Evaluation negativ", 0, NA))
describe(dat$DV_eval_pos)
table(dat$DV_eval_pos)

dat$DV_eval_neg <- NA
dat$DV_eval_neg <- ifelse(dat$DV_eval_4 == "Evaluation negativ", 1, 
ifelse(dat$DV_eval_4 == "Evaluation neutral" | dat$DV_eval_4 == "Evaluation positiv", 0, NA))
table(dat$DV_eval_neg)

dat$candname <- factor(dat$candname,
levels = c(0, 1), 
labels = c("Italian", "Algerian"))

#Information: "No answer" -> missing

save(dat, file = "dat")



