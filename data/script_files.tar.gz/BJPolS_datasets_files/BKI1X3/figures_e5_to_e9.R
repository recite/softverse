#Get objects
old_ws = ls()

#Load data
candidate_data <- read.csv("./data/candidates/full_data_merged_w_codes021119.csv")


#creating the quartiles of district-level muslim population shares
candidate_data$quartile <- ifelse(candidate_data$prop_islam < 0.25, "Proportion Islam < 25%",
                           ifelse(candidate_data$prop_islam > 0.25 & candidate_data$prop_islam < 0.50, "25% < Proportion Islam < 50%",
                                  ifelse(candidate_data$prop_islam > 0.50 & candidate_data$prop_islam < 0.75, "50% < Proportion Islam < 75%", 
                                         ifelse(candidate_data$prop_islam > 0.75, "75% < Proportion Islam", NA))))

candidate_data$quartile <- factor(candidate_data$quartile, levels = 
                                    c("Proportion Islam < 25%", "25% < Proportion Islam < 50%", 
                                      "50% < Proportion Islam < 75%", "75% < Proportion Islam"))


#removing the rows in which we don't have demographic data
candidate_data <- candidate_data[!is.na(candidate_data$quartile),]

#creating indicator variable if the candidate is in the area covered by NVMS
nvms <- c("11", "12", "18", "99", "31", "32", "36", "35", "52", "53", "61", "62", "71", "72", "73", "81", "82", "91", "94")
candidate_data$NVMS <- ifelse(substr(candidate_data$kab_code, 1, 2) %in% nvms, "NVMS", "Non-NVMS")

##creating the list to remove the parties that weren't around in 2009, 
#the regional parties, and the islam-based parties
parties_non_2009 <- c("Partai Daerah Aceh", "PARTAI BERKARYA", "Partai Solidaritas Indonesia",
                      "Persatuan Indonesia", "Partai Daerah Aceh", "PARTAI NANGGROE ACEH", 
                      "PARTAI SIRA", "PARTAI ACEH", "PAN", "PKB", "PSI")

#removing those candidates that don't have campaign platform statements
candidate_data_motivation <- candidate_data[!is.na(candidate_data$motivation) & !(candidate_data$motivation ==  ""),]

#tranforming data and plotting into platform graph
p <-  candidate_data_motivation %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, quartile) %>% summarise(mean(relig_platform)) %>%

  ggplot(aes(x=namaPartai, y =`mean(relig_platform)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Platforms Mentioning Religion") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(quartile~.)
  

ggsave(plot = p, "./output/figures/figure_e5a.pdf", width = 11, height = 8)
rm(p)

#tranforming data and plotting into hajj graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, quartile) %>% summarise(mean(hajj, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(hajj, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Conducting the Hajj") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(quartile~.)

ggsave(plot = p, "./output/figures/figure_e6a.pdf", width = 11, height = 8)

rm(p)

#tranforming data and plotting into college education graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, quartile) %>% summarise(mean(college, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(college, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Completing College") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(quartile~.)

ggsave(plot = p, "./output/figures/figure_e7a.pdf", width = 11, height = 8)

rm(p)

#tranforming data and plotting into incumbency graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, quartile) %>% summarise(mean(polt_experience, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(polt_experience, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Having Political Experience") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(quartile~.)

ggsave(plot = p, "./output/figures/figure_e8a.pdf", width = 11, height = 8)

rm(p)


candidate_data$number_kids <- as.character(candidate_data$number_kids)
candidate_data$number_kids <- ifelse(candidate_data$number_kids == "-", 0, candidate_data$number_kids)
candidate_data$number_kids <- as.numeric(candidate_data$number_kids)

#tranforming data and plotting into children graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, quartile) %>% summarise(mean(number_kids, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(number_kids, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Average Number of Kids") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(quartile~.)

ggsave(plot = p, "./output/figures/figure_e9a.pdf", width = 11, height = 8)
rm(p)


##########################
## NVMS FACET#############
##########################

#tranforming data and plotting into platformn graph
p <-  candidate_data_motivation %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, NVMS) %>% summarise(mean(relig_platform, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(relig_platform, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Mentioning Religion") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(NVMS~.)

ggsave(plot = p, "./output/figures/figure_e5b.pdf", width = 11, height = 4)

rm(p)



#tranforming data and plotting into hajj graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, NVMS) %>% summarise(mean(hajj, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(hajj, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Completing Hajj") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(NVMS~.)

ggsave(plot = p, "./output/figures/figure_e6b.pdf", width = 11, height = 4)

rm(p)


#tranforming data and plotting into college graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, NVMS) %>% summarise(mean(college, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(college, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates Completing College") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(NVMS~.)

ggsave(plot = p, "./output/figures/figure_e7b.pdf", width = 11, height = 4)

rm(p)

#tranforming data and plotting into college graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, NVMS) %>% summarise(mean(polt_experience, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(polt_experience, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Proportion of Candidates With Political Experience") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(NVMS~.)

ggsave(plot = p, "./output/figures/figure_e8b.pdf", width = 11, height = 4)

rm(p)


#tranforming data and plotting into children graph
p <-  candidate_data %>% filter(!(namaPartai %in% parties_non_2009)) %>% 
  group_by(namaPartai, type, NVMS) %>% summarise(mean(number_kids, na.rm = T)) %>%
  
  ggplot(aes(x=namaPartai, y =`mean(number_kids, na.rm = T)`, fill = type)) + 
  geom_bar(stat = "identity", color = "darkgrey") + theme_test() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) + xlab("Name of Party") + 
  ylab("Average Number of Kids") + 
  scale_fill_manual(values = c("lightgreen", "darkgrey")) + facet_wrap(NVMS~.)

ggsave(plot = p, "./output/figures/figure_e9b.pdf", width = 11, height = 4)

rm(p)


#cleanup
rm(list = setdiff(ls(), old_ws))