#Get objects
old_ws = ls()

#############
#First Stage#
#############
fs_lm = lm(frac_IT ~ IT_win, mergedTable_podes[(sample_ni_it)])
fs_lm %>% cluster_errors(clusters = mergedTable_podes[(sample_ni_it), cluster], vcov = F)

#Data for plotting
plot_data = mergedTable_podes[(sample_ni_it), list(IT_win, frac_IT)] 
plot_data[, Condition := ifelse(IT_win == T, "Islamist Win", "Secular Win")]
plot_data[, mean := mean(frac_IT), by = Condition]

pdf('./output/figures/figure_c1.pdf')
p = ggplot(plot_data, aes(x=frac_IT)) +
  geom_histogram(binwidth=0.1, alpha=.5, position="identity") + theme_bw() +
  geom_vline(aes(xintercept = mean)) +
  xlab("Frac. Islamist Seats in Dapil") + 
  ylab("Count") + facet_grid(Condition ~ .)
print(p)
dev.off()

#Clean up
drop = setdiff(ls(), c(old_ws)) 
rm(list = drop)