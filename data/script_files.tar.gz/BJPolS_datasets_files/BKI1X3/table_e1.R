##Get objects
old_ws = ls()

#Sharia Laws
budget_2008 = fread('./data/budget/budget_2008_fin.csv', header = T) 
budget_2013 = fread('./data/budget/budget_2013_fin.csv', header = T) 
budget = rbindlist(list(budget_2008, budget_2013))

budget[year %in% 2008, election_cycle := 2004]
budget[year %in% 2013, election_cycle := 2009]

#Create analysis data
kabupaten_elections = dapil_elections_all[, list(
  total_seats = sum(dapil_seats, na.rm = T),
  total_it_wins = sum(all_IT_seats, na.rm = T),
  total_close_it_seats = sum(sample_ni_it, na.rm = T),
  total_close_it_wins = sum(sample_ni_it & IT_win, na.rm = T),
  total_ic_wins = sum(all_IC_seats, na.rm = T),
  total_close_ic_seats = sum(sample_ni_ic, na.rm = T),
  total_close_ic_wins = sum(sample_ni_ic & IC_win, na.rm = T),
  total_icit_wins = sum(all_ICIT_seats, na.rm = T),
  total_close_icit_seats = sum(sample_ni_icit, na.rm = T),
  total_close_icit_wins = sum(sample_ni_icit & ICIT_win, na.rm = T)
) , by = list(kab_code, election_cycle)]

kabupaten_elections[, paste0(c('it', 'ic', 'icit'), "_seat_pct") := lapply(.SD, function(x) x / kabupaten_elections[['total_seats']]), .SDcols = paste0("total_",c('it', 'ic', 'icit'),"_wins")]
kabupaten_elections[, paste0(c('it', 'ic', 'icit'), "_close_pct") := lapply(.SD, function(x) x / kabupaten_elections[['total_seats']]), .SDcols = paste0("total_close_",c('it', 'ic', 'icit'),"_seats")]
kabupaten_elections[, paste0(c('it', 'ic', 'icit'), "saturated") := lapply(.SD, function(x) paste(x, kabupaten_elections[['total_seats']], sep=":")), .SDcols = paste0("total_close_",c('it', 'ic', 'icit'),"_seats")]
kabupaten_elections[, paste0(c('it', 'ic', 'icit'), "_iv_pct") := lapply(.SD, function(x) x / kabupaten_elections[['total_seats']]), .SDcols = paste0("total_close_",c('it', 'ic', 'icit'),"_wins")]

setkey(budget, kab_code, election_cycle)
setkey(kabupaten_elections, kab_code, election_cycle)

budgetTable = budget[kabupaten_elections]

###############################
#Analysis: reduced form and IV#
###############################
rf1 = felm(sec_prop ~ it_iv_pct + it_close_pct , data = budgetTable)
rf2 = felm(sec_prop ~  it_iv_pct | itsaturated | 0 | 0, budgetTable)
iv1 = felm(sec_prop ~  it_close_pct | 0 | (it_seat_pct ~ it_iv_pct) | 0, budgetTable)
iv2 = felm(sec_prop ~  0 | itsaturated | (it_seat_pct ~ it_iv_pct) | 0, budgetTable)

table_list = list(rf1,rf2, iv1, iv2)


table = stargazer(table_list, type = 'latex', 
                  title = "Estimated Effects of Islamist Victory on Local Security Spending",
                  #out = './output/tables/security_spending.tex',
                  label = 'tab:security_spending',
                  keep = c('it_iv_pct', 'it_seat_pct'),
                  model.names = F,
                  model.numbers = T,
                  dep.var.labels = c("Kabupaten Security Spending (\\% of total)"), 
                  dep.var.caption = "",
                  covariate.labels = c("Islamist Close Wins (\\% of all seats)", "Islamist Wins (\\% of all seats)"),
                  add.lines = list(c('Reduced Form', rep(c('X', ''), each = 2)),
                                   c('Instrumental Variables', rep(c('', 'X'), each = 2)),
                                   c('Covariates', rep(c('Linear', 'Saturated'), 2))),
                  star.cutoffs = c(0.1, 0.05, 0.01),
                  #float.env = 'sidewaystable',
                  notes.align = 'l',
                  multicolumn = T,
                  keep.stat = 'n', 
                  style = "apsr")

note_text = "Standard errors are robust. Observations are kabupaten (districts). IV specifications instrument for the fraction of seats won by Islamists with the fraction of final seats won by Islamists by less than 1 percent. Covariates are either the fraction of final seats contested closely between Islamists and secular nationalist parties specified as either linearly or as dummies for each fraction."

write_latex(table, note_text, './output/tables/table_e1.tex')


#Clean up
drop = setdiff(ls(), c(old_ws)) 
rm(list = drop)