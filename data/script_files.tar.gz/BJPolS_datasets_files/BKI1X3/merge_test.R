rm(list=ls())
library(dplyr)
library(foreign)
library(readstata13)


#getting yuhkis data
setwd("~/Dropbox/Indonesia_elections_violence/Data/Census 2000 dataverse")
yuk_data <- read.dta13("tso_APSR_2018_rep2.dta")

#getting podes data
setwd("~/Dropbox/Indonesia_elections_violence/Data/PODES/podes2000")
pod2000 <- read.dbf("PDS20001.dbf")
pod2000$descode <- paste0(pod2000$PROP, pod2000$KAB, pod2000$KEC, pod2000$DESA)
pod2000$kabid <- paste0(pod2000$PROP, pod2000$KAB)
pod2000$popv <- pod2000$B4AR2A

#selecting the variables we want
pod_test <- pod2000[,c("descode", "kabid", "popv")]
yuk_test <- yuk_data[,c("kabid", "popv")]

#making variables same type
pod_test$kabid <- as.numeric(pod_test$kabid)

#trying to direct merge
test <- left_join(yuk_test, pod_test, by = c("kabid", "popv"))




