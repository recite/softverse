
library(foreign)
setwd("C:/users/jon/desktop/current projects/ongoing projects/polarization vote choice/")
cands2010 <- read.dta("2010 cands.dta") 

windows(height=20,width=18)
par(mar=c(3, 2.5, 2, 2.5))
par(mgp = c(1.5, 0.5, 0))
par(mfrow=c(2,2))


cands2006 <- read.dta("2006 cands.dta") 
plot(density(cands2006$repest-0.28),xlim=c(-2.25,2.25),ylim=c(0,1.5),main="Distribution of Platform Locations \n (2006 House candidates)",xlab="Platform Locations", cex.main=.9,cex=.9,lwd=2,cex.lab=0.8,cex.axis=0.7,ylab="Density")
lines(density(cands2006$demest-0.28),lwd=2,lty=2)
text(-1,1,"D")
text(1,1,"R")

cit2006 <- read.dta("2006 cces.dta") 

plot(density(cit2006$V1[cit2006$pid3==3]),xlim=c(-2.25,2.25),ylim=c(0,1.5),main="Distribution of Citizen Preferences \n (2006 CCES respondents)",xlab="Platform Locations", cex.main=.9,cex=.9,lwd=2,cex.lab=0.8,cex.axis=0.7,ylab="Density")
lines(density(cit2006$V1[cit2006$pid3==1]),lwd=2,lty=2)
lines(density(cit2006$V1[cit2006$pid3==2]),lwd=2,lty=3)
text(-1.5,.55,"D")
text(1.75,.55,"R")
text(-.5,.3,"I")

plot(density(cands2010$r_cand_ip),xlim=c(-2.25,2.25),ylim=c(0,1),main="Distribution of Platform Locations \n (2010 House candidates)",xlab="Platform Locations", cex.main=.9,cex=.9,lwd=2,cex.lab=0.8,cex.axis=0.7,ylab="Density",lty=1)
lines(density(cands2010$d_cand_ip),lwd=2,lty=2)
text(-1.5,.8,"D")
text(1.75,.8,"R")

cit2010 <- read.dta("2010 cces.dta") 

plot(density(cit2010$np_score[cit2010$party=="R"]),xlim=c(-2.25,2.25),ylim=c(0,1),main="Distribution of Citizen Preferences \n (2010 CCES respondents)",xlab="Platform Locations", cex.main=.9,cex=.9,lwd=2,cex.lab=0.8,cex.axis=0.7,ylab="Density")
lines(density(cit2010$np_score[cit2010$party=="D"]),lwd=2,lty=2)
lines(density(cit2010$np_score[cit2010$party=="I"]),lwd=2,lty=3)
text(-1.5,.55,"D")
text(1.5,.55,"R")
text(.55,.4,"I")



