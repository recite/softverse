#######################
# Covariates of Measurment

  library(stringr)
  library(foreign)
  library(apsrtable)

  # Other measures
  dat <- readRDS("Merge_est_covar.Rds")
  
  ## Modell-Output
  positions <- readRDS("res_party.RDS")
  positions$py <- str_c(positions$pid, "_", positions$year)
  positions <- positions[str_detect(positions$par, "x"), c("mean", "py")]
  colnames(positions) <- c("position_estimate", "py")
  
  load("alternativmeasures.Rdata")
  dat$py <- str_c(dat$pid, "_", dat$year)
  

  cmp <- read.dta("MPDataset_MPDS2016a.dta", convert.factors = F)
  
  ## Number of available Manifestos
  dat$party_age_1 <- NA
  dat$party_age_2 <- NA
  for(i in 1:nrow(dat)){
    dat$party_age_1[i] <- sum(cmp$party == dat$cmp_id[i])
    dat$party_age_2[i] <- min(cmp$date[cmp$party == dat$cmp_id[i]])
  }
  dat$party_age_2 <- str_extract(dat$party_age_2, "^\\d{4}")
  dat$party_age_2 <- as.numeric("2014") - as.numeric(dat$party_age_2)
  
  
  rozenas <- readRDS("res_party_rozenas.RDS")
  rozenas <- rozenas[ str_detect(rozenas$par, "nu"),]
  rozenas$py <- str_c(rozenas$pid, "_", rozenas$year)
  rozenas <- rozenas[, c("mean", "py")]
  colnames(rozenas) <- c("rozenas", "py")
  
  # Prepare Data
  dat$govt <- ifelse(dat$govt == 0, 0, 1)
  dat$vote_cat <- cut(dat$vote, breaks = c(1, 10, 20, 30, 40, 50))
  dat$family <- as.factor(dat$family)  
  levels(dat$family) <- c(
  	"Radical Right",
 	  "Conservatives",
  	"Liberal",
  	"Christian-Democratic",
  	"Socialist",
    "Radical Left",
    "Green",
    "Regionalist",
    "No family",
    "Confessional",
    "Agrarian/Center"
  )
  dat$family <- relevel(dat$family, ref = "No family")
  dat$lrgen <- as.numeric(as.character(dat$lrgen))
  dat$lrgen_cat <- cut(dat$lrgen, breaks = c(0, 2, 4, 6, 8, 10))
  dat$lrgen_sqr <- dat$lrgen^2
  dat$log_vote <- log(dat$vote)

  new_dat <- merge(dat, alternativmasse, by = "py")
  new_dat <- merge(new_dat, rozenas, by = "py")
  
  ## Model in paper
  m <- lm(mean ~ log_vote + govt + lrgen + lrgen_sqr + family, data = dat)
  
  ## Robustness for paper
  r1 <- lm(mean ~ log_vote + govt + lrgen + lrgen_sqr, data = dat)
  
 ## Robustness for paper II
  
  r2 <- lm(mean ~ log_vote + govt + family, data = dat)
  
  ## Reviewer 3
  dat$log_age <- log(dat$party_age_2)
  reviewer3 <- lm(mean ~ log_vote + govt + lrgen + lrgen_sqr + log_age + family, data = dat)

  
  apsrtable(
  	m, r1, r2,
  	coef.names = c(
  		"(Intercept)",
  		"log(Vote share)",
  		"Government participation",
  		"Left-right position",
  		"Left-right position (squared)",
  		"Party family: Radical Right",
  		"Party family: Conservatives",
  		"Party family: Liberal",
  		"Party family: Christian-Democr.",
  		"Party family: Socialist",
  		"Party family: Radical Left",
  		"Party family: Green", 
      "Party family: Regionalist",
  		"Party family: Confessional",
  		"Party family: Agrarian"
  	)
  )

  
  ## Figure 
  
  pred_dat <- data.frame(
  	mean = mean(dat$mean),
  	log_vote = mean(dat$log_vote),
  	govt = 1,
  	lrgen = seq(
  		from = min(dat$lrgen),
  		to = max(dat$lrgen),
  		by = .2
  	),
  	family = "Conservatives"
  )
  
  pred_dat$lrgen_sqr <- pred_dat$lrgen^2
  
  pred <- predict(
  	m,
  	newdata = pred_dat,
  	se.fit = T
  )
  
  pred$hi <- pred$fit + pred$se.fit * 1.96
  pred$lo <- pred$fit - pred$se.fit * 1.96
  
  pdf("res_reg_comprehensive.pdf")
  
  plot(
    pred_dat$lrgen,
  	pred$fit,
  	ylim = range(pred$fit) + c(-.15, .2),
  	type = "l",
  	bty = "n",
  	xlab = "Left-right position",
  	ylab = "Predicted ambiguity"
  )
  
  polygon(
  	c(
  	  pred_dat$lrgen,
  		rev(pred_dat$lrgen)
  	),
  	c(
  		pred$lo,
  		rev(pred$hi)
  	),
  	border = NA,
  	col = gray(.6, alpha = .5)
  )
  
  rug(dat$lrgen)
  
  dev.off()
    
  
  
  