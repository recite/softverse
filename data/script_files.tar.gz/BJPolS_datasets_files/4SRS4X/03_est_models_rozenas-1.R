#################
# Estimate Models 

library(rstan)

# SAMPLING PARAMTERS

  rstan_options(auto_write = TRUE) 
  CHAINS <- 4
  ITER <- 2000
  BURNIN <- 1500

# Source Data
  source("99_est_stan_rozenas.R")

# Load Data
  chc <- readRDS("CHES_POLICY_COMBINED_DATA_06_14_min3perc.Rds")

# Print Info
  cat("Estimate Models for", length(unique(chc$ctry_name)), "countries and 3 time points\n")
  cat("Using", CHAINS, "chains and",ITER ,"total draws \n")
  cat(rep("=",10),"\n\n")

# Run Model
  for(c in unique(chc$ctry_name)){
    for(y in c("2006","2010","2014")){
      
      cat("Model",c,y,"\n")
      cat(rep("=",10),"\n\n")    
      res <- est_ros_stan(chc,country = c,year=y,
                          iteration=ITER, nchains=CHAINS,nburnin=BURNIN
                          ,control=list(adapt_delta = 0.999, max_treedepth=100)
                          )
      saveRDS(res,paste("res_rozenas_",c,"_",y,".Rds",sep=""))
    }
  }
