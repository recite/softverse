##################################
# Creates Figures

# 0) Simulation Figures
# A) Country specific figures
# B) Country-comparsion figures
# C) Comparsion with other measurments
# D) Boxplots for with other measures

# Libraries
require("GGally")
require("ggplot2")

# Load Data-sets
  chc <- readRDS("CHES_POLICY_COMBINED_DATA_06_14_min3perc.Rds")
  res <- readRDS("res_party.RDS")
  res_rozenas <- readRDS("res_party_rozenas.RDS")
  items <- readRDS("res_items.RDS")
  load("alternativmeasures.Rdata") 

# Attach Rozenas measure to alternativemasse
  sel <- grep("nu",res_rozenas$par)
  res_rozans_merge <- res_rozenas[sel,c("year","pid","mean")]
  alternativmasse <- merge(alternativmasse, res_rozans_merge)
  names(alternativmasse)[13] <- "rozans_mean"
  
  
# Load GGPLOT Figure functions
  source("99_graphs.R")

# Item Names
  issue_names <- c("Spend vs Tax","Deregulation",
                   "Redistribution",  "Civlib Laworder",
                   "Sociallifestyle","Religious Principle",
                   "Immigrate Policy","Immigrant Asylum",
                   "Urban Rural","Regions",  "Ethnic Minorities")

# Manipulate Ctry Names
  chc$ctry_name <- as.character(chc$ctry_name); chc$ctry_name[chc$ctry_nam=="LAT"] <- "lat"; chc$ctry_name <- as.factor(chc$ctry_name)
  res$ctry_nam[res$ctry_nam=="LAT"] <- "lat"  
  items$ctry_nam[items$ctry_nam=="LAT"] <- "lat"  
  
# Manipulate some Party Names
  chc$pid_nam[chc$pid_nam=="Linkspartei/PDS" & !is.na(chc$pid_nam)] <- "LINKE"
  res$pid_nam[res$pid_nam=="Linkspartei/PDS" & !is.na(res$pid_nam)] <- "LINKE"
  
##########################
# 0) Simulation Figures
  
  d <- readRDS("res_simulation_combined.Rds")
  
  # Subset Data; Create Factors
  d <- d[grep("nu\\[",d$par),]
  names(d)[grep("%",names(d))] <- c("vvlow","vlow","low","mid","high","vhigh","vvhigh")
  d$parties <- as.factor(d$parties)
  d$type <- as.factor(d$type)
  d$party <- as.factor(LETTERS[1:6])
  
  # Plot using ggplot
  pdf("sim_ambiguity.pdf", width=12)
  ggplot(d) +  facet_grid(parties ~ type, scales="free_x") + 
    geom_segment(aes(x=vlow,xend=vhigh,y=party,yend=party),
                 size=0.8,alpha=0.8) +
    geom_segment(aes(x=low,xend=high,y=party,yend=party),
                 size=1.5) +
    geom_point(aes(x=mean,y=party),
               size=2) +
    xlab("Estimates") + ylab("") + 
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          legend.position = "top"
          ,text=element_text(family="Palatino", size=11)
          ,strip.text.y = element_text(size=13,angle=360)
    ) +   scale_colour_grey() + theme_bw()
  dev.off()
  

###########################
# A) Country specific figures
  
# Loop over Country-years and save figures to pdf
# Change loop for more cases
  
  for(ctry in c("ger")){

    print(ctry)

    # Party Estimates
    pdf(paste("est_party_",ctry,".pdf",sep=""), width=12)
    print(ggplot_party_est(data=chc, c=ctry))
    dev.off()
    

    for(year in c("2014")){
      
      # Expert Distribution for each year
      pdf(paste("dist_",ctry,"_",year,".pdf",sep=""), width=12)
      print(ggplot_distribution_experts(data=chc, c=ctry,y=year))
      dev.off()
      
    }
    }
  
###########################
# B) Country-comparsion figures
  

  # Plot Ambguity for each year
  for(year in c("2014")){
  
    pdf(paste("est_amb_all_",year,".pdf",sep=""), width=12)
    print(ggplot_cob_est(y = year))
    dev.off()
    
  }

  # Plot all Ambguity estimates together (not in main article)
  # pdf("figure/est_amb_all.pdf", width=12)
  # print(ggplot_cob_est(y = c("2006","2010","2014")))
  # dev.off()
  

  
##############################
# C) Correlation Plots
  
  # Ambguity
  pdf("corr_aggreagte.pdf", width=12)
  print(ggplot_alternative_d())
  dev.off()
  
###########################
# Boxplots
  
  # Other measures
  dat <- readRDS("out/Merge_est_covar.Rds")
  
  
  # Prepare Data
  dat$govt <- ifelse(dat$govt ==0, 0,1)
  dat$vote_cat <- cut(dat$vote,breaks = c(1,10,20,30,40,50))
  dat$family <- as.factor(dat$family)  
  levels(dat$family) <- c("Radical Right","Conservatives","Liberal","Christian-Democratic","Socialist",
                          "Radical Left","Green","Regionalist","No family","Confessional","Agrarian/Center")
  dat$lrgen_cat <- cut(dat$lrgen,breaks = c(0,2,4,6,8,10))
  
  
  # Regression stuff
  dat$lrgen_sqr <- dat$lrgen^2
  m <- lm(log(mean) ~  -1 + log(vote) + govt + lrgen + lrgen_sqr,data=dat)
  summary(m)
  
  
  # Create Boxplots
  
  # Vote Share
  pdf("figure/cov_vote.pdf")
  ggplot(dat) + geom_boxplot(aes(y=mean,x=vote_cat),na.rm = TRUE) + coord_flip() +
      xlab("Vote share in national election most prior") + ylab("Ambiguity Estimate") +
    theme_bw() +
    theme(text=element_text(family="Palatino", size=11)) +   
    scale_fill_grey() 
  dev.off()
  
  # Party Family
  pdf("figure/cov_family.pdf")
  # Drop no family
  ggplot(dat[!dat$family=="No family",]) + geom_boxplot(aes(y=mean,x=reorder(family, mean, FUN=median),na.rm = TRUE)) +
    xlab("Party family") + ylab("Ambiguity Estimates") + 
    coord_flip() +
    theme_bw() +
    theme(text=element_text(family="Palatino", size=11)) +   
    scale_fill_grey() 
  dev.off()
  
  # Generell Left-Right Orientation
  pdf("figure/cov_flrgen.pdf")
  ggplot(dat) + geom_boxplot(aes(y=mean,x=as.factor(lrgen_cat)),na.rm = TRUE) +
    # coord_flip() +
    xlab("Average Left-Right Expert Placement") + ylab("Ambiguity Estimate") +
    theme_bw() +
    theme(text=element_text(family="Palatino", size=11)) +   
    scale_fill_grey()
  dev.off()
  
  # Government Particpation
  pdf("figure/cov_govt.pdf")
  dat$govt <- ifelse(dat$govt ==0, 0,1)
  dat$govt <- as.factor(dat$govt)
  levels(dat$govt) <- c("Party not in government", "In Goverment at least part of the year")
  ggplot(dat) + geom_boxplot(aes(y=mean,x=govt),na.rm = TRUE) +
    # coord_flip() +
    xlab("Average Left-Right Expert Placement") + ylab("Ambiguity Estimate") +
    theme_bw() +
    theme(text=element_text(family="Palatino", size=11)) +   
    scale_fill_grey()
  dev.off()
  
  
  
  
  