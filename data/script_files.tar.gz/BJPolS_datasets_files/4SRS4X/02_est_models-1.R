#################
# Estimate Models 


# SAMPLING PARAMTERS
CHAINS <- 4
ITER <- 1000

# Source Data
source("99_est_stan.R")

# Load Data
chc <- readRDS("CHES_POLICY_COMBINED_DATA_06_14_min3perc.Rds")

# Print Info
cat("Estimate Models for", length(unique(chc$ctry_name)), "countries and 3 time points\n")
cat("Using", CHAINS, "chains and",ITER ,"total draws \n")
cat(rep("=",10),"\n\n")

for(c in unique(chc$ctry_name)){
  for(y in c("2006","2010","2014")){
    
    cat("Model",c,y,"\n")
    cat(rep("=",10),"\n\n")    
    res <- est_stan(chc,country = c,year=y,iteration=ITER, chains=CHAINS)
    saveRDS(res,paste("res_",c,"_",y,".Rds",sep=""))
  }
}
