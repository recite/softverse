# w14 vaccine experiment
library(data.table)
library(tidyverse)
library(dtplyr)
library(colorblindr)
library(here)
set.seed(11111)

here::here()
source("code/vaccine_experiments_functions.R")

wave14.c.exp.oh <- data.table::fread("data/w14_vac_message_cleaned_onehot.csv")
wave14.c.exp.oh$covnews_fb[is.na(wave14.c.exp.oh$covnews_fb)] <- 0

out_path <- "output/"

message('running without fb covariate')
message_patriotism_binary <- run.hte(conditions = c("Control","Patriotism"),
                                     full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                     which = "message")
save(message_patriotism_binary, file = paste0(out_path, "main_output/message_patriotism_binary.RData"))

message_patriotism_continuous <- run.hte(conditions = c("Control","Patriotism"),
                                         full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                         which = "message", outcome = "continuous")
save(message_patriotism_continuous, file = paste0(out_path, "main_output/message_patriotism_continuous.RData"))

message_people_binary <- run.hte(conditions = c("Control","People you know"),
                                 full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                 which = "message")
save(message_people_binary, file = paste0(out_path, "main_output/message_people_binary.RData"))

message_people_continuous <- run.hte(conditions = c("Control","People you know"),
                                     full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                     which = "message", outcome = "continuous")
save(message_people_continuous, file = paste0(out_path, "main_output/message_people_continuous.RData"))

message_physician_binary <- run.hte(conditions = c("Control","Physician recommend"),
                                    full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                    which = "message")
save(message_physician_binary, file = paste0(out_path, "main_output/message_physician_binary.RData"))

message_physician_continuous <- run.hte(conditions = c("Control","Physician recommend"),
                                        full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                        which = "message", outcome = "continuous")
save(message_physician_continuous, file = paste0(out_path, "main_output/message_physician_continuous.RData"))

message_harm_binary <- run.hte(conditions = c("Control","Preventing harm"),
                               full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                               which = "message")
save(message_harm_binary, file = paste0(out_path, "main_output/message_harm_binary.RData"))

message_harm_continuous <- run.hte(conditions = c("Control","Preventing harm"),
                                   full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                   which = "message", outcome = "continuous")
save(message_harm_continuous, file = paste0(out_path, "main_output/message_harm_continuous.RData"))

message_scientists_binary <- run.hte(conditions = c("Control","Scientists recommend"),
                                     full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                     which = "message")
save(message_scientists_binary, file = paste0(out_path, "main_output/message_scientists_binary.RData"))

message_scientists_continuous <- run.hte(conditions = c("Control","Scientists recommend"),
                                         full_data = wave14.c.exp.oh[,-which(names(wave14.c.exp.oh) == "covnews_fb"), with = FALSE],
                                         which = "message", outcome = "continuous")
save(message_scientists_continuous, file = paste0(out_path, "main_output/message_scientists_continuous.RData"))

set.seed(11111)
message('running with fb covariate')
message_patriotism_binary <- run.hte(conditions = c("Control","Patriotism"),
                                     which = "message")
save(message_patriotism_binary, file = paste0(out_path, "with_facebook_covariate/message_patriotism_binary.RData"))

message_patriotism_continuous <- run.hte(conditions = c("Control","Patriotism"),
                                         which = "message", outcome = "continuous")
save(message_patriotism_continuous, file = paste0(out_path, "with_facebook_covariate/message_patriotism_continuous.RData"))

message_people_binary <- run.hte(conditions = c("Control","People you know"),
                                 which = "message")
save(message_people_binary, file = paste0(out_path, "with_facebook_covariate/message_people_binary.RData"))

message_people_continuous <- run.hte(conditions = c("Control","People you know"),
                                     which = "message", outcome = "continuous")
save(message_people_continuous, file = paste0(out_path, "with_facebook_covariate/message_people_continuous.RData"))

message_physician_binary <- run.hte(conditions = c("Control","Physician recommend"),
                                    which = "message")
save(message_physician_binary, file = paste0(out_path, "with_facebook_covariate/message_physician_binary.RData"))

message_physician_continuous <- run.hte(conditions = c("Control","Physician recommend"),
                                        which = "message", outcome = "continuous")
save(message_physician_continuous, file = paste0(out_path, "with_facebook_covariate/message_physician_continuous.RData"))

message_harm_binary <- run.hte(conditions = c("Control","Preventing harm"),
                               which = "message")
save(message_harm_binary, file = paste0(out_path, "with_facebook_covariate/message_harm_binary.RData"))

message_harm_continuous <- run.hte(conditions = c("Control","Preventing harm"),
                                   which = "message", outcome = "continuous")
save(message_harm_continuous, file = paste0(out_path, "with_facebook_covariate/message_harm_continuous.RData"))

message_scientists_binary <- run.hte(conditions = c("Control","Scientists recommend"),
                                     which = "message")
save(message_scientists_binary, file = paste0(out_path, "with_facebook_covariate/message_scientists_binary.RData"))

message_scientists_continuous <- run.hte(conditions = c("Control","Scientists recommend"),
                                         which = "message", outcome = "continuous")
save(message_scientists_continuous, file = paste0(out_path, "with_facebook_covariate/message_scientists_continuous.RData"))
