

## REPLICATION MATERIAL FOR
## HOW DOES UNCERTAINTY AFFECT VOTERS' PREFERENCES?
## BRITISH JOURNAL OF POLITICAL SCIENCE
## AUTHOR: LOVE CHRISTENSEN


####################################
########## FILE 2: ANALYSIS ########
####################################

## read packages
library(tidyverse)
library(lmtest)
library(car)
library(estimatr)
library(gridExtra)
library(reshape2)
library(MASS)

## read the cleaned data
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
load("../data/dat_uncertainty_BJPS_cleaned.RData")


## Structure of analysis:

## 1. First stage: outcome beliefs and idealistic preferences (Table 3)
## 2. Second stage: policy attitudes (Table 4)
## 3. IV analysis: Quantitative beliefs (Appendix F.4)
## 4. IV analysis: Qualitative beliefs (Appendix F.4)
## 5. Association between attitudes and idealistic preferences (Appendix F.2)
## 6. Heterogeneity: Risk preferences (Appendix F.6)
## 7. Heterogeneity: MW, CT, EXPERT TPP  (Appendix F.7)
## 8. Heterogeneity: Partisan TPP  (Figure 3, Appendix F.7)
## 9. Drop single forecast treaments (Appendix F.13)
## 10. Difference-of-means estimator (Appendix F.10)
## 11. Ordered probit  (Appendix F.12)
## 12. Outcomes in loss or gain domain (Appendix F.9)
## 13. Strength of priors in control group (Appendix F.3)
## 14. Qualitative beliefs (Appendix F.11)
## 15. Alternative uncertainty operationalization (Appendix F.8)
## 16. Numerical literacy (Appendix F.14)
## 17. Belief Uncertainty (Appendix F.5)
  

##########################################################################
## 1. First stage: outcome beliefs and idealistic preferences (Table 3) ##
##########################################################################

# Beliefs

mw_quant_mod1 <- lm_robust(mw_quant ~ mw_forecast_center * (Condition == "Partisan") + 
                             mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = dat)
mw_quant_f1 <- linearHypothesis(mw_quant_mod1, 'mw_forecast_center + mw_forecast_center:Condition == "Partisan"TRUE = 0',
                                test = c("F"))
mw_quant_f2 <- linearHypothesis(mw_quant_mod1, 'mw_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude = 0',
                                test = c("F"))

ct_quant_mod1 <- lm_robust(ct_quant ~ ct_forecast_center * (Condition == "Partisan") + 
                             ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = dat)
ct_quant_f1 <- linearHypothesis(ct_quant_mod1, 'ct_forecast_center + ct_forecast_center:Condition == "Partisan"TRUE = 0',
                                test = c("F"))
ct_quant_f2 <- linearHypothesis(ct_quant_mod1, 'ct_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude = 0',
                                test = c("F"))

tpp_quant_mod1 <- lm_robust(tpp_quant ~ tpp_forecast_center * (Condition == "Partisan") + 
                              tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                            se = "stata",
                            data = dat)
tpp_quant_f1 <- linearHypothesis(tpp_quant_mod1, 'tpp_forecast_center + tpp_forecast_center:Condition == "Partisan"TRUE = 0',
                                 test = c("F"))
tpp_quant_f2 <- linearHypothesis(tpp_quant_mod1, 'tpp_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:tpp_forecast_uncertain_magnitude = 0',
                                 test = c("F"))

# idealistic preferences

mw_ideal_mod1 <- lm_robust(mw_ideal ~ mw_forecast_center * (Condition == "Partisan") + 
                             mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = dat)
mw_ideal_f1 <- linearHypothesis(mw_ideal_mod1, 'mw_forecast_center + mw_forecast_center:Condition == "Partisan"TRUE = 0',
                                test = c("F"))
mw_ideal_f2 <- linearHypothesis(mw_ideal_mod1, 'mw_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude = 0',
                                test = c("F"))

ct_ideal_mod1 <- lm_robust(ct_ideal ~ ct_forecast_center * (Condition == "Partisan") + 
                             ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = dat)
ct_ideal_f1 <- linearHypothesis(ct_ideal_mod1, 'ct_forecast_center + ct_forecast_center:Condition == "Partisan"TRUE = 0',
                                test = c("F"))
ct_ideal_f2 <- linearHypothesis(ct_ideal_mod1, 'ct_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude = 0',
                                test = c("F"))

tpp_ideal_mod1 <- lm_robust(tpp_ideal ~ tpp_forecast_center * (Condition == "Partisan") + 
                              tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                            se = "stata",
                            data = dat)
tpp_ideal_f1 <- linearHypothesis(tpp_ideal_mod1, 'tpp_forecast_center + tpp_forecast_center:Condition == "Partisan"TRUE = 0',
                                 test = c("F"))
tpp_ideal_f2 <- linearHypothesis(tpp_ideal_mod1, 'tpp_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:tpp_forecast_uncertain_magnitude = 0',
                                 test = c("F"))

#################################################
## 2. Second stage: policy attitudes (Table 4) ##
#################################################

mw_likert_mod1 <- lm_robust(mw_likert ~ mw_forecast_center * (Condition == "Partisan")  +
                              mw_forecast_uncertain_magnitude * (Condition == "Partisan") +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_likert_f1 <- linearHypothesis(mw_likert_mod1, 'mw_forecast_center + mw_forecast_center:Condition == "Partisan"TRUE  = 0',
                                 test = c("F"))
mw_likert_f2 <- linearHypothesis(mw_likert_mod1, 'mw_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude = 0',
                                 test = c("F"))

ct_likert_mod1 <- lm_robust(ct_likert ~ ct_forecast_center * (Condition == "Partisan")  +
                              ct_forecast_uncertain_magnitude * (Condition == "Partisan") +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_likert_f1 <- linearHypothesis(ct_likert_mod1, 'ct_forecast_center + ct_forecast_center:Condition == "Partisan"TRUE  = 0',                                 
                                 test = c("F"))
ct_likert_f2 <- linearHypothesis(ct_likert_mod1, 'ct_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude = 0',
                                 test = c("F"))

tpp_likert_mod1 <- lm_robust(tpp_likert ~ tpp_forecast_center * (Condition == "Partisan")  +
                               tpp_forecast_uncertain_magnitude * (Condition == "Partisan") +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_likert_f1 <- linearHypothesis(tpp_likert_mod1, 'tpp_forecast_center + tpp_forecast_center:Condition == "Partisan"TRUE  = 0',
                                  test = c("F"))
tpp_likert_f2 <- linearHypothesis(tpp_likert_mod1, 'tpp_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:tpp_forecast_uncertain_magnitude = 0',
                                  test = c("F"))

#########################################################
## 3. IV analysis: Quantitative beliefs (Appendix F.4) ##
#########################################################


mw_likert_iv1 <- iv_robust(mw_likert ~ mw_quant|mw_forecast_center * (Condition == "Partisan") + 
                             mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se_type = "stata", data=dat, return_vcov = TRUE)

ct_likert_iv1 <- iv_robust(ct_likert ~ ct_quant|ct_forecast_center * (Condition == "Partisan") + 
                             ct_forecast_uncertain_magnitude * (Condition == "Partisan"), data=dat,
                           se_type = "stata")

tpp_likert_iv1 <- iv_robust(tpp_likert ~ tpp_quant|tpp_forecast_center * (Condition == "Partisan") + 
                              tpp_forecast_uncertain_magnitude * (Condition == "Partisan"), data=dat,
                            se_type = "stata")


#########################################################
## 4. IV analysis: Qualitative beliefs (Appendix F.4) ###
#########################################################

mw_likert_iv2 <- iv_robust(mw_likert ~ mw_qual_increase|mw_forecast_center * (Condition == "Partisan") + 
                             mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se_type = "stata", data=dat, return_vcov = TRUE)

ct_likert_iv2 <- iv_robust(ct_likert ~ ct_qual_increase|ct_forecast_center * (Condition == "Partisan") + 
                             ct_forecast_uncertain_magnitude * (Condition == "Partisan"), data=dat,
                           se_type = "stata")

tpp_likert_iv2 <- iv_robust(tpp_likert ~ tpp_qual_increase|tpp_forecast_center * (Condition == "Partisan") + 
                              tpp_forecast_uncertain_magnitude * (Condition == "Partisan"), data=dat,
                            se_type = "stata")

#################################################################################
## 5. Association between attitudes and idealistic preferences (Appendix F.2) ###
#################################################################################

mw_likert_ideal1 <- lm_robust(mw_likert ~ mw_ideal,
                              se_type = "stata", data=dat)

mw_likert_ideal2 <- lm_robust(mw_likert ~ mw_ideal  +
                                age +
                                age2 +
                                female +
                                educ_college_degree +
                                educ_no_highschool +
                                income_less50K +
                                income_100K150K +
                                income_150Kabove, se_type = "stata", data=dat)

ct_likert_ideal1 <- lm_robust(ct_likert ~ ct_ideal,
                              se_type = "stata", data=dat)

ct_likert_ideal2 <- lm_robust(ct_likert ~ ct_ideal  +
                                age +
                                age2 +
                                female +
                                educ_college_degree +
                                educ_no_highschool +
                                income_less50K +
                                income_100K150K +
                                income_150Kabove, se_type = "stata", data=dat)

tpp_likert_ideal1 <- lm_robust(tpp_likert ~ tpp_ideal,
                               se_type = "stata", data=dat)

tpp_likert_ideal2 <- lm_robust(tpp_likert ~ tpp_ideal  +
                                 age +
                                 age2 +
                                 female +
                                 educ_college_degree +
                                 educ_no_highschool +
                                 income_less50K +
                                 income_100K150K +
                                 income_150Kabove, se_type = "stata", data=dat)


#######################################################
## 6. Heterogeneity: Risk preferences (Appendix F.6) ##
#######################################################

# attitudes

mw_likert_rp1 <- lm_robust(mw_likert ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = dat,
                           se = "stata")

mw_likert_rp2 <- lm_robust(mw_likert ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")

mw_likert_rp3 <- lm_robust(mw_likert ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Partisan"),
                           se = "stata")

ct_likert_rp1 <- lm_robust(ct_likert ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = dat,
                           se = "stata")

ct_likert_rp2 <- lm_robust(ct_likert ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")

ct_likert_rp3 <- lm_robust(ct_likert ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Partisan"),
                           se = "stata")



tpp_likert_rp1 <- lm_robust(tpp_likert ~ tpp_forecast_center
                           + tpp_forecast_uncertain_magnitude
                           + riskpref
                           + tpp_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = dat,
                           se = "stata")

tpp_likert_rp2 <- lm_robust(tpp_likert ~ tpp_forecast_center
                           + tpp_forecast_uncertain_magnitude
                           + riskpref
                           + tpp_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")

tpp_likert_rp3 <- lm_robust(tpp_likert ~ tpp_forecast_center
                           + tpp_forecast_uncertain_magnitude
                           + riskpref
                           + tpp_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Partisan"),
                           se = "stata")


# beliefs


mw_quant_rp1 <- lm_robust(mw_quant ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = dat,
                           se = "stata")

mw_quant_rp2 <- lm_robust(mw_quant ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")

mw_quant_rp3 <- lm_robust(mw_quant ~ mw_forecast_center
                           + mw_forecast_uncertain_magnitude
                           + riskpref
                           + mw_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Partisan"),
                           se = "stata")

ct_quant_rp1 <- lm_robust(ct_quant ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = dat,
                           se = "stata")

ct_quant_rp2 <- lm_robust(ct_quant ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")

ct_quant_rp3 <- lm_robust(ct_quant ~ ct_forecast_center
                           + ct_forecast_uncertain_magnitude
                           + riskpref
                           + ct_forecast_uncertain_magnitude:riskpref
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Partisan"),
                           se = "stata")


tpp_quant_rp1 <- lm_robust(tpp_quant ~ tpp_forecast_center
                            + tpp_forecast_uncertain_magnitude
                            + riskpref
                            + tpp_forecast_uncertain_magnitude:riskpref
                            + age 
                            + female 
                            + educ_college_degree 
                            + educ_no_highschool 
                            + income_less50K 
                            + income_100K150K 
                            + income_150Kabove,
                            data = dat,
                            se = "stata")

tpp_quant_rp2 <- lm_robust(tpp_quant ~ tpp_forecast_center
                            + tpp_forecast_uncertain_magnitude
                            + riskpref
                            + tpp_forecast_uncertain_magnitude:riskpref
                            + age 
                            + female 
                            + educ_college_degree 
                            + educ_no_highschool 
                            + income_less50K 
                            + income_100K150K 
                            + income_150Kabove,
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")

tpp_quant_rp3 <- lm_robust(tpp_quant ~ tpp_forecast_center
                            + tpp_forecast_uncertain_magnitude
                            + riskpref
                            + tpp_forecast_uncertain_magnitude:riskpref
                            + age 
                            + female 
                            + educ_college_degree 
                            + educ_no_highschool 
                            + income_less50K 
                            + income_100K150K 
                            + income_150Kabove,
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")

###################################################################
## 7. Partisan Heterogeneity: MW, CT, EXPERT TPP  (Appendix F.7) ##
###################################################################

mw_quant_part <- lm_robust(mw_quant ~ mw_forecast_center * democrat * (Condition == "Partisan")
                              + mw_forecast_center * republican * (Condition == "Partisan")
                              + mw_forecast_uncertain_magnitude * democrat * (Condition == "Partisan")
                              + mw_forecast_uncertain_magnitude * republican * (Condition == "Partisan")
                              + age 
                              + female 
                              + educ_college_degree 
                              + educ_no_highschool 
                              + income_less50K 
                              + income_100K150K 
                              + income_150Kabove,
                              data = dat,
                              se = "stata")
mw_quant_part_f1 <- linearHypothesis(mw_quant_part, 'mw_forecast_center:democrat:Condition == "Partisan"TRUE  = mw_forecast_center:Condition == "Partisan"TRUE:republican', test = c("F"))
mw_quant_part_f2 <- linearHypothesis(mw_quant_part, 'mw_forecast_center:democrat  = mw_forecast_center:republican', test = c("F"))
mw_quant_part_f3 <- linearHypothesis(mw_quant_part, 'democrat:mw_forecast_uncertain_magnitude  = republican:mw_forecast_uncertain_magnitude', test = c("F"))
mw_quant_part_f4 <- linearHypothesis(mw_quant_part, 'democrat:Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude  = Condition == "Partisan"TRUE:republican:mw_forecast_uncertain_magnitude', test = c("F"))


mw_likert_part <- lm_robust(mw_likert ~ mw_forecast_center * democrat * (Condition == "Partisan")
                               + mw_forecast_center * republican * (Condition == "Partisan")
                               + mw_forecast_uncertain_magnitude * democrat * (Condition == "Partisan")
                               + mw_forecast_uncertain_magnitude * republican * (Condition == "Partisan")
                               + age 
                               + female 
                               + educ_college_degree 
                               + educ_no_highschool 
                               + income_less50K 
                               + income_100K150K 
                               + income_150Kabove,
                               data = dat,
                               se = "stata")
mw_likert_part_f1 <- linearHypothesis(mw_likert_part, 'mw_forecast_center:democrat:Condition == "Partisan"TRUE  = mw_forecast_center:Condition == "Partisan"TRUE:republican', test = c("F"))
mw_likert_part_f2 <- linearHypothesis(mw_likert_part, 'mw_forecast_center:democrat  = mw_forecast_center:republican', test = c("F"))
mw_likert_part_f3 <- linearHypothesis(mw_likert_part, 'democrat:mw_forecast_uncertain_magnitude  = republican:mw_forecast_uncertain_magnitude', test = c("F"))
mw_likert_part_f4 <- linearHypothesis(mw_likert_part, 'democrat:Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude  = Condition == "Partisan"TRUE:republican:mw_forecast_uncertain_magnitude', test = c("F"))

ct_quant_part <- lm_robust(ct_quant ~ ct_forecast_center * democrat * (Condition == "Partisan")
                              + ct_forecast_center * republican * (Condition == "Partisan")
                              + ct_forecast_uncertain_magnitude * democrat * (Condition == "Partisan")
                              + ct_forecast_uncertain_magnitude * republican * (Condition == "Partisan")
                              + age 
                              + female 
                              + educ_college_degree 
                              + educ_no_highschool 
                              + income_less50K 
                              + income_100K150K 
                              + income_150Kabove,
                              data = dat,
                              se = "stata")
ct_quant_part_f1 <- linearHypothesis(ct_quant_part, 'ct_forecast_center:democrat:Condition == "Partisan"TRUE  = ct_forecast_center:Condition == "Partisan"TRUE:republican', test = c("F"))
ct_quant_part_f2 <- linearHypothesis(ct_quant_part, 'ct_forecast_center:democrat  = ct_forecast_center:republican', test = c("F"))
ct_quant_part_f3 <- linearHypothesis(ct_quant_part, 'democrat:ct_forecast_uncertain_magnitude  = republican:ct_forecast_uncertain_magnitude', test = c("F"))
ct_quant_part_f4 <- linearHypothesis(ct_quant_part, 'democrat:Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude  = Condition == "Partisan"TRUE:republican:ct_forecast_uncertain_magnitude', test = c("F"))


ct_likert_part <- lm_robust(ct_likert ~ ct_forecast_center * democrat * (Condition == "Partisan")
                              + ct_forecast_center * republican * (Condition == "Partisan")
                              + ct_forecast_uncertain_magnitude * democrat * (Condition == "Partisan")
                              + ct_forecast_uncertain_magnitude * republican * (Condition == "Partisan")
                              + age 
                              + female 
                              + educ_college_degree 
                              + educ_no_highschool 
                              + income_less50K 
                              + income_100K150K 
                              + income_150Kabove,
                              data = dat,
                              se = "stata")
ct_likert_part_f1 <- linearHypothesis(ct_likert_part, 'ct_forecast_center:democrat:Condition == "Partisan"TRUE  = ct_forecast_center:Condition == "Partisan"TRUE:republican', test = c("F"))
ct_likert_part_f2 <- linearHypothesis(ct_likert_part, 'ct_forecast_center:democrat  = ct_forecast_center:republican', test = c("F"))
ct_likert_part_f3 <- linearHypothesis(ct_likert_part, 'democrat:ct_forecast_uncertain_magnitude  = republican:ct_forecast_uncertain_magnitude', test = c("F"))
ct_likert_part_f4 <- linearHypothesis(ct_likert_part, 'democrat:Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude  = Condition == "Partisan"TRUE:republican:ct_forecast_uncertain_magnitude', test = c("F"))

tpp_quant_part <- lm_robust(tpp_quant ~ tpp_forecast_center * democrat
                           + tpp_forecast_center * republican
                           + tpp_forecast_uncertain_magnitude * democrat
                           + tpp_forecast_uncertain_magnitude * republican
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")
tpp_quant_part_f1 <- linearHypothesis(tpp_quant_part, 'tpp_forecast_center:democrat = tpp_forecast_center:republican', test = c("F"))
tpp_quant_part_f3 <- linearHypothesis(tpp_quant_part, 'democrat:tpp_forecast_uncertain_magnitude = republican:tpp_forecast_uncertain_magnitude', test = c("F"))

tpp_likert_part <- lm_robust(tpp_likert ~ tpp_forecast_center * democrat
                            + tpp_forecast_center * republican
                            + tpp_forecast_uncertain_magnitude * democrat
                            + tpp_forecast_uncertain_magnitude * republican
                            + age 
                            + female 
                            + educ_college_degree 
                            + educ_no_highschool 
                            + income_less50K 
                            + income_100K150K 
                            + income_150Kabove,
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
tpp_likert_part_f1 <- linearHypothesis(tpp_quant_part, 'tpp_forecast_center:democrat = tpp_forecast_center:republican', test = c("F"))
tpp_likert_part_f3 <- linearHypothesis(tpp_quant_part, 'democrat:tpp_forecast_uncertain_magnitude = republican:tpp_forecast_uncertain_magnitude', test = c("F"))

tpp_quant_exp <- lm_robust(tpp_quant ~ tpp_forecast_center
                           + democrat
                           + republican
                           + tpp_forecast_uncertain_magnitude
                           + tpp_forecast_center:democrat
                           + tpp_forecast_center:republican
                           + tpp_forecast_uncertain_magnitude:democrat
                           + tpp_forecast_uncertain_magnitude:republican
                           + age 
                           + female 
                           + educ_college_degree 
                           + educ_no_highschool 
                           + income_less50K 
                           + income_100K150K 
                           + income_150Kabove,
                           data = subset(dat, Condition == "Expert"),
                           se = "stata")
tpp_quant_exphet_f1 <- linearHypothesis(tpp_quant_exp, 'tpp_forecast_center:democrat = tpp_forecast_center:republican', test = c("F"))
tpp_quant_exphet_f2 <- linearHypothesis(tpp_quant_exp,  'democrat:tpp_forecast_uncertain_magnitude = republican:tpp_forecast_uncertain_magnitude', test = c("F"))

tpp_likert_exp <- lm_robust(tpp_likert ~ tpp_forecast_center
                            + democrat
                            + republican
                            + tpp_forecast_uncertain_magnitude
                            + tpp_forecast_center:democrat
                            + tpp_forecast_center:republican
                            + tpp_forecast_uncertain_magnitude:democrat
                            + tpp_forecast_uncertain_magnitude:republican
                            + age 
                            + female 
                            + educ_college_degree 
                            + educ_no_highschool 
                            + income_less50K 
                            + income_100K150K 
                            + income_150Kabove,
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
tpp_likert_exphet_f1 <- linearHypothesis(tpp_likert_exp, 'tpp_forecast_center:democrat = tpp_forecast_center:republican', test = c("F"))
tpp_likert_exphet_f2 <- linearHypothesis(tpp_likert_exp, 'democrat:tpp_forecast_uncertain_magnitude = republican:tpp_forecast_uncertain_magnitude', test = c("F"))

##############################################################
## 8. Heterogeneity: Partisan TPP  (Figure 3, Appendix F.7) ##
##############################################################

tpp_quant_part <- lm_robust(tpp_quant ~ tpp_forecast_center 
                                + democrat
                                + republican
                                + tpp_forecast_uncertain_magnitude
                                + tpp_rep_high
                                + tpp_forecast_center:democrat
                                + tpp_forecast_center:republican
                                + tpp_forecast_uncertain_magnitude:democrat
                                + tpp_forecast_uncertain_magnitude:democrat:tpp_rep_high
                                + tpp_forecast_uncertain_magnitude:republican
                                + tpp_forecast_uncertain_magnitude:republican:tpp_rep_high
                                + age 
                                + female 
                                + educ_college_degree 
                                + educ_no_highschool 
                                + income_less50K 
                                + income_100K150K 
                                + income_150Kabove,
                                data = subset(dat, Condition == "Partisan"),
                                se = "stata")

tpp_likert_part <- lm_robust(tpp_likert ~ tpp_forecast_center 
                                + democrat
                                + republican
                                + tpp_forecast_uncertain_magnitude
                                + tpp_rep_high
                                + tpp_forecast_center:democrat
                                + tpp_forecast_center:republican
                                + tpp_forecast_uncertain_magnitude:democrat
                                + tpp_forecast_uncertain_magnitude:democrat:tpp_rep_high
                                + tpp_forecast_uncertain_magnitude:republican
                                + tpp_forecast_uncertain_magnitude:republican:tpp_rep_high
                                + age 
                                + female 
                                + educ_college_degree 
                                + educ_no_highschool 
                                + income_less50K 
                                + income_100K150K 
                                + income_150Kabove,
                                data = subset(dat, Condition == "Partisan"),
                                se = "stata")


#######################################################
## 9. Drop single forecast treaments (Appendix F.13) ##
#######################################################

mw_quant_uncert <- lm_robust(mw_quant ~ mw_forecast_center * (Condition == "Partisan") 
                           +  mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = subset(dat, mw_forecast_uncertain_magnitude > 0))

mw_likert_uncert <- lm_robust(mw_likert ~ mw_forecast_center * (Condition == "Partisan") 
                           +  mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = subset(dat, mw_forecast_uncertain_magnitude > 0))

ct_quant_uncert <- lm_robust(ct_quant ~ ct_forecast_center * (Condition == "Partisan") 
                             +  ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                             se = "stata",
                             data = subset(dat, ct_forecast_uncertain_magnitude > 0))

ct_likert_uncert <- lm_robust(ct_likert ~ ct_forecast_center * (Condition == "Partisan") 
                              +  ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                              se = "stata",
                              data = subset(dat, ct_forecast_uncertain_magnitude > 0))

tpp_quant_uncert <- lm_robust(tpp_quant ~ tpp_forecast_center * (Condition == "Partisan") 
                             +  tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                             se = "stata",
                             data = subset(dat, tpp_forecast_uncertain_magnitude > 0))

tpp_likert_uncert <- lm_robust(tpp_likert ~ tpp_forecast_center * (Condition == "Partisan") 
                              +  tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                              se = "stata",
                              data = subset(dat, tpp_forecast_uncertain_magnitude > 0))


#######################################################
## 10. Difference-of-means estimator (Appendix F.10) ##
#######################################################

mw_likert_dom <- lm_robust(mw_likert ~ mw_forecast_inc 
                           + mw_forecast_uncertain
                           + (Condition == "Partisan")
                           + mw_forecast_inc:(Condition == "Partisan")
                           + mw_forecast_uncertain:(Condition == "Partisan"),
                           se = "stata",
                           data = dat)

mw_quant_dom <- lm_robust(mw_quant ~ mw_forecast_inc 
                          + mw_forecast_uncertain
                          + (Condition == "Partisan")
                          + mw_forecast_inc:(Condition == "Partisan")
                          + mw_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)

mw_ideal_dom <- lm_robust(mw_ideal ~ mw_forecast_inc 
                          + mw_forecast_uncertain
                          + (Condition == "Partisan")
                          + mw_forecast_inc:(Condition == "Partisan")
                          + mw_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)

ct_likert_dom <- lm_robust(ct_likert ~ ct_forecast_inc 
                           + ct_forecast_uncertain
                           + (Condition == "Partisan")
                           + ct_forecast_inc:(Condition == "Partisan")
                           + ct_forecast_uncertain:(Condition == "Partisan"),
                           se = "stata",
                           data = dat)

ct_quant_dom <- lm_robust(ct_quant ~ ct_forecast_inc 
                          + ct_forecast_uncertain
                          + (Condition == "Partisan")
                          + ct_forecast_inc:(Condition == "Partisan")
                          + ct_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)

ct_ideal_dom <- lm_robust(ct_ideal ~ ct_forecast_inc 
                          + ct_forecast_uncertain
                          + (Condition == "Partisan")
                          + ct_forecast_inc:(Condition == "Partisan")
                          + ct_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)

tpp_likert_dom <- lm_robust(tpp_likert ~ tpp_forecast_inc 
                           + tpp_forecast_uncertain
                           + (Condition == "Partisan")
                           + tpp_forecast_inc:(Condition == "Partisan")
                           + tpp_forecast_uncertain:(Condition == "Partisan"),
                           se = "stata",
                           data = dat)

tpp_quant_dom <- lm_robust(tpp_quant ~ tpp_forecast_inc 
                          + tpp_forecast_uncertain
                          + (Condition == "Partisan")
                          + tpp_forecast_inc:(Condition == "Partisan")
                          + tpp_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)

tpp_ideal_dom <- lm_robust(tpp_ideal ~ tpp_forecast_inc 
                          + tpp_forecast_uncertain
                          + (Condition == "Partisan")
                          + tpp_forecast_inc:(Condition == "Partisan")
                          + tpp_forecast_uncertain:(Condition == "Partisan"),
                          se = "stata",
                          data = dat)


#########################################
## 11. Ordered probit  (Appendix F.12) ##
#########################################

mw_ideal_oprob <- polr(factor(mw_ideal) ~ mw_forecast_center 
                        + mw_forecast_uncertain_magnitude
                       + (Condition == "Partisan")
                        + mw_forecast_center : (Condition == "Partisan")
                       + mw_forecast_uncertain_magnitude : (Condition == "Partisan"),
                        data = dat, method = c("probit"), Hess = TRUE)

mw_likert_oprob <- polr(factor(mw_likert) ~  mw_forecast_center 
                        + mw_forecast_uncertain_magnitude
                        + (Condition == "Partisan")
                        + mw_forecast_center : (Condition == "Partisan")
                        + mw_forecast_uncertain_magnitude : (Condition == "Partisan"),
                        data = dat, method = c("probit"), Hess = TRUE)

ct_ideal_oprob <- polr(factor(ct_ideal) ~  ct_forecast_center 
                       + ct_forecast_uncertain_magnitude
                       + (Condition == "Partisan")
                       + ct_forecast_center : (Condition == "Partisan")
                       + ct_forecast_uncertain_magnitude : (Condition == "Partisan"),
                       data = dat, method = c("probit"), Hess = TRUE)

ct_likert_oprob <- polr(factor(ct_likert) ~  ct_forecast_center 
                        + ct_forecast_uncertain_magnitude
                        + (Condition == "Partisan")
                        + ct_forecast_center : (Condition == "Partisan")
                        + ct_forecast_uncertain_magnitude : (Condition == "Partisan"),
                        data = dat, method = c("probit"), Hess = TRUE)

tpp_ideal_oprob <- polr(factor(tpp_ideal) ~  tpp_forecast_center 
                        + tpp_forecast_uncertain_magnitude
                        + (Condition == "Partisan")
                        + tpp_forecast_center : (Condition == "Partisan")
                        + tpp_forecast_uncertain_magnitude : (Condition == "Partisan"),
                       data = dat, method = c("probit"), Hess = TRUE)

tpp_likert_oprob <- polr(factor(tpp_likert) ~  tpp_forecast_center 
                         + tpp_forecast_uncertain_magnitude
                         + (Condition == "Partisan")
                         + tpp_forecast_center : (Condition == "Partisan")
                         + tpp_forecast_uncertain_magnitude : (Condition == "Partisan"),
                        data = dat, method = c("probit"), Hess = TRUE)


########################################################
## 12. Outcomes in loss or gain domain (Appendix F.9) ##
########################################################

ct_quant_gl <- lm_robust(ct_quant ~ ct_forecast_increase + ct_forecast_decrease + ct_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

ct_likert_gl <- lm_robust(ct_likert ~ ct_forecast_increase + ct_forecast_decrease + ct_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

tpp_quant_gl <- lm_robust(tpp_quant ~ tpp_forecast_increase + tpp_forecast_decrease + tpp_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

tpp_likert_gl <- lm_robust(tpp_likert ~ tpp_forecast_increase + tpp_forecast_decrease + tpp_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

## note that for MW reform, the gain domain implies a forecast decrease, since the outcome variable is unemployment
mw_quant_gl <- lm_robust(mw_quant ~  mw_forecast_decrease + mw_forecast_increase + mw_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

mw_likert_gl <- lm_robust(mw_likert ~ mw_forecast_decrease + mw_forecast_increase + mw_forecast_uncertain + (Condition == "Partisan"),
          se = "stata",
          data = dat)

############################################################
## 13. Strength of priors in control group (Appendix F.3) ##
############################################################

dat_prior <- dat
dat_prior$mw_cert[dat_prior$Condition == "Control"] <- dat_prior$mw_cert_c[dat_prior$Condition == "Control"]
dat_prior$ct_cert[dat_prior$Condition == "Control"] <- dat_prior$ct_cert_c[dat_prior$Condition == "Control"]
dat_prior$tpp_cert[dat_prior$Condition == "Control"] <- dat_prior$tpp_cert_c[dat_prior$Condition == "Control"]
dat_prior <- subset(dat_prior, Condition == "Control")
dat_prior$id <- 1:nrow(dat_prior)
dat_prior <- dat_prior[, c("mw_cert", "ct_cert", "tpp_cert")]
names(dat_prior) <- c("cert_mw", "cert_ct", "cert_tpp")

dat_prior <- reshape(dat_prior, varying = 1:3, sep = "_", direction = "long", timevar = "policy", idvar = "id")
dat_prior$policy <- factor(dat_prior$policy, levels = c("mw", "ct", "tpp"))

cert_mod <- lm_robust(cert ~ factor(policy),
                       se = "stata",
                       clusters = id,
                       data = dat_prior)

#############################################
## 14. Qualitative beliefs (Appendix F.11) ##
#############################################

## Minimum wage
mw_qual_mod1 <- lm_robust(mw_qual_increase ~ mw_forecast_center * (Condition == "Partisan") + 
                            mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = dat)
mw_qual_f1 <- linearHypothesis(mw_qual_mod1, 'mw_forecast_center + mw_forecast_center:Condition == "Partisan"TRUE = 0',
                               test = c("F"))

mw_qual_f2 <- linearHypothesis(mw_qual_mod1, 'mw_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude = 0',
                               test = c("F"))


## Corporate tax
ct_qual_mod1 <- lm_robust(ct_qual_increase ~ ct_forecast_center * (Condition == "Partisan") + 
                            ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = dat)
ct_qual_f1 <- linearHypothesis(ct_qual_mod1, 'ct_forecast_center + ct_forecast_center:Condition == "Partisan"TRUE = 0',
                               test = c("F"))

ct_qual_f2 <- linearHypothesis(ct_qual_mod1, 'ct_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude = 0',
                               test = c("F"))

## Trans-pacific partnership
tpp_qual_mod1 <- lm_robust(tpp_qual_increase ~ tpp_forecast_center * (Condition == "Partisan") + 
                             tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = dat)

tpp_qual_f1 <- linearHypothesis(tpp_qual_mod1, 'tpp_forecast_center + tpp_forecast_center:Condition == "Partisan"TRUE = 0',
                                test = c("F"))

tpp_qual_f2 <- linearHypothesis(tpp_qual_mod1, 'tpp_forecast_uncertain_magnitude + Condition == "Partisan"TRUE:tpp_forecast_uncertain_magnitude = 0',
                                test = c("F"))


###################################################################
## 15. Alternative uncertainty operationalization (Appendix F.8) ##
####################################################################

# SUPPORT

#### simple interaction
ct_robint_mod2 <- lm_robust(ct_likert ~ ct_forecast_center*ct_forecast_uncertain_magnitude +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_mod2_f <- linearHypothesis(ct_robint_mod2, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

ct_robint_mod3 <- lm_robust(ct_likert ~ ct_forecast_center*ct_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_mod3_f <- linearHypothesis(ct_robint_mod3, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

ct_robint_mod4 <- lm_robust(ct_likert ~ ct_forecast_center*ct_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
ct_robint_mod4_f <- linearHypothesis(ct_robint_mod4, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

#### interaction: loss domain
ct_robint_mod5 <- lm_robust(ct_likert ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain) +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_mod5_f <- linearHypothesis(ct_robint_mod5, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))

ct_robint_mod6 <- lm_robust(ct_likert ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain), 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_mod6_f <- linearHypothesis(ct_robint_mod6, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))

ct_robint_mod7 <- lm_robust(ct_likert ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain), 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
ct_robint_mod7_f <- linearHypothesis(ct_robint_mod7, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))


## interaction: includes zero
ct_robint_mod8 <- lm_robust(ct_likert ~ ct_forecast_center  +
                              ct_forecast_uncertain_magnitude +
                              ct_spread_0:ct_forecast_uncertain_magnitude +
                              ct_spread_0 +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_mod8_f <- linearHypothesis(ct_robint_mod8, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                     test = c("F"))

ct_robint_mod9 <- lm_robust(ct_likert ~ ct_forecast_center  +
                              ct_forecast_uncertain_magnitude +
                              ct_spread_0:ct_forecast_uncertain_magnitude +
                              ct_spread_0, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_mod9_f <- linearHypothesis(ct_robint_mod9, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                     test = c("F"))

ct_robint_mod10 <- lm_robust(ct_likert ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_spread_0:ct_forecast_uncertain_magnitude +
                               ct_spread_0, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
ct_robint_mod10_f <- linearHypothesis(ct_robint_mod10, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                      test = c("F"))

## interaction: forecast crossing

ct_robint_mod11 <- lm_robust(ct_likert ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
ct_robint_mod11_f <- linearHypothesis(ct_robint_mod11, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

ct_robint_mod12 <- lm_robust(ct_likert ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
ct_robint_mod12_f <- linearHypothesis(ct_robint_mod12, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

ct_robint_mod13 <- lm_robust(ct_likert ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
ct_robint_mod13_f <- linearHypothesis(ct_robint_mod13, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

#### simple interaction
tpp_robint_mod2 <- lm_robust(tpp_likert ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_mod2_f <- linearHypothesis(tpp_robint_mod2, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

tpp_robint_mod3 <- lm_robust(tpp_likert ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_mod3_f <- linearHypothesis(tpp_robint_mod3, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

tpp_robint_mod4 <- lm_robust(tpp_likert ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
tpp_robint_mod4_f <- linearHypothesis(tpp_robint_mod4, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

#### interaction: loss domain
tpp_robint_mod5 <- lm_robust(tpp_likert ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain) +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_mod5_f <- linearHypothesis(tpp_robint_mod5, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))

tpp_robint_mod6 <- lm_robust(tpp_likert ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain), 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_mod6_f <- linearHypothesis(tpp_robint_mod6, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))

tpp_robint_mod7 <- lm_robust(tpp_likert ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain), 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
tpp_robint_mod7_f <- linearHypothesis(tpp_robint_mod7, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))


## interaction: includes zero
tpp_robint_mod8 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                               tpp_forecast_uncertain_magnitude +
                               tpp_spread_0:tpp_forecast_uncertain_magnitude +
                               tpp_spread_0 +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_mod8_f <- linearHypothesis(tpp_robint_mod8, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                      test = c("F"))

tpp_robint_mod9 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                               tpp_forecast_uncertain_magnitude +
                               tpp_spread_0:tpp_forecast_uncertain_magnitude +
                               tpp_spread_0, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_mod9_f <- linearHypothesis(tpp_robint_mod9, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                      test = c("F"))

tpp_robint_mod10 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_spread_0:tpp_forecast_uncertain_magnitude +
                                tpp_spread_0, 
                              data = subset(dat, Condition == "Partisan"),
                              se = "stata")
tpp_robint_mod10_f <- linearHypothesis(tpp_robint_mod10, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                       test = c("F"))

## interaction: forecast crossing

tpp_robint_mod11 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing +
                                (Condition == "Partisan"), 
                              data = dat,
                              se = "stata")
tpp_robint_mod11_f <- linearHypothesis(tpp_robint_mod11, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

tpp_robint_mod12 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing, 
                              data = subset(dat, Condition == "Expert"),
                              se = "stata")
tpp_robint_mod12_f <- linearHypothesis(tpp_robint_mod12, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

tpp_robint_mod13 <- lm_robust(tpp_likert ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing, 
                              data = subset(dat, Condition == "Partisan"),
                              se = "stata")
tpp_robint_mod13_f <- linearHypothesis(tpp_robint_mod13, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

#### simple interaction
mw_robint_mod2 <- lm_robust(mw_likert ~ mw_forecast_center*mw_forecast_uncertain_magnitude +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_mod2_f <- linearHypothesis(mw_robint_mod2, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

mw_robint_mod3 <- lm_robust(mw_likert ~ mw_forecast_center*mw_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_mod3_f <- linearHypothesis(mw_robint_mod3, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

mw_robint_mod4 <- lm_robust(mw_likert ~ mw_forecast_center*mw_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
mw_robint_mod4_f <- linearHypothesis(mw_robint_mod4, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

#### interaction: loss domain
mw_robint_mod5 <- lm_robust(mw_likert ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain) +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_mod5_f <- linearHypothesis(mw_robint_mod5, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))

mw_robint_mod6 <- lm_robust(mw_likert ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain), 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_mod6_f <- linearHypothesis(mw_robint_mod6, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))

mw_robint_mod7 <- lm_robust(mw_likert ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain), 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
mw_robint_mod7_f <- linearHypothesis(mw_robint_mod7, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))


## interaction: includes zero
mw_robint_mod8 <- lm_robust(mw_likert ~ mw_forecast_center  +
                              mw_forecast_uncertain_magnitude +
                              mw_spread_0:mw_forecast_uncertain_magnitude +
                              mw_spread_0 +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_mod8_f <- linearHypothesis(mw_robint_mod8, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                     test = c("F"))

mw_robint_mod9 <- lm_robust(mw_likert ~ mw_forecast_center  +
                              mw_forecast_uncertain_magnitude +
                              mw_spread_0:mw_forecast_uncertain_magnitude +
                              mw_spread_0, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_mod9_f <- linearHypothesis(mw_robint_mod9, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                     test = c("F"))

mw_robint_mod10 <- lm_robust(mw_likert ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_spread_0:mw_forecast_uncertain_magnitude +
                               mw_spread_0, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
mw_robint_mod10_f <- linearHypothesis(mw_robint_mod10, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                      test = c("F"))

## interaction: forecast crossing

mw_robint_mod11 <- lm_robust(mw_likert ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
mw_robint_mod11_f <- linearHypothesis(mw_robint_mod11, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))

mw_robint_mod12 <- lm_robust(mw_likert ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
mw_robint_mod12_f <- linearHypothesis(mw_robint_mod12, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))

mw_robint_mod13 <- lm_robust(mw_likert ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
mw_robint_mod13_f <- linearHypothesis(mw_robint_mod13, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))


## Beliefs

#### simple interaction
ct_robint_q_mod2 <- lm_robust(ct_quant ~ ct_forecast_center*ct_forecast_uncertain_magnitude +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_q_mod2_f <- linearHypothesis(ct_robint_q_mod2, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

ct_robint_q_mod3 <- lm_robust(ct_quant ~ ct_forecast_center*ct_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_q_mod3_f <- linearHypothesis(ct_robint_q_mod3, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

ct_robint_q_mod4 <- lm_robust(ct_quant ~ ct_forecast_center*ct_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
ct_robint_q_mod4_f <- linearHypothesis(ct_robint_q_mod4, 'ct_forecast_uncertain_magnitude + ct_forecast_center:ct_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

#### interaction: loss domain
ct_robint_q_mod5 <- lm_robust(ct_quant ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain) +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_q_mod5_f <- linearHypothesis(ct_robint_q_mod5, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))

ct_robint_q_mod6 <- lm_robust(ct_quant ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain), 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_q_mod6_f <- linearHypothesis(ct_robint_q_mod6, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))

ct_robint_q_mod7 <- lm_robust(ct_quant ~ ct_forecast_center + 
                              ct_forecast_uncertain_magnitude +
                              (ct_loss_domain) +
                              ct_forecast_uncertain_magnitude:(ct_loss_domain), 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
ct_robint_q_mod7_f <- linearHypothesis(ct_robint_q_mod7, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_loss_domain = 0', 
                                     test = c("F"))


## interaction: includes zero
ct_robint_q_mod8 <- lm_robust(ct_quant ~ ct_forecast_center  +
                              ct_forecast_uncertain_magnitude +
                              ct_spread_0:ct_forecast_uncertain_magnitude +
                              ct_spread_0 +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
ct_robint_q_mod8_f <- linearHypothesis(ct_robint_q_mod8, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                     test = c("F"))

ct_robint_q_mod9 <- lm_robust(ct_quant ~ ct_forecast_center  +
                              ct_forecast_uncertain_magnitude +
                              ct_spread_0:ct_forecast_uncertain_magnitude +
                              ct_spread_0, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
ct_robint_q_mod9_f <- linearHypothesis(ct_robint_q_mod9, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                     test = c("F"))

ct_robint_q_mod10 <- lm_robust(ct_quant ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_spread_0:ct_forecast_uncertain_magnitude +
                               ct_spread_0, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
ct_robint_q_mod10_f <- linearHypothesis(ct_robint_q_mod10, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_spread_0 = 0', 
                                      test = c("F"))

## interaction: forecast crossing

ct_robint_q_mod11 <- lm_robust(ct_quant ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
ct_robint_q_mod11_f <- linearHypothesis(ct_robint_q_mod11, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

ct_robint_q_mod12 <- lm_robust(ct_quant ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
ct_robint_q_mod12_f <- linearHypothesis(ct_robint_q_mod12, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

ct_robint_q_mod13 <- lm_robust(ct_quant ~ ct_forecast_center  +
                               ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing:ct_forecast_uncertain_magnitude +
                               ct_forecast_crossing, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
ct_robint_q_mod13_f <- linearHypothesis(ct_robint_q_mod13, 'ct_forecast_uncertain_magnitude + ct_forecast_uncertain_magnitude:ct_forecast_crossing = 0', 
                                      test = c("F"))

#### simple interaction
tpp_robint_q_mod2 <- lm_robust(tpp_quant ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_q_mod2_f <- linearHypothesis(tpp_robint_q_mod2, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

tpp_robint_q_mod3 <- lm_robust(tpp_quant ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_q_mod3_f <- linearHypothesis(tpp_robint_q_mod3, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

tpp_robint_q_mod4 <- lm_robust(tpp_quant ~ tpp_forecast_center*tpp_forecast_uncertain_magnitude, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
tpp_robint_q_mod4_f <- linearHypothesis(tpp_robint_q_mod4, 'tpp_forecast_uncertain_magnitude + tpp_forecast_center:tpp_forecast_uncertain_magnitude = 0', 
                                      test = c("F"))

#### interaction: loss domain
tpp_robint_q_mod5 <- lm_robust(tpp_quant ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain) +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_q_mod5_f <- linearHypothesis(tpp_robint_q_mod5, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))

tpp_robint_q_mod6 <- lm_robust(tpp_quant ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain), 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_q_mod6_f <- linearHypothesis(tpp_robint_q_mod6, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))

tpp_robint_q_mod7 <- lm_robust(tpp_quant ~ tpp_forecast_center + 
                               tpp_forecast_uncertain_magnitude +
                               (tpp_loss_domain) +
                               tpp_forecast_uncertain_magnitude:(tpp_loss_domain), 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
tpp_robint_q_mod7_f <- linearHypothesis(tpp_robint_q_mod7, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_loss_domain = 0', 
                                      test = c("F"))


## interaction: includes zero
tpp_robint_q_mod8 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                               tpp_forecast_uncertain_magnitude +
                               tpp_spread_0:tpp_forecast_uncertain_magnitude +
                               tpp_spread_0 +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
tpp_robint_q_mod8_f <- linearHypothesis(tpp_robint_q_mod8, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                      test = c("F"))

tpp_robint_q_mod9 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                               tpp_forecast_uncertain_magnitude +
                               tpp_spread_0:tpp_forecast_uncertain_magnitude +
                               tpp_spread_0, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
tpp_robint_q_mod9_f <- linearHypothesis(tpp_robint_q_mod9, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                      test = c("F"))

tpp_robint_q_mod10 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_spread_0:tpp_forecast_uncertain_magnitude +
                                tpp_spread_0, 
                              data = subset(dat, Condition == "Partisan"),
                              se = "stata")
tpp_robint_q_mod10_f <- linearHypothesis(tpp_robint_q_mod10, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_spread_0 = 0', 
                                       test = c("F"))

## interaction: forecast crossing

tpp_robint_q_mod11 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing +
                                (Condition == "Partisan"), 
                              data = dat,
                              se = "stata")
tpp_robint_q_mod11_f <- linearHypothesis(tpp_robint_q_mod11, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

tpp_robint_q_mod12 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing, 
                              data = subset(dat, Condition == "Expert"),
                              se = "stata")
tpp_robint_q_mod12_f <- linearHypothesis(tpp_robint_q_mod12, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

tpp_robint_q_mod13 <- lm_robust(tpp_quant ~ tpp_forecast_center  +
                                tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing:tpp_forecast_uncertain_magnitude +
                                tpp_forecast_crossing, 
                              data = subset(dat, Condition == "Partisan"),
                              se = "stata")
tpp_robint_q_mod13_f <- linearHypothesis(tpp_robint_q_mod13, 'tpp_forecast_uncertain_magnitude + tpp_forecast_uncertain_magnitude:tpp_forecast_crossing = 0', 
                                       test = c("F"))

#### simple interaction
mw_robint_q_mod2 <- lm_robust(mw_quant ~ mw_forecast_center*mw_forecast_uncertain_magnitude +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_q_mod2_f <- linearHypothesis(mw_robint_q_mod2, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

mw_robint_q_mod3 <- lm_robust(mw_quant ~ mw_forecast_center*mw_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_q_mod3_f <- linearHypothesis(mw_robint_q_mod3, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

mw_robint_q_mod4 <- lm_robust(mw_quant ~ mw_forecast_center*mw_forecast_uncertain_magnitude, 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
mw_robint_q_mod4_f <- linearHypothesis(mw_robint_q_mod4, 'mw_forecast_uncertain_magnitude + mw_forecast_center:mw_forecast_uncertain_magnitude = 0', 
                                     test = c("F"))

#### interaction: loss domain
mw_robint_q_mod5 <- lm_robust(mw_quant ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain) +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_q_mod5_f <- linearHypothesis(mw_robint_q_mod5, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))

mw_robint_q_mod6 <- lm_robust(mw_quant ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain), 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_q_mod6_f <- linearHypothesis(mw_robint_q_mod6, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))

mw_robint_q_mod7 <- lm_robust(mw_quant ~ mw_forecast_center + 
                              mw_forecast_uncertain_magnitude +
                              (mw_loss_domain) +
                              mw_forecast_uncertain_magnitude:(mw_loss_domain), 
                            data = subset(dat, Condition == "Partisan"),
                            se = "stata")
mw_robint_q_mod7_f <- linearHypothesis(mw_robint_q_mod7, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_loss_domain = 0', 
                                     test = c("F"))


## interaction: includes zero
mw_robint_q_mod8 <- lm_robust(mw_quant ~ mw_forecast_center  +
                              mw_forecast_uncertain_magnitude +
                              mw_spread_0:mw_forecast_uncertain_magnitude +
                              mw_spread_0 +
                              (Condition == "Partisan"), 
                            data = dat,
                            se = "stata")
mw_robint_q_mod8_f <- linearHypothesis(mw_robint_q_mod8, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                     test = c("F"))

mw_robint_q_mod9 <- lm_robust(mw_quant ~ mw_forecast_center  +
                              mw_forecast_uncertain_magnitude +
                              mw_spread_0:mw_forecast_uncertain_magnitude +
                              mw_spread_0, 
                            data = subset(dat, Condition == "Expert"),
                            se = "stata")
mw_robint_q_mod9_f <- linearHypothesis(mw_robint_q_mod9, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                     test = c("F"))

mw_robint_q_mod10 <- lm_robust(mw_quant ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_spread_0:mw_forecast_uncertain_magnitude +
                               mw_spread_0, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
mw_robint_q_mod10_f <- linearHypothesis(mw_robint_q_mod10, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_spread_0 = 0', 
                                      test = c("F"))

## interaction: forecast crossing

mw_robint_q_mod11 <- lm_robust(mw_quant ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing +
                               (Condition == "Partisan"), 
                             data = dat,
                             se = "stata")
mw_robint_q_mod11_f <- linearHypothesis(mw_robint_q_mod11, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))

mw_robint_q_mod12 <- lm_robust(mw_quant ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing, 
                             data = subset(dat, Condition == "Expert"),
                             se = "stata")
mw_robint_q_mod12_f <- linearHypothesis(mw_robint_q_mod12, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))

mw_robint_q_mod13 <- lm_robust(mw_quant ~ mw_forecast_center  +
                               mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing:mw_forecast_uncertain_magnitude +
                               mw_forecast_crossing, 
                             data = subset(dat, Condition == "Partisan"),
                             se = "stata")
mw_robint_q_mod13_f <- linearHypothesis(mw_robint_q_mod13, 'mw_forecast_uncertain_magnitude + mw_forecast_uncertain_magnitude:mw_forecast_crossing = 0', 
                                      test = c("F"))

############################################
## 16. Numerical literacy (Appendix F.14) ##
############################################

mw_quant_nl1 <- lm_robust(mw_quant ~ mw_forecast_center * (Condition == "Partisan") + 
                             mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                           se = "stata",
                           data = subset(dat, mw_forecast_center > 0))

mw_quant_nl2 <- lm_robust(mw_quant ~ mw_forecast_center * (Condition == "Partisan") + 
                            mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = subset(dat, mw_forecast_center < 0))

ct_quant_nl1 <- lm_robust(ct_quant ~ ct_forecast_center * (Condition == "Partisan") + 
                            ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = subset(dat, ct_forecast_center > 0))

ct_quant_nl2 <- lm_robust(ct_quant ~ ct_forecast_center * (Condition == "Partisan") + 
                            ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = subset(dat, ct_forecast_center < 0))

tpp_quant_nl1 <- lm_robust(tpp_quant ~ tpp_forecast_center * (Condition == "Partisan") + 
                            tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = subset(dat, tpp_forecast_center > 0))

tpp_quant_nl2 <- lm_robust(tpp_quant ~ tpp_forecast_center * (Condition == "Partisan") + 
                            tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = subset(dat, tpp_forecast_center < 0))


###########################################
## 17. Belief Uncertainty (Appendix F.5) ##
###########################################


mw_mod_cert1 <- lm_robust(mw_cert ~ mw_forecast_center * (Condition == "Partisan") + 
                            mw_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = dat)

ct_mod_cert1 <- lm_robust(ct_cert ~ ct_forecast_center * (Condition == "Partisan") + 
                            ct_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = dat)

tpp_mod_cert1 <- lm_robust(tpp_cert ~ tpp_forecast_center * (Condition == "Partisan") + 
                            tpp_forecast_uncertain_magnitude * (Condition == "Partisan"),
                          se = "stata",
                          data = dat)



