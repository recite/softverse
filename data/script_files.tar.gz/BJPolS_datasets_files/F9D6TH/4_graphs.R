

## REPLICATION MATERIAL FOR
## HOW DOES UNCERTAINTY AFFECT VOTERS' PREFERENCES?
## BRITISH JOURNAL OF POLITICAL SCIENCE
## AUTHOR: LOVE CHRISTENSEN


####################################
########### FILE 4: GRAPHS #########
####################################

############################################
## PLEASE RUN 2_models.R BEFORE THIS FILE ##
############################################

library(tikzDevice)

## Note that all figures are saved in tikz-format as .tex-files and then compiled in the latex document
## Figures are saved to "../output/figures/"

#################################
##### 1. Reduced form graph #####
#################################

mw_predict_dat <- data.frame('(Intercept)' = 1, 
                             "mw_forecast_center" = seq(-4, 4, 1), 
                             'Condition' = 0,
                             "mw_forecast_uncertain_magnitude" = 0,
                             'mw_forecast_center:Condition == "Partisan"TRUE' = 0,
                             'Condition == "Partisan"TRUE:mw_forecast_uncertain_magnitude' = 0)
mw_fit_red <- predict(mw_likert_mod1, newdata = mw_predict_dat, se = TRUE)
mw_fit_red <- mw_fit_red %>% 
  data.frame %>% 
  mutate(low = fit - 1.96 * se.fit,
         high = fit + 1.96 * se.fit,
         forecast = seq(-4,4,1)) 

ct_predict_dat <- data.frame('(Intercept)' = 1, 
                             "ct_forecast_center" = seq(-4, 4, 1), 
                             'Condition' = 0,
                             "ct_forecast_uncertain_magnitude" = 0,
                             'ct_forecast_center:Condition == "Partisan"TRUE' = 0,
                             'Condition == "Partisan"TRUE:ct_forecast_uncertain_magnitude' = 0)
ct_fit_red <- predict(ct_likert_mod1, newdata = ct_predict_dat, se = TRUE)
ct_fit_red <- ct_fit_red %>% 
  data.frame %>% 
  mutate(low = fit - 1.96 * se.fit,
         high = fit + 1.96 * se.fit,
         forecast = seq(-4,4,1)) 


tpp_predict_dat <- data.frame('(Intercept)' = 1, 
                             "tpp_forecast_center" = seq(-4, 4, 1), 
                             'Condition' = 0,
                             "tpp_forecast_uncertain_magnitude" = 0,
                             'tpp_forecast_center:Condition == "Partisan"TRUE' = 0,
                             'Condition == "Partisan"TRUE:tpp_forecast_uncertain_magnitude' = 0)
tpp_fit_red <- predict(tpp_likert_mod1, newdata = tpp_predict_dat, se = TRUE)
tpp_fit_red <- tpp_fit_red %>% 
  data.frame %>% 
  mutate(low = fit - 1.96 * se.fit,
         high = fit + 1.96 * se.fit,
         forecast = seq(-4, 4, 1)) 


graph_tpp_red <- ggplot(tpp_fit_red, aes(forecast, fit)) +
  geom_line() +
  geom_ribbon(data = tpp_fit_red, aes(ymin = low, ymax = high), alpha = 0.2) +
  theme_bw()  +
  scale_y_continuous(breaks = seq(3.5, 5.5, 0.5), limits = c(3.5, 5.5)) +
  ggtitle("Trans-Pacific Partnership") +
  xlab("Prediction $\\Delta$ manufacturing jobs ") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks=seq(-4,4,2)) +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

graph_ct_red <- ggplot(ct_fit_red, aes(forecast, fit)) +
  geom_line() +
  geom_ribbon(data = ct_fit_red, aes(ymin = low, ymax = high), alpha = 0.2) +
  theme_bw() +
  scale_y_continuous(breaks = seq(3.5, 5.5, 0.5), limits = c(3.5, 5.5)) +
  ggtitle("Corporate Tax") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks=seq(-4,4,2)) +
  xlab("Prediction $\\Delta$ employment rate ") +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

graph_mw_red <- ggplot(mw_fit_red, aes(forecast, fit)) +
  geom_line() +
  geom_ribbon(data = mw_fit_red, aes(ymin = low, ymax = high), alpha = 0.2) +
  theme_bw() +
  scale_y_continuous(breaks = seq(3.5, 5.5, 0.5), limits = c(3.5, 5.5)) +
  ggtitle("Minimum Wage") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks=seq(-4,4,2)) +
  xlab("Prediction $\\Delta$ unemployment rate ") +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

tikz(file = "../output/figures/fig_red_form.tex", width = 8.5, height = 3.2)
grid.arrange(graph_mw_red, graph_ct_red, graph_tpp_red, nrow = 1)
dev.off()

#######################
##### 2. IV GRAPH #####
#######################

# MW
beta <- mw_likert_iv1$coefficients # vector of coefficients
sigma <- mw_likert_iv1$vcov # vcov matrix
theta <- mvrnorm(1000, mu = beta, Sigma = sigma) # one thousand draws of betas

var_values_matrix <- data.frame(intercept = 1, unemp_rate = seq(0, 3, length.out = 5))

mw_expected_iv <- as.matrix(var_values_matrix) %*% t(theta)
mw_expected_iv <- data.frame(t(apply(mw_expected_iv, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
mw_expected_iv$belief <- seq(0, 3, length.out = 5)
names(mw_expected_iv) <- c("lower", "median", "upper", "belief")

# CT
beta <- ct_likert_iv1$coefficients # vector of coefficients
sigma <- ct_likert_iv1$vcov # vcov matrix
theta <- mvrnorm(1000, mu = beta, Sigma = sigma) # one thousand draws of betas

var_values_matrix <- data.frame(intercept = 1, emp_rate = seq(0, 3, length.out = 5))

ct_expected_iv <- as.matrix(var_values_matrix) %*% t(theta)
ct_expected_iv <- data.frame(t(apply(ct_expected_iv, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
ct_expected_iv$belief <- seq(0, 3, length.out = 5)
names(ct_expected_iv) <- c("lower", "median", "upper", "belief")


# TPP
beta <- tpp_likert_iv1$coefficients # vector of coefficients
sigma <- tpp_likert_iv1$vcov # vcov matrix
theta <- mvrnorm(1000, mu = beta, Sigma = sigma) # one thousand draws of betas

var_values_matrix <- data.frame(intercept = 1, man_jobs = seq(.5, .9, length.out = 5))

tpp_expected_iv <- as.matrix(var_values_matrix) %*% t(theta)
tpp_expected_iv <- data.frame(t(apply(tpp_expected_iv, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_expected_iv$belief <- seq(.5, .9, length.out = 5)
names(tpp_expected_iv) <- c("lower", "median", "upper", "belief")



graph_tpp_iv <- ggplot(tpp_expected_iv, aes(belief, median)) +
  geom_line() +
  geom_ribbon(data = tpp_expected_iv, aes(ymin = lower, ymax = upper), alpha = 0.3) +
  theme_minimal()  +
  scale_y_continuous(breaks = seq(2, 7, 1), limits = c(2, 7)) +
  ggtitle("Trans-Pacific Partnership") +
  xlab("Belief $\\Delta$ manufacturing jobs") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks= seq(.5, .9, length.out = 5)) +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

graph_ct_iv <- ggplot(ct_expected_iv, aes(belief, median)) +
  geom_line() +
  geom_ribbon(data = ct_expected_iv, aes(ymin = lower, ymax = upper), alpha = 0.3) +
  theme_bw()  +
  scale_y_continuous(breaks = seq(2, 7, 1), limits = c(2, 7)) +
  ggtitle("Corporate tax") +
  xlab("Belief $\\Delta$ employment rate ") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks=seq(0, 3, length.out = 5)) +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

graph_mw_iv <- ggplot(mw_expected_iv, aes(belief, median)) +
  geom_line() +
  geom_ribbon(data = mw_expected_iv, aes(ymin = lower, ymax = upper), alpha = 0.3) +
  theme_bw()  +
  scale_y_continuous(breaks = seq(2, 7, 1), limits = c(2, 7)) +
  ggtitle("Minimum wage") +
  xlab("Belief $\\Delta$ unemployment rate ") +
  theme(aspect.ratio=1) +
  scale_x_continuous(breaks=seq(0, 3, length.out = 5)) +
  ylab("Support") +
  theme(panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        panel.grid.major = element_line(colour = "gray87"),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

tikz(file = "../output/figures/fig_iv.tex", width = 8, height = 3)
grid.arrange(graph_mw_iv, graph_ct_iv, graph_tpp_iv, nrow = 1)
dev.off()

#####################################
##### 3. Partisan heterogeneity #####
#####################################

## First differences comparing within partisan groups
## Effect of having a optimistic Democrat or Republican prediction for Republican respondents of

#### BELIEFS #####
### PARTISAN SENDERS ###
## REPUBLICAN ##

set.seed(1010)
beta <- tpp_quant_part$coefficients # vector of coefficients
sigma <- tpp_quant_part$vcov # vcov matrix
theta <- mvrnorm(1000, mu = beta, Sigma = sigma) # one thousand draws of betas

var_values_republican_1 <- data.frame("intercept" = 1, 
                                "tpp_forecast_center" = 0,
                                "democrat" = 0,
                                "republican" = 1,
                                "tpp_forecast_uncertain_magnitude" = 2,
                                "tpp_rep_high" = 1,
                                "age" = 0,
                                "female" = 0,
                                "educ_college_degree" = 0,
                                "educ_nohighscool" = 0,
                                "income_less50K" = 0,
                                "income_100K150K" = 0,
                                "income_150Kabove" = 0,
                                "tpp_forecast_center:democrat" = 0,
                                "tpp_forecast_center:republican" = 0,
                                "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                "republican:tpp_forecast_uncertain_magnitude" = 2,
                                "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 2
                                )

var_values_republican_2 <- data.frame("intercept" = 1, 
                                  "tpp_forecast_center" = 0,
                                  "democrat" = 0,
                                  "republican" = 1,
                                  "tpp_forecast_uncertain_magnitude" = 2,
                                  "tpp_rep_high" = 0,
                                  "age" = 0,
                                  "female" = 0,
                                  "educ_college_degree" = 0,
                                  "educ_nohighscool" = 0,
                                  "income_less50K" = 0,
                                  "income_100K150K" = 0,
                                  "income_150Kabove" = 0,
                                  "tpp_forecast_center:democrat" = 0,
                                  "tpp_forecast_center:republican" = 0,
                                  "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                  "republican:tpp_forecast_uncertain_magnitude" = 2,
                                  "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                  "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
                                  )

tpp_quant_republican_1 <- as.matrix(var_values_republican_1) %*% t(theta)
tpp_quant_republican_2 <- as.matrix(var_values_republican_2) %*% t(theta)
tpp_republican_fd <- tpp_quant_republican_1 - tpp_quant_republican_2
tpp_republican_quant_part_fd <- data.frame(t(apply(tpp_republican_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_republican_quant_part_fd <- data.frame(tpp_republican_quant_part_fd,
                                            outcome = "Belief",
                                            pid = "Republican")
names(tpp_republican_quant_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")


## DEMOCRAT ##

var_values_democrat_1 <- data.frame("intercept" = 1, 
                                      "tpp_forecast_center" = 0,
                                      "democrat" = 1,
                                      "republican" = 0,
                                      "tpp_forecast_uncertain_magnitude" = 2,
                                      "tpp_rep_high" = 1,
                                      "age" = 0,
                                      "female" = 0,
                                      "educ_college_degree" = 0,
                                      "educ_nohighscool" = 0,
                                      "income_less50K" = 0,
                                      "income_100K150K" = 0,
                                      "income_150Kabove" = 0,
                                      "tpp_forecast_center:democrat" = 0,
                                      "tpp_forecast_center:republican" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude" = 2,
                                      "republican:tpp_forecast_uncertain_magnitude" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 2,
                                      "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

var_values_democrat_2 <- data.frame("intercept" = 1, 
                                      "tpp_forecast_center" = 0,
                                      "democrat" = 1,
                                      "republican" = 0,
                                      "tpp_forecast_uncertain_magnitude" = 2,
                                      "tpp_rep_high" = 0,
                                      "age" = 0,
                                      "female" = 0,
                                      "educ_college_degree" = 0,
                                      "educ_nohighscool" = 0,
                                      "income_less50K" = 0,
                                      "income_100K150K" = 0,
                                      "income_150Kabove" = 0,
                                      "tpp_forecast_center:democrat" = 0,
                                      "tpp_forecast_center:republican" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude" = 2,
                                      "republican:tpp_forecast_uncertain_magnitude" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                      "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

tpp_quant_democrat_1 <- as.matrix(var_values_democrat_1) %*% t(theta)
tpp_quant_democrat_2 <- as.matrix(var_values_democrat_2) %*% t(theta)
tpp_democrat_fd <- tpp_quant_democrat_1 - tpp_quant_democrat_2
tpp_democrat_quant_part_fd <- data.frame(t(apply(tpp_democrat_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_democrat_quant_part_fd <- data.frame(tpp_democrat_quant_part_fd,
                                           outcome = "Belief",
                                           pid = "Democrat")
names(tpp_democrat_quant_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")

## INDEPENDENT


var_values_independent_1 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 0,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 1,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 2,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

var_values_independent_2 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 0,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 0,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

tpp_quant_independent_1 <- as.matrix(var_values_independent_1) %*% t(theta)
tpp_quant_independent_2 <- as.matrix(var_values_independent_2) %*% t(theta)
tpp_independent_fd <- tpp_quant_independent_1 - tpp_quant_independent_2
tpp_independent_quant_part_fd <- data.frame(t(apply(tpp_independent_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_independent_quant_part_fd <- data.frame(tpp_independent_quant_part_fd,
                                         outcome = "Belief",
                                         pid = "Independent")
names(tpp_independent_quant_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")

##### ATTITUDE #####

set.seed(1010)
beta <- tpp_likert_part$coefficients # vector of coefficients
sigma <- tpp_likert_part$vcov # vcov matrix
theta <- mvrnorm(1000, mu = beta, Sigma = sigma) # one thousand draws of betas

var_values_republican_1 <- data.frame("intercept" = 1, 
                                      "tpp_forecast_center" = 0,
                                      "democrat" = 0,
                                      "republican" = 1,
                                      "tpp_forecast_uncertain_magnitude" = 2,
                                      "tpp_rep_high" = 1,
                                      "age" = 0,
                                      "female" = 0,
                                      "educ_college_degree" = 0,
                                      "educ_nohighscool" = 0,
                                      "income_less50K" = 0,
                                      "income_100K150K" = 0,
                                      "income_150Kabove" = 0,
                                      "tpp_forecast_center:democrat" = 0,
                                      "tpp_forecast_center:republican" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                      "republican:tpp_forecast_uncertain_magnitude" = 2,
                                      "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                      "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 2
)

var_values_republican_2 <- data.frame("intercept" = 1, 
                                      "tpp_forecast_center" = 0,
                                      "democrat" = 0,
                                      "republican" = 1,
                                      "tpp_forecast_uncertain_magnitude" = 2,
                                      "tpp_rep_high" = 0,
                                      "age" = 0,
                                      "female" = 0,
                                      "educ_college_degree" = 0,
                                      "educ_nohighscool" = 0,
                                      "income_less50K" = 0,
                                      "income_100K150K" = 0,
                                      "income_150Kabove" = 0,
                                      "tpp_forecast_center:democrat" = 0,
                                      "tpp_forecast_center:republican" = 0,
                                      "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                      "republican:tpp_forecast_uncertain_magnitude" = 2,
                                      "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                      "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

tpp_likert_republican_1 <- as.matrix(var_values_republican_1) %*% t(theta)
tpp_likert_republican_2 <- as.matrix(var_values_republican_2) %*% t(theta)
tpp_republican_fd <- tpp_likert_republican_1 - tpp_likert_republican_2
tpp_republican_likert_part_fd <- data.frame(t(apply(tpp_republican_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_republican_likert_part_fd <- data.frame(tpp_republican_likert_part_fd,
                                          outcome = "Attitude",
                                          pid = "Republican")
names(tpp_republican_likert_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")

## DEMOCRAT ##

var_values_democrat_1 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 1,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 1,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 2,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 2,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

var_values_democrat_2 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 1,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 0,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 2,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

tpp_likert_democrat_1 <- as.matrix(var_values_democrat_1) %*% t(theta)
tpp_likert_democrat_2 <- as.matrix(var_values_democrat_2) %*% t(theta)
tpp_democrat_fd <- tpp_likert_democrat_1 - tpp_likert_democrat_2
tpp_democrat_likert_part_fd <- data.frame(t(apply(tpp_democrat_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_democrat_likert_part_fd <- data.frame(tpp_democrat_likert_part_fd,
                                          outcome = "Attitude",
                                          pid = "Democrat")
names(tpp_democrat_likert_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")


## INDEPENDENT

var_values_independent_1 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 0,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 1,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

var_values_independent_2 <- data.frame("intercept" = 1, 
                                    "tpp_forecast_center" = 0,
                                    "democrat" = 0,
                                    "republican" = 0,
                                    "tpp_forecast_uncertain_magnitude" = 2,
                                    "tpp_rep_high" = 0,
                                    "age" = 0,
                                    "female" = 0,
                                    "educ_college_degree" = 0,
                                    "educ_nohighscool" = 0,
                                    "income_less50K" = 0,
                                    "income_100K150K" = 0,
                                    "income_150Kabove" = 0,
                                    "tpp_forecast_center:democrat" = 0,
                                    "tpp_forecast_center:republican" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude" = 0,
                                    "democrat:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0,
                                    "republican:tpp_forecast_uncertain_magnitude:tpp_rep_high" = 0
)

tpp_likert_independent_1 <- as.matrix(var_values_independent_1) %*% t(theta)
tpp_likert_independent_2 <- as.matrix(var_values_independent_2) %*% t(theta)
tpp_independent_fd <- tpp_likert_independent_1 - tpp_likert_independent_2
tpp_independent_likert_part_fd <- data.frame(t(apply(tpp_independent_fd, 1, function(x) quantile(x, probs = c(0.025, 0.5, 0.975)))))
tpp_independent_likert_part_fd <- data.frame(tpp_independent_likert_part_fd,
                                          outcome = "Attitude",
                                          pid = "Independent")
names(tpp_independent_likert_part_fd) <- c("lower", "mean", "upper", "outcome", "Partisanship")


#### MAKE PLOT

dat_fd <- rbind(tpp_democrat_quant_part_fd,
                tpp_independent_quant_part_fd,
                tpp_republican_quant_part_fd,
                tpp_democrat_likert_part_fd,
                tpp_independent_likert_part_fd,
                tpp_republican_likert_part_fd)

dat_fd <- dat_fd %>%
  mutate(Partisanship = factor(Partisanship),
         Partisanship = factor(Partisanship, levels = rev(levels(Partisanship))))



fig_part <- ggplot(dat_fd, aes(colour = Partisanship)) +
  geom_hline(yintercept = 0, colour = gray(1/2), lty = 2) +
  geom_pointrange(aes(x = outcome, 
                      y = mean, 
                      ymin = lower,
                      ymax = upper,
                      shape = Partisanship,
                      fill = Partisanship),
                  lwd = 1/2, 
                  position = position_dodge(width = 1/2)) +
  coord_flip() +
  theme_minimal(base_size = 9)  +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.text.y=element_text(colour="black", size = 9),
        axis.text.x=element_text(colour="black", size = 9)) +
  scale_y_continuous("\nFirst Differences",
                     limits = c(-1.25, 1.25), 
                     breaks = seq(-1, 1, by = .5)) +
  ggtitle("") +
  xlab("") +
  scale_colour_manual(values=c("#E91D0E", "#999999", "#0015BC")) +
  scale_fill_manual(values=c("#FFFFFF", "#FFFFFF", "#FFFFFF")) +
  scale_shape_manual(values = c(22, 21, 24)) +
  guides(colour = guide_legend(reverse = TRUE),
         shape = guide_legend(reverse = TRUE),
         fill = guide_legend(reverse = TRUE))


tikz(file = "../output/figures/fig_part.tex", width = 5, height = 3)
fig_part
dev.off()

