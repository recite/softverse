###BJPS Replication Files
#Emily Kalah Gade
# 27 Jan 2020
library(pglm) # pannel model 
library(betareg) #beta regression
library(stargazer) # tables in latex

#### Table 1 

m2<-read.csv("house_BJPS_rep.csv", stringsAsFactors = F, header = T)
m2$Male[m2$gender =="M"]<-1
m2$Male[m2$gender =="F"]<-0

m3<-na.omit(m2)

ols<-lm(m3$nuactive ~m3$frequency_religLWIC, data=m3)

ols1<-lm(m3$nuactive ~ m3$frequency_chapp +  m3$party + m3$Male + m3$evangel, data = m3)

ols2<-lm(m3$nuactive ~ m3$frequency_religLWIC + m3$party + m3$Male + m3$evangel, data = m3)

summary(ols)
summary(ols1)
summary(ols2)
stargazer(ols,  ols2, ols1)


### Table 2

IVDV_2<-read.csv("senate_BJPS_rep.csv", header = T, stringsAsFactors = F)
IVDV_2<-na.omit(IVDV_2)

ols_full<-lm(IVDV_2$frequency_religLWIC ~ IVDV_2$Female + IVDV_2$veryReligous + IVDV_2$dw1 
             + IVDV_2$unemploy + IVDV_2$aa + IVDV_2$upforElection + IVDV_2$veryconservative, data=IVDV_2)


b_full<-betareg(IVDV_2$frequency_religLWIC ~ IVDV_2$Female + IVDV_2$veryReligous 
                + IVDV_2$dw1 + IVDV_2$unemploy + IVDV_2$aa + IVDV_2$upforElection + IVDV_2$veryconservative, data=IVDV_2)


selectdata2<-IVDV_2[ order(IVDV_2$URLs, IVDV_2$year) ,]
selectdata2<-na.omit(selectdata2)
pdata <- pdata.frame(selectdata2, index=c("URLs", "year"))


basics<-plm(pdata$frequency_religLWIC~ #IVDV_2$Female +
              pdata$veryReligous + pdata$dw1 + pdata$unemploy + #pdata$aa + 
              pdata$upforElection + pdata$veryconservative, data= pdata, 
            start=NULL, model = "pooling", effect = "twoways")

stargazer(b_full, basics, ols_full)

