set.seed(5168)
## responsibility attribution ##

	library(foreign)
	library(mnormt)
	library(ordinal)

  data <- read.dta('Denmark (2014).dta')

  data <- subset(data, data$Party != 1) #Remove Venstre
  data <- subset(data, data$Party != 2) #Remove Socialdemokraterne
  data <- subset(data, data$Party != 3) #Remove Dansk Folkeparti
  data <- subset(data, data$Party != 4) #Remove Radikale
  data <- subset(data, data$Party != 7) #Remove Liberal Alliance
  data <- subset(data, data$Party != 8) #Remove Det Konservative Folkeparti
  data <- subset(data, data$Party != 9) #Remove Kristendemokraterne

	model <- clmm(as.factor(Resp_attribution) ~ Prime_minister + Cabinet + Opposition + DK_Perc_seats + Prime_minister * DK_Perc_seats + Cabinet * DK_Perc_seats + Opposition*DK_Perc_seats + (1 | pid), data = data, HESS = TRUE, link = 'probit')
	summary(model)

	pars <- as.matrix(model$coefficients)
	vce <- vcov(model)
	vce <- vce[-c(12), ]       
	vce <- vce[, -c(12)]       
	
	simCoef <- rmnorm(1000, as.vector(pars),as.matrix(vce))

	summary(model)

	pmHi <- c()
	pmLo <- c()
	pmMed <- c()

  partnerHi <- c()
  partnerLo <- c()
  partnerMed <- c()

	supHi <- c()
	supLo <- c()
	supMed <- c()

	oppHi <- c()
	oppLo <- c()
	oppMed <- c()

  otherHi <- c()
  otherLo <- c()
  otherMed <- c()

  part_pred <- c()
  opp_pred <- c()
  
  marg_effect <- c()
  margeff_Hi <- c()
  margeff_Lo <- c()
  margeff_Med <- c()

for(i in 0:25){
  
  ## partner party 
  agg <- simCoef[, 5] * 0 + 
    simCoef[, 6] * 1 + 
    simCoef[, 7] * 0 + 
    simCoef[, 8] * i + 
    simCoef[, 9] * 0 + 
    simCoef[, 10] * i + 
    simCoef[, 11] * 0 
  
  pred1 <- pnorm(simCoef[, 1], agg, sd = 1)
  pred2 <- pnorm(simCoef[, 2], agg, sd = 1) - pred1
  pred3 <- pnorm(simCoef[, 3], agg, sd = 1) - pred2 - pred1
  pred4 <- pnorm(simCoef[, 4], agg, sd = 1) - pred3 - pred2 - pred1
  pred5 <- 1 - pred1 - pred2 - pred3 - pred4
  
  part_pred <- pred5 * 5 + 
    pred4 * 4 + 
    pred3 * 3 + 
    pred2 * 2 + 
    pred1
    
  ## opp party 
  agg <- simCoef[, 5] * 0 + 
    simCoef[, 6] * 0 + 
    simCoef[, 7] * 1 + 
    simCoef[, 8] * i + 
    simCoef[, 9] * 0 + 
    simCoef[, 10] * 0 + 
    simCoef[, 11] * i 
  
  pred1 <- pnorm(simCoef[, 1], agg, sd = 1)
  pred2 <- pnorm(simCoef[, 2], agg, sd = 1) - pred1
  pred3 <- pnorm(simCoef[, 3], agg, sd = 1) - pred2 - pred1
  pred4 <- pnorm(simCoef[, 4], agg, sd = 1) - pred3 - pred2 - pred1
  pred5 <- 1 - pred1 - pred2 - pred3 - pred4
  
  opp_pred <- pred5 * 5 + 
    pred4 * 4 + 
    pred3 * 3 + 
    pred2 * 2 + 
    pred1
    
  
  #get marginal effect 
  marg_effect = part_pred - opp_pred
  margeff_Hi[i + 1] = quantile(marg_effect, 0.975)
  margeff_Lo[i + 1] = quantile(marg_effect, 0.025)
  margeff_Med[i + 1] = quantile(marg_effect, 0.5)
  
}  

#seats sequence
seats <- seq(0, 25, 1)

#Now create the figure
par(mar=c(3.5,6.2,1.5,1.5))      
plot(1, 1, type = 'n',
     xlim = c(0, 25),
     ylim = c(0, 1.5),
     xlab = '',
     ylab = '',
     main = '', 
     axes = FALSE)
axis(1,at=seq(0,25,5),labels=T)          
axis(2,at=seq(0,1.5,0.50),labels=T)
polygon(c(seats, rev(seats)), c(margeff_Hi, rev(margeff_Lo)), col = rgb(red = 0.1, 0.1, 0, 0.2), border = FALSE)
lines(seats, margeff_Med, col = rgb(0.1, 0.1, 0, 1), lwd = 3)
abline(h=0,col="red")

mtext("Change in \nresponsibility attribution", side=2, line=2.5, cex=1.2)       
mtext("Perceived seat %", side=1, line=2.2, cex=1.2)        

dev.copy(png,'Figure 10b DK 2014 - Marginal effect of support party categorization.png', height = 490, width = 633)  
dev.off()  
