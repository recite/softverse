# Please read the readme file before executing this script!
paths <- c("working", "output")
sapply(1:length(paths), function(i) dir.create(paths[i]))
source("01_prep_bes.R")
source("02_analysis.R")