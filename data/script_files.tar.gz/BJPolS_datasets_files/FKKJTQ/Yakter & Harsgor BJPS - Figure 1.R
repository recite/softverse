## load packages
library(readstata13)
library(tidyr)
library(dplyr)
library(ggplot2)
library(reshape)
library(scales)

## prepare data
# Load data
dat <- read.dta13("Yakter & Harsgor BJPS - data.dta")
dat <- select(dat,support_int_jw,hope_int_jw,ts_date,year_month)
# tranform data from wide to long
dat.long <- reshape(dat,varying=c("support_int_jw","hope_int_jw"),v.names="net",timevar="topic",direction="long",idvar="ts_date")
dat.long$topic <- as.factor(dat.long$topic) 

## Figure 1
plot <- ggplot(data=dat.long,aes(x=ts_date)) +
  geom_line(data=dat.long,aes(x=ts_date,y=net,linetype=topic)) + 
  annotate("text",x=as.Date("2013-01-01", "%Y-%m-%d"), y=0.67, label="Net Support for Negotiations", hjust=0,vjust=1,size=4) +
  annotate("text",x=as.Date("2013-05-01", "%Y-%m-%d"), y=-0.2, label="Net Hope in Practice", hjust=0,vjust=1,size=4) +
  labs(x="Date",y="Net Support / Hope") +
  scale_x_date(breaks = seq(as.Date("2002-01-01"), as.Date("2020-01-01"), by="3 years"), date_labels = "%Y") +
  scale_y_continuous(limits = c(-0.7,0.7), breaks=seq(-0.6,0.6,by=0.2), labels = scales::percent) +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid = element_blank()
  )

## save to file
ggsave("Figure 1.pdf", plot=plot, width=6, height=3.5)