## load packages
library(readstata13)
library(strucchange)
library(tidyr)
library(dplyr)
library(ggplot2)
library(patchwork)


## prepare data
dat <- read.dta13("Yakter & Harsgor BJPS - data.dta")

# plots
plot.pr <- ggplot(data=dat, aes(y=support_int_jw,x=ts_date)) +
  geom_line() + 
  geom_smooth(data=filter(dat,year_month<=200601),method="lm",se=FALSE,color = "black") +
  geom_smooth(data=filter(dat,year_month>=200601,year_month<=200904),method="lm",se=FALSE,color = "black") +
  geom_smooth(data=filter(dat,year_month>=200904,year_month<=201610),method="lm",se=FALSE,color = "black") +
  geom_smooth(data=filter(dat,year_month>=201610),method="lm",se=FALSE,color = "black") +
  annotate("text",x=as.Date("2006-03-01", "%Y-%m-%d"),y=0.02,label="A",hjust=0,size=3.5) +
  annotate("text",x=as.Date("2009-06-01", "%Y-%m-%d"),y=0.02,label="B",hjust=0,size=3.5) +
  annotate("text",x=as.Date("2016-12-01", "%Y-%m-%d"),y=0.02,label="C",hjust=0,size=3.5) +
  geom_vline(xintercept = as.numeric(dat$ts_date[55]),linetype="dashed") +
  geom_vline(xintercept = as.numeric(dat$ts_date[94]),linetype="dashed") + 
  geom_vline(xintercept = as.numeric(dat$ts_date[184]),linetype="dashed") + 
  labs(x="Date",y="Net Support",title = "Net Support for Negotiations") +
  scale_x_date(breaks = seq(as.Date("2002-01-01"), as.Date("2020-01-01"), by="3 years"), date_labels = "%Y") +
  scale_y_continuous(limits = c(0,0.7), breaks=seq(0,0.7,by=0.1), labels = scales::percent_format(accuracy = 1)) +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        plot.title = element_text(size=11),
  )

plot.op <- ggplot(data=dat, aes(y=hope_int_jw,x=ts_date)) +
  geom_line() + 
  geom_smooth(data=filter(dat,year_month<=200604),,method="lm",se=FALSE,color = "black") +
  geom_smooth(data=filter(dat,year_month>=200604,year_month<=201309),method="lm",se=FALSE,color = "black") +
  geom_smooth(data=filter(dat,year_month>=201309),method="lm",se=FALSE,color = "black") +
  annotate("text",x=as.Date("2006-06-01", "%Y-%m-%d"),y=-0.68,label="D",hjust=0,size=3.5) +
  annotate("text",x=as.Date("2013-11-01", "%Y-%m-%d"),y=-0.68,label="E",hjust=0,size=3.5) +
  geom_vline(xintercept = as.numeric(dat$ts_date[58]),linetype="dashed") +
  geom_vline(xintercept = as.numeric(dat$ts_date[147]),linetype="dashed") + 
  labs(x="Date",y="Net Hope",title = "Net Hope in Practice") +
  scale_x_date(breaks = seq(as.Date("2002-01-01"), as.Date("2020-01-01"), by="3 years"), date_labels = "%Y") +
  scale_y_continuous(limits = c(-0.7,0.1), breaks=seq(-0.7,0.1,by=0.1), labels = scales::percent_format(accuracy = 1)) +
  theme_bw() +
  theme(legend.position = "none",
        panel.grid = element_blank(),
        plot.title = element_text(size=11),
  )

plot <- plot.pr + plot.op +  plot_layout(ncol = 1)

ggsave(file = "Figure 4.pdf", plot=plot, width=6, height=4.5)