## load packages
library(readstata13)
library(tidyr)
library(dplyr)
library(ggplot2)
library(reshape)
library(naniar)
library(imputeTS)
library(writexl)


## load and prepare data
dat <- read.dta13("Yakter & Harsgor BJPS - data.dta")
dat <- filter(dat,year_month>=200107,year_month<=202005)
dat.f <- select(dat,ts_date,opt_net_jw,princ_net_jw)

## create DVs with different interpolation methods (later analyzed in Stata code)
# net support
sprt <- as.ts(dat.f$princ_net_jw)
sprt.kal.st <- na_kalman(sprt)
ggplot_na_imputations(sprt,sprt.kal.st)
sprt.kal.ar <- na_kalman(sprt,model="auto.arima")
ggplot_na_imputations(sprt,sprt.kal.ar)
sprt.ma.ex <- na_ma(sprt, k=2)
ggplot_na_imputations(sprt,sprt.ma.ex)
sprt.ma.l <- na_ma(sprt, weighting = "linear", k=2)
ggplot_na_imputations(sprt,sprt.ma.l)

dat.f$sprt.kal.st <- as.data.frame(sprt.kal.st)
dat.f$sprt.kal.ar <- as.data.frame(sprt.kal.ar)
dat.f$sprt.ma.ex <- as.data.frame(sprt.ma.ex)
dat.f$sprt.ma.l <- as.data.frame(sprt.ma.l)
dat.f$sprt.kal.st <- unlist(sprt.kal.st)
dat.f$sprt.kal.ar <- unlist(sprt.kal.ar)
dat.f$sprt.ma.ex <- unlist(sprt.ma.ex)
dat.f$sprt.ma.l <- unlist(sprt.ma.l)


# net hope
sprt <- as.ts(dat.f$princ_net_jw)
sprt.kal.st <- na_kalman(sprt)
ggplot_na_imputations(sprt,sprt.kal.st)
sprt.kal.ar <- na_kalman(sprt,model="auto.arima")
ggplot_na_imputations(sprt,sprt.kal.ar)
sprt.ma.ex <- na_ma(sprt)
ggplot_na_imputations(sprt,sprt.ma.ex)
sprt.ma.l <- na_ma(sprt, weighting = "linear")
ggplot_na_imputations(sprt,sprt.ma.l)

dat.f$sprt.kal.st <- as.data.frame(sprt.kal.st)
dat.f$sprt.kal.ar <- as.data.frame(sprt.kal.ar)
dat.f$sprt.ma.ex <- as.data.frame(sprt.ma.ex)
dat.f$sprt.ma.l <- as.data.frame(sprt.ma.l)
dat.f$sprt.kal.st <- unlist(sprt.kal.st)
dat.f$sprt.kal.ar <- unlist(sprt.kal.ar)
dat.f$sprt.ma.ex <- unlist(sprt.ma.ex)
dat.f$sprt.ma.l <- unlist(sprt.ma.l)

# save file (excel format, later merged into primary .dat file)
write_xlsx(dat.f,"datf.xlsx")
