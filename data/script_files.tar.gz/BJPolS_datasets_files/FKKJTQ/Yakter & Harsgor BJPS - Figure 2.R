## load packages
library(foreign)
library(tidyr)
library(dplyr)
library(ggplot2)
library(reshape)
library(scales)
library(patchwork)

## prepare data
dat <- read.csv("Yakter & Harsgor BJPS - Figure 2 data.csv")
dat.long <- gather(dat,key=iv,value=effect,log_rockets:hawkish_selection)
dat.long$dv = factor(dat.long$dv, levels = c("support","hope"))  
dat.long$iv = factor(dat.long$iv, levels = c("log_rockets","log_casualties","negotiations","hawkish_selection"))  

## Figure 2
plot <- ggplot(data=dat.long,aes(y=effect, x=lag)) +
  geom_bar(stat = "identity") +
  facet_grid(dv ~ iv,
            labeller = labeller(
               dv=c(support = "DV: Net Support",hope = "DV: Net Hope"),
               iv=c(log_rockets="Log Rockets", log_casualties="Log Casualties",
                    negotiations="Negotiations",hawkish_selection="Hawkish Leadership"))) +
  geom_hline(yintercept = 0) +
  scale_x_continuous(breaks=c(0:9)) +
  scale_y_continuous(breaks=seq(-14,4,2)) +
  labs(x="Months After One-time Change", y="Effect on Dependent Variable") +
  theme_bw() +
  theme(panel.grid = element_blank(),
  )

## save to file
ggsave("Figure 2.pdf", plot=plot, width=7, height=3.5)