## This file replicates the analysis of the Danish experiments in Bhatti, Dahlgaard, Hansen, and Hansen (2016)
## "Is door-to-door canvassing effective in Europe? Evidence from a meta-study across six European countries"

## read in packages 
## install.packages("rmeta", "ggplot2", "dplyr") ## uncomment to install packages
library(ri)

## Clean up and load data
rm(list=ls())
setwd("~/dropbox/CET/our products/work in progress/doer til doer/bjps/replication files")
load("rep_tabs.rdata")

## recreate Copenhagen data from table

## Extract unique treatment probs
unique_probs <- 
  unique((rownames(rep_tabs[[1]][,1,1,])))

## Verify that there are 18 unique probs

length(unique_probs) == 18

rep_tabs[[1]][unique_probs[1],1,1,]

data <- NULL
for (i in 1){
  for (j in 1:2){
    for (k in 1:2){
      for (l in unique_probs){
        data <- rbind(data,
                      matrix(rep(as.numeric(c(l, k - 1, j - 1, i - 1) ),
                                 each = rep_tabs[[1]][l, k, j, i]),
                             nrow = rep_tabs[[1]][l, k, j, i]) )
      }
    }
  }          
}

for (i in 2){
  for (j in 2){
    for (k in 1:2){
      for (l in unique_probs){
        data <- rbind(data,
                      matrix(rep(as.numeric(c(l, k - 1, j - 1, i - 1) ),
                                 each = rep_tabs[[1]][l, k, j, i]),
                             nrow = rep_tabs[[1]][l, k, j, i]) )
      }
    }          
  }
}

cph_data <- 
  data.frame(data)

colnames(cph_data) <- 
  c("probs", "voted", "assigned", "delivered")


# repeat for Randers ------------------------------------------------------

## Extract unique treatment probs
unique_probs <- "0.5"

length(unique_probs) == 1

data <- NULL
for (i in 1){
  for (j in 1:2){
    for (k in 1:2){
      for (l in unique_probs){
        data <- rbind(data,
                      matrix(rep(as.numeric(c(l, k - 1, j - 1, i - 1) ),
                                 each = rep_tabs[[2]][l, k, j, i]),
                             nrow = rep_tabs[[2]][l, k, j, i]) )
      }
    }
  }          
}

for (i in 2){
  for (j in 2){
    for (k in 1:2){
      for (l in unique_probs){
        data <- rbind(data,
                      matrix(rep(as.numeric(c(l, k - 1, j - 1, i - 1) ),
                                 each = rep_tabs[[2]][l, k, j, i]),
                             nrow = rep_tabs[[2]][l, k, j, i]) )
      }
    }          
  }
}

ran_data <- 
  data.frame(data)

colnames(ran_data) <- 
  c("probs", "voted", "assigned", "delivered")
