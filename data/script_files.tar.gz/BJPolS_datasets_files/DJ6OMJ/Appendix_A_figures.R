# Appendix A Figures####
# set theme
rm(list = ls())
library(tidyverse)
library(foreign)
library(ggthemes)
library(interflex)
final_df = read.dta("~/Dropbox/political_risk/replication_files/pc_df_2022test.dta")
final_df2012 = final_df  %>%  filter(year >2011)


theme_zl = function() {
  theme_pubclean(15) + 
    theme(legend.position="bottom", 
          legend.title = element_blank(),
          panel.border = element_blank(), 
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))
}


#Figure A2: Outcome Variation####

final_df2012 %>% 
  group_by(year) %>% 
  mutate(roa = mean(roa, na.rm = T)) %>% 
  mutate(symbol == "mean") %>% 
  ggplot(aes(x = year, y = roa)) +
  geom_line() +
  geom_point()+
  theme_zl() 

#ggsave("~/Dropbox/Apps/Overleaf/cost_revolving_door_2020/outcome_variation.pdf",width = 16,height = 9)


#Figure A3: Treatment Status Visualization####   
library(panelView)
library(RColorBrewer) 
library(wesanderson)
library(PanelMatch)

color_like = wes_palette("Darjeeling2")[2:1]

final_df2012 %>% 
  mutate(year = as.integer(year),
         symbol = as.numeric(symbol),) %>% 
  filter(year >2011) %>% 
  as.data.frame() %>% 
  DisplayTreatment(unit.id = "symbol",
                   time.id = "year", 
                   legend.position = "bottom",
                   xlab = "", ylab = "",
                   treatment = "pc_dummy", 
                   data = .,
                   color.of.treated = wes_palette("Darjeeling2")[2],
                   color.of.untreated = wes_palette("Darjeeling2")[1],
                   # title = ""
                   dense.plot = TRUE,
                   hide.y.axis.label = TRUE) +
  theme(legend.title = element_blank())

ggsave("~/Dropbox/Apps/Overleaf/cost_revolving_door_2020/treatment_status.pdf",width = 4,height = 6)

#Figure A4 Diagnostic Tests for Marginal Effects Analysis ####
interaction = final_df2012 %>% 
  select(roa,roe,pc_dummy,purge_l,mkt_index,symbol,year,size,"incmope_l", "npc", "cppcc", "cpc") %>% 
  as.data.frame()

# data raw plot
f1 = interflex(Y = "roa", D = "pc_dummy", X = "mkt_index", 
               Z = c("incmope_l", "npc", "cppcc", "cpc", "size"),
               estimator = "raw",na.rm = T,
               Xlabel  = "Market Development Index",
               #treat.type = "discrete",
               theme.bw = TRUE, show.grid = FALSE,
               FE = c("symbol", "year"),
               ncols = 2,
               data = interaction
)
# data raw plot
f2 = interflex(Y = "roa", D = "pc_dummy", X = "purge_l", 
               Z = c("incmope_l", "npc", "cppcc", "cpc", "size"),
               estimator = "raw",na.rm = T,
               Xlabel  = "Purge",
               #treat.type = "discrete",
               theme.bw = TRUE, show.grid = FALSE,
               FE = c("symbol", "year"),
               ncols = 2,
               data = interaction)

ggarrange(f1,f2,ncol = 1)
ggsave("/Users/zerenli1992/Dropbox/Apps/Overleaf/cost_revolving_door_2020/market_dev_diag.png")

