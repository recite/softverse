############################
# Appendix C for Li 2022####
############################
rm(list = ls())
# load packages
library(tidyverse)
library(haven)
library(panelView)
library(readxl)
library(gridExtra)
library(stargazer)
library(ggpubr)
library(lfe)
library(interflex)
library(PanelMatch)
# set theme
theme_zl = function() {
  theme_pubclean(15) + 
    theme(legend.position="bottom", 
          legend.title = element_blank(),
          panel.border = element_blank(), 
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))
}

# load data
pc_city = read_rds( "~/Dropbox/political_risk/replication_files/pc_city_correlation.rds")

# Figure C1####

ggplot(pc_city, aes(x = log(gdp), y =pc_ratio)) +
  geom_point(alpha =.8) +
  geom_smooth() +
  xlab("logged GDP") +
  ylab("Revolver Ratio") +
  theme_zl()

ggsave( "/Users/zerenli1992/Dropbox/Apps/Overleaf/cost_revolving_door_2020/revolver_gdp.pdf")

# Table C1 ####
# Negative Correlation between Economic Development and RD Recruitment 

m1 = lm(pc_ratio ~ log(gdp),pc_city) 
m2 = lm(pc_ratio ~ log(gdp_pc),pc_city) 
m3 = lm(pc ~ log(gdp),pc_city)
m4 = lm(pc ~ log(gdp_pc),pc_city)

stargazer::stargazer(m1,m2, m3,m4,
                     omit.stat = c("ser","rsq","f"),
                     covariate.labels = c("logged GDP","log GDP per capita"),
                     no.space = T,
                     style = "qje",
                     dep.var.labels = c("Revolver Ratio", "Average Number of Revolvers","Revolver Ratio"),
                     type = "text")


