# Appendix D ####
rm(list = ls())
## load package and data
library(tidyverse)
library(haven)
library(panelView)
library(readxl)
library(gridExtra)
library(stargazer)
library(ggpubr)
library(lfe)
library(interflex)


theme_zl <- function(...) {
  theme_pubclean(15) +
    theme(#axis.text.x = element_text(size=15),
      #axis.text.y = element_text(size=15),
      legend.title = element_blank(),
      legend.position="bottom",
      legend.box="vertical",
      legend.margin=margin(),
      #legend.text=element_text(size=15),
      ...
    )}

# load data
final_df = read_dta("/Users/zerenli1992/Dropbox/political_risk/replication_files/pc_df_2022test.dta")
final_df2012 = final_df  %>%  filter(year >2011)


# Table D2####
m2 = felm(n_positive_r ~   pc_f3_dummy + pc_f2_dummy + pc_f1_dummy +
            pc_dummy_1 + pc_dummy_2 +  pc_l1_dummy + pc_l2_dummy  +  pc_l3plus_dummy + size  +incmope_l  + npc + cppcc  + cpc  |symbol + year |0|symbol, final_df %>% filter(year %in% 2012:2016))


flex_vis = function(m1) {
  df =   summary(m1)$coefficients[1:8,1:2] %>% 
    as.data.frame()  %>% 
    mutate(type = "ROA",
           var = var_label) %>% 
    rename(se = `Cluster s.e.`, 
           coef = `Estimate`) %>% 
    tibble() 
  
  df$var = factor(df$var, levels = var_label)
  rect<-data.frame(xstart=c(0,3.5,5.5),xend=c(3.5,5.5,9),col=letters[1:3])
  gtext<-data.frame(txt=c("Will Hire","Currently Hire","Used to Hire"),x=(rect$xstart+rect$xend)/2,y=max(df$coef)*4)
  
  ggplot(df) + 
    geom_pointrange(aes(x =  var, y = coef,  ymax = coef + 1.96*se, ymin = coef -1.96*se))+
    geom_rect(data=rect,aes(xmin=xstart,xmax=xend,ymin=-Inf,ymax=Inf,fill=col),alpha=.2)+
    geom_hline(yintercept=0,linetype = "dashed") + 
    ylab("Estimate of Revolving Door") +
    xlab("")  +
    scale_fill_manual(values=c("grey60","white","grey60"))+
    theme(legend.text=element_text(size=14))+
    guides(fill=F) +
    geom_text(data=gtext,aes(label=txt,x=x,y=y),size=5) + 
    theme_zl()
}

var_label <-c("In 3\n years" ,
              "In 2\n years",
              "In 1\n year",
              "For 1\n year",
              "For 2+\n years",
              "1 year\n ago",
              "2 years\n ago",
              "3 years\n ago")

flex_vis(m2)

