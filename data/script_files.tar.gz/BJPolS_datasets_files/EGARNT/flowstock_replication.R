#######################################################################
## Against the Flow: Public Opposition to Immigration Stock and Flow ##
## Yotam Margalit & Omer Solodoch #####################################
## Tel Aviv University, Department of Political Science ###############
## July 2019 ##########################################################
#######################################################################

install.packages("directlabels")
install.packages("readxl")
install.packages("tidyverse")
library(directlabels)
library(readxl)
library(tidyverse)

## Figure 1:
stocks_USA <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig1data.xlsx")
ggplot(data = stocks_USA, aes(x = year, y= num, shape = var)) + 
  geom_line(linetype = 1, size=1.2) +
  geom_point(size = 1.2) +
  scale_y_continuous(name = "Number of Immigrants (in thousands)", limits=c(0,12000),
                     breaks = seq(0, 12000, 2000)) +
  scale_x_continuous(name = "", limits=c(2000,2017),
                     breaks = seq(2000,2016, 5)) +
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(), panel.grid.minor.x = element_blank())+
  theme(legend.position = "none") +
  geom_dl(aes(label = var), method = list(dl.trans(x=x-1), dl.combine("last.points"), 
                                          vjust=-1, cex = 0.9)) 


## Figure 2a:
stockPa <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig2a_data.xlsx")
ggplot(data = stockPa, aes(x = as.factor(Treatment), y = Admission)) +
  geom_bar(stat = "identity", alpha = 0.6, col = "black", width=0.6) +
  labs(x = "", y = "Approve Most or All (%)") +
  geom_errorbar(aes(ymin=Admission - 1.96*SE, ymax=Admission + 1.96*SE), 
                lwd=1, width=0) +
  coord_cartesian(ylim=c(15,55)) +
  ggtitle("") + 
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank())

## Figure 2b:
stockPb <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig2b_data.xlsx")
ggplot(stockPb, aes(level, coef)) + 
  geom_hline(yintercept=0, lty=2, lwd=1) +
  geom_errorbar(aes(ymin=coef - 1.96*SE, ymax=coef + 1.96*SE), 
                lwd=1, width=0, color="blue") +
  geom_point(size = 2) +
  ggtitle("") +
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) +
  coord_flip() +
  scale_x_continuous(name = "", breaks = stockPb$level, labels = stockPb$lab,
                     minor_breaks = seq(0, 20, 1)) +
  scale_y_continuous(name = "", limits=c(0,20),
                     minor_breaks = seq(0, 15, 5)) +
  labs(y = "") 

## Figure 3:
stereotypes <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig3_data.xlsx")
ggplot(stereotypes, aes(level, mean, fill=treat)) + 
  geom_vline(xintercept=stereotypes$level, col ="grey") +
  geom_point(stat = "identity", alpha = 0.8,
             position = position_dodge(width = 0.25), size = 2, aes(colour=treat, shape = treat)) +
  geom_errorbar(stat = "identity", alpha = 0.8,
                position = position_dodge(width = 0.25),
                aes(colour=treat, ymin=mean - 1.96*SE, ymax=mean + 1.96*SE), 
                lwd=1, width=0) +
  ggtitle("") +
  theme(plot.title = element_text(size = 10, face = "bold")) +
  coord_flip() +
  scale_x_continuous(name = "", breaks = stereotypes$level, labels = stereotypes$var,
                     minor_breaks = seq(0, 10, 1),
                     sec.axis = sec_axis(~.+0, name = "", breaks = stereotypes$level,
                                         labels = stereotypes$var2)) +
  scale_y_continuous(name = "", limits=c(0,100),
                     minor_breaks = seq(0, 100, 25)) +
  labs(y = "") +
  scale_colour_manual(values=c("black", "gray35")) +
  scale_shape_manual(values=c(16, 17)) +
  theme(legend.title = element_blank(),
        legend.position=c("bottom"))

## Figure 4:
stockP_reason <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig4_data.xlsx")
ggplot(data = stockP_reason, aes(x = treat, y = mean)) +
  geom_bar(stat = "identity", alpha = 0.6, col = "black", width=0.4) +
  labs(x = "", y = "Approve most or all applicants (%)") +
  geom_errorbar(aes(ymin=mean - 1.96*SE, ymax=mean + 1.96*SE), 
                lwd=1, width=0) +
  coord_cartesian(ylim=c(30,70)) +
  scale_x_continuous(name = "", breaks = stockP_reason$treat, labels = stockP_reason$group) +
  ggtitle("") + 
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) +
  facet_grid(~reason)

## Figure 5:
skillP1 <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig5_data.xlsx")
ggplot(skillP1, aes(level, coef)) + 
  geom_hline(yintercept=0, lty=2, lwd=0.5) +
  geom_errorbar(aes(ymin=coef - 1.645*SE, ymax=coef + 1.645*SE),
                lwd=1.3, width=0) +
  geom_errorbar(aes(ymin=coef - 1.96*SE, ymax=coef + 1.96*SE), 
                lwd=0.7, width=0) +
  geom_point(size = 2.4) +
  ggtitle("") +
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) +
  coord_flip() +
  scale_x_continuous(name = "", breaks = skillP1$level, labels = skillP1$outcome,
                     minor_breaks = seq(0, 5, 1)) +
  scale_y_continuous(name = "", limits=c(-0.1,0.1),
                     minor_breaks = seq(-0.1, 0.1, 0.1)) +
  labs(y = "") 

## Figure 6
skillP2 <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig6_data.xlsx")
ggplot(data = skillP2, aes(x = skill, y = mean)) +
  geom_bar(stat = "identity", alpha = 0.6, col = "black", width=0.4) +
  labs(x = "", y = "Approve most or all applicants (%)") +
  geom_errorbar(aes(ymin=mean - 1.96*SE, ymax=mean + 1.96*SE), 
                lwd=1, width=0) +
  scale_y_continuous(limit=c(0,70)) +
  scale_x_continuous(name = "", breaks = skillP2$skill, labels = skillP2$skillab) +
  ggtitle("") + 
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) +
  facet_grid(~location)

## Figure 7:
cjoint_inter <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig7_data.xlsx")
ggplot(cjoint_inter, aes(LEVEL, coef, col=Effect)) + 
  geom_hline(yintercept=0, lty=2, lwd=1) +
  geom_errorbar(stat = "identity", alpha = 0.8,
                position = position_dodge(width = 0.05),
                aes(colour=Effect, ymin=coef - 1.645*SE, ymax=coef + 1.645*SE), 
                lwd=1.3, width=0) +
  geom_errorbar(stat = "identity", alpha = 0.8,
                position = position_dodge(width = 0.05),
                aes(colour=Effect, ymin=coef - 1.96*SE, ymax=coef + 1.96*SE),
                lwd=0.7, width=0) +
  geom_point(stat = "identity", alpha = 0.8,
             position = position_dodge(width = 0.05), 
             size = 2, aes(colour=Effect, shape = Effect)) +
  ggtitle("") +
  theme(plot.title = element_text(size = 10, face = "bold"),
        axis.text.y = element_text(face = c('bold', 'plain', 'plain', 
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain','plain','plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain','plain','plain','plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain'))) +
  coord_flip() +
  scale_x_continuous(name = "", breaks = cjoint_inter$LEVEL, labels = cjoint_inter$lab,
                     minor_breaks = seq(0, 6, 1)) +
  scale_y_continuous(name = "", limits=c(-0.6,0.6),
                     minor_breaks = seq(-1, 1, 0.1)) +
  scale_color_manual(values=c("black", "grey54")) +
  labs(y = "") 


###### Figure 8:
ANES_2018_bars <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_Fig8_data.xlsx")
ggplot(data = ANES_2018_bars, aes(x = Level, y = Mean)) +
  geom_bar(stat = "identity", alpha = 0.6, col = "black", width=0.08) +
  labs(x = "", y = "Support Policy (%)") +
  geom_errorbar(aes(ymin=Mean - 1.96*SE, ymax=Mean + 1.96*SE), 
                lwd=1, width=0) +
  coord_cartesian(ylim=c(0,100)) +
  scale_x_continuous(name = "", breaks = ANES_2018_bars$Level, labels = ANES_2018_bars$Trump) +
  ggtitle("") + 
  theme(plot.title = element_text(size = 10, face = "bold"),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()) +
  facet_grid(~Policy)


####################### Supporting Information
## Figure A2:
stockP_gr <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_FigA2_data.xlsx")
ggplot(stockP_gr, aes(level, Admission, col=Treatment)) + 
  geom_point(size = 2) +
  ggtitle("") +
  coord_flip() +
  scale_x_continuous(name = "", breaks = stockP_gr$level, labels = stockP_gr$Group,
                     minor_breaks = seq(20, 70, 1)) +
  scale_y_continuous(name = "Approve most or all (%)", limits=c(20,70),
                     minor_breaks = seq(0, 10, 5)) +
  scale_color_manual(values=c("black", "grey54"))

######### Figure A3:
cjoint_inter2 <- read_excel("C:/Users/LENOVO/Documents/R/data/flows_FigA3_data.xlsx")
ggplot(cjoint_inter2, aes(LEVEL, coef, col=Effect)) + 
  geom_hline(yintercept=0, lty=2, lwd=1) +
  geom_errorbar(stat = "identity", alpha = 0.8,
                position = position_dodge(width = 0.05),
                aes(colour=Effect, ymin=coef - 1.645*SE, ymax=coef + 1.645*SE), 
                lwd=1.3, width=0) +
  geom_errorbar(stat = "identity", alpha = 0.8,
                position = position_dodge(width = 0.05),
                aes(colour=Effect, ymin=coef - 1.96*SE, ymax=coef + 1.96*SE),
                lwd=0.7, width=0) +
  geom_point(stat = "identity", alpha = 0.8,
             position = position_dodge(width = 0.05), 
             size = 2, aes(colour=Effect, shape = Effect)) +
  ggtitle("") +
  theme(plot.title = element_text(size = 10, face = "bold"),
        axis.text.y = element_text(face = c('bold', 'plain', 'plain', 
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain','plain','plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain','plain','plain','plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain',
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain',
                                            'bold', 'plain','plain','plain','plain','plain'))) +
  coord_flip() +
  scale_x_continuous(name = "", breaks = cjoint_inter2$LEVEL, labels = cjoint_inter2$lab,
                     minor_breaks = seq(0, 6, 1)) +
  scale_y_continuous(name = "", limits=c(-0.6,0.6),
                     minor_breaks = seq(-1, 1, 0.1)) +
  labs(y = "") +
  scale_color_manual(values=c("black", "grey54")) +
  facet_grid(~facet)


