abstentions.include <- F

## Load Libraries ##

vcovCluster <- function(
                        model,
                        cluster
                        )
  {
require(sandwich)
require(lmtest)
if(nrow(model.matrix(model))!=length(cluster)){
  stop("check your data: cluster variable has different N than model")
}
M <- length(unique(cluster))
N <- length(cluster)           
K <- model$rank   
if(M<50){
  warning("Fewer than 50 clusters, variances may be unreliable (could try block bootstrap instead).")
}
dfc <- (M/(M - 1)) * ((N - 1)/(N - K))
uj  <- apply(estfun(model), 2, function(x) tapply(x, cluster, sum));
rcse.cov <- dfc * sandwich(model, meat = crossprod(uj)/N)
return(rcse.cov)
}

library(ggplot2)
library(reshape2)
library(data.table)
library(stargazer)

## Load Data ##

load(file="EP7rollcalls.Rdata")

## For each vote, did a given national party have any defections?

## Output should be, for each national party, on each vote, was there at least one defection?

nmeps <- dim(EUVoteTextData$RollCall)[1]
nvotes <- dim(EUVoteTextData$RollCall)[2]

roll.call.matrix <- matrix(NA,nmeps,nvotes)

for (j in 1:nvotes){
	roll.call.matrix[,j] <- replace(roll.call.matrix[,j],as.character(EUVoteTextData$RollCall[,j]) == "For",1)
	roll.call.matrix[,j] <- replace(roll.call.matrix[,j],as.character(EUVoteTextData$RollCall[,j]) == "Against",0)
if(abstentions.include) 	roll.call.matrix[,j] <- replace(roll.call.matrix[,j],as.character(EUVoteTextData$RollCall[,j]) == "Abstain",2)
	}

roll.call.matrix <- data.table(roll.call.matrix)

EUVoteTextData$RollCall <- data.table(EUVoteTextData$RollCall)
EUVoteTextData$VoterData <- data.table(EUVoteTextData$VoterData)
EUVoteTextData$VoteData <- data.table(EUVoteTextData$VoteData)

roll.call.matrix <- cbind(paste(EUVoteTextData$VoterData$Country,EUVoteTextData$VoterData$NationalParty, sep="-"),roll.call.matrix)

setnames(roll.call.matrix,1,"Party")

out <- roll.call.matrix[,lapply(.SD,function(x) length(unique(x[!is.na(x)]))),by="Party"]

party.defection <- melt(out,id.vars="Party")

party.defection$value[party.defection$value==0] <- NA
party.defection$value[party.defection$value==1] <- FALSE
party.defection$value[party.defection$value==2] <- TRUE
if(abstentions.include) party.defection$value[party.defection$value==3] <- TRUE

## Are parties from open-list systems more likely to suffer defections?

EUVoteTextData$VoterData$Partymerge <- paste(EUVoteTextData$VoterData$Country,EUVoteTextData$VoterData$NationalParty, sep="-")

details <- EUVoteTextData$VoterData[,
					list(
					Country=unique(Country),
					Party=unique(NationalParty),
					nmeps=length(unique(Name))
					),
					by=Partymerge
					]

setnames(party.defection,"Party","Partymerge")
setkey(details,Partymerge)
setkey(party.defection, Partymerge)

test <- merge(party.defection,details)

open.list.broad <- c("Austria","Belgium","Bulgaria","Cyprus","Czech Republic","Denmark","Estonia","Finland","Ireland","Italy","Latvia","Lithuania","Luxembourg","Malta","Netherlands","Poland","Slovakia","Slovenia","Sweden")

#open.list.narrow <- c("Cyprus","Czech Republic","Denmark","Estonia","Finland","Ireland","Italy","Latvia","Lithuania","Luxembourg","Malta","Poland")

test$open<-F
test$open[test$Country%in% open.list.broad] <- T

# TABLE 3
model <- glm(value ~ open + nmeps,data=test,family="binomial")

# Cluster errors on country
# st.ers <- sqrt(diag(vcovCluster(model,test$Country[-model$na.action])))
# stargazer(model,se=list(st.ers))

stargazer(model,report="vct")
