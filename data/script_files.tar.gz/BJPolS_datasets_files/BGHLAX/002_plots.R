library(ggplot2)
library(foreign)
library(reshape2)
library(weights)
library(plyr)

# DEFINE MANUALE BASE THEME

BaseThemeX90 <- function(base_size = 14) {
  structure(list(
    axis.line =         theme_blank(),
    axis.text.x =       theme_text(size = base_size , colour = "black",  hjust = .5 , vjust=1),
    axis.text.y =       theme_text(size = base_size , colour = "black", hjust = 0 , vjust=.5 ), # changes position of X axis text
    axis.ticks =        theme_segment(colour = "grey50"),
    axis.title.x =      theme_text(size = base_size, hjust = .85), # changes position of Y axis label
    axis.title.y =      theme_text(size = base_size,angle=90,vjust=.01,hjust=.1),
    legend.background = theme_rect(colour=NA),
    legend.key =        theme_rect(fill = "grey95", colour = "white"),
    #  legend.key.size =   unit(1.2, "lines"),
    legend.text =       theme_text(size = base_size ),
    legend.title =      theme_text(size = base_size , face = "bold", hjust = 0),
    legend.position =   "right"  ), class = "options")
}

setwd("//Users/hangartn/Dropbox/List Survey Experiment/ReplicationArchive")

# FIGURE 4 lineplot_info_bw.pdf

d <- read.dta("ers_experiment.dta")
d <- subset(d, treatment=="closed-list / with information" | treatment=="open-list / with information")
d$treatment <- factor(d$treatment, exclude = c(1,3) )
df1 <- melt(ddply(d,.(treatment),function(x){wpct(x$partyvote, weight=x$w8)[c(3,5,1,2,4)]}),id.vars = 1)

pos.mat = rbind(c(df1$value[1],df1$value[2]), c(df1$value[3],df1$value[4]), c(df1$value[5],df1$value[6]), c(df1$value[7],df1$value[8]), c(df1$value[9],df1$value[10]))
rownames(pos.mat) = c("LAB", "UKIP", "CON", "GRN", "LD")
full.names = c("LAB", "UKIP",  "CON", "GRN", "LD.")
partycolors <- c("#DC241f" ,"#B7009D", "#0087DC","#6AB023","#FDBB30")
partycolors <- c(grey(.6),grey(.5),grey(.4),grey(.3),grey(.2)) 

name.y = .007 
name.ys = c(name.y, name.y, -name.y - .002, -name.y, name.y)

marg = .2
name.marg = 0
change.marg = .15

colnames(pos.mat) = c("Closed-list with info", "Open-list with info")

p = ggplot(data=df1, aes(treatment, value, colour=variable, shape=variable))
p = p + geom_point(size=I(4))
p = p + scale_colour_manual(values = partycolors)
p = p + labs(colour=" ") 
p = p + scale_y_continuous('Party vote shares')
for(i in seq(from = 1, to = 9, by = 2)){
  the.change = round(df1$value[i+1]-df1$value[i], 2)
  p = p + annotate("text", x=2.25, y=df1$value[i+1], label=paste(ifelse(the.change > 0, "+", ""), the.change, sep = ""), color=partycolors[round((1+i)/2)], size=6)
}
p <- p + geom_segment(aes(x= (1+ 0.05), y = (df1$value[1]+((df1$value[2]-df1$value[1])/1)*0.05), xend= (2-0.05), yend=(df1$value[2]-((df1$value[2]-df1$value[1])/1)*0.05)), size=1, colour=partycolors[round((1+1)/2)], lineend="round") 
p <- p + geom_segment(aes(x= (1+ 0.05), y = (df1$value[3]+((df1$value[4]-df1$value[3])/1)*0.05), xend= (2-0.05), yend=(df1$value[4]-((df1$value[4]-df1$value[3])/1)*0.05)), size=1, colour=partycolors[round((1+3)/2)], lineend="round") 
p <- p + geom_segment(aes(x= (1+ 0.05), y = (df1$value[5]+((df1$value[6]-df1$value[5])/1)*0.05), xend= (2-0.05), yend=(df1$value[6]-((df1$value[6]-df1$value[5])/1)*0.05)), size=1, colour=partycolors[round((1+5)/2)], lineend="round") 
p <- p + geom_segment(aes(x= (1+ 0.05), y = (df1$value[7]+((df1$value[8]-df1$value[7])/1)*0.05), xend= (2-0.05), yend=(df1$value[8]-((df1$value[8]-df1$value[7])/1)*0.05)), size=1, colour=partycolors[round((1+7)/2)], lineend="round") 
p <- p + geom_segment(aes(x= (1+ 0.05), y = (df1$value[9]+((df1$value[10]-df1$value[9])/1)*0.05), xend= (2-0.05), yend=(df1$value[10]-((df1$value[10]-df1$value[9])/1)*0.05)), size=1, colour=partycolors[round((1+9)/2)], lineend="round") 
p <- p + scale_x_discrete(name=" ", breaks=c("closed-list / with information", "open-list / with information"), labels=c("Closed list", "Open list") )
p = p + theme(axis.text.x = element_text(colour="black", size=12))
p = p + scale_shape_manual(values = c(16,17,15,18,8))
p = p + labs(color=" ")
p = p + labs(shape=" ")
print(p)

dev.off()
pdf("../results/figs/lineplot_info_bw.pdf",width=8,height=9)
print(p)
dev.off()

# FIGURE 5 ciplot_info_bw.pdf


d <- read.dta("parmest2.dta")

d$voter <- factor(c(
  "GRN voting GRN      ","GRN voting LAB      ","GRN voting LD      ", "GRN voting CON      ","GRN voting UKIP      ",
  "LAB voting GRN      ","LAB voting LAB      ","LAB voting LD      ", "LAB voting CON      ","LAB voting UKIP      ",
  "LD voting GRN      ","LD voting LAB      ","LD voting LD      ","LD voting CON      ","LD voting UKIP      ",
  "CON voting GRN      ","CON voting LAB      ","CON voting LD      ","CON voting CON      ","CON voting UKIP      ",
  "UKIP voting GRN      ","UKIP voting LAB      ","UKIP voting LD      ","UKIP voting CON      ","UKIP voting UKIP      "))


d$order <- 1:nrow(d)
d <- d[order(d$order),]

dd <- data.frame(voter= c(
  "GRN identifiers:      ",
  "    ",
  "LAB identifiers:      ",
  "  ",
  "LD identifiers:       ",
  "   ",   
  "CON identifiers:      ",
  " ",
  "UKIP identifiers:     "
), idnum=NA, parm=NA, label=NA, estimate=100,stderr=0, dof=NA, t=NA, p=NA, min95=100,max95=100, order=c(.5,5.1,5.5,10.1,10.5,15.1,15.5,20.1,20.5)
)

d <- rbind(d,dd)
d <-d[order(d$order),]
d$voter <- factor(d$voter,levels=unique(d$voter)[length(d$voter):1])

partycolors <- c("#0087DC" , "#6AB023","#DC241f","#FDBB30",  "#B7009D")
# greyscale
partycolors <- c(grey(.6),grey(.5),grey(.4),grey(.3),grey(.2)) 

d$Party <- factor(c(NA,"GRN","LAB","LD","CON","UKIP",NA,NA,"GRN","LAB","LD","CON","UKIP",NA,NA,
                    "GRN","LAB","LD","CON","UKIP",NA,NA,"GRN","LAB","LD","CON","UKIP",NA,NA,
                    "GRN","LAB","LD","CON","UKIP"))

yylab <- c("Effect of change from closed list to open list")

p = ggplot(d,aes(y=estimate,x=voter,colour=Party, shape=Party))
p = p + coord_flip(ylim = c(-.225, .225))
p = p + geom_hline(yintercept = 0,size=.5,colour="blue",linetype="dotted")
p = p +geom_pointrange(aes(ymin=min95,ymax=max95,width=.4),position="dodge",size=1)
p = p + scale_y_continuous(name=yylab,breaks=seq(-.5,.5,.1))
#p = p + scale_y_continuous(name=yylab,breaks=seq(-.2,.2,.1),labels=llabels)
p = p + scale_colour_discrete("Party:") + scale_x_discrete(name="")
p = p + scale_color_manual(values=partycolors)
p = p + scale_shape_manual(values = c(16,17,15,18,8))
print(p)

dev.off()
pdf("../results/figs/ciplot_info_bw.pdf",width=7.5,height=10)
p = p + theme(legend.position = "none")
print(p)
dev.off()

# FIGURE 6 ciplot_eu_info_bw.pdf

d <- read.dta("parmest.dta")

d$pe <- d$estimate
d$se <- d$stderr
d$lb <- d$min95
d$ub <- d$max95


d$group <- factor(c(rep("pro_eu",2),rep("neutral",2),rep("anti_eu",2)),levels=c("pro_eu","neutral","anti_eu"),labels=c("Pro EU","Neutral","Anti EU"))
d$Party <- factor(rep(c("CON","UKIP"),3),levels=c("CON","UKIP"),labels=c("Conservative Party","UK Independence Party"))



p = ggplot(d,aes(y=pe,x=group, color=Party, shape=Party))
p = p + scale_color_manual(values=c("#333333", grey(.4)))
p = p + scale_linetype_manual(values=c("dotdash", "dotted"))
p = p +  geom_hline(yintercept = 0,size=1,colour="black",linetype="dotted")
p = p +geom_pointrange(aes(ymin=lb,ymax=ub,width=.5),position= position_dodge(width=+.5),size=1)
p = p + scale_y_continuous(name="Effect of change from closed list to open list") 
p = p + scale_x_discrete(name="\n Voters' stance on European integration") 
p = p + labs(color=" ")
p = p + labs(shape=" ")
p = p + theme(axis.text.x = element_text(colour="black", size=12))
print(p)



dev.off()
pdf("../results/figs/ciplot_eu_info_bw.pdf",width=8,height=8)
print(p)
dev.off()

# FIGURE S11 balance_bw.pdf

d <- read.dta("balance.dta")
x <- seq(0,1,length.out=22)
pdf("../results/figs/balance_bw.pdf",width=8,height=8)
plot(x,d$pvalue,xlab="Uniform Distribution",ylab="p-values", pch=19)
abline(c(0,0),c(1,1), col = grey(.4), lty="dashed")
pointLabel(x,d$pvalue, labels = paste("  ", d$covariates, "  ", sep=""), cex=0.7, col = grey(.4))
dev.off()

# FIGURE S12 lineplot_allparties2_bw.pdf

setwd("//Users/hangartn/Dropbox/List Survey Experiment/data")

# main plot: treatmen 1 vs 4 , no lines

d <- read.dta("ers_experiment.dta")

d$treatment <- factor(d$treatment,levels(d$treatment)[c(1,3,2,4)])

df1 <- melt(ddply(d,.(treatment),function(x){wpct(x$partyvote, weight=x$w8)[c(3,5,1,2,4)]}),id.vars = 1)


pos.mat = rbind(c(df1$value[1],df1$value[2],df1$value[3],df1$value[4]), c(df1$value[5],df1$value[6],df1$value[7],df1$value[8]), 
                c(df1$value[9],df1$value[10],df1$value[11],df1$value[12]),c(df1$value[13],df1$value[14],df1$value[15],df1$value[16]),
                c(df1$value[17],df1$value[18],df1$value[19],df1$value[20]))
rownames(pos.mat) = c("LAB", "UKIP", "CON", "GRN", "LD")
full.names = c("LAB", "UKIP",  "CON", "GRN", "LD")
partycolors <- c("#DC241f" ,"#B7009D", "#0087DC","#6AB023","#FDBB30")
# greyscale
partycolors <- rev(c("#333333","#4D4D4D", "#808080","#B3B3B3","white")) 

name.y = .007 
name.ys = c(name.y, name.y, -name.y - .002, -name.y, name.y)

marg = .2
name.marg = 0
change.marg = .15

colnames(pos.mat) = c("Closed list, no info","Open list, no info", "Closed list with info", "Open list with info")

p = ggplot(data=df1, aes(treatment, value))
p = p + aes(shape = variable) + geom_point(aes(color = variable), size = 6)
p = p + scale_colour_manual(values = partycolors)
p = p + scale_shape_manual(values = c(16,17,15,18,8))

p = p + labs(colour=" ")
p = p + labs(shape=" ") 
p = p + scale_y_continuous('Party vote shares')

p <- p + scale_x_discrete(name=" ", breaks=c("closed-list / no information", "open-list / no information", "closed-list / with information", "open-list / with information"), 
                          labels=c("Closed list, no info", "Open list, no info", "Closed list with info", "Open list with info") )
p = p + theme(axis.text.x = element_text(colour="black", size=12))

print(p)
p = p   + opts(legend.position = "none")
print(p)

dev.off()
pdf("../results/figs/lineplot_allparties2_bw.pdf",width=12,height=9)
print(p)
dev.off()

