#Replication Files Expertise Paradox
library(foreign);library(multiwayvcov); 
library(readstata13); library(interplot); library(stargazer)

#Study 1 data
setwd("~/Dropbox/Patrik_Miguel/replication_files")
po<-read.csv('pp13.csv',stringsAsFactors = F)

#Study 2 data
pot<-read.csv('pp14.csv',stringsAsFactors = F)



#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table 1
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

prop.table(table(po$health_support))
prop.table(table(po$educ_support))
prop.table(table(po$refugees_support))
prop.table(table(po$begging_support))
prop.table(table(po$housing_support))

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure 1
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

m1<-lm(underst_complexity~expert+educ+age+party,po)
m2<-lm(strong_opinion~expert+educ+age+party,po)
m3<-lm(facts~expert+educ+age+party,po)
m4<-lm(majority_opinion~expert+educ+age+party,po)

main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

dev.off()
par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure 2 - Drop-one analysis
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

#Complexity models
comp2<-lm(underst_complexity~expert+educ+age+party,po[po$issue!='educ',])
comp3<-lm(underst_complexity~expert+educ+age+party,po[po$issue!='health',])
comp4<-lm(underst_complexity~expert+educ+age+party,po[po$issue!='social_sec',])
comp5<-lm(underst_complexity~expert+educ+age+party,po[po$issue!='integration',])
comp6<-lm(underst_complexity~expert+educ+age+party,po[po$issue!='housing',])

comp_ests<-c(coef(comp2)[2],
             coef(comp3)[2],
             coef(comp4)[2],
             coef(comp5)[2],
             coef(comp6)[2])
comp_ses<-c(sqrt(vcov(comp2)[2,2]),
            sqrt(vcov(comp3)[2,2]),
            sqrt(vcov(comp4)[2,2]),
            sqrt(vcov(comp5)[2,2]),
            sqrt(vcov(comp6)[2,2]))



#Facts-based models
f2<-lm(facts~expert+educ+age+party,po[po$issue!='educ',])
f3<-lm(facts~expert+educ+age+party,po[po$issue!='health',])
f4<-lm(facts~expert+educ+age+party,po[po$issue!='social_sec',])
f5<-lm(facts~expert+educ+age+party,po[po$issue!='integration',])
f6<-lm(facts~expert+educ+age+party,po[po$issue!='housing',])

f_ests<-c(coef(f2)[2],
          coef(f3)[2],
          coef(f4)[2],
          coef(f5)[2],
          coef(f6)[2])
f_ses<-c(sqrt(vcov(f2)[2,2]),
         sqrt(vcov(f3)[2,2]),
         sqrt(vcov(f4)[2,2]),
         sqrt(vcov(f5)[2,2]),
         sqrt(vcov(f6)[2,2]))

#Strong opinion models
s2<-lm(strong_opinion~expert+educ+age+party,po[po$issue!='educ',])
s3<-lm(strong_opinion~expert+educ+age+party,po[po$issue!='health',])
s4<-lm(strong_opinion~expert+educ+age+party,po[po$issue!='social_sec',])
s5<-lm(strong_opinion~expert+educ+age+party,po[po$issue!='integration',])
s6<-lm(strong_opinion~expert+educ+age+party,po[po$issue!='housing',])

s_ests<-c(coef(s2)[2],
          coef(s3)[2],
          coef(s4)[2],
          coef(s5)[2],
          coef(s6)[2])
s_ses<-c(sqrt(vcov(s2)[2,2]),
         sqrt(vcov(s3)[2,2]),
         sqrt(vcov(s4)[2,2]),
         sqrt(vcov(s5)[2,2]),
         sqrt(vcov(s6)[2,2]))

#Majority models
ma2<-lm(majority_opinion~expert+educ+age+party,po[po$issue!='educ',])
ma3<-lm(majority_opinion~expert+educ+age+party,po[po$issue!='health',])
ma4<-lm(majority_opinion~expert+educ+age+party,po[po$issue!='social_sec',])
ma5<-lm(majority_opinion~expert+educ+age+party,po[po$issue!='integration',])
ma6<-lm(majority_opinion~expert+educ+age+party,po[po$issue!='housing',])

ma_ests<-c(coef(ma2)[2],
           coef(ma3)[2],
           coef(ma4)[2],
           coef(ma5)[2],
           coef(ma6)[2])
ma_ses<-c(sqrt(vcov(ma2)[2,2]),
          sqrt(vcov(ma3)[2,2]),
          sqrt(vcov(ma4)[2,2]),
          sqrt(vcov(ma5)[2,2]),
          sqrt(vcov(ma6)[2,2]))

cls<-c('purple1','firebrick2','gold','green2','dodgerblue1')
par(mar=c(4,11,2,1))
plot(c(-.6,.6), c(3,7), xlim=c(-.6,.45), ylab='',ylim=c(2.7,6.6), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)

#Complexity
ys <- rev(c(6,6.1,6.2,6.3,6.4))
for (i in 1:5){
  segments(comp_ests[i]-1.96*comp_ses[i],ys[i], comp_ests[i]+1.96*comp_ses[i],ys[i], col=cls[i])
  segments(comp_ests[i]-1.65*comp_ses[i],ys[i], comp_ests[i]+1.65*comp_ses[i],ys[i], col=cls[i],lwd=2)
  points(comp_ests[i], ys[i], pch=20, col=cls[i])
}

#Facts
ys <- rev(c(5,5.1,5.2,5.3,5.4))
for (i in 1:5){
  segments(f_ests[i]-1.96*f_ses[i],ys[i], f_ests[i]+1.96*f_ses[i],ys[i], col=cls[i])
  segments(f_ests[i]-1.65*f_ses[i],ys[i], f_ests[i]+1.65*f_ses[i],ys[i], col=cls[i],lwd=2)
  points(f_ests[i], ys[i], pch=20, col=cls[i])
}

#Strong opinion
ys <- rev(c(4,4.1,4.2,4.3,4.4))
for (i in 1:5){
  segments(s_ests[i]-1.96*s_ses[i],ys[i], s_ests[i]+1.96*s_ses[i],ys[i], col=cls[i])
  segments(s_ests[i]-1.65*s_ses[i],ys[i], s_ests[i]+1.65*s_ses[i],ys[i], col=cls[i],lwd=2)
  points(s_ests[i], ys[i], pch=20, col=cls[i])
}

#Majority
ys <- rev(c(3,3.1,3.2,3.3,3.4))
for (i in 1:5){
  segments(ma_ests[i]-1.96*ma_ses[i],ys[i], ma_ests[i]+1.96*ma_ses[i],ys[i], col=cls[i])
  segments(ma_ests[i]-1.65*ma_ses[i],ys[i], ma_ests[i]+1.65*ma_ses[i],ys[i], col=cls[i],lwd=2)
  points(ma_ests[i], ys[i], pch=20, col=cls[i])
}

#Pooled
ys <- rev(c(2.9,3.9,4.9,5.9))
for (i in 1:5){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}

ys <- rev(c(3.25,4.25,5.25,6.25))
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts','The voters hold a\nstrong opinion','Opinion aligned with\nthe majority of voters'),
     las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))

legend('topright',title='Issue dropped', c('Education', 'Healthcare','Social welfare','Immigration','Housing','None'),ncol = 1,bty='n',cex=.8,
       col=c(cls,'black'), lty=1,pch=20,title.adj = 0)


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure 3 - Effects by form of expertise
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
po$tenure_bin<-ifelse(po$tenure<5,0,1)

# # # PANEL A
cpl_college_degree<-lm(underst_complexity~expert*college_degree+party+age+tenure_bin,po)
cpl_educ<-interplot(cpl_college_degree,'expert','college_degree')
cpl_educ90<-interplot(cpl_college_degree,'expert','college_degree',ci=.9)
op_college_degree<-lm(strong_opinion~expert*college_degree+party+age+tenure_bin,po)
op_educ<-interplot(op_college_degree,'expert','college_degree')
op_educ90<-interplot(op_college_degree,'expert','college_degree',ci=.9)
facts_college_degree<-lm(facts~expert*college_degree+party+age+tenure_bin,po)
facts_educ<-interplot(facts_college_degree,'expert','college_degree')
facts_educ90<-interplot(facts_college_degree,'expert','college_degree',ci=.9)
maj_college_degree<-lm(majority_opinion~expert*college_degree+party+age+tenure_bin,po)
maj_educ<-interplot(maj_college_degree,'expert','college_degree')
maj_educ90<-interplot(maj_college_degree,'expert','college_degree',ci=.9)

main_coefs<-c(cpl_educ$data$coef1[1],cpl_educ$data$coef1[2],
              facts_educ$data$coef1[1],facts_educ$data$coef1[2],
              op_educ$data$coef1[1],op_educ$data$coef1[2],
              maj_educ$data$coef1[1],maj_educ$data$coef1[2])

par(mar=c(4,11,1,1))
ys <- rev(c(1.4,1.6,2.9,3.1,4.4,4.6,5.9,6.1))
plot(main_coefs, ys, xlim=c(-.8,.4), ylab='',ylim=c(1.2,6.9), yaxt='n', type='n', 
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
segments(0,6.4,0,0, lty=2)
for (i in 1:8){
  if(i%%2==0){
    points(main_coefs[i], ys[i], pch=20, col='black')
  }
  else{
    points(main_coefs[i], ys[i], pch=20, col='gray')
  }
}
segments(cpl_educ$data$lb[1],ys[1],cpl_educ$data$ub[1],ys[1], col='gray')
segments(cpl_educ$data$lb[2],ys[2],cpl_educ$data$ub[2],ys[2], col='black')
segments(facts_educ$data$lb[1],ys[3],facts_educ$data$ub[1],ys[3], col='gray')
segments(facts_educ$data$lb[2],ys[4],facts_educ$data$ub[2],ys[4], col='black')
segments(op_educ$data$lb[1],ys[5],op_educ$data$ub[1],ys[5], col='gray')
segments(op_educ$data$lb[2],ys[6],op_educ$data$ub[2],ys[6], col='black')
segments(maj_educ$data$lb[1],ys[7],maj_educ$data$ub[1],ys[7], col='gray')
segments(maj_educ$data$lb[2],ys[8],maj_educ$data$ub[2],ys[8], col='black')

segments(cpl_educ90$data$lb[1],ys[1],cpl_educ90$data$ub[1],ys[1], col='gray',lwd=3)
segments(cpl_educ90$data$lb[2],ys[2],cpl_educ90$data$ub[2],ys[2], col='black',lwd=3)
segments(facts_educ90$data$lb[1],ys[3],facts_educ90$data$ub[1],ys[3], col='gray',lwd=3)
segments(facts_educ90$data$lb[2],ys[4],facts_educ90$data$ub[2],ys[4], col='black',lwd=3)
segments(op_educ90$data$lb[1],ys[5],op_educ90$data$ub[1],ys[5], col='gray',lwd=3)
segments(op_educ90$data$lb[2],ys[6],op_educ90$data$ub[2],ys[6], col='black',lwd=3)
segments(maj_educ90$data$lb[1],ys[7],maj_educ90$data$ub[1],ys[7], col='gray',lwd=3)
segments(maj_educ90$data$lb[2],ys[8],maj_educ90$data$ub[2],ys[8], col='black',lwd=3)

ys <- rev(c(1.5,3,4.5,6))
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based\nopinion on facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.8,-.6,-.4,-.2,0,.2,.4))
legend('top',c('No college degree    ', 'College degree'),
       bty='n',ncol=2,cex=.9,col=c('gray','black'),pch=20,lwd=2)


# # # PANEL B
po$tenure_bin<-ifelse(po$tenure<5,0,1)

cpl_tenure_bin<-lm(underst_complexity~expert*tenure_bin+party+age+college_degree,po)
cpl_ten<-interplot(cpl_tenure_bin,'expert','tenure_bin')
cpl_ten90<-interplot(cpl_tenure_bin,'expert','tenure_bin',ci=.9)
op_tenure_bin<-lm(strong_opinion~expert*tenure_bin+party+age+college_degree,po)
op_ten<-interplot(op_tenure_bin,'expert','tenure_bin')
op_ten90<-interplot(op_tenure_bin,'expert','tenure_bin',ci=.9)
facts_tenure_bin<-lm(facts~expert*tenure_bin+party+age+college_degree,po)
facts_ten<-interplot(facts_tenure_bin,'expert','tenure_bin')
facts_ten90<-interplot(facts_tenure_bin,'expert','tenure_bin',ci=.9)
maj_tenure_bin<-lm(majority_opinion~expert*tenure_bin+party+age+college_degree,po)
maj_ten<-interplot(maj_tenure_bin,'expert','tenure_bin')
maj_ten90<-interplot(maj_tenure_bin,'expert','tenure_bin',ci=.9)

main_coefs<-c(cpl_ten$data$coef1[1],cpl_ten$data$coef1[2],
              facts_ten$data$coef1[1],facts_ten$data$coef1[2],
              op_ten$data$coef1[1],op_ten$data$coef1[2],
              maj_ten$data$coef1[1],maj_ten$data$coef1[2])

par(mar=c(4,1,2,1))
ys <- rev(c(1.4,1.6,2.9,3.1,4.4,4.6,5.9,6.1))

plot(main_coefs, ys, xlim=c(-.8,.4), ylab='',ylim=c(1.2,6.9), yaxt='n', type='n', 
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
segments(0,6.4,0,0, lty=2)
for (i in 1:8){
  if(i%%2==0){
    points(main_coefs[i], ys[i], pch=20, col='black')
  }
  else{
    points(main_coefs[i], ys[i], pch=20, col='gray')
  }
}
segments(cpl_ten$data$lb[1],ys[1],cpl_ten$data$ub[1],ys[1], col='gray')
segments(cpl_ten$data$lb[2],ys[2],cpl_ten$data$ub[2],ys[2], col='black')
segments(facts_ten$data$lb[1],ys[3],facts_ten$data$ub[1],ys[3], col='gray')
segments(facts_ten$data$lb[2],ys[4],facts_ten$data$ub[2],ys[4], col='black')
segments(op_ten$data$lb[1],ys[5],op_ten$data$ub[1],ys[5], col='gray')
segments(op_ten$data$lb[2],ys[6],op_ten$data$ub[2],ys[6], col='black')
segments(maj_ten$data$lb[1],ys[7],maj_ten$data$ub[1],ys[7], col='gray')
segments(maj_ten$data$lb[2],ys[8],maj_ten$data$ub[2],ys[8], col='black')

segments(cpl_ten90$data$lb[1],ys[1],cpl_ten90$data$ub[1],ys[1], col='gray',lwd=3)
segments(cpl_ten90$data$lb[2],ys[2],cpl_ten90$data$ub[2],ys[2], col='black',lwd=3)
segments(facts_ten90$data$lb[1],ys[3],facts_ten90$data$ub[1],ys[3], col='gray',lwd=3)
segments(facts_ten90$data$lb[2],ys[4],facts_ten90$data$ub[2],ys[4], col='black',lwd=3)
segments(op_ten90$data$lb[1],ys[5],op_ten90$data$ub[1],ys[5], col='gray',lwd=3)
segments(op_ten90$data$lb[2],ys[6],op_ten90$data$ub[2],ys[6], col='black',lwd=3)
segments(maj_ten90$data$lb[1],ys[7],maj_ten90$data$ub[1],ys[7], col='gray',lwd=3)
segments(maj_ten90$data$lb[2],ys[8],maj_ten90$data$ub[2],ys[8], col='black',lwd=3)

ys <- rev(c(1.5,3,4.5,6))
axis(1,at=c(-.8,-.6,-.4,-.2,0,.2,.4))
legend('top',c('Below median   ', 'Above median'),
       bty='n',ncol=2,cex=.9,col=c('gray','black'),pch=20,lwd=2,y.intersp=0)



#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure 4 - Effects of priming on self-confidence
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
confid_mod<-lm(doubts~treat_expertise+pp14_party+pp14_edu+pp14_age+pp14_age,pot)
waste_mod<-lm(waste_time~treat_expertise+pp14_party+pp14_edu+pp14_age,pot)

main_coefs<-c(coef(confid_mod)[2], coef(waste_mod)[2])
main_SEs<-c(sqrt(vcov(confid_mod)[2,2]), sqrt(vcov(waste_mod)[2,2]))
ys <- rev(c(4.5,6))

dev.off()
par(mar=c(5,12,2,1))
plot(main_coefs, ys, xlim=c(-.6,.4), ylab='',ylim=c(4,6.4), yaxt='n', type='n', cex=.8,
     xlab='Effects of expertise prime',axes = F)
abline(v=0,lty=3)
for (i in 1:2){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('I often have doubts about\nmy own decisions in office',
                       'It is a waste of time to pay\nattention to certain ideas'), las=2, cex=.8,tick=F)
axis(1,at=c(-.6,-.4,-.2,0,.2,.4))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Appendix B
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table B1 - Descriptives
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
pot$pp14_finished<-as.character(pot$pp14_finished)
po$w14<-NA
for (i in po$idnr){
  po$w14[po$idnr==i]<-ifelse(i %in% pot$idnr[pot$pp14_finished=='True'], 1,0)
}

#Age
summary(po$age) #Wave 13
summary(po$age[po$w14==1]) #Wave 14

#Gender
prop.table(table(po$female)) #Wave 13
prop.table(table(po$female[po$w14==1])) #Wave 14

#Education
prop.table(table(po$college_degree)) #Wave 13
prop.table(table(po$college_degree[po$w14==1])) #Wave 14

#Party
sort(round(prop.table(table(po$party)),3),decreasing=T) #Wave 13
sort(round(prop.table(table(po$party[po$w14==1])),3),decreasing=T) #Wave 14

#Level of government
prop.table(table(pst$local)) # Wave 13
prop.table(table(pst$local[po$w14==1])) #Wave 14
prop.table(table(pst$regional)) #Wave 13
prop.table(table(pst$regional[po$w14==1])) #Wave 14
prop.table(table(pst$national)) #Wave 13
prop.table(table(pst$national[po$w14==1])) #Wave 14


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table B2 - Issue areas by high/low expertise
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
prop.table(table(po$issue_high_expertise))
prop.table(table(po$issue_low_expertise))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Appendix C
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table C1 - Main effects study 1
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
# # Plain
m1p<-lm(underst_complexity~expert,po)
m2p<-lm(strong_opinion~expert,po)
m3p<-lm(facts~expert,po)
m4p<-lm(majority_opinion~expert,po)

stargazer(m1p,m1,m3p,m3,m2p,m2,m4p,m4,
          no.space=T,digits=2,
          covariate.labels=c('Policy Expertise',
                             'Educational Level',
                             'Age',
                             'Social Democrats',
                             'Centre Party',
                             'Liberals',
                             'Moderate Party',
                             'Christian Democrats',
                             'Green Party',
                             'Sweden Democrats',
                             'Feminist Initiative',
                             'Other Party'),
          star.cutoffs = c(.10,0.05, 0.01))

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table C2 - Effects by formal expertise
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

stargazer(cpl_college_degree,facts_college_degree,op_college_degree,maj_college_degree,
          no.space=T,digits=2,
          covariate.labels=c('Expertise',
                             'College Degree',
                             'Social Democrats',
                             'Centre Party',
                             'Liberals',
                             'Moderate Party',
                             'Christian Democrats',
                             'Green Party',
                             'Sweden Democrats',
                             'Feminist Initiative',
                             'Other Party',
                             'Age',
                             'Experience in Office',
                             'Expertise $\times$ College Degree'),
          star.cutoffs = c(.10,0.05, 0.01))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table C3 - Effects by informal expertise
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

stargazer(cpl_tenure_bin,facts_tenure_bin,op_tenure_bin,maj_tenure_bin,
          no.space=T,digits=2,
          covariate.labels=c('Expertise',
                             'Experience in Office',
                             'Social Democrats',
                             'Centre Party',
                             'Liberals',
                             'Moderate Party',
                             'Christian Democrats',
                             'Green Party',
                             'Sweden Democrats',
                             'Feminist Initiative',
                             'Other Party',
                             'Age',
                             'College Degree',
                             'Expertise $\times$ Experience in Office'),
          star.cutoffs = c(.10,0.05, 0.01))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table C4 - Study 2 main results table
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

stargazer(confid_mod,waste_mod,
          no.space=T,digits=2,star.cutoffs = c(.10,0.05, 0.01))



#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Appendix D
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D1 - Main effects without covariate adjustment
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
main_coefs<-c(coef(m1p)[2], coef(m3p)[2], coef(m2p)[2], coef(m4p)[2])
main_SEs<-c(sqrt(vcov(m1p)[2,2]), sqrt(vcov(m3p)[2,2]),sqrt(vcov(m2p)[2,2]),sqrt(vcov(m4p)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

dev.off()
par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D2 - Main effects accounting for opinion/majority alignment
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
po$voters_position<-ifelse(po$issue=='educ',abs(1-po$educ_support),
                           ifelse(po$issue=='health',abs(1-po$health_support),
                                  ifelse(po$issue=='integration',abs(1-po$refugees_support),
                                         ifelse(po$issue=='social_sec',abs(1-po$begging_support),
                                                ifelse(po$issue=='housing',abs(1-po$housing_support),NA)))))

po$voters_aligned_w_majority<-ifelse(po$issue=='educ',ifelse(po$voters_position==0,1,0),
                                     ifelse(po$issue=='health',ifelse(po$voters_position==1,1,0),
                                            ifelse(po$issue=='integration',ifelse(po$voters_position==1,1,0),
                                                   ifelse(po$issue=='social_sec',ifelse(po$voters_position==1,1,0),
                                                          ifelse(po$issue=='housing',ifelse(po$voters_position==0,1,0),NA)))))

m1<-lm(underst_complexity~expert+voters_aligned_w_majority+educ+age+party,po)
m2<-lm(strong_opinion~expert+voters_aligned_w_majority+educ+age+party,po)
m3<-lm(facts~expert+voters_aligned_w_majority+educ+age+party,po)
m4<-lm(majority_opinion~expert+voters_aligned_w_majority+educ+age+party,po)

main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D3 - Effect w selected issue FEs
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
m1fe<-lm(underst_complexity~expert+party+educ+age+as.factor(issue),po)
m2fe<-lm(strong_opinion~expert+party+educ+age+as.factor(issue),po)
m3fe<-lm(facts~expert+party+educ+age+as.factor(issue),po)
m4fe<-lm(majority_opinion~expert+party+educ+age+as.factor(issue),po)

cse_m1 <- sqrt(diag(cluster.vcov(m1fe, po$issue)))
cse_m2 <- sqrt(diag(cluster.vcov(m2fe, po$issue)))
cse_m3 <- sqrt(diag(cluster.vcov(m3fe, po$issue)))
cse_m4 <- sqrt(diag(cluster.vcov(m4fe, po$issue)))
main_SEs<-c(cse_m1[2],cse_m3[2],cse_m2[2],cse_m4[2])

main_coefs<-c(coef(m1fe)[2], coef(m3fe)[2], coef(m2fe)[2], coef(m4fe)[2])
main_SEs<-c(sqrt(vcov(m1fe)[2,2]), sqrt(vcov(m3fe)[2,2]),sqrt(vcov(m2fe)[2,2]),sqrt(vcov(m4fe)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

dev.off()
par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D4 - Effects with high-low expertise pairing FEs
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
po$policy_combo<-paste(po$issue_low_expertise,po$issue_high_expertise,sep="_")

m1<-lm(underst_complexity~expert+educ+age+party+as.factor(policy_combo),po)
m2<-lm(strong_opinion~expert+educ+age+party+as.factor(policy_combo),po)
m3<-lm(facts~expert+educ+age+party+as.factor(policy_combo),po)
m4<-lm(majority_opinion~expert+educ+age+party+as.factor(policy_combo),po)


main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D5 - Effects accounting for issue salience
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
m1<-lm(underst_complexity~expert+educ+age+party+opinion_intensity,po)
m2<-lm(strong_opinion~expert+educ+age+party+opinion_intensity,po)
m3<-lm(facts~expert+educ+age+party+opinion_intensity,po)
m4<-lm(majority_opinion~expert+educ+age+party+opinion_intensity,po)

main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D6 - Effects accounting for level of government
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
m1<-lm(underst_complexity~expert+educ+age+party+level1,po)
m2<-lm(strong_opinion~expert+educ+age+party+level1,po)
m3<-lm(facts~expert+educ+age+party+level1,po)
m4<-lm(majority_opinion~expert+educ+age+party+level1,po)

main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.6,.3), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))

#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D7 - Effects for local/non-local officials
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
po$local<-ifelse(po$level1=='local',1,0)
po$national<-ifelse(po$level1=='national',1,0)
po$other<-ifelse(po$level1=='other',1,0)

#Local
l1<-lm(underst_complexity~expert+educ+age+party,po[po$local==1,])
l2<-lm(strong_opinion~expert+educ+age+party,po[po$local==1,])
l3<-lm(facts~expert+educ+age+party,po[po$local==1,])
l4<-lm(majority_opinion~expert+educ+age+party,po[po$local==1,])

l_ests<-c(coef(l1)[2],
          coef(l2)[2],
          coef(l3)[2],
          coef(l4)[2])
l_ses<-c(sqrt(vcov(l1)[2,2]),
         sqrt(vcov(l2)[2,2]),
         sqrt(vcov(l3)[2,2]),
         sqrt(vcov(l4)[2,2]))



#Regional and National
n1<-lm(underst_complexity~expert+educ+age+party,po[po$local==0,])
n2<-lm(strong_opinion~expert+educ+age+party,po[po$local==0,])
n3<-lm(facts~expert+educ+age+party,po[po$local==0,])
n4<-lm(majority_opinion~expert+educ+age+party,po[po$local==0,])


n_ests<-c(coef(n1)[2],
          coef(n2)[2],
          coef(n3)[2],
          coef(n4)[2])
n_ses<-c(sqrt(vcov(n1)[2,2]),
         sqrt(vcov(n2)[2,2]),
         sqrt(vcov(n3)[2,2]),
         sqrt(vcov(n4)[2,2]))

par(mar=c(4,11,1,1))
ys <- rev(c(1.6,3.2,4.6,6.1))
plot(l_ests, ys, xlim=c(-.8,.4), ylab='',ylim=c(1.2,8), yaxt='n', type='n', 
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
segments(0,6.4,0,0, lty=3)
for (i in 1:4){
  segments(l_ests[i]-1.96*l_ses[i],ys[i], l_ests[i]+1.96*l_ses[i],ys[i], col='black')
  segments(l_ests[i]-1.65*l_ses[i],ys[i], l_ests[i]+1.65*l_ses[i],ys[i], col='black',lwd=2)
  points(l_ests[i], ys[i], pch=20, col='black')
  segments(n_ests[i]-1.96*n_ses[i],ys[i]-.2, n_ests[i]+1.96*n_ses[i],ys[i]-.2, col='gray')
  segments(n_ests[i]-1.65*n_ses[i],ys[i]-.2, n_ests[i]+1.65*n_ses[i],ys[i]-.2, col='gray',lwd=2)
  points(n_ests[i], ys[i]-.2, pch=20, col='gray')
}

legend('top',title='Local official',c('Yes   ', 'No'),
       bty='n',ncol=2,cex=.9,col=c('black','gray'),pch=20,lwd=2)
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table D1 - Effects conditional on government level
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
l1int<-lm(underst_complexity~expert*local+educ+age+party,po)
l2int<-lm(strong_opinion~expert*local+educ+age+party,po)
l3int<-lm(facts~expert*local+educ+age+party,po)
l4int<-lm(majority_opinion~expert*local+educ+age+party,po)

stargazer(l1int,l2int,l3int,l4int,
          no.space=T,digits=2,
          covariate.labels=c('Expertise',
                             'Local representative',
                             'Education','Age',
                             'Social Democrats',
                             'Centre Party',
                             'Liberals',
                             'Moderate Party',
                             'Christian Democrats',
                             'Green Party',
                             'Sweden Democrats',
                             'Feminist Initiative',
                             'Other Party',
                             'Expertise $\\times$ Local Representative'),
          star.cutoffs = c(.10,0.05, 0.01))



#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D8 - effects by gender
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
m1<-lm(underst_complexity~expert*female+educ+age+party,po)
m2<-lm(strong_opinion~expert*female+educ+age+party,po)
m3<-lm(facts~expert*female+educ+age+party,po)
m4<-lm(majority_opinion~expert*female+educ+age+party,po)


main_coefs_male<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs_male<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys_male <- rev(c(1.4,2.9,4.4,5.9))

main_coefs_female<-c(coef(m1)[2]+coef(m1)[15], coef(m3)[2]+coef(m3)[15], coef(m2)[2]+coef(m2)[15], coef(m4)[2]+coef(m4)[15])
main_SEs_female<-c(sqrt(vcov(m1)[2,2]+vcov(m1)[15,15]+2*vcov(m1)[2,15]), 
                   sqrt(vcov(m3)[2,2]+vcov(m3)[15,15]+2*vcov(m3)[2,15]),
                   sqrt(vcov(m2)[2,2]+vcov(m2)[15,15]+2*vcov(m2)[2,15]),
                   sqrt(vcov(m4)[2,2]+vcov(m4)[15,15]+2*vcov(m4)[2,15]))
ys_female <- rev(c(1.6,3.1,4.6,6.1))


par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.8,.3), ylab='',ylim=c(1.2,6.9), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs_male[i]-1.96*main_SEs_male[i],ys_male[i], main_coefs_male[i]+1.96*main_SEs_male[i],ys_male[i], col='black')
  segments(main_coefs_male[i]-1.65*main_SEs_male[i],ys_male[i], main_coefs_male[i]+1.65*main_SEs_male[i],ys_male[i], col='black',lwd=2)
  points(main_coefs_male[i], ys_male[i], pch=20, col='black')
  
  segments(main_coefs_female[i]-1.96*main_SEs_female[i],ys_female[i], main_coefs_female[i]+1.96*main_SEs_female[i],ys_female[i], col='gray')
  segments(main_coefs_female[i]-1.65*main_SEs_female[i],ys_female[i], main_coefs_female[i]+1.65*main_SEs_female[i],ys_female[i], col='gray',lwd=2)
  points(main_coefs_female[i], ys_female[i], pch=20, col='gray')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.6,-.4,-.2,0,.2))
legend('top',c('Woman    ', 'Man'),
       bty='n',ncol=2,cex=.9,col=c('gray','black'),pch=20,lwd=2)


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Table D2 -- Policy support by expertise domain
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
t.test(po$health_support[po$issue=='health' & po$expert==1],po$health_support[po$issue=='health' & po$expert==0])
t.test(po$educ_support[po$issue=='educ' & po$expert==1],po$educ_support[po$issue=='educ' & po$expert==0])
t.test(po$refugees_support[po$issue=='integration' & po$expert==1],po$refugees_support[po$issue=='integration' & po$expert==0])
t.test(po$begging_support[po$issue=='social_sec' & po$expert==1],po$begging_support[po$issue=='social_sec' & po$expert==0])
t.test(po$housing_support[po$issue=='housing' & po$expert==1],po$housing_support[po$issue=='housing' & po$expert==0])


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D9 - Effects conditional on officials who picked same issue area in both waves
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#Identify subjects in W13 who picked the same issues in broader list in W14
for (i in po$idnr){
  po$agreement_expertise[po$idnr==i]<-pot$agreement_expertise[po$idnr==i]
}

#Now only with those in agreement
m1<-lm(underst_complexity~expert+educ+age+party,po[po$agreement_expertise%in%1,])
m2<-lm(strong_opinion~expert+educ+age+party,po[po$agreement_expertise%in%1,])
m3<-lm(facts~expert+educ+age+party,po[po$agreement_expertise%in%1,])
m4<-lm(majority_opinion~expert+educ+age+party,po[po$agreement_expertise%in%1,])

main_coefs<-c(coef(m1)[2], coef(m3)[2], coef(m2)[2], coef(m4)[2])
main_SEs<-c(sqrt(vcov(m1)[2,2]), sqrt(vcov(m3)[2,2]),sqrt(vcov(m2)[2,2]),sqrt(vcov(m4)[2,2]))
ys <- rev(c(1.5,3,4.5,6))

par(mar=c(4,11,2,1))
plot(main_coefs, ys, xlim=c(-.8,.5), ylab='',ylim=c(1.2,6.3), yaxt='n', type='n', cex=.8,
     xlab='Effects of policy expertise\non the assessment of voters opinion',axes = F)
abline(v=0,lty=3)
for (i in 1:4){
  segments(main_coefs[i]-1.96*main_SEs[i],ys[i], main_coefs[i]+1.96*main_SEs[i],ys[i], col='black')
  segments(main_coefs[i]-1.65*main_SEs[i],ys[i], main_coefs[i]+1.65*main_SEs[i],ys[i], col='black',lwd=2)
  points(main_coefs[i], ys[i], pch=20, col='black')
}
axis(2,at=ys, labels=c('The voters understand\ncomplexity of the issue','The voters based opinion\non facts',
                       'The voters hold\nthis position strongly', 'Opinion aligned with\nthe majority of voters'), las=2, cex=.8)
axis(1,at=c(-.8,-.6,-.4,-.2,0,.2,.4))


#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%
#$% Figure D10 - Effects by time in office (continuous)
#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%#$%

cpl_tenure<-lm(underst_complexity~expert*tenure+party+age+educ,po)
interplot(cpl_tenure,'expert','tenure')+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of expertise")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='Gray80')+labs(caption = "")+
  scale_x_discrete(name ="Terms in office", 
                   limits=1:8)

op_tenure<-lm(strong_opinion~expert*tenure+party+age+educ,po)
interplot(op_tenure,'expert','tenure')+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of expertise")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='Gray80')+labs(caption = "")+
  scale_x_discrete(name ="Terms in office", 
                   limits=1:8)

facts_tenure<-lm(facts~expert*tenure+party+age+educ,po)
interplot(facts_tenure,'expert','tenure')+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of expertise")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='Gray80')+labs(caption = "")+
  scale_x_discrete(name ="Terms in office", 
                   limits=1:8)

maj_tenure<-lm(majority_opinion~expert*tenure+party+age+educ,po)
interplot(maj_tenure,'expert','tenure')+
  theme_bw()+ 
  theme(panel.grid.minor = element_blank(),axis.text=element_text(size=12),
        axis.title=element_text(size=12))+
  ylab("Marginal effect of expertise")+
  geom_hline(yintercept = 0, linetype = "dashed")+geom_line(color='Gray80')+labs(caption = "")+
  scale_x_discrete(name ="Terms in office", 
                   limits=1:8)


