

######################################################
## Replication file for Aidt and Leon (2020)        ##
## "The role of structural factors and diffusion    ##
## in social unrest: evidence from the Swing riots" ##
######################################################

rm(list=ls())

library(spdep)
library(foreign)

# Update as necessary
setwd("C:/Users/k1466170/Documents/Great Reform riots/UK riots/Data/Parish Names/Hobsbawm/replication material - BJPolS")

# Stata file saved in old version (12 or before)
riots <- read.dta("riotscrosssectionRJan2020.dta")

# Create a matrix of locations
loc<-cbind(riots$longitude,riots$latitude)
# Find all neighbours within a 10 km radius (Great Circle distances)
nearby<-dnearneigh(loc,0,10,longlat=TRUE)
# Create the weight matrix
W<-nb2mat(nearby,glist=NULL,style="W",zero.policy=TRUE)

# Create a diagonal matrix of the 'correct' dimension
dim(W)
I<-diag(9484)


# Create the augmented weight matrix and invert it (the coefficient is from the first column of
# table 1 in the paper

W2<-I-0.7591390*W
W3<-solve(W2)

# Sum columns and calculate the summary statistics
impact<-matrix(colSums(W3))

impact[934]

# Calculate the mean and standard deviation
mean(impact)
median(impact)
sd(impact)
min(impact)
max(impact)


# Produce Figure 2 in the paper: the histogram of the frequency of impacts
hist(impact, main="", xlab = "Impact of an additional riot", ylab = "Number of parishes", breaks=20)





