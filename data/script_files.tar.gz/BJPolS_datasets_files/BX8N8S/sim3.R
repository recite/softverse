## don't forget to set your directory ##
## read in data ##
## get that data in order ##

	rm(list = ls())
	library(foreign)
	setwd('~replication')

## stack parameters ##
	probHoldL <- c()
	probChangeL <- c()
	survey <- c()		
	surveyHold <- c()
	bbt <- c()	
			
	bbt <- na.omit(read.dta('fullBeta3.dta'))			

	losses <- c()

	for(k in 1:length(bbt[, 1])){
		draw <- rank(runif(10))[1]
		data <- read.dta(paste('data', draw, '.dta', sep = ''))

		data$govCompSubNew <- c()
		data$govCompSubNew[data$survey == 'dpes82.86'] <- sd(data$govCompSub[data$survey == 'dpes82.86' & data$gov == 1])
		data$govCompSubNew[data$survey == 'dpes86.89'] <- sd(data$govCompSub[data$survey == 'dpes86.89' & data$gov == 1])
		data$govCompSubNew[data$survey == 'dpes89.94'] <- sd(data$govCompSub[data$survey == 'dpes89.94' & data$gov == 1])
		data$govCompSubNew[data$survey == 'nes01.05'] <- sd(data$govCompSub[data$survey == 'nes01.05' & data$gov == 1])
		data$govCompSubNew[data$survey == 'nzes05.08'] <- sd(data$govCompSub[data$survey == 'nzes05.08' & data$gov == 1])
		data$govCompSubNew[data$survey == 'dnes01.05'] <- sd(data$govCompSub[data$survey == 'dnes01.05' & data$gov == 1])
		data$govCompSubNew[data$survey == 'ses91.94'] <- sd(data$govCompSub[data$survey == 'ses91.94' & data$gov == 1])
		data$govCompSubNew[data$survey == 'gles02.05'] <- sd(data$govCompSub[data$survey == 'gles02.05' & data$gov == 1])
		data$govCompSubNew[data$survey == 'gles05.09'] <- sd(data$govCompSub[data$survey == 'gles05.09' & data$gov == 1])
		data$govCompSubOld <- (data$govCompSub - data$govCompSubNew) * data$gov
		data$govCompSubNew <- (data$govCompSubNew + data$govCompSub) * data$gov
		data$economy <- data$economy + abs(min(data$economy))
		data$economyGov <- data$economy * data$gov

		data$holdL <- exp(bbt[k, 1] * data$gov + 
			bbt[k, 2] * data$govCompSubOld +
			bbt[k, 3] * data$lr +
			bbt[k, 4] * (data$lr * data$gov) + 
			bbt[k, 5] * data$economyGov + 
			bbt[k, 6] * data$govCompSubOld * data$lr * data$gov + 
			bbt[k, 7] * data$govCompSubOld * data$economyGov)

		data$changeL <- exp(bbt[k, 1] * data$gov + 
			bbt[k, 2] * data$govCompSubNew +
			bbt[k, 3] * data$lr +
			bbt[k, 4] * (data$lr * data$gov) + 
			bbt[k, 5] * data$economyGov + 
			bbt[k, 6] * data$govCompSubNew * data$lr * data$gov + 
			bbt[k, 7] * data$govCompSubNew * data$economyGov)
			
		probHoldL <- c()
		probChangeL <- c()
		survey <- c()		
		surveyHold <- c()
		c <- 1

		for(j in unique(data$group)){
			probHoldL[c] <- sum(data$holdL[data$gov == 1 & data$group == j])/sum(data$holdL[data$group == j])

			probChangeL[c] <- sum(data$changeL[data$gov == 1 & data$group == j])/sum(data$changeL[data$group == j])

			surveyHold[c] <- data$survey[data$group == j][1]
			
			c <- c+1
		}

		x <- runif(probHoldL)
		probChangeL <- as.numeric(probChangeL > x)
		probHoldL <- as.numeric(probHoldL > x)
		total <- mean(probChangeL - probHoldL, na.rm = TRUE)
		vote <- c()
		
		for(j in 1:length(unique(surveyHold))){
			vote[j] <- mean(probChangeL[surveyHold == unique(surveyHold)[j]] - probHoldL[surveyHold == unique(surveyHold)[j]])
			survey[j] <- unique(surveyHold)[j]
		}
		
		summary(vote)

		cat('parameter', k, 'complete...\n')
		cat('loss this iteration', mean(total), '...\n')
		cat('average loss', mean(vote), '...\n')
			
		losses <- data.frame(vote, survey, k, total)

		if(k == 1){
			write.table(losses, file = 'losses3.txt', sep = '|')
		}else{
			write.table(losses, file = 'losses3.txt', sep = '|', append = TRUE, col.names = FALSE)
		}
	}
	
