# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
##header ##
# R version 4.1.1 (2021-08-10)
# Platform: x86_64-w64-mingw32/x64 (64-bit)

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## setup  ----
rm(list=ls())

# check whether other packages than base packages are loaded
# if yes, they are detached to avoid
loadedpackages <- names(sessionInfo()$otherPkgs)
if (length(loadedpackages>0)) {
  lapply(paste("package",loadedpackages, sep=":"), detach, character.only = TRUE, unload = TRUE)
}

# define and set working directory
mywd <- "your working directory"
setwd(mywd)

# check if required folders exist
folders <- c("data","scripts","out")
all(sapply(folders, dir.exists))

# install required packages from CRAN
p_needed <- c("devtools","dplyr","emmeans","MASS")
# package versions used: devtools 2.4.3; dplyr 1.0.7; emmeans 1.7.1-1; MASS 7.3-54
packages <- rownames(installed.packages())
p_to_install <- p_needed[!(p_needed %in% packages)]
if (length(p_to_install) > 0) {
  install.packages(p_to_install)
}

# load packages
lapply(p_needed, require, character.only = TRUE)

# ggeffects automatically back-transforms values, even if this is unwanted, so slight adaptions had to be made to the ggemmeans-function
# this is a fork based on version 1.1.1.1 on Github
# here, I check if you already have the package installed and, if you do, will re-install the version you currently have at the end of the file
# CAUTION: if you installed from CRAN you will get the same version you had, if you installed from Github you will get the most recent version from there
# if you therefore need the old version from Github you have currently installed, do not install this
try(ggeffectsversion <- utils::packageDescription("ggeffects")$Version)
install_github("imrem/ggeffects", upgrade="never")
require(ggeffects)

rm(list=setdiff(ls(), "ggeffectsversion"))

load("data/applausebymonth.RDATA")

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## cleaning ----

# AUSTRIA #
# after the BZ� split from the FP� in 2005, both parties remained in the same PPG until the next election
# it therefore is not clear when government- and when opposition-MPs applauded, this period is removed entirely
applausebymonth <- applausebymonth[!(applausebymonth$country=="at" & 
                                       applausebymonth$date>="2005-04" & 
                                       applausebymonth$date<="2006-09"),]

# OK (ohne Klub, without PPG) are removed, as they are not really a PPG
applausebymonth <- applausebymonth[!(applausebymonth$party_from=="ohne Klubzugeh�rigkeit"),]
applausebymonth <- applausebymonth[!(applausebymonth$party_to=="ohne Klubzugeh�rigkeit"),]

# GENERAL #
# we are only interested in speeches by the gov parties
applausebymonth <- applausebymonth[applausebymonth$gov_party_to==1,]

# re-level the dyad-variable so that opposition applause to a government party is the reference category
applausebymonth$dyad2 <- relevel(applausebymonth$dyad2, ref = "gov-opp")

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## model ----

# calculate negative binomial model
model <- glm.nb(applause ~ date*dyad2*country + 
                  words_party_to, data = applausebymonth)

# adding all coefficients that make up the coalition mood
sim <- ggemmeans(model= model, terms=c("date", "dyad2", "country"), 
                 ci.lvl = 0.95, back.transform = FALSE)

# only keep the dyad that makes up the mood (applause by gov party for gov party)
sim <- sim[sim$group=="gov-gov",]
sim$date <- as.Date(paste(sim$x,"-01",sep=""))
sim$x <- NULL

# separate between Austria and Germany
sim_at <- sim[sim$facet=="at",]
sim_de <- sim[sim$facet=="de",]

# we now predicted values for the whole time periods in both countries, even though in some months we only have data for one country
# keep only those observations backed by data
dateat <- data.frame(unique(applausebymonth$date[applausebymonth$country=="at"]))
names(dateat)[1] <- "date"
dateat$date <- as.Date(paste(dateat$date,"-01",sep=""))
model_ATcoefs <- merge(sim_at, dateat, all.y = T)

datede <- data.frame(unique(applausebymonth$date[applausebymonth$country=="de"]))
names(datede)[1] <- "date"
datede$date <- as.Date(paste(datede$date,"-01",sep=""))
model_DEcoefs <- merge(sim_de, datede, all.y = T)

# add cabinet variable
model_ATcoefs <- model_ATcoefs %>%
  mutate(cabinet = ifelse(date<="2005-05-01", "Sch�ssel II",
                          ifelse(date >= "2005-05-01" & date <="2006-12-1", "Sch�ssel III", 
                                 ifelse(date >= "2007-01-1" & date <="2008-11-1", "Gusenbauer", 
                                        ifelse(date >= "2008-12-1" & date <="2013-11-1", "Faymann I", 
                                               ifelse(date >= "2013-12-1" & date <="2016-04-1", "Faymann II", 
                                                      ifelse(date >= "2016-05-1" & date <="2017-11-1", "Kern", 
                                                             ifelse(date >= "2017-12-1", "Kurz", ""))))))))

model_DEcoefs <- model_DEcoefs %>%
  mutate(cabinet = ifelse(date<="2002-10-01", "Schr�der I",
                          ifelse(date >= "2002-10-01" & date <="2005-11-01", "Schr�der II", 
                                 ifelse(date >= "2005-12-01" & date <="2009-10-01", "Merkel I", 
                                        ifelse(date >= "2009-11-01" & date <="2013-12-01", "Merkel II", 
                                               ifelse(date >= "2014-01-01" & date <="2018-02-01", "Merkel III", 
                                                      ifelse(date >= "2018-03-01", "Merkel IV", "")))))))


names(model_ATcoefs)[2] <- "mood"
names(model_ATcoefs)[7] <- "country"
names(model_DEcoefs)[2] <- "mood"
names(model_DEcoefs)[7] <- "country"

# the first observation in Germany is the reference group and is removed
model_DEcoefs <- model_DEcoefs[-1,]

# add a few variables necessary for the validity checks
# honeymoon = month of formation + next 3 months
model_ATcoefs$honeymoon <- ifelse((model_ATcoefs$cabinet == "Gusenbauer" & model_ATcoefs$date >= '2007-01-01' & model_ATcoefs$date <= '2007-04-01') |
                            (model_ATcoefs$cabinet == "Faymann I" & model_ATcoefs$date >= '2008-12-01' & model_ATcoefs$date <= '2009-03-01') |
                            (model_ATcoefs$cabinet == "Faymann II" & model_ATcoefs$date >= '2013-12-01' & model_ATcoefs$date <= '2014-03-01') |
                            (model_ATcoefs$cabinet == "Kern" & model_ATcoefs$date >= '2017-05-01' & model_ATcoefs$date <= '2017-08-01') |
                            (model_ATcoefs$cabinet == "Kurz" & model_ATcoefs$date >= '2017-12-01' & model_ATcoefs$date <= '2018-03-01'),1,0)


model_DEcoefs$honeymoon <- ifelse((model_DEcoefs$cabinet == "Schr�der I" & model_DEcoefs$date >= '1998-10-01' & model_DEcoefs$date <= '1999-01-01') |
                            (model_DEcoefs$cabinet == "Schr�der II" & model_DEcoefs$date >= '2002-10-01' & model_DEcoefs$date <= '2003-01-01') |
                            (model_DEcoefs$cabinet == "Merkel I" & model_DEcoefs$date >= '2005-11-01' & model_DEcoefs$date <= '2006-02-01') |
                            (model_DEcoefs$cabinet == "Merkel II" & model_DEcoefs$date >= '2009-10-01' & model_DEcoefs$date <= '2010-01-01') |
                            (model_DEcoefs$cabinet == "Merkel III" & model_DEcoefs$date >= '2013-12-01' & model_DEcoefs$date <= '2014-03-01'),1,0)

# caretaker = times when early elections have been decided but gov remains in office AND times after elections when old government is still in office
model_ATcoefs$caretaker <- ifelse((model_ATcoefs$cabinet == "Sch�ssel III" & model_ATcoefs$date >= '2006-07-01') |
                            (model_ATcoefs$cabinet == "Gusenbauer" & model_ATcoefs$date >= '2008-07-01') |
                            (model_ATcoefs$cabinet == "Faymann I" & model_ATcoefs$date >= '2013-10-01') |
                            (model_ATcoefs$cabinet == "Kern" & model_ATcoefs$date >= '2017-05-01'),1,0)

model_DEcoefs$caretaker <- ifelse((model_DEcoefs$cabinet == "Schr�der II" & model_DEcoefs$date == '2005-11-01') |
                            (model_DEcoefs$cabinet == "Merkel II" & model_DEcoefs$date >= '2013-11-01') |
                            (model_DEcoefs$cabinet == "Merkel III" & model_DEcoefs$date >= '2017-11-01'),1,0)

# coalition fixed-effects = all different combinations of parties that have been in a coalition
model_ATcoefs$coalition <- ifelse(model_ATcoefs$cabinet== "Sch�ssel II" | model_ATcoefs$cabinet== "Kurz", "schwarzblau",
                          ifelse(model_ATcoefs$cabinet== "Sch�ssel III", "schwarzorange", "rotschwarz"))

model_DEcoefs$coalition <- ifelse(model_DEcoefs$cabinet== "Schr�der I" | model_DEcoefs$cabinet== "Schr�der II", "rotgr�n",
                          ifelse(model_DEcoefs$cabinet== "Merkel II", "schwarzgelb", "schwarzrot"))


# add a delayed mood variable (necessary for predictive validity)
# it's not added for the first observation in each cabinet
model_ATcoefs$mood_lag <- NA
model_ATcoefs$std.error_lag <- NA
for (x in 2:nrow(model_ATcoefs)){
  if (model_ATcoefs$cabinet[x-1]==model_ATcoefs$cabinet[x]){
    model_ATcoefs$mood_lag[x] <- model_ATcoefs$mood[x-1]
    model_ATcoefs$std.error_lag[x] <- model_ATcoefs$std.error[x-1]
  }
}

model_DEcoefs$mood_lag <- NA
model_DEcoefs$std.error_lag <- NA
for (x in 2:nrow(model_DEcoefs)){
  if (model_DEcoefs$cabinet[x-1]==model_DEcoefs$cabinet[x]){
    model_DEcoefs$mood_lag[x] <- model_DEcoefs$mood[x-1]
    model_DEcoefs$std.error_lag[x] <- model_DEcoefs$std.error[x-1]
  }
}

# save file before standardizing (needed for simulations)
save(model_ATcoefs, model_DEcoefs, file = "out/coefficients_unstand.RDATA")

# standardize the mood between 0 and 10
model_ATcoefs$mood_lag <- NULL
model_ATcoefs$std.error_lag <- NULL
model_DEcoefs$mood_lag <- NULL
model_DEcoefs$std.error_lag <- NULL

combined <- rbind(model_ATcoefs,model_DEcoefs)

combined$mood2 <- ((combined$mood - min(combined$mood))/
                         (max(combined$mood)- min(combined$mood)))*10

combined$conf.low <- ((combined$conf.low - min(combined$mood))/
                        (max(combined$mood)- min(combined$mood)))*10

combined$conf.high <- ((combined$conf.high - min(combined$mood))/
                         (max(combined$mood)- min(combined$mood)))*10

combined$std.error <- combined$std.error*(combined$mood2/combined$mood)

combined$mood <- combined$mood2
combined$mood2 <- NULL

# data for Germany and Austria are seperated again after standardizing, variable "group" is not needed anymore and removed
mood_at <- combined[c(1:146),-6]
mood_de <- combined[c(147:354),-6]

# add a delayed mood variable (necessary for predictive validity)
# it's not added for the first observation in each cabinet
mood_at$mood_lag <- NA
mood_at$std.error_lag <- NA
for (x in 2:nrow(mood_at)){
  if (mood_at$cabinet[x-1]==mood_at$cabinet[x]){
    mood_at$mood_lag[x] <- mood_at$mood[x-1]
    mood_at$std.error_lag[x] <- mood_at$std.error[x-1]
  }
}

mood_de$mood_lag <- NA
mood_de$std.error_lag <- NA
for (x in 2:nrow(mood_de)){
  if (mood_de$cabinet[x-1]==mood_de$cabinet[x]){
    mood_de$mood_lag[x] <- mood_de$mood[x-1]
    mood_de$std.error_lag[x] <- mood_de$std.error[x-1]
  }
}

mood <- rbind(mood_at, mood_de)

# the forked version of ggeffects is uninstalled here
detach("package:ggeffects")
remove.packages("ggeffects")

# if the package was installed before this file was executed, it is reinstalled
# if it was originally downloaded from CRAN the same version as before is installed
# if it was originally downloaded from Github the current Github version is installed
if (exists("ggeffectsversion")==TRUE){
  tryinstall <- try(install_version("ggeffects", version = ggeffectsversion, 
                      repos = "http://cran.us.r-project.org", upgrade="never"))
  
    if (inherits(tryinstall, "try-error")==TRUE) {
      install_github("strengejacke/ggeffects", upgrade="never")
    }

}

# save mood file
rm(list=setdiff(ls(), c("mood", "mood_at", "mood_de")))

save.image("out/mood.RDATA")
