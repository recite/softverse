sim_concurrent = function(dataframe, variable, se) {
  n_rows <- nrow(dataframe)

  col_var <- which(names(dataframe) %in% variable)
  
  col_se <- which(names(dataframe) %in% se)
  
  mood_sim <- rnorm(n = n_rows, mean = dataframe[,col_var], sd = dataframe[,col_se])
  mood_sim <- (10-0)/(max(mood_sim)-min(mood_sim))*(mood_sim-max(mood_sim))+10
  
  sim_data <- cbind(dataframe, data.frame(mood_sim))

  model <- lm(mood_sim ~  joint_diff + share_comp + honeymoon + caretaker +  mood_lag + coalition, data = sim_data)
  
  summary(model)
}

sim_predictive = function(dataframe, variable, se) {
  n_rows <- nrow(dataframe)

  col_var <- which(names(dataframe) %in% variable)
  
  col_se <- which(names(dataframe) %in% se)

  mood_sim_lag <- rnorm(n = n_rows, mean = dataframe[,col_var], sd = dataframe[,col_se])
  mood_sim_lag <- (10-0)/(max(mood_sim_lag, na.rm = TRUE)-
                            min(mood_sim_lag, na.rm = TRUE))*(mood_sim_lag-max(mood_sim_lag, na.rm = TRUE))+10
  
  sim_data <- cbind(dataframe, data.frame(mood_sim_lag))
  
  model <- coxph(formula=Surv(tstart, time, status) ~ mood_sim_lag + d_gov  + d_opp  +
                   agriculture  +     defence + economy +     education +   environment +
                   finance +     foreign  +  health + industry +    interior +    justice +     
                   labour +      social + monthspassed + monthspassedsq + coalition, 
                 id = id,
                 data=sim_data)
}