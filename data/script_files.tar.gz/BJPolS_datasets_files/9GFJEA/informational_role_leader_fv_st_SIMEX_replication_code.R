###########################################################################
# Replication code for THE INFORMATIONAL ROLE OF PARTY LEADER CHANGES
# Simex analysis
# Version: november 2016
# Author: Pablo Fernandez-Vazquez
# R version 3.3.1
# data source: leaders_perceptions_final.dta
###########################################################################

library(dplyr)
library(haven)
library(simex)

leaders <- read_dta("informational_role_leader_fv_st.dta")


# RIDDING OF NAs
job.complete <- na.omit ( select ( leaders,  meanlr, lmeanlr, mlogrile, leaderch, mlogrile_leaderch, lmeanlr_leaderch, mlogrile_VAR, mlogrile_leaderch_VAR, meanlr_VAR, lmeanlr_VAR, lmeanlr_leaderch_VAR, lmeanlr_leaderch_VAR, gov )  )


#### PARTIES IN GOVERNMENT
set.seed(4)

government <- simex(model=lm(meanlr ~ lmeanlr+lmeanlr_leaderch+mlogrile+mlogrile_leaderch + leaderch, data=subset(job.complete, gov==1), x=TRUE),
	 SIMEXvariable=c("mlogrile", "mlogrile_leaderch", "meanlr", "lmeanlr", "lmeanlr_leaderch")
, measurement.error=cbind(sqrt(subset(job.complete, gov==1)$mlogrile_VAR), sqrt(subset(job.complete, gov==1)$mlogrile_leaderch_VAR), 
sqrt(subset(job.complete, gov==1)$meanlr_VAR),sqrt(subset(job.complete, gov==1)$lmeanlr_VAR),sqrt(subset(job.complete, gov==1)$lmeanlr_leaderch_VAR)),lambda = c(0.5, 1, 1.5, 2), 
B = 100, fitting.method = "quadratic", jackknife.estimation = "quadratic", 
asymptotic = F)

summary(government)

sqrt(mean(government$residuals^2)) # computing RMSE



#### PARTIES IN OPPOSITION
set.seed(4)

opposition <-simex(model=lm(meanlr ~ lmeanlr+lmeanlr_leaderch+mlogrile+mlogrile_leaderch + leaderch, data=subset(job.complete, gov==0), x=TRUE),
	 SIMEXvariable=c("mlogrile", "mlogrile_leaderch", "meanlr", "lmeanlr", "lmeanlr_leaderch")
, measurement.error=cbind(sqrt(subset(job.complete, gov==0)$mlogrile_VAR), sqrt(subset(job.complete, gov==0)$mlogrile_leaderch_VAR), 
sqrt(subset(job.complete, gov==0)$meanlr_VAR),sqrt(subset(job.complete, gov==0)$lmeanlr_VAR),sqrt(subset(job.complete, gov==0)$lmeanlr_leaderch_VAR)),lambda = c(0.5, 1, 1.5, 2), 
B = 100, fitting.method = "quadratic", jackknife.estimation = "quadratic", 
asymptotic = F)

summary(opposition)

sqrt(mean(opposition$residuals^2)) # computing RMSE

