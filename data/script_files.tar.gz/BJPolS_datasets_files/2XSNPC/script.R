## header ------------------------------------------------------------------------------------------------------------------
# R version 3.3.1 (2016-06-21)
# Platform: x86_64-w64-mingw32/x64 (64-bit)


## setup -------------------------------------------------------------------------------------------------------------------
rm(list=ls())

# define and set working directory
mywd <- "your working directory"
setwd(mywd)

# check if required folders exist
folders <- c("data","scripts","out")
all(sapply(folders, dir.exists))

# install required packages from CRAN
p_needed <- c("VGAM", "corpcor", "MASS", "readstata13", "ggplot2", "foreign", "survival", "flexsurv", "cmprsk", "parfm", "plyr")
packages <- rownames(installed.packages())
p_to_install <- p_needed[!(p_needed %in% packages)]
if (length(p_to_install) > 0) {
  install.packages(p_to_install)
}

lapply(p_needed, require, character.only = TRUE)

# log-likelihood functions defined by Chiba, Martin, and Stevenson (2015); adjusted for updated version of VNORM function
source("scripts/3_LLfunctions_newVNORM.R")

# load data
load("data/attempt_data.Rda")

# rename attempt_id
attempt.data <- rename(attempt.data, replace = c("attempt_id" = "caseid"))

# generate interaction terms for formation stage
attempt.data$seat_shareXseat_share <- attempt.data$seat_share * attempt.data$seat_share
attempt.data$ideo_rangeXseat_share <- attempt.data$ideo_range * attempt.data$seat_share
attempt.data$ideo_rangeXseat_shareXseat_share <- attempt.data$ideo_range * attempt.data$seat_share * attempt.data$seat_share

# generate censoring indicator
attempt.data$censor_discelec[attempt.data$attempt_inconclusive==0] <- 1
attempt.data$censor_discelec[attempt.data$attempt_inconclusive==1] <- 0

# emulate Fine and Gray (1999); see also Geskus (2011)
attempt.data.competing <- attempt.data
attempt.data.competing$attempt_bargaining_duration[(attempt.data.competing$attempt_inconclusive==1) &
                                                     attempt.data.competing$b_outcome==1] <- 88


## univariate analysis - formation stage -----------------------------------------------------------------------------------

# formation equation
eqn.formation <- as.formula(b_outcome ~ median_party + sq + ideo_range + seat_share 
                      + ideo_rangeXseat_share + seat_shareXseat_share 
                      + ideo_rangeXseat_shareXseat_share)

# estimate formation stage
univ.formation <- estimate.clogit(eqn.formation, attempt.data.competing, constraint = F)

# store estimation results
save(univ.formation, file = "out/univ.formation.rda")

# use estimates as starting values for joint estimation
beta.formation <- univ.formation$fit$par


## univariate analysis - duration stage ------------------------------------------------------------------------------------

# duration equation
eqn.duration <- as.formula(attempt_bargaining_duration ~ 
                        attempt_pref_tangentiality 
                      + attempt_ideo_range
                      + attempt_pre_gov_di
                      + attempt_min_leader_years_log 
                      + attempt_parties + attempt_pec + attempt_time_pressure + attempt_lagged_dur
                      + failed_d2 + failed_d3 + failed_d4 + failed_d5
                      + process_post_elec
                      + process_complexity_2 + process_complexity_3 + process_complexity_4 + process_complexity_5 + process_complexity_6
                      + country_pos_parl + country_semi_pres + country_east + process_first
                      + year_d2 + year_d3 + year_d4 + year_d5 + year_d6	+ year_d7	+ year_d8	+ year_d9	+ year_d10 + year_d11	+ year_d12 + year_d13	+ year_d14 + year_d15	+ year_d16 + year_d17 + year_d18 + year_d19	+year_d20	+year_d21	+year_d22	+year_d23	+year_d24	+year_d25	+year_d26	+year_d27	+year_d28	+year_d29	+year_d30	+year_d31	+year_d32	+year_d33	+year_d34	+year_d35)

# estimate duration stage
univ.duration <- estimate.univdur(eqn.duration, "election", "weibull", attempt.data.competing)

# store estimation results
save(univ.duration, file = "out/univ.duration.rda")

# use estimates as starting values for joint estimation
beta.duration <- univ.duration$fit$par


## bivariate analysis (joint estimation) weibull ---------------------------------------------------------------------------

# starting values
joint.init <- c(beta.formation, beta.duration, 0)

# estimate selection-duration dependent competing-risk Weibull AFT model
biv.formation.duration <- estimate.cld(eqn.formation, eqn.duration, 
                                      failure.type = "election", dist = "weibull", data = attempt.data.competing,
                                      WantHessian = T, init = joint.init, constraint = F)

# store estimation results
save(biv.formation.duration, file = "out/biv.formation.duration.rda")

# display empirical results Table 1
disp.cld(biv.formation.duration)
biv.formation.duration$fit$value


## robustness: alternative parametric model specifications ---------------------------------------------------------------

# estimate selection-duration independent competing-risk Weibull AFT model
model2 <- estimate.cld(eqn.formation, eqn.duration, 
                                       failure.type = "election", dist = "weibull", data = attempt.data,
                                       WantHessian = T, init = joint.init, constraint = F)

# display empirical results Table S.2
disp.cld(model2)

# duration equation for survreg function
eqn.duration.survreg <- as.formula(Surv(attempt_bargaining_duration, censor_discelec) 
                ~ attempt_pref_tangentiality 
                + attempt_ideo_range
                + attempt_pre_gov_di
                + attempt_min_leader_years_log 
                + attempt_parties + attempt_pec + attempt_time_pressure + attempt_lagged_dur
                + as.factor(attempt_previous_failed)
                + process_post_elec + as.factor(process_complexity_lb) 
                + country_pos_parl + country_semi_pres + country_east + process_first
                + as.factor(year)
                + cluster(process_id))

# estimate dependent competing-risk Weibull AFT model with cluster robust S.E.
model3 <- survreg(eqn.duration.survreg, attempt.data.competing, dist = "weibull", robust = TRUE)

# display empirical results Table S.2
summary(model3)

# estimate independent competing-risk Weibull AFT model with cluster robust S.E.
model4 <- survreg(eqn.duration.survreg, attempt.data, dist = "weibull", robust = TRUE)

# display empirical results Table S.2
summary(model4)


## robustness: alternative semi-parametric model specifications ----------------------------------------------------------

# estimate dependent competing-risk PH model (Fine and Gray 1999)
attempt.data $ fstatus[attempt.data $ attempt_inconclusive==0] <- 1
attempt.data $ fstatus[attempt.data $ attempt_inconclusive==1] <- 2
fstatus <- attempt.data $ fstatus

attempt.data $ ftime <- attempt.data $ attempt_bargaining_duration
ftime <- attempt.data $ ftime

crrcov <- as.matrix(attempt.data[attr(terms(eqn.duration),"term.labels")], ncol = 56)

model5 <- crr(ftime,fstatus,crrcov)

# display empirical results Table S.3
summary(model5)

# estimate independent competing-risk Cox PH model with cluster robust S.E.
model6 <- coxph(eqn.duration.survreg, attempt.data, robust = TRUE)

# display empirical results Table S.3
summary(model6)


## obtain and plot quantities of interest -----------------------------------------------------------------------------------------

# subset the data
dur.pool <- attempt.data[attempt.data$b_outcome==1,]
dur.pool.r <- dur.pool[dur.pool$censor_discelec==1,]

# range of observed duration until replacement
range(dur.pool.r$attempt_bargaining_duration)
summary(dur.pool.r$attempt_bargaining_duration)

# failure time
ft <- seq(from = 1, to = 90, length = 90)

# parameter estimates & Variance/Covariance matrix
load("out/biv.formation.duration.rda")
disp.cld(biv.formation.duration)
coef <- matrix(biv.formation.duration$fit$par)
vcov <- -solve(biv.formation.duration$fit$hessian)

# draw covariate estimates from the multivariate normal distribution
n.sim <- 1000
simid <- 1:n.sim
set.seed(123456)
drawn <- mvrnorm(n.sim, coef, vcov)
xsel <- length(attr(terms(eqn.formation),"term.labels"))+1
drawndf <- data.frame(drawn[,xsel:(ncol(drawn)-2)])
colnames(drawndf) <- c(attr(terms(eqn.duration),"term.labels"),"Constant")
dfn <- names(drawndf)

# define variable of interest
xj <- "attempt_pref_tangentiality"
xjdf <- dur.pool$attempt_pref_tangentiality
summary(xjdf)
xjval <- sort(c(0,(quantile(xjdf)[2]-quantile(xjdf)[3]),(quantile(xjdf)[4]-quantile(xjdf)[3]),seq((summary(xjdf)[1]-summary(xjdf)[3]),(summary(xjdf)[6]-summary(xjdf)[3]),by=((abs((summary(xjdf)[1]-summary(xjdf)[3]))+abs(summary(xjdf)[6]-summary(xjdf)[3]))/10))))
xjvalmed <- sort(c(summary(xjdf)[3],quantile(xjdf)[2],quantile(xjdf)[4],seq(summary(xjdf)[1],summary(xjdf)[6],by=((abs(summary(xjdf)[6])-abs(summary(xjdf)[1]))/10))))

# set all other variables to mean and mode respectively
notxj <- setdiff(names(drawndf), xj)
xi <- data.frame(dur.pool)
xi <- xi[,match(notxj[1:(length(notxj)-1)], names(xi))]
ximeans <- t(data.frame(colMeans(xi)))
ximeans[2] <- 0
ximeans[3] <- summary(dur.pool$attempt_min_leader_years_log)[3]
ximeans[4] <- 3
ximeans[5] <- 0
ximeans[8:11] <- rep(0,4)
ximeans[12:21] <- c(1,0,0,0,0,1,1,0,0,0)
ximeans[22:55] <- rep(0,34)
ximeans[47] <- 1
ximeans[56] <- 1

betasxj <- drawndf[,match(xj, names(drawndf))]
betasxi <- drawndf[,match(notxj, names(drawndf))]
betas <- as.matrix(cbind(betasxj,betasxi))

p.ci <- lambda.ci <- labmda.ci.med <- matrix(NA, nrow=n.sim, ncol=1)
medsurvival.ci <- rel.hazard <- matrix(NA, nrow=n.sim, ncol=length(xjval))

x <- 1
i <- 1
for (x in 1:length(xjval)){
  xs <- c(xjvalmed[x],ximeans)
  for (i in 1:n.sim){
    p.ci[i,1] <- exp(drawn[i,(ncol(drawn)-1)])
    lambda.ci[i,1] <- exp(-xs %*% betas[i,])
    medsurvival.ci[i,x] <- lambda.ci[i,1]^(-1) * log(2)^(1/p.ci[i,1])
    rel.hazard[i,x] <- exp(-xjval[x] %*% betas[i,1])^(p.ci[i,1])
  }
}

rel.hazard.q <- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
rel.hazard.q <- do.call(rbind, replicate(n.sim, t(rel.hazard.q), simplify=FALSE)) 
rel.hazard.q <- rel.hazard.q[order(rel.hazard.q[,1], decreasing = FALSE),]

medsurvival.q <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
medsurvival.q <- do.call(rbind, replicate(n.sim, t(medsurvival.q), simplify=FALSE)) 
medsurvival.q <- medsurvival.q[order(medsurvival.q[,1]),]

medsurvival.vec <- as.vector(medsurvival.ci)
rel.hazard.vec <- as.vector(rel.hazard)

x <- sort(rep.int(xjval, n.sim))
obj <- cbind(simid,rel.hazard.vec,x,rel.hazard.q,medsurvival.vec,medsurvival.q)
obj <- data.frame(SimID = obj[,1] ,XJ = obj[,3], QI = obj[,2], P025 = obj[,4], P975 = obj[,5], medsurv = obj[,6], medsurvP025 = obj[,7], medsurvP975 = obj[,8])
obj <- subset(obj, QI >= P025 & QI <= P975)
rugx <- c((xjdf-summary(xjdf)[3]),rep(NA,(nrow(obj)-length(xjdf))))
obj <- cbind(obj,rugx)
overall.max <- max(obj$P975)

# plot figure 3.1
p1 <- ggplot(obj, aes(XJ, QI)) +
  geom_smooth(method = "loess", se = FALSE,color = "black") +  
  geom_line(aes(group = SimID, alpha = 0.1),colour = "gray80") +
  geom_hline(aes(yintercept = 1), linetype = "dotted") +
  scale_alpha_continuous(range = c(0, 0.1), guide = FALSE) +
  xlab("Preference tangentiality (average standard deviation of issue emphasis)") + ylab("Relative sub-hazard") +
  scale_x_continuous(breaks=c(min(xjval),xjval[5],0,xjval[11],max(xjval)),labels=c("0.0", "2.7", "3.4", "4.6", "8.8")) +
  scale_y_continuous(limits = c(0,6),breaks=c(0,2,4,6)) +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(), 
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black")) +
  geom_rug(aes(x = rugx), sides="b", color="gray60")

tiff("out/fig31.tif", res=600, compression = "lzw", height=7.3, width=10, units="in")
p1
dev.off()

predrelhaz<- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.5))
c(predrelhaz[5],predrelhaz[6],predrelhaz[9])

predsurv <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.5))
c(predsurv[5],predsurv[6],predsurv[9])


# define variable of interest
xj <- "attempt_pre_gov_di"
xjdf <- dur.pool$attempt_pre_gov_di
summary(xjdf)

xjval <- c(0,1)
xjvalmed <- c(0,1) 

## set all other variables to mean and mode respectively
notxj <- setdiff(names(drawndf), xj)
xi <- data.frame(dur.pool)
xi <- xi[,match(notxj[1:(length(notxj)-1)], names(xi))]
ximeans <- t(data.frame(colMeans(xi)))
ximeans[3] <- summary(dur.pool$attempt_min_leader_years_log)[3]
ximeans[4] <- 3
ximeans[5] <- 0
ximeans[8:11] <- rep(0,4)
ximeans[12] <- 1
ximeans[13:21] <- c(0,0,0,0,1,1,0,0,0)
ximeans[22:55] <- rep(0,34)
ximeans[47] <- 1
ximeans[56] <- 1

betasxj <- drawndf[,match(xj, names(drawndf))]
betasxi <- drawndf[,match(notxj, names(drawndf))]
betas <- as.matrix(cbind(betasxj,betasxi))

p.ci <- lambda.ci <- labmda.ci.med <- matrix(NA, nrow=n.sim, ncol=1)
medsurvival.ci <- rel.hazard <- matrix(NA, nrow=n.sim, ncol=length(xjval))

x <- 1
i <- 1
for (x in 1:length(xjval)){
  xs <- c(xjvalmed[x],ximeans)
  for (i in 1:n.sim){
    p.ci[i,1] <- exp(drawn[i,(ncol(drawn)-1)])
    lambda.ci[i,1] <- exp(-xs %*% betas[i,])
    medsurvival.ci[i,x] <- lambda.ci[i,1]^(-1) * log(2)^(1/p.ci[i,1])
    rel.hazard[i,x] <- exp(-xjval[x] %*% betas[i,1])^(p.ci[i,1])
  }
}

rel.hazard.q <- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
rel.hazard.q <- do.call(rbind, replicate(n.sim, t(rel.hazard.q), simplify=FALSE)) 
rel.hazard.q <- rel.hazard.q[order(rel.hazard.q[,1], decreasing = FALSE),]

medsurvival.q <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
medsurvival.q <- do.call(rbind, replicate(n.sim, t(medsurvival.q), simplify=FALSE)) 
medsurvival.q <- medsurvival.q[order(medsurvival.q[,1]),]

medsurvival.vec <- as.vector(medsurvival.ci)
rel.hazard.vec <- as.vector(rel.hazard)

x <- sort(rep.int(xjval, n.sim))
obj <- cbind(simid,rel.hazard.vec,x,rel.hazard.q,medsurvival.vec,medsurvival.q)
obj <- data.frame(SimID = obj[,1] ,XJ = obj[,3], QI = obj[,2], P025 = obj[,4], P975 = obj[,5], medsurv = obj[,6], medsurvP025 = obj[,7], medsurvP975 = obj[,8])
obj <- subset(obj, QI >= P025 & QI <= P975)
rugx <- c((xjdf-summary(xjdf)[3]),rep(NA,(nrow(obj)-length(xjdf))))
obj <- cbind(obj,rugx)
overall.max <- max(obj$P975)

# plot figure 3.2
p2 <- ggplot(obj, aes(XJ, QI)) +
  geom_point(aes(group = SimID, alpha = 0.1),colour = "gray80") +
  geom_point(aes(x=1, y=2.732305),colour = "black") +
  geom_point(aes(x=0, y=1),colour = "black") +
  geom_point(aes(x=1.5, y=1),colour = "white") +
  geom_point(aes(x=-0.5, y=1),colour = "white") +
  geom_hline(aes(yintercept = 1), linetype = "dotted") +
  scale_alpha_continuous(range = c(0, 0.1), guide = FALSE) +
  xlab("Incumbency (previous government parties)") + ylab("Relative sub-hazard") +
  scale_x_continuous(breaks=c(0,1),labels=c("no (70.3 percent)", "yes (29.7 percent)")) +
  scale_y_continuous(limits = c(0,6),breaks=c(0,2,4,6)) +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(), 
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))

tiff("out/fig32.tif", res=600, compression = "lzw", height=7.3, width=10, units="in")
p2
dev.off()

predrelhaz<- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.5))
predrelhaz

predsurv <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.5))
predsurv


# define variable of interest
xj <- "attempt_min_leader_years_log"
xjdf <- dur.pool$attempt_min_leader_years_log
summary(xjdf)

xjval <- sort(c(0,(quantile(xjdf)[2]-quantile(xjdf)[3]),(quantile(xjdf)[4]-quantile(xjdf)[3]),seq((summary(xjdf)[1]-summary(xjdf)[3]),(summary(xjdf)[6]-summary(xjdf)[3]),by=((abs((summary(xjdf)[1]-summary(xjdf)[3]))+abs(summary(xjdf)[6]-summary(xjdf)[3]))/10))))
xjvalmed <- sort(c(summary(xjdf)[3],quantile(xjdf)[2],quantile(xjdf)[4],seq(summary(xjdf)[1],summary(xjdf)[6],by=((abs(summary(xjdf)[1])+abs(summary(xjdf)[6]))/10))))

# set all other variables to mean and mode respectively
notxj <- setdiff(names(drawndf), xj)
xi <- data.frame(dur.pool)
xi <- xi[,match(notxj[1:(length(notxj)-1)], names(xi))]
ximeans <- t(data.frame(colMeans(xi)))
ximeans[3] <- 0
ximeans[4] <- 3
ximeans[5] <- 0
ximeans[8:11] <- rep(0,4)
ximeans[12:21] <- c(1,0,0,0,0,1,1,0,0,0)
ximeans[22:55] <- rep(0,34)
ximeans[47] <- 1
ximeans[56] <- 1

betasxj <- drawndf[,match(xj, names(drawndf))]
betasxi <- drawndf[,match(notxj, names(drawndf))]
betas <- as.matrix(cbind(betasxj,betasxi))

p.ci <- lambda.ci <- labmda.ci.med <- matrix(NA, nrow=n.sim, ncol=1)
medsurvival.ci <- rel.hazard <- matrix(NA, nrow=n.sim, ncol=length(xjval))

x <- 1
i <- 1
for (x in 1:length(xjval)){
  xs <- c(xjvalmed[x],ximeans)
  for (i in 1:n.sim){
    p.ci[i,1] <- exp(drawn[i,(ncol(drawn)-1)])
    lambda.ci[i,1] <- exp(-xs %*% betas[i,])
    medsurvival.ci[i,x] <- lambda.ci[i,1]^(-1) * log(2)^(1/p.ci[i,1])
    rel.hazard[i,x] <- exp(-xjval[x] %*% betas[i,1])^(p.ci[i,1])
  }
}

rel.hazard.q <- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
rel.hazard.q <- do.call(rbind, replicate(n.sim, t(rel.hazard.q), simplify=FALSE)) 
rel.hazard.q <- rel.hazard.q[order(rel.hazard.q[,1], decreasing = FALSE),]

medsurvival.q <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.025,.975))
medsurvival.q <- do.call(rbind, replicate(n.sim, t(medsurvival.q), simplify=FALSE)) 
medsurvival.q <- medsurvival.q[order(medsurvival.q[,1]),]

medsurvival.vec <- as.vector(medsurvival.ci)
rel.hazard.vec <- as.vector(rel.hazard)

x <- sort(rep.int(xjval, n.sim))
obj <- cbind(simid,rel.hazard.vec,x,rel.hazard.q,medsurvival.vec,medsurvival.q)
obj <- data.frame(SimID = obj[,1] ,XJ = obj[,3], QI = obj[,2], P025 = obj[,4], P975 = obj[,5], medsurv = obj[,6], medsurvP025 = obj[,7], medsurvP975 = obj[,8])
obj <- subset(obj, QI >= P025 & QI <= P975)
rugx <- c((xjdf-summary(xjdf)[3]),rep(NA,(nrow(obj)-length(xjdf))))
obj <- cbind(obj,rugx)
overall.max <- max(obj$P975)

# plot figure 3.3
p3 <- ggplot(obj, aes(XJ, QI)) +
  geom_smooth(method = "loess", se = FALSE,color = "black") +  
  geom_line(aes(group = SimID, alpha = 0.1),colour = "gray80") +
  geom_hline(aes(yintercept = 1), linetype = "dotted") +
  scale_alpha_continuous(range = c(0, 0.1), guide = FALSE) +
  xlab("Leadership tenure (time in office in years)") + ylab("Relative sub-hazard") +
  scale_x_continuous(breaks=c(min(xjval),xjval[8],0,xjval[12],max(xjval)),labels=c("0", "0.3", "1.2", "3.2", "11.6")) +
  scale_y_continuous(limits = c(0,6),breaks=c(0,2,4,6)) +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(), 
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black")) +
  geom_rug(aes(x = rugx), sides="b", color="gray60")

tiff("out/fig33.tif", res=600, compression = "lzw", height=7.3, width=10, units="in")
p3
dev.off()

predrelhaz<- apply(rel.hazard, MARGIN = 2, FUN = quantile, probs = c(.5))
c(predrelhaz[7],predrelhaz[10],predrelhaz[12])

predsurv <- apply(medsurvival.ci, MARGIN = 2, FUN = quantile, probs = c(.5))
c(predsurv[7],predsurv[10],predsurv[12])

## end of file -------------------------------------------------------------
