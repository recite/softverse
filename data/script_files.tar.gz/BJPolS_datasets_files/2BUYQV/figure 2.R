library(tidyverse)
library(ggplot2)

plt_dta <- filter(data_black, abs(distance_garner) <= 14)

ggplot(plt_dta, aes(distance_garner, met_effective)) +
  theme_bw() +
  stat_summary(fun = "mean", colour = "black", size = 1, geom = "point") +
  theme(panel.border = element_blank(),
        axis.line = element_line(color = 'black'),
        legend.text = element_text(size=12),
        axis.text=element_text(size=10),
        axis.title=element_text(size=12))+
  geom_smooth(data=subset(plt_dta, distance_garner < 0), method = "lm", fill = "grey48", colour = "grey54", alpha = .2)+
  geom_smooth(data=subset(plt_dta, distance_garner >= 0), method = "lm", fill = "grey0", colour = "grey6")+
  xlab("Distance from Eric Garner's killing (days)") +
  ylab("Overall Satisfaction with  the Police") +
  geom_vline(xintercept = 0, linetype = "dashed")
