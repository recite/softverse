library(gtrendsR)
library(tidyverse)


time_frame_garner <- c("2014-06-17 2014-09-17")

garner_compare <- gtrends(keyword = c("Eric Garner"), 
                          time = time_frame_garner, gprop = "web", geo = c("US", "GB"))

garner_compare <- garner_compare$interest_over_time

garner_compare$hits[garner_compare$hits == "<1"] <- .5

garner_compare$hits <- as.numeric(garner_compare$hits)
garner_compare$geo <- ifelse(garner_compare$geo == "GB", "United Kingdom", "United States")

p1 <- ggplot(garner_compare, aes(x = date, y = hits, group=geo, color = geo, linetype = geo)) +
  geom_line(size = 1) +
  scale_color_manual(values=c('black','black')) +
  scale_linetype_manual(values= c('dashed', 'solid')) + 
  theme_bw()  +
  theme(panel.border = element_blank(),
        axis.line = element_line(color = 'black'),
        plot.title = element_text(size=10, hjust = 0.5),
        legend.position = "bottom",
        legend.title = element_blank(),
        legend.text = element_text(size=12),
        axis.text=element_text(size=10),
        axis.title=element_text(size=12),
        legend.spacing.x = unit(.25, 'cm'))+
  xlab("Date") +
  ylab("Search Hits") +
  geom_segment(x = as.POSIXct("2014-07-17"), y = 0, xend = as.POSIXct("2014-07-17"), yend = 100, colour = "black",
