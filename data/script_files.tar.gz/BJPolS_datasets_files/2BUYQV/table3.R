#Table 3

#Black
dt <- data_black
table3a <- data.frame(`Overall Evaluation` = table_c(dt$met_effective, dt$distance_garner, control = cbind(dt$`45-54`), cluster = dt$borough),
                     `Police Fairness` = table_c(dt$fairness_score, dt$distance_garner, control = cbind(dt$`45-54`), cluster = dt$borough),
                     `Community Engagement` = table_c(dt$engage_score, dt$distance_garner, control = cbind(dt$`45-54`), cluster = dt$borough),
                     `Police Effectiveness` = table_c(dt$effectiveness_score, dt$distance_garner, control = cbind(dt$`45-54`), cluster = dt$borough))
table3a

#White
dt <- data_white
table3b <- data.frame(`Overall Evaluation` = table_c(dt$met_effective, dt$distance_garner, control = cbind(dt$`35-44`), cluster = dt$borough),
                     `Police Fairness` = table_c(dt$fairness_score, dt$distance_garner, control = cbind(dt$`35-44`), cluster = dt$borough),
                     `Community Engagement` = table_c(dt$engage_score, dt$distance_garner, control = cbind(dt$`35-44`), cluster = dt$borough),
                     `Police Effectiveness` = table_c(dt$effectiveness_score, dt$distance_garner, control = cbind(dt$`35-44`), cluster = dt$borough))
table3b

#South Asian
dt <- data_asian
table3c <- data.frame(`Overall Evaluation` = table_c(dt$met_effective, dt$distance_garner,  control = dt$parttime, cluster = dt$borough),
                     `Police Fairness` = table_c(dt$fairness_score, dt$distance_garner, control = dt$parttime, cluster = dt$borough),
                     `Community Engagement` = table_c(dt$engage_score, dt$distance_garner,  control = dt$parttime, cluster = dt$borough),
                     `Police Effectiveness` = table_c(dt$effectiveness_score, dt$distance_garner, control = dt$parttime, cluster = dt$borough))
table3c

