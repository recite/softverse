# Main results Table 2

# Black
dt <- data_black
table2a <- data.frame(`Overall Evaluation` = table_m(dt$met_effective, dt$distance_garner, cluster=dt$borough),
                      `Police Fairness` = table_m(dt$fairness_score, dt$distance_garner, cluster=dt$borough),
                      `Community Engagement` = table_m(dt$engage_score, dt$distance_garner, cluster=dt$borough),
                      `Police Effectiveness` = table_m(dt$effectiveness_score, dt$distance_garner, cluster=dt$borough))
table2a

# White
dt <- data_white
table2b <- data.frame(`Overall Evaluation`= table_m(dt$met_effective, dt$distance_garner, cluster=dt$borough),
                      `Police Fairness` = table_m(dt$fairness_score, dt$distance_garner, cluster=dt$borough),
                      `Community Engagement` = table_m(dt$engage_score, dt$distance_garner, cluster=dt$borough),
                      `Police Effectiveness` = table_m(dt$effectiveness_score, dt$distance_garner, cluster=dt$borough))
table2b

# South Asian
dt <- data_asian
table2c <- data.frame(`Overall Evaluation` = table_m(dt$met_effective, dt$distance_garner, cluster=dt$borough),
                      `Police Fairness` = table_m(dt$fairness_score, dt$distance_garner, cluster=dt$borough),
                      `Community Engagement` = table_m(dt$engage_score, dt$distance_garner, cluster=dt$borough),
                      `Police Effectiveness` = table_m(dt$effectiveness_score, dt$distance_garner, cluster=dt$borough))
table2c
