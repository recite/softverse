setwd("~/Dropbox/Broockman-Kaufman-Lenz Roll Call Look Up and Heuristics Experiments/Replication/Studies 2-4/data/raw")
library(tidyverse)

read.csv("Issue+Publics+and+Heuristics+Early+2018_March+12%2C+2018_15.40.csv", stringsAsFactors = FALSE) %>%
  select(-c(1:22)) %>%
  select(-zip5, -zip4, -end_comments, -custom1) %>%
  write.csv('heuristics_early2018_data_pii_removed.csv', row.names = F)


