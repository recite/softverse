import csv
import states
import requests

from bs4 import BeautifulSoup


def request(method, params):
	params['key'] = 'x'
	r = requests.get('http://api.votesmart.org/' + method, params=params)
	#print r.url
	return BeautifulSoup(r.text, 'xml')


def hammer(s):
	if not isinstance(s, unicode):
		return s
	for enc in ("utf-8","utf-16", "utf-32"):
		try:
			return s.encode(enc, "replace") 
		except:
			pass
	return s


### CANDIDATES AND THEIR ATTRIBUTES
candidate_attributes = ['candidateId', 'firstName', 'lastName', 'officeParties', 'officeStatus',
		'officeDistrictId', 'officeDistrictName', 'officeStateId']
def extractCandDict(cand_soup):
	return {attribute: hammer(getattr(cand_soup, attribute).text) for attribute in candidate_attributes}

print request('Officials.getByOfficeState', {'officeId': 5, 'stateId': 'ID'})

## HOUSE MEMBERS
print 'House Members'
def getMCsForState(stateAbbrev):
	soup = request('Officials.getByOfficeState', {'officeId': 5, 'stateId': stateAbbrev})
	return [extractCandDict(candidate) for candidate in soup.find_all('candidate')]

with open('all_house_members.csv', 'w') as csv_file:
	writer = csv.DictWriter(csv_file, candidate_attributes, extrasaction='ignore')
	writer.writeheader()
	for state in states.states:
		print state[0]
		for candidate in getMCsForState(state[0]):
			try:
				writer.writerow(candidate)
			except:
				print 'Failed on candidate %s' % candidate['candidateId']

"""

## SENATORS
print 'Senators'
def getSenatorsForState(stateAbbrev):
	soup = request('Officials.getByOfficeState', {'officeId': 6, 'stateId': stateAbbrev})
	return [extractCandDict(candidate) for candidate in soup.find_all('candidate')]

with open('all_senators.csv', 'w') as csv_file:
	writer = csv.DictWriter(csv_file, candidate_attributes, extrasaction='ignore')
	writer.writeheader()
	for state in states.states:
		print state[0]
		for candidate in getSenatorsForState(state[0]):
			try:
				writer.writerow(candidate)
			except:
				print 'Failed on candidate %s' % candidate['candidateId']

"""



