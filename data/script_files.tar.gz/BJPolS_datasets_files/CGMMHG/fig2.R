# SET DIRECTORY TO SOURCE FILE 

library(plyr)
library(tidyverse)
library(readstata13)
library(ggplot2)

# Respondent Perception
data <- read.dta13('../../data/cleaned/study1_individual.dta')   

data$actual_group_ideology <- NA
data$actual_group_ideology[data$recipient_cfscore3 == -1] <- 'Liberal'
data$actual_group_ideology[data$recipient_cfscore3 == 0] <- 'Moderate'
data$actual_group_ideology[data$recipient_cfscore3 == 1] <- 'Conservative'
data$actual_group_ideology <- factor(paste0(data$actual_group_ideology, ' SIGs'), ordered = TRUE,
                                     levels = paste0(c('Liberal', 'Moderate', 'Conservative'), ' SIGs'))

data$r_ideology <- NA
data$r_ideology[data$libcon3 <= 3] <- 'Liberal'
data$r_ideology[data$libcon == 4] <- 'Moderate'
data$r_ideology[data$libcon >= 5] <- 'Conservative'
data$r_ideology <- factor(paste0(data$r_ideology, ' Respondents'), ordered = TRUE,
                          levels = paste0(c('Liberal', 'Moderate', 'Conservative'), ' Respondents'))

data$perceived_group_ideology <- NA
data$perceived_group_ideology[data$interest_knowledg3 == -1] <- 'Liberal'
data$perceived_group_ideology[data$interest_knowledg3 == 0] <- 'Moderate'
data$perceived_group_ideology[data$interest_knowledg3 == 1] <- 'Conservative'
data$perceived_group_ideology[is.na(data$interest_knowledg3)] <- 'DK'
data$perceived_group_ideology <- factor(data$perceived_group_ideology, ordered = TRUE,
                                        levels = c('Liberal', 'Moderate', 'Conservative', 'DK'))

# Where do people perceive SIGs?
g <- data %>% 
  filter(!is.na(r_ideology)) %>%
  group_by(r_ideology, perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('Blue', 'Purple', 'Red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'none') +
  theme(axis.text.x = element_text(size=8)) +
  xlab('Respondents Placed SIGs As...') + ylab('') + ggtitle('Perceptions of All SIGs') +
  facet_wrap(~r_ideology)
ggsave('../../figures/fig2a.pdf', g,
       width = 10, height = 4, units = 'in', scale = .8)


g.consgroups <- data %>% 
  filter(!is.na(r_ideology)) %>%
  filter(actual_group_ideology == 'Conservative SIGs') %>%
  group_by(r_ideology, perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('Blue', 'Purple', 'Red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'none') +
  theme(axis.text.x = element_text(size=8)) +
  xlab('Respondents Placed SIGs As...') + ylab('') + ggtitle('Perceptions of Conservative SIGs') +
  facet_wrap(~r_ideology)

g.libgroups <- data %>% 
  filter(!is.na(r_ideology)) %>%
  filter(actual_group_ideology == 'Liberal SIGs') %>%
  group_by(r_ideology, perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('Blue', 'Purple', 'Red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'bottom') +
  theme(axis.text.x = element_text(size=8)) +
  xlab('Respondents Placed SIGs As...') + ylab('') + ggtitle('Perceptions of Liberal SIGs') +
  facet_wrap(~r_ideology)

ggsave('../../figures/fig2b.pdf', g.consgroups,
       width = 10, height = 4, units = 'in', scale = .8)
ggsave('../../figures/fig2c.pdf', g.libgroups,
       width = 10, height = 4.5, units = 'in', scale = .8) # bigger because has legend

