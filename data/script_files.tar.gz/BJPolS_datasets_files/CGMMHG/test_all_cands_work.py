import csv
import ConstructAPIResponse

# Make sure all candidates work.
with open('processed_MCs_for_api.csv', 'rbU') as csvfile:
	r = csv.DictReader(csvfile, delimiter=',')
	for row in r:
		try:
			response = ConstructAPIResponse.tryBothSurveyAPIResponse(row['candidateid'])
			if response['issuepub_eligible'] != 'TRUE':
				print row['candidateid']
		except Exception as e:
			print 'Failed because %s on candidateid %s.' % (str(e), row['candidateid'])
