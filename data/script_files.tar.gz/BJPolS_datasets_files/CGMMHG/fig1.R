# SET DIRECTORY TO SOURCE FILE 

library(plyr)
library(dplyr)
library(tidyverse)
library(readstata13)
library(ggplot2)

# Actual SIG Ideology
data <- read.dta13('../../data/cleaned/study1between_aggregated.dta')   

data$cf <- NA
data$cf[data$recipient_cfscore3 == -1] <- 'Liberal'
data$cf[data$recipient_cfscore3 == 0] <- 'Moderate'
data$cf[data$recipient_cfscore3 == 1] <- 'Conservative'
data$cf <- factor(data$cf, ordered = TRUE, levels = c('Liberal', 'Moderate', 'Conservative'))

# Truth
g <- data %>%
  group_by(cf) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = cf, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = cf)) +
  scale_fill_manual('Actual SIG Ideology', values = c('blue', 'purple', 'red')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  xlab('SIG CFScore') + ggtitle('Actual Distribution of Interest Group Ideology') +
  theme_bw() + theme(legend.position = 'none') + ylab('')
ggsave('../../figures/fig1a.pdf', g, width = 5, height = 3.5, scale = 1.1)


# Respondent Perception in aggregate
data <- read.dta13('../../data/cleaned/study1_individual.dta')   

data$actual_group_ideology <- NA
data$actual_group_ideology[data$recipient_cfscore3 == -1] <- 'Liberal'
data$actual_group_ideology[data$recipient_cfscore3 == 0] <- 'Moderate'
data$actual_group_ideology[data$recipient_cfscore3 == 1] <- 'Conservative'
data$actual_group_ideology <- factor(paste0(data$actual_group_ideology, ' SIGs'), ordered = TRUE,
                                     levels = paste0(c('Liberal', 'Moderate', 'Conservative'), ' SIGs'))

data$r_ideology <- NA
data$r_ideology[data$libcon3 <= 3] <- 'Liberal'
data$r_ideology[data$libcon == 4] <- 'Moderate'
data$r_ideology[data$libcon >= 5] <- 'Conservative'
data$r_ideology <- factor(paste0(data$r_ideology, ' Respondents'), ordered = TRUE,
                          levels = paste0(c('Liberal', 'Moderate', 'Conservative'), ' Respondents'))

data$perceived_group_ideology <- NA
data$perceived_group_ideology[data$interest_knowledg3 == -1] <- 'Liberal'
data$perceived_group_ideology[data$interest_knowledg3 == 0] <- 'Moderate'
data$perceived_group_ideology[data$interest_knowledg3 == 1] <- 'Conservative'
data$perceived_group_ideology[is.na(data$interest_knowledg3)] <- 'Don\'t Know'
data$perceived_group_ideology <- factor(data$perceived_group_ideology, ordered = TRUE,
                                        levels = c('Liberal', 'Moderate', 'Conservative', 'Don\'t Know'))


# Perception of groups
g <- data %>% 
  filter(!is.na(r_ideology)) %>%
  group_by(perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('blue', 'purple', 'red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'bottom') +
  xlab('') + ylab('') + ggtitle('Respondent Perceptions of All SIGs')
ggsave('../../figures/fig1b.pdf', g,
       width = 5, height = 4, units = 'in', scale = 1.1)


g.consgroups <- data %>% 
  filter(!is.na(r_ideology)) %>%
  filter(actual_group_ideology == 'Conservative SIGs') %>%
  group_by(perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('blue', 'purple', 'red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'bottom') +
  xlab('') + ylab('') + ggtitle('Respondent Perceptions of Conservative SIGs')

g.libgroups <- data %>% 
  filter(!is.na(r_ideology)) %>%
  filter(actual_group_ideology == 'Liberal SIGs') %>%
  group_by(perceived_group_ideology) %>% 
  dplyr::summarise(count=n()) %>% 
  mutate(perc=count/sum(count)) %>%
  ggplot(aes(x = perceived_group_ideology, y = perc)) +
  geom_bar(stat = 'identity', aes(fill = perceived_group_ideology)) +
  scale_fill_manual('Placed SIG As', values = c('blue', 'purple', 'red', 'grey')) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw() + theme(legend.position = 'bottom') +
  xlab('') + ylab('') + ggtitle('Respondent Perceptions of Liberal SIGs')

ggsave('../../figures/fig1c.pdf', g.consgroups,
       width = 5, height = 4, units = 'in', scale = 1.1)
ggsave('../../figures/fig1d.pdf', g.libgroups,
       width = 5, height = 4, units = 'in', scale = 1.1)


